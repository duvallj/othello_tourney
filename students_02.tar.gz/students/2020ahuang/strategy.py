# Jan 12, 0952 version
#Austin Huang 2/9/2018
import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

REALSQUARES = [  # 10*x+y in (x,y) for x in range(1,9): for y in range(1,9)
]

WEIGHTEDMATRIX = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 240, -50,  30,  10,  10,  30, -50, 240,   0,
    0, -50, -150, -10,  -5,  -5, -10, -150, -50, 0,
    0,  30, -10,  20,   3,   3,  20, -10,  30,   0,
    0,  10,  -5,   3,  10,  10,   3,  -5,  10,   0,
    0,  10,  -5,   3,  10,  10,   3,  -5,  10,   0,
    0,  30, -10,  20,   3,   3,  20, -10,  30,   0,
    0, -50, -150, -10,  -5,  -5, -10, -150, -50, 0,
    0, 240, -50,  30,  10,  10,  30, -50, 240,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

VERT,HORI, DIA1, DIA2 = (N, S), (W, E), (NW, SE), (NE, SW)

TEST_DIR = [VERT, HORI, DIA1, DIA2]
#EDGES = {TOP: [x for x in range(12, 18)], RIGHT: [x for x in range(28, 88, 10)], LEFT: [x for x in range(21, 81, 10)], BOTTOM: [x for x in range(82,88)]}

SEEN_BOARDS = {}
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, board, move, score=0):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self, other):
        return self.score < other.score

class Strategy():
    def __init__(self):
        pass

    def fatscore(self, board, player):
        PLAYER = {'o': -1, '@' : 1, '?' : 0, '.' : 0 }
        if (board, player) in SEEN_BOARDS:
            return SEEN_BOARDS[(board, player)]
        else:
            fat = sum([PLAYER[board[i]] * WEIGHTEDMATRIX[i] for i in range(11,89)])
            (stable, frontier, move) = self.analyze_board(board)
            if move <= 16:
                df = self.relative_freedom(board)
                fat += 6*df + 0.6*frontier
            elif move <= 32:
                df = self.relative_freedom(board)
                fat += 7 * df + 0.4 * frontier
            elif move <= 48:
                df = self.relative_freedom(board)
                fat += 6*df + 0.2*frontier
            fat += stable * (10)
            SEEN_BOARDS[(board, player)] = fat
            return fat

    def analyze_board(self, board):
        stable, move, frontier = 0, 0, 0
        for x in range(11, 89):
            if board[x] == BLACK:
                move += 1
                for d in DIRECTIONS:
                    if board[x + d] == EMPTY:
                        frontier -= 1
                        break
                stable += self.calculate_stability(x, board)
            elif board[x] == WHITE:
                move += 1
                for d in DIRECTIONS:
                    if board[x + d] == EMPTY:
                        frontier += 1
                        break
                stable -= self.calculate_stability(x, board)
        return (stable, frontier ,move)

    def calculate_stability(self,square, board):
        stability = 1
        player = board[square]
        for x in TEST_DIR:
            to_check0 = square + x[0]
            while(board[to_check0] == player):
                to_check0 += x[0]
            if board[to_check0] == OUTER:
                continue
            else:
                to_check1 = square + x[1]
                while(board[to_check1] == player):
                    to_check1 += x[1]
                if board[to_check1] == OUTER or (board[to_check1] == self.opponent(player) and board[to_check0] == self.opponent(player)):
                    continue
                elif board[to_check1] == EMPTY and board[to_check0] == EMPTY:
                    stability = 0
                else:
                    return -1
        return stability

    def relative_freedom(self, board):
        return len(self.get_valid_moves(board, BLACK)) - len(self.get_valid_moves(board, WHITE))

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = ""
        for x in range(0,100):
            if x < 10 or x > 90 or x % 10 == 0 or x % 10 == 9:
                board += OUTER
            elif x == 44 or x == 55:
                board += WHITE
            elif x == 54 or x == 45:
                board += BLACK
            else:
                board += EMPTY
        return board

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        string = "  12345678\n"
        for x in range(1, 9):
            string += (str(x) + " ")
            for y in range(1, 9):
                string += board[10 * x + y]
            string += "\n"
        return string

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        else:
            return BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        examine = square + direction
        if board[examine] != self.opponent(player):
            return None
        else:
            while board[examine] == self.opponent(player):
                examine = examine + direction
            if board[examine] == OUTER or board[examine] == EMPTY:
                return None
            else:
                return examine

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] is EMPTY:
            for direction in DIRECTIONS:
                if self.find_match(board, player, move, direction) != None:
                    return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        new_board = board
        for dir in DIRECTIONS:
            result = self.find_match(board, player, move, dir)
            if result is not None:
                for x in range(move, result, dir):
                    new_board = str(new_board[0:x]) + str(player) + str(new_board[x + 1:])
        return new_board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        return [x for x in range(11, 89) if self.is_move_valid(board, player, x)]

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if len(self.get_valid_moves(board, player)) == 0:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        score = 0
        for x in range(11, 89):
            if board[x] == BLACK or board[x] == WHITE:
                if board[x] == player:
                    score += 1
                else:
                    score -= 1
        return score

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.next_player(board, player) == None:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0: #score node and return it
            node.score = self.fatscore(board, player) #dummy hueristic
            return node
        my_moves = self.get_valid_moves(board, player)
        children = list()
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None: #aka game ends
                c = Node(next_board, move, 10000*self.score(next_board))
                children.append(c)
            else: #game is still going
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth - 1).score
                children.append(c)
        winner = (best[player](children))
        return winner

    def alphabeta_search(self, node, player, depth, alpha, beta):
        best = {BLACK: max, WHITE: min}
        x_board = node.board
        if depth == 0: #score node and return it
            node.score = self.fatscore(x_board, player)
            return node
        my_moves = self.get_valid_moves(x_board, player)
        children = list()
        for move in my_moves:
            next_board = self.make_move(x_board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None: #aka game ends
                c = Node(next_board, move, 100000*self.score(next_board))
                children.append(c)
            else: #game is still going
                c = Node(next_board, move)
                c.score = self.alphabeta_search(c, next_player, depth - 1, alpha, beta).score
                children.append(c)
            if player == BLACK:
                alpha = max(alpha, c.score)
            if player == WHITE:
                beta = min(beta, c.score)
            if alpha >= beta:
                #print("Pruned!")
                break
        winner = (best[player](children))
        return winner

    def alphabeta_strategy(self, board, player, depth = 5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node = Node(board, None)
        return self.alphabeta_search(node, player, depth, -1000000, 1000000).move

    def minmax_strategy(self, board, player, depth = 5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node = Node(board, None)
        return self.minmax_search(node, player, depth).move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        board = "".join(board)
        while (True):
            ## doing random in a loop is pointless but it's just an example
            #best_move.value = self.alphabeta_strategy(board, player, depth)
            best_move.value = self.alphabeta_strategy(board, player, depth)
            print("depth reached:" + str(depth))
            if depth<3:
                depth += 2
            else:
                depth+= 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            #if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    game =  ParallelPlayer()
    #game = StandardPlayer()
    game.play()
