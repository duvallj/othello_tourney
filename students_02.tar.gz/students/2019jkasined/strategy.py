import sys
import random
import math

def printBoard(arr):
	for x in range(64):
		if x%8==7:
			print(arr[x]+"\n")
		else:
			print (arr[x]+" ",end="")

def legalMoves(board,token):
	pzl=board
	turn=token
	if turn=="x":
		opp="o"
	else:
		opp="x"
	ansList=[]

	for i in range(64):
		if(pzl[i]=="."):
			pos=False
			counter=0
			curPos=i-8
			while curPos>=0 and curPos<64:
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos-8

			counter=0
			curPos=i+8
			while curPos>=0 and curPos<64:
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos+8

			counter=0
			curPos=i-9
			while curPos>=0 and curPos<64:
				if(int(curPos/8)+1 != int((curPos+9)/8)):
					break
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos-9

			counter=0
			curPos=i+9
			while curPos>=0 and curPos<64:
				if(int(curPos/8)-1 != int((curPos-9)/8)):
					break
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos+9

			counter=0
			curPos=i-7
			while curPos>=0 and curPos<64:
				if(int(curPos/8)+1 != int((curPos+7)/8)):
					break
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos-7

			counter=0
			curPos=i+7
			while curPos>=0 and curPos<64:
				if(int(curPos/8)-1 != int((curPos-7)/8)):
					break
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos+7

			counter=0
			curPos=i-1
			while curPos>=0 and curPos<64:
				if(int(curPos/8) != int((curPos+1)/8)):
					break
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos-1

			counter=0
			curPos=i+1
			while curPos>=0 and curPos<64:
				if(int(curPos/8) != int((curPos-1)/8)):
					break
				if pzl[curPos]==".":
					break
				if pzl[curPos]==opp:
					counter+=1
				if pzl[curPos]==turn and counter>0:
					pos=True
					break
				elif pzl[curPos]==turn:
					break
				curPos=curPos+1

			if pos==True:
				ansList.append(i)
	return ansList

def inserz(pzl, ind, char):
	return pzl[0:ind]+ char + pzl[ind+1:]

def modifyBoard(lst,bord,piece):
	for i in lst:
		bord=inserz(bord,i,piece)
	return bord

def makeMove(board,turn,posi):
	pzl=board
	if turn=="x":
		opp="o"
	else:
		opp="x"
	i=posi
	pos=False
	if(pzl[i]=="."):
		counter=0
		curPos=i-8
		arrOfC=[]
		while curPos>=0 and curPos<64:
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos-8

		arrOfC=[]
		counter=0
		curPos=i+8
		while curPos>=0 and curPos<64:
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos+8

		arrOfC=[]
		counter=0
		curPos=i-9
		while curPos>=0 and curPos<64:
			if(int(curPos/8)+1 != int((curPos+9)/8)):
				break
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos-9

		arrOfC=[]
		counter=0
		curPos=i+9
		while curPos>=0 and curPos<64:
			if(int(curPos/8)-1 != int((curPos-9)/8)):
				break
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos+9

		arrOfC=[]
		counter=0
		curPos=i-7
		while curPos>=0 and curPos<64:
			if(int(curPos/8)+1 != int((curPos+7)/8)):
				break
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos-7

		arrOfC=[]
		counter=0
		curPos=i+7
		while curPos>=0 and curPos<64:
			if(int(curPos/8)-1 != int((curPos-7)/8)):
				break
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos+7

		arrOfC=[]
		counter=0
		curPos=i-1
		while curPos>=0 and curPos<64:
			if(int(curPos/8) != int((curPos+1)/8)):
				break
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos-1

		arrOfC=[]
		counter=0
		curPos=i+1
		while curPos>=0 and curPos<64:
			if(int(curPos/8) != int((curPos-1)/8)):
				break
			if pzl[curPos]==".":
				break
			if pzl[curPos]==opp:
				counter+=1
				arrOfC.append(curPos)
			if pzl[curPos]==turn and counter>0:
				pos=True
				pzl=modifyBoard(arrOfC,pzl,turn)
				pzl=inserz(pzl,i,turn)
				break
			elif pzl[curPos]==turn:
				break
			curPos=curPos+1
	return pzl

def evalboard(board,token):
	if token=="x":
		enemy="o"
	else:
		enemy="x"
	ans=0
	for i in board:
		if i==token:
			ans=ans+1
		elif i==enemy:
			ans=ans-1
	return ans

def dotCount(pzl):
	counter=0
	for i in pzl:
		if i==".":
			counter+=1
	return counter

def negamax(board,token):
	if token=="x":
		enemy="o"
	else:
		enemy="x"
	if len(legalMoves(board,token))==0 and len(legalMoves(board,enemy))==0:  return [evalboard(board,token)]
	lm=legalMoves(board,token)
	if  not lm:
		nm=negamax(board,enemy)+[-1]
		return [-nm[0]]+nm[1:]
	nmList=sorted([negamax(makeMove(board,token,mv),enemy)+[mv] for mv in lm])
	best=nmList[0]
	return [-best[0]] +best[1:]

def negamaxTerminal(brd,token,improvable,hardBound):
	if token=="x":
		enemy="o"
	else:
		enemy="x"
	lm=legalMoves(brd,token)
	if not lm:
		lm=legalMoves(brd,enemy)
		if not lm: return [evalboard(brd,token),-3]
		nm=negamaxTerminal(brd,enemy,-hardBound,-improvable)+ [-1]
		return [-nm[0]]+nm[1:]
	best=[]
	newHB=-improvable
	for mv in lm:
		nm=negamaxTerminal(makeMove(brd,token,mv),enemy,-hardBound,newHB)+[mv]
		if not best or nm[0]<newHB:
			best=nm
			if nm[0]<newHB:
				newHB=nm[0]
				if -newHB>hardBound: return [-best[0]]+best[1:]
	return [-best[0]] + best[1:]

def cmdMain():
	inp=sys.argv
	startBoard="...........................ox......xo..........................."
	for i in range(1,len(inp)):
		inp[i]=inp[i].lower()
	if len(inp)==3:
		pzl=inp[1]
		turn=inp[2]
	elif len(inp)==2:
		pzl=inp[1]
		count=0
		for i in pzl:
			if i=="x" or i=="o":
				count=count+1
		if count%2==0:
			turn="x"
		else:
			turn="o"
	else:
		pzl=startBoard
		turn="x"

	if(turn=="x"):
		opp="o"
	else:
		opp="x"

	ansList=legalMoves(pzl,turn)	
	printBoard(pzl)
	print("legal moves: " + str(ansList))
	if(dotCount(pzl)<=11):
		#nm=negamax(pzl,turn)
		nm=negamaxTerminal(pzl,turn,-math.inf,math.inf)
		print("my heuristic move is: "+ str(nm[-1]))
		print("negamaxTerminal "+ str(nm[0]) +str(nm[1:len(nm)-1:-1])+ " "+ " and my move is "+str(nm[-1]))
	else:
		printBoard(pzl)
		corners=[0,7,56,63]
		lines=[[0,1,2,3,4,5,6,7],[0,8,16,24,32,40,48,56],[56,57,58,59,60,61,62,63],[7,15,23,31,39,47,55,63]]
		cStones=[[0,1,8,9],[7,6,14,15],[56,48,49,57],[63,54,55,62]]
		nonEdge=[9,14,49,54]
		roundOne=[]
		roundTwo=[]
		for m in ansList:
			if m in corners:
				roundOne.append(m)
		if len(roundOne)!=0:
			print(random.choice(roundOne))	
		else:
			for m in ansList:
				for l in lines:
					for ind in range(8):
						if m == l[ind]:
							pzlTemp=makeMove(pzl,turn,m)
							firPart=l[:ind+1]
							secPart=l[ind:]
							firPart=[pzlTemp[x] for x in firPart]
							secPart=[pzlTemp[x] for x in secPart]
							
							if(firPart.count(turn)==len(firPart) or secPart.count(turn)==len(secPart)):
								roundTwo.append(m)					

			if len(roundTwo)!=0:
				print(random.choice(roundTwo))
					
			else:
				inCase3=[]
				for m in ansList:
					for c in cStones:
						if m in c:
							if pzl[m]!=pzl[c[0]]:
								inCase3.append(m)
								ansList.remove(m)
				if len(ansList)==0:
					print(random.choice(inCase3))
					
				else:
					inCase4=[]
					for m in ansList:
						for l in lines:
							if m in l:
								inCase4.append(m)
								ansList.remove(m)
					
					if len(ansList)!=0:
						print(random.choice(ansList))

					else:
						print(random.choice(inCase4))


if __name__=="__main__":
	cmdMain()

def findBestMove(brd,token):
	pzl=brd
	turn=token
	if(turn=="x"):
		opp="o"
	else:
		opp="x"
	ansList=legalMoves(pzl,turn)	
	if(dotCount(pzl)<=11):
		#nm=negamax(pzl,turn)
		nm=negamaxTerminal(pzl,turn,-math.inf,math.inf)
		return nm[-1]
	else:
		corners=[0,7,56,63]
		lines=[[0,1,2,3,4,5,6,7],[0,8,16,24,32,40,48,56],[56,57,58,59,60,61,62,63],[7,15,23,31,39,47,55,63]]
		cStones=[[0,1,8,9],[7,6,14,15],[56,48,49,57],[63,54,55,62]]
		nonEdge=[9,14,49,54]
		roundOne=[]
		roundTwo=[]
		for m in ansList:
			if m in corners:
				roundOne.append(m)
		if len(roundOne)!=0:
			return random.choice(roundOne)
		else:
			for m in ansList:
				for l in lines:
					for ind in range(8):
						if m == l[ind]:
							pzlTemp=makeMove(pzl,turn,m)
							firPart=l[:ind+1]
							secPart=l[ind:]
							firPart=[pzlTemp[x] for x in firPart]
							secPart=[pzlTemp[x] for x in secPart]
							
							if(firPart.count(turn)==len(firPart) or secPart.count(turn)==len(secPart)):
								roundTwo.append(m)					

			if len(roundTwo)!=0:
				return random.choice(roundTwo)
					
			else:
				inCase3=[]
				for m in ansList:
					for c in cStones:
						if m in c:
							if pzl[m]!=pzl[c[0]]:
								inCase3.append(m)
								ansList.remove(m)
				if len(ansList)==0:
					return random.choice(inCase3)
					
				else:
					inCase4=[]
					for m in ansList:
						for l in lines:
							if m in l:
								inCase4.append(m)
								ansList.remove(m)
					
					if len(ansList)!=0:
						return random.choice(ansList)

					else:
						return random.choice(inCase4)


class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		brd=''.join(board).replace('?',"").replace('@','x')
		token='x' if player=='@' else 'o'
		mv=findBestMove(brd,token)
		mv1=11+(mv//8)*10+(mv%8)
		best_move.value=mv1