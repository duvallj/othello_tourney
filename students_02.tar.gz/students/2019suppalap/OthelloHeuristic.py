import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = [N, NE, E, SE, S, SW, W, NW]
PLAYERS = {BLACK: "Black", WHITE: "White"}


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node:
    def __init__(self, state, last_move,score=0):
        self.last_move = last_move
        self.state = state
        self.score = score

    def __lt__(self, other):
        return self.score < other.score
    # a class that holds board, player, move, score info for minmax tree
class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    # def get_pretty_board(self, board):
    #     prettyBoard = ''.join(board)
    #     prettyBoard = prettyBoard.replace("?"," ")
    #     #print("PB",prettyBoard)
    #     self.display(prettyBoard)
    #
        #"""Get a string representation of the board."""

    def opponent(self, player):
        if player == BLACK:
            return WHITE
        return BLACK

    def find_match(self, board, player, square, direction):
        """

        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        position = square +direction
        if board[position] != self.opponent(player):
            return None
        while(board[position] == self.opponent(player)):
            position = position + direction
        if board[position] == player:
            return square
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move]!= EMPTY:
            return False
        for dir in DIRECTIONS:
            retFind = self.find_match(board,player,move,dir)
            if retFind is not None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        boardList = list(board)
        boardList[move] = player
        for dir in DIRECTIONS:
            match = self.find_match(board,player,move,dir)
            if match is not None:
                position = move + dir
                if player == BLACK:
                    while (boardList[position] == WHITE):
                        boardList[position] = BLACK
                        position = position + dir
                if player == WHITE:
                    while (boardList[position] == BLACK):
                        boardList[position] = WHITE
                        position = position + dir
        return boardList

        # turn it into a list to make the move

    def get_valid_moves(self, board, player):
        validList = []
        """Get a list of all legal moves for player."""
        for i in range(11,89):
            if board[i] == EMPTY and self.is_move_valid(board,player,i):
                #for dir in DIRECTIONS:
                    #print("dir",dir)
                    #print("i",i)
                    #matchSquare = self.find_match(board,player,i,dir)
                    #if matchSquare is not None:
                validList.append(i)
                        #break
                    #if matchSquare is not None and matchSquare not in validList:

        return validList

        #pass

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        validMoves = self.get_valid_moves(board, player)
        #print("valid moves",validMoves)
        listLen = len(validMoves)
        #print("listLen",listLen)
        if listLen ==0:
            return False
        return True

        #pass
    def get_pretty_board(self,board):
        global state

        prettyBoard = board
        prettyBoard = ''.join(prettyBoard)
        prettyBoard = prettyBoard.replace("?"," ")
        s = list(board)
        top = "┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐"
        middle = "├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤"
        interior = "│ %s │ %s │ %s │ %s │ %s │ %s │ %s │ %s │ %s │ %s │"
        bottom = "└───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘"
        print(top)
        print(interior % (s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8],s[9]))
        print(middle)
        print(interior % (s[10], s[11], s[12], s[13], s[14], s[15], s[16], s[17],s[18],s[19]))
        print(middle)
        print(interior % (s[20], s[21], s[22], s[23], s[24], s[25], s[26],s[27], s[28], s[29]))
        print(middle)
        print(interior % (s[30], s[31], s[32], s[33], s[34], s[35],s[36], s[37], s[38], s[39]))
        print(middle)
        print(interior % (s[40], s[41], s[42], s[43], s[44],s[45], s[46], s[47], s[48], s[49]))
        print(middle)
        print(interior % (s[50], s[51], s[52], s[53], s[54], s[55], s[56], s[57], s[58], s[59]))
        print(middle)
        print(interior % (s[60], s[61], s[62],s[63], s[64], s[65], s[66], s[67], s[68], s[69]))
        print(middle)
        print(interior % (s[70], s[71],s[72], s[73], s[74], s[75], s[76], s[77], s[78], s[79]))
        print(middle)
        print(interior % (s[80],s[81],s[82], s[83], s[84], s[85], s[86], s[87], s[88], s[89]))
        print(middle)
        print(interior % (s[90], s[91], s[92], s[93], s[94], s[95], s[96], s[97], s[98], s[99]))
        print(bottom)
        return " "
    def next_player(self, board, prev_player):
        #print("entered")
        #print("prev_player",prev_player)
        if self.game_over(board,prev_player):
            #print("none, game over")
            return None
        # if prev_player == BLACK and self.has_any_valid_moves(board,WHITE):
        #     #print("next player", WHITE)
        #     return WHITE
        # if prev_player == WHITE and self.has_any_valid_moves(board,BLACK):
        #     #print("next player", BLACK)
        #     return BLACK
        # if prev_player ==BLACK and self.has_any_valid_moves(board,BLACK):
        #     return BLACK
        # if prev_player ==WHITE and self.has_any_valid_moves(board,WHITE):
        #     return WHITE
        opponent = self.opponent(prev_player)
        if self.has_any_valid_moves(board,opponent):
            return opponent
        if self.has_any_valid_moves(board,prev_player):
            return prev_player
        return None
        """Which player should move next?  Returns None if no legal moves exist."""
        #pass
    def weighted_score(self,board,player=BLACK):
        SCORE =[
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, -20, 20, 5, 5, 20, -20, 120, 0, 0, -20, -40, -5, -5, -5, -5, -40, -20,
            0, 0, 20, -5, 15, 3, 3, 15, -5, 20, 0, 0, 5, -5, 3, 3, 3, 3, -5, 5, 0, 0, 5, -5, 3, 3, 3, 3, -5, 5, 0, 0,
            20, -5, 15, 3, 3, 15, -5, 20, 0, 0, -20, -40, -5, -5, -5, -5, -40, -20, 0, 0, 120, -20, 20, 5, 5, 20, -20,
            120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        blackPiece = 0
        whitePiece = 0
        # self.display(board)
        for square in range(11,89):
        #for square in board:
            if board[square] == BLACK:
                blackPiece += SCORE[square]
            if board[square] == WHITE:
                whitePiece += SCORE[square]
        # print("black",blackPiece)
        # print("white",whitePiece)
        # if player == BLACK:
        score = blackPiece - whitePiece
        # if player == WHITE:
        #     score = whitePiece - blackPiece
        # print("score",score)
        return score

    def heuristic(self,board,player=BLACK):
        blackPiece = 0
        whitePiece = 0
        # self.display(board)
        for square in board:
            if square == BLACK:
                blackPiece += 1
            if square == WHITE:
                whitePiece += 1
        if blackPiece > whitePiece:
            p = 100*(blackPiece/(blackPiece+whitePiece))
        else:
            p = -100 * (whitePiece / (blackPiece + whitePiece))
        corners = [11,18,81,88]
        B=0
        W=0
        if board[11] == BLACK:
            B=B+1
        if board[11] == WHITE:
            W=W+1
        if board[18] == BLACK:
            B=B+1
        if board[18] == WHITE:
            W=W+1
        if board[81] == BLACK:
            B=B+1
        if board[81] == WHITE:
            W=W+1
        if board[88] == BLACK:
            B=B+1
        if board[88] == WHITE:
            W=W+1
        c = 25*B-25*W
        blackAdj=0
        whiteAdj = 0
        for adjacent in [12,17,21,28,87,82,78,71]:
            if adjacent == BLACK:
                blackAdj = blackAdj +1
            if adjacent == WHITE:
                whiteAdj = whiteAdj+1
        l = -12.5*blackAdj +12.5*whiteAdj
        score = (10 * p) + (801.724 * c) + (382.026 * l)
        return score



    def score(self, board, player=BLACK):
        #print("entered score")
        #boardList = list(board)
        blackPiece = 0
        whitePiece = 0
        #self.display(board)
        for square in board:
            if square == BLACK:
                blackPiece +=1
            if square == WHITE:
                whitePiece +=1
        #print("black",blackPiece)
        #print("white",whitePiece)
        # if player == BLACK:
        score = blackPiece - whitePiece
        # if player == WHITE:
        #     score = whitePiece - blackPiece
        #print("score",score)
        return score
        """Compute player's score (number of player's pieces minus opponent's)."""
        #pass

    def game_over(self, board, player):
       # print("entered game_over")
        """Return true if player and opponent have no valid moves"""
        whitePlayer = self.has_any_valid_moves(board,WHITE)
        #print("whitePlayer",whitePlayer)
        blackPlayer = self.has_any_valid_moves(board,BLACK)
        #print("blackPlayer",blackPlayer)
        if whitePlayer is False and blackPlayer is False:
            #print("game over!!!!")
            return True
        #print("game not over!!!")
        return False
        #pass

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        best = {BLACK: max, WHITE: min}
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board = node.state
        if depth == 0:
            node.score = self.heuristic(board, player)
            return node
        children = []
        my_moves = self.get_valid_moves(board, player)
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)  # look at next_board and determine whose move it willbe
            if next_player is None:
                c = Node(''.join(next_board), move, score = 1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(''.join(next_board), move)
                c.score = self.minmax_search(c, next_player, depth=depth - 1).score
                children.append(c)
        winner = best[player](children)
        node.score = winner.score
        return winner


    def minmax_strategy(self, board, player, depth=3):
        best = {BLACK: max, WHITE: min}
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        board2 = Node(board, None)
        return self.minmax_search(board2, player,depth).last_move
    def alphabeta(self,node,player,depth,alpha,beta):
        best = {BLACK: max, WHITE: min}
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board = node.state
        if depth == 0:
            node.score = self.weighted_score(board, player)
            return node
        children = []
        my_moves = self.get_valid_moves(board, player)
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)  # look at next_board and determine whose move it willbe
            if next_player is None:
                c = Node(''.join(next_board), move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(''.join(next_board), move)
                c.score = self.alphabeta(c, next_player, depth - 1,alpha,beta).score
                children.append(c)
            if player == BLACK:
                alpha = max(alpha,c.score)
            if player == WHITE:
                beta = min(beta,c.score)
            if alpha >= beta:
                break
        winner = best[player](children)
        node.score = winner.score
        return winner
    def alphabeta_strategy(self,board,player,depth = 5):
        board2 = Node(board,None)
        return  self.alphabeta(board2,player,depth,-100000000,10000000).last_move
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board2 = Node(board, None)
        depth = 3
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta(board2, player, depth, -100000000, 10000000).last_move
            depth += 1

        # board2 = Node(board, None)
        # best_move.value = self.alphabeta(board2, player, 5, -100000000, 10000000).last_move

    standard_strategy = best_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.random_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            print("BLACK")
        elif black_score < 0:
            print("WHITE")
        else:
            print("TIE")

        return board, ref.score(board, BLACK)  # ,winner

cases = (
    ('???????????........??........??........??...o@...??...@o...??........??........??........???????????', '@',
     [34, 43, 56, 65]),
    ('???????????........??........??........??...o@...??...@@@..??........??........??........???????????', 'o',
     [46, 64, 66]),
    ('???????????........??........??........??...ooo..??...@@@..??........??........??........???????????', '@',
     [33, 34, 35, 36, 37]),
    ('???????????........??........??..@.....??...@oo..??...@@@..??........??........??........???????????', 'o',
     [43, 63, 64, 65, 66, 67]),
    ('???????????........??........??..@.....??...@oo..??...@o@..??....o...??........??........???????????', '@',
     [34, 36, 47, 66, 74, 76]),
    ('???????????........??........??..@.....??...@oo..??...@@@..??....o@..??........??........???????????', 'o',
     [43, 47, 63, 64, 67, 76]),
    ('???????????........??........??..@.....??...@oo..??...@@o..??....ooo.??........??........???????????', '@',
     [35, 36, 37, 47, 57, 75, 76, 77]),
    ('???????????........??........??..@...@.??...@o@..??...@@o..??....ooo.??........??........???????????', 'o',
     [22, 36, 43, 47, 53, 63]),
    ('???????????........??........??..@...@.??..ooo@..??...o@o..??....ooo.??........??........???????????', '@',
     [35, 42, 53, 57, 75, 76, 77]),
    ('???????????........??........??..@...@.??..ooo@..??...o@@..??....o@o.??.....@..??........???????????', 'o',
     [22, 23, 47, 57, 77, 85, 87]),
    ('???????????........??........??..@...@.??..ooo@..??...o@@..??....o@o.??.....o..??....o...???????????', '@',
     [34, 35, 42, 53, 64, 68, 74, 75, 78, 86]),
    ('???????????........??........??..@...@.??..ooo@..??...o@@..??....o@@@??.....o..??....o...???????????', 'o',
     [22, 23, 36, 47, 57, 58, 77, 78]),
    ('???????????........??........??..@...@.??..ooo@..??...o@o..??....o@o@??.....o.o??....o...???????????', '@',
     [35, 42, 53, 57, 64, 75, 86, 88]),
    ('???????????........??........??..@...@.??..ooo@..??...o@o..??....o@o@??.....o.@??....o..@???????????', 'o',
     [22, 23, 36, 47, 77]),
    ('???????????........??..o.....??..o...@.??..ooo@..??...o@o..??....o@o@??.....o.@??....o..@???????????', '@',
     [22, 34, 35, 42, 53, 57, 64, 75, 86]),
    ('???????????........??..o.....??..o...@.??..ooo@..??...o@o..??....@@o@??....@o.@??....o..@???????????', 'o',
     [36, 47, 64, 74, 77]),
    ('???????????........??..o.....??..o...@.??..ooo@..??...o@o..??...oooo@??....@o.@??....o..@???????????', '@',
     [22, 34, 35, 42, 53, 57, 63, 73, 77, 86]),
    ('???????????........??..o.....??..o...@.??.@@@@@..??...o@o..??...oooo@??....@o.@??....o..@???????????', 'o',
     [28, 32, 34, 35, 36, 51, 53, 74, 84, 86]),
    ('???????????........??..o.....??..o...@.??.@@@@@..??...o@o..??...oooo@??...ooo.@??....o..@???????????', '@',
     [13, 22, 24, 53, 57, 63, 73, 77, 84, 86, 87]),
    ('???????????........??..o.....??..o...@.??.@@@@@..??...o@o..??...oo@o@??...ooo@@??....o..@???????????', 'o',
     [28, 32, 34, 35, 36, 51, 53, 57, 87]),
    ('???????????........??..o.....??..o...@.??.@@@@@..??...o@oo.??...oooo@??...ooo@@??....o..@???????????', '@',
     [13, 22, 24, 47, 53, 58, 63, 73, 84, 86, 87]),
    ('???????????........??..o.....??..o...@.??.@@@@@..??..@@@oo.??...oooo@??...ooo@@??....o..@???????????', 'o',
     [28, 31, 32, 34, 35, 36, 51, 52, 63, 87]),
    ('???????????........??..o.....??..oo..@.??.@@oo@..??..@o@oo.??...oooo@??...ooo@@??....o..@???????????', '@',
     [12, 13, 22, 24, 25, 35, 47, 58, 63, 73, 86, 87]),
    ('???????????........??..o.....??..oo@.@.??.@@@@@..??..@o@oo.??...oooo@??...ooo@@??....o..@???????????', 'o',
     [24, 25, 28, 31, 32, 36, 51, 52, 63, 87]),
    ('???????????........??..oo....??..ooo.@.??.@@@@o..??..@o@oo.??...oooo@??...ooo@@??....o..@???????????', '@',
     [12, 13, 14, 15, 22, 25, 26, 47, 58, 63, 73, 84, 86, 87]),
    ('???????????........??..oo....??..ooo.@.??.@@@@o..??..@o@@@@??...oooo@??...ooo@@??....o..@???????????', 'o',
     [28, 31, 32, 36, 41, 47, 48, 51, 52, 62, 63, 87]),
    ('???????????........??..oo....??..ooo.@.??.@@@@o.o??..@o@@o@??...oooo@??...ooo@@??....o..@???????????', '@',
     [12, 13, 14, 15, 22, 25, 26, 36, 38, 47, 63, 73, 83, 84, 86, 87]),
    ('???????????........??..oo....??..ooo.@.??.@@@@o.o??..@@@@o@??...o@oo@??...oo@@@??....o.@@???????????', 'o',
     [26, 28, 31, 41, 47, 51, 52, 62, 63, 86]),
    ('???????????........??..oo....??..ooo.@.??.@@o@o.o??..o@@@o@??.o.o@oo@??...oo@@@??....o.@@???????????', '@',
     [12, 13, 14, 15, 22, 25, 36, 38, 47, 52, 63, 73, 83, 84, 86]),
    ('???????????........??..oo....??..ooo.@.??.@@o@o.o??..@@@@o@??.o@@@oo@??...oo@@@??....o.@@???????????', 'o',
     [26, 28, 31, 41, 47, 51, 52, 73, 86]),
    ('???????????........??..oo....??..ooo.@.??.o@o@o.o??o.@@@@o@??.o@@@oo@??...oo@@@??....o.@@???????????', '@',
     [12, 13, 14, 22, 25, 26, 31, 36, 38, 41, 47, 61, 71, 73, 83, 84, 86]),
    ('???????????...@....??..o@....??..o@o.@.??.o@@@o.o??o.@@@@o@??.o@@@oo@??...oo@@@??....o.@@???????????', 'o',
     [13, 15, 25, 26, 28, 47, 52, 73, 86]),
    ('???????????...@....??..o@...o??..o@o.o.??.o@@@o.o??o.@@@@o@??.o@@@oo@??...oo@@@??....o.@@???????????', '@',
     [12, 13, 22, 25, 26, 31, 32, 36, 38, 41, 47, 61, 71, 73, 83, 84, 86]),
    ('???????????...@....??..o@...o??@.o@o.o.??.@@@@o.o??o.@@@@o@??.o@@@oo@??...oo@@@??....o.@@???????????', 'o',
     [13, 15, 25, 41, 47, 52, 73, 86]),
    ('???????????...@....??..o@...o??@.o@o.o.??.@o@@o.o??o.o@o@o@??.ooo@oo@??..ooo@@@??....o.@@???????????', '@',
     [12, 22, 25, 26, 32, 36, 38, 47, 52, 61, 71, 72, 83, 84, 86]),
    ('???????????...@....??..o@.@.o??@.o@@.o.??.@o@@o.o??o.o@o@o@??.ooo@oo@??..ooo@@@??....o.@@???????????', 'o',
     [13, 15, 17, 25, 36, 41, 47, 86]),
    ('???????????..o@....??..oo.@.o??@.o@o.o.??.@o@@o.o??o.o@o@o@??.ooo@oo@??..ooo@@@??....o.@@???????????', '@',
     [12, 15, 22, 25, 32, 36, 38, 47, 52, 61, 71, 72, 83, 84, 86]),
    ('???????????..o@....??..oo.@.o??@.o@o.o.??.@o@@o.o??o.o@o@o@??.o@o@oo@??.@@@@@@@??....o.@@???????????', 'o',
     [15, 17, 25, 41, 52, 82, 83, 84, 86]),
    ('???????????..o@....??..oo.@.o??@.o@o.o.??.@o@@o.o??o.o@o@o@??.o@o@oo@??.@@@oo@@??....oo@@???????????', '@',
     [12, 15, 22, 25, 32, 36, 38, 47, 52, 61, 71, 84]),
    ('???????????..o@....??..oo.@.o??@.o@o.o.??.@o@@@@o??o.o@o@@@??.o@o@o@@??.@@@oo@@??....oo@@???????????', 'o',
     [15, 17, 25, 36, 41, 52, 71, 82, 83, 84]),
    ('???????????..o@....??..ooo@.o??@.ooo.o.??.@o@@@@o??o.o@o@@@??.o@o@o@@??.@@@oo@@??....oo@@???????????', '@',
     [12, 15, 22, 27, 32, 36, 38, 52, 61, 71, 84]),
    ('???????????.@@@....??..@oo@.o??@.o@o.o.??.@o@@@@o??o.o@o@@@??.o@o@o@@??.@@@oo@@??....oo@@???????????', 'o',
     [15, 17, 22, 27, 36, 41, 52, 71, 82, 83, 84]),
    ('???????????.@@@....??..@oo@.o??@.o@ooo.??.@o@@o@o??o.o@oo@@??.o@o@o@@??.@@@oo@@??....oo@@???????????', '@',
     [15, 16, 22, 27, 32, 38, 52, 61, 71, 84]),
    ('???????????.@@@....??..@oo@.o??@.o@ooo.??.@o@@o@o??o.o@oo@@??.o@o@@@@??.@@@@o@@??...@@@@@???????????', 'o',
     [15, 16, 17, 22, 27, 38, 41, 71, 81, 82, 83]),
    ('???????????.@@@....??..@oo@.o??@.o@ooo.??.@o@@o@o??o.o@oo@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', '@',
     [15, 16, 22, 27, 32, 38, 52, 61, 71, 82]),
    ('???????????.@@@....??..@oo@.o??@@@@ooo.??.@@@@o@o??o.o@oo@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', 'o',
     [15, 16, 17, 21, 22, 27, 38, 41, 52, 61, 71, 81, 82]),
    ('???????????.@@@....??..@ooooo??@@@@ooo.??.@@@@o@o??o.o@oo@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', '@',
     [15, 16, 17, 18, 38, 52, 61, 71, 82]),
    ('???????????.@@@.@..??..@o@@oo??@@@@o@o.??.@@@@@@o??o.o@o@@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', 'o',
     [15, 17, 21, 22, 38, 41, 61, 71, 81, 82]),
    ('???????????.@@@.@o.??..@o@ooo??@@@@o@o.??.@@@@@@o??o.o@o@@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', '@',
     [15, 18, 38, 52, 61, 71, 82]),
    ('???????????.@@@@@o.??..@@@ooo??@@@@o@o.??.@@@@@@o??o.o@o@@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', 'o',
     [11, 21, 22, 38, 41, 61, 71, 81, 82]),
    ('???????????.@@@@@o.??.ooooooo??@@o@o@o.??.@@o@@@o??o.o@o@@@??.oooo@@@??.@oo@o@@??..o@@@@@???????????', '@',
     [11, 18, 38, 52, 61, 82]),
    ('???????????.@@@@@o.??.ooooooo??@@o@o@o.??.@@o@@@o??o@@@o@@@??.@@oo@@@??.@o@@o@@??..o@@@@@???????????', 'o',
     [11, 21, 38, 41, 61, 71, 81, 82]),
    ('???????????.@@@@@o.??.ooooooo??@oo@o@o.??.o@o@@@o??oo@@o@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????', '@',
     [11, 18, 21, 38, 41, 61, 71, 81]),
    ('???????????@@@@@@o.??.@oooooo??@o@@o@o.??.o@@@@@o??oo@@@@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????', 'o',
     [21, 38]),
    ('???????????@@@@@@o.??oooooooo??@o@@o@o.??.o@@@@@o??oo@@@@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????', '@',
     [18, 38, 41, 61, 71, 81]),
    ('???????????@@@@@@@@??oooooo@o??@o@@o@o.??.o@@@@@o??oo@@@@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????', 'o',
     [38, 41]),
    ('???????????@@@@@@@@??oooooo@o??oo@@o@o.??oo@@@@@o??oo@@@@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????', '@',
     [38, 61, 71, 81]),
    ('???????????@@@@@@@@??oooooo@@??oo@@o@@@??oo@@@@@@??oo@@@@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????', '@',
     [61, 71, 81]),
    ('???????????@@@@@@@@??@ooooo@@??@o@@o@@@??@o@@@@@@??@@@@@@@@??@@@oo@@@??.oo@@o@@??.oo@@@@@???????????', 'o',
     [71]),
    ('???????????@@@@@@@@??@ooooo@@??@o@@o@@@??@o@o@@@@??@@o@@@@@??@o@oo@@@??ooo@@o@@??.oo@@@@@???????????', '@',[81]))

def test_all():
    ref = Strategy()

    for i in cases:
        board, player, moves = i
        # assert(ref.get_valid_moves(board,player) == i)
        my_moves = ref.get_valid_moves(board, player)
        print(sorted(my_moves), sorted(moves))
        assert (set(my_moves) == set(moves))
def test_moves():
    ref = Strategy()
    next_board = ref.get_starting_board()
    infile = open("moves.txt", "r")
    counter = 0
    for line in infile.readlines():
        counter += 1
        board, player, move = line.strip().split(" ")
        print("testing line %i" % counter)
        assert (board == next_board)
        next_board = ref.make_move(board, player, int(move))
        print(next_board)
    if counter == 60: print("All Tests Pass!")
    infile.close()

#################################################
# The main routine
################################################

if __name__ == "__main__":
    game = ParallelPlayer()
    game.play()
    # game = Strategy()
    # board = '???????????@@@@@@@@??@ooooo@@??@o@@o@@@??@o@@@@@@??@@@@@@@@??@@@oo@@@??.oo@@o@@??.oo@@@@@???????????'
    # player = "o"
    # #game.display(board)
    # #test_all()
    # test_moves()
    # #print(game.get_valid_moves(board,player))
    # #game.display("???????????........??........??....o...??..@@o...??...@o...??........??........??........???????????")
    # game.display("???????????........??........??....o...??..@@o...??...@o...??........??........??........???????????")
    # game.display(game.make_move("???????????........??........??....o...??..@@o...??...@o...??........??........??........???????????","@", 36))
    # game.display("???????????........??........??....o@..??..@@@...??...@o...??........??........??........???????????")
    #
