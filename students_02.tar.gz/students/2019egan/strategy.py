import Othello_Core
import random
import math
#Eric Gan Pd. 1

class Strategy(Othello_Core.OthelloCore):
    #Best Strategy method - Uses alphabeta to find the next move  
    def best_strategy(self, board, player, best_move, still_running):
        depth = 2
        moves = self.possible_moves(board, player)
        fMove = random.choice(moves)
        #Finding the piece for the player
        if player is Othello_Core.BLACK:
            value = '@'
        else:
            value = 'o'
        #If there are no possible moves, return 0
        if len(moves) == 0:
            best_move.value = 0
        #If there is a corner move available, play that move
        elif 11 in moves:
            best_move.value = 11
        elif 81 in moves:
            best_move.value = 81
        elif 18 in moves:
            best_move.value = 18
        elif 88 in moves:
            best_move.value = 88
        else:
            while still_running.value:
                #Alphabeta
                best_move.value = self.alphabeta(fMove, board, player, [], depth, -math.inf, math.inf, True)[1]
                depth = depth + 1
    def possible(self, board, player, move):
    #If the cell already has a piece, then you can't move there
        if board[move] != ".":
            return False
        #Setting the row and column of the move
        row = (move)//10
        column = (move)%10
        #Determining the letter that represents your move as well as what represents the opponent
        if player is Othello_Core.WHITE:
            value = 'o'
            opvalue = '@'
        else:
            value = '@'
            opvalue = 'o'
        #Go through all 8 possibilities of directions
        for x in [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, 1], [-1, -1], [1, -1], [1, 1]]:
            fRow = row + x[0]
            fCol = column + x[1]
            #Keep moving in one direction until it hits the edge of the board or hits a piece of opposite color
            while fRow >= 1 and fRow < 9 and fCol >= 1 and fCol < 9 and board[(10*fRow) + fCol] == opvalue:
                fRow = fRow + x[0]
                fCol = fCol + x[1]
                #If happens to hit a piece of same color in that direction, return true
                if fRow >= 1 and fRow < 9 and fCol >= 1 and fCol < 9:
                    if board[(10*fRow) + fCol] == value:
                        return True
        return False
    #Uses possible() to create a list of possible moves
    def possible_moves(self, board, player):
        moves = []
        for i in range(11, 89):
            if self.possible(board, player, i):
                moves.append(i)
        return moves

    #Alphabeta algorithm
    def alphabeta(self, fMove, board, player, moves, depth, alpha, beta, maximizingPlayer):
        #Points assigned to each sqaure in the grid
        #Setting certain values based on player color
        if player is Othello_Core.WHITE:
            value = 'o'
            opvalue = '@'
            opponent = Othello_Core.BLACK
        else:
            value = '@'
            opvalue = 'o'
            opponent = Othello_Core.WHITE
        #When depth reaches 0, return the final heuristic and move
        if depth == 0:
            return self.calcHeuristic(player, board), fMove
        #If finding a move from side of player, trying to find a move that gives largest heuristic value
        if maximizingPlayer:
            v = -math.inf
            for i in range(11, 89):
                if self.possible(board, player, i):
                    moves.append(i)
            for x in moves:
                temp = board
                temp[x] = value
                v = max(v, self.alphabeta(x, temp, opponent, [], depth - 1, alpha, beta, False)[0])
                if v > alpha:
                    alpha = v
                    fMove = x
                if beta <= alpha:
                    break
            return v, fMove
        #If finding a move from side of opponent, trying to find a move that gives largest heuristic value
        else:
            v = math.inf
            for i in range(11, 89):
                if self.possible(board, player, i):
                    moves.append(i)
            for x in moves:
                board[x] = value
                v = min(v, self.alphabeta(x, board, player, [], depth - 1, alpha, beta, True)[0])
                if v < beta:
                    beta = v
                    fMove = x
                if beta <= alpha:
                    break
            return v, fMove
    def calcHeuristic(self, player, board):
        #Values to use for different ways to calculate heuristic
        pScore = 0
        pScore1 = 0
        pScore2 = 0
        pScore3 = 0
        pScore4 = 0
        oScore = 0
        oScore1 = 0
        oScore2 = 0
        oScore3 = 0
        oScore4 = 0
        #Weighted squres taken from admin code
        SQUARE_WEIGHTS = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        #Determines Player color
        if player is Othello_Core.WHITE:
            value = 'o'
            opvalue = '@'
            opponent = Othello_Core.BLACK
        else:
            value = '@'
            opvalue = 'o'
            opponent = Othello_Core.WHITE
        #Calculates heuristic based on squares around the corner. Squares surrounding corners are bad and will give a negataive heuristic value
        if board[11] == '.':
            if board[12] == value:
                pScore3 = pScore3 + 1
            elif board[12] == opvalue:
                oScore3 = oScore3 + 1
            if board[21] == value:
                pScore3 = pScore3 + 1
            elif board[21] == opvalue:
                oScore3 = oScore3 + 1
            if board[22] == value:
                pScore3 = pScore3 + 1
            elif board[22] == opvalue:
                oScore3 = oScore3 + 1
        if board[18] == '.':
            if board[17] == value:
                pScore3 = pScore3 + 1
            elif board[17] == opvalue:
                oScore3 = oScore3 + 1
            if board[28] == value:
                pScore3 = pScore3 + 1
            elif board[28] == opvalue:
                oScore3 = oScore3 + 1
            if board[27] == value:
                pScore3 = pScore3 + 1
            elif board[27] == opvalue:
                oScore3 = oScore3 + 1
        if board[81] == '.':
            if board[82] == value:
                pScore3 = pScore3 + 1
            elif board[82] == opvalue:
                oScore3 = oScore3 + 1
            if board[71] == value:
                pScore3 = pScore3 + 1
            elif board[71] == opvalue:
                oScore3 = oScore3 + 1
            if board[72] == value:
                pScore3 = pScore3 + 1
            elif board[72] == opvalue:
                oScore3 = oScore3 + 1
        if board[88] == '.':
            if board[87] == value:
                pScore3 = pScore3 + 1
            elif board[87] == opvalue:
                oScore3 = oScore3 + 1
            if board[78] == value:
                pScore3 = pScore3 + 1
            elif board[78] == opvalue:
                oScore3 = oScore3 + 1
            if board[77] == value:
                pScore3 = pScore3 + 1
            elif board[77] == opvalue:
                oScore3 = oScore3 + 1
        result3 = (oScore3 - pScore3) * 750
##        result3 = pScore3 * -200
        #Calculates heuristic based on number of squares, weighted squares, and number of squres with loose ends
        for x in range(11, 89):
            row = (x)//10
            column = (x)%10
            if board[x] == value:
                pScore = pScore + 60
                pScore1 = pScore1 + SQUARE_WEIGHTS[x]
            elif board[x] == opvalue:
                oScore = oScore + 60
                oScore1 = oScore1 + SQUARE_WEIGHTS[x]
            if board[x] == value or board[x] == opvalue:
                for i in [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, 1], [-1, -1], [1, -1], [1, 1]]:
                    fRow = row + i[0]
                    fCol = column + i[1]
                    if fRow >= 1 and fRow < 9 and fCol >= 1 and fCol < 9:
                        if board[(10*fRow) + fCol] == '.':
                            if board[x] == value:
                                pScore4 = pScore4 + 75
                            elif board[x] == opvalue:
                                oScore4 = oScore4 + 75
                            break
        #Calculates heuristic values based on differences between player and opponent
        result = (pScore - oScore)
##        result = pScore * 50
        result4 = (oScore4 - pScore4)
##        result4 = pScore4 * -75
        result1 = (pScore1 - oScore1) * 5
##        result1 = pScore1
        #Calculates heurstic value by comparing number of corner pieces to opponent corner pieces
        if board[11] == value:
            pScore2 = pScore2 + 750
        elif board[11] == opvalue:
            oScore2 = oScore2 + 750
        if board[18] == value:
            pScore2 = pScore2 + 750
        elif board[18] == opvalue:
            oScore2 = oScore2 + 750
        if board[81] == value:
            pScore2 = pScore2 + 750
        elif board[81] == opvalue:
            oScore2 = oScore2 + 750
        if board[88] == value:
            pScore2 = pScore2 + 750
        elif board[88] == opvalue:
            oScore2 = oScore2 + 750
        result2 = (pScore2 - oScore2) 
##        result2 = pScore2 * 750
        #Adds all the heuristic values up to get a final heuristic value
        return result + result1 + result2 + result3 + result4
            
            
            
            

    
