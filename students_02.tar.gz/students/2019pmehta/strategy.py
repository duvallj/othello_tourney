class Strategy:
   def best_strategy(self, board, player, best_move, still_running):
      game = list(''.join(board).replace("?","").replace("@","X").replace("o","O"))
      player = "X" if player == "@" else "O"
      moves = partitionMoves(game,player)
      opp = "X" if player == "O" else "O"
      choice = chooseBest(moves,player,game,opp)
      choice = ((choice//8) * 10) + (choice%8) + 11
      best_move.value = choice
      if game.count(".") == 6:   
         negMax = negamax(game,player,1)
         move = negMax[-1]
         moves = partitionMoves(game,player)
         if move in moves:
            bestt = 11 + (move//8)*10 + (move%8)
            best_move.value = bestt
         
def chooseBest(moves,player,game,opp):
   if len(moves) == 0:
      return 64
   copy = set(moves)
   listt = list(moves)
   #greedy corners
   for i in moves:
      if i in [0,7,56,63]:
         return i
   game2 = game[:]
   for i in moves:
      game2[i] = player
      moves2 = partitionMoves(game,opp)
      copy2 = set(moves2)
      for x in copy2:
         if x in [0,7,56,63] and i in moves2 and i in copy:
            copy.remove(i)
      game2[i] = "."
   if len(copy) == 0:
      copy = set(moves)
   #safe edges
   CX = {1:0,8:0,9:0,6:7,15:7,14:7,57:56,48:56,49:56,62:63,55:63,54:63}
   pre3 = set(moves)
   #c or x moves
   for i in listt:
      if i in CX:
         if game[CX.get(i)] != player:
            copy.remove(i)
   if len(copy) == 0:
      return chooseBest2(pre3,player,game,opp)
   else:
      return chooseBest2(copy,player,game,opp)   
      
def chooseBest2(set,player,game,opp):
   dict = {}
   edges = [0,1,2,3,4,5,6,7,8,16,24,32,40,48,56,57,58,59,60,61,62,63,55,47,39,31,23,15]
   for i in set:
      if i in edges:
         return i
      countt = 0
      game[i] = player
      countt += flipTokens(game,i,row,player,opp)
      countt += flipTokens(game,i,col,player,opp)
      countt += flipTokens(game,i,diag,player,opp)
      dict[i] = countt
   inverse = [(val, key) for key, val in dict.items()]
   return max(inverse)[1]

def partitionMoves(game,player):
   moves = rows(game,player)
   moves1 = cols(game,player)
   moves2 = diags(game,player)
   moves3 = moves.union(moves1)
   finalmoves = moves3.union(moves2)
   return finalmoves

def flipTokens(game,pos,table,player,opp):
   count = 0
   for i in table:
      if pos in i:
         positions = i[:]
         characters = [game[x] for x in i]
         if player in characters and opp in characters:
            fragment = ''.join(characters)
            setsX = ["XOX","XOOX","XOOOX","XOOOOX","XOOOOOX","XOOOOOOX"]
            setsO = ["OXO","OXXO","OXXXO","OXXXXO","OXXXXXO","OXXXXXXO"]
            if player == "X":
               for x in setsX:
                  if x in fragment:
                     length = len(x)
                     index = positions.index(pos)
                     frag1 = fragment[index:index + length]
                     frag2 = fragment[index-length+1:index+1]
                     if frag1 == x:
                        for y in range(index, index+length):
                           count+=1
                     if frag2 == x:
                        for y in range(index-length+1,index):
                           count+=1
            else:
               for x in setsO:
                  if x in fragment:
                     length = len(x)
                     index = positions.index(pos)
                     frag1 = fragment[index:index + length]
                     frag2 = fragment[index-length+1:index+1]
                     if frag1 == x:
                        for y in range(index, index+length):
                           count+=1
                     if frag2 == x:
                        for y in range(index-length+1,index):
                           count+=1
   return count

def cols(game,player):
   if player == "X":
      sets = ["XO.","XOO.","XOOO.","XOOOO.","XOOOOO.","XOOOOOO."]
      sets2 = [".OX",".OOX",".OOOOX",".OOOOOX",".OOOOOOX",".OOOX"]
   else:
      sets = ["OX.","OXX.","OXXX.","OXXXX.","OXXXXX.","OXXXXXX."]
      sets2 = [".XO",".XXO",".XXXO",".XXXXO",".XXXXXO",".XXXXXXO"]
   moves = set()
   for i in col:
      sequence = [game[x] for x in i]
      seqstring = ''.join(sequence)  
      for a in sets:
         if a in seqstring:
            moves.add(i[seqstring.index(a)+len(a)-1])
      for b in sets2:
         if b in seqstring:
            moves.add(i[seqstring.index(b)])
   return moves

def diags(game,player):
   if player == "X":
      sets = ["XO.","XOO.","XOOO.","XOOOO.","XOOOOO.","XOOOOOO."]
      sets2 = [".OX",".OOX",".OOOOX",".OOOOOX",".OOOOOOX",".OOOX"]
   else:
      sets = ["OX.","OXX.","OXXX.","OXXXX.","OXXXXX.","OXXXXXX."]
      sets2 = [".XO",".XXO",".XXXO",".XXXXO",".XXXXXO",".XXXXXXO"]
   moves = set()
   for i in diag:
      sequence = [game[x] for x in i]
      seqstring = ''.join(sequence)   
      for a in sets:
         if a in seqstring:
            moves.add(i[seqstring.index(a)+len(a)-1])
      for b in sets2:
         if b in seqstring:
            moves.add(i[seqstring.index(b)])
   return moves

def negamax(game,player,level):
   if level == 0:
      return [evalGame(game,player)]
   moves = partitionMoves(game)
   opp = "O" if player == "X" else "X"
   if len(moves) == 0:
      negMax = negamax(game,opp,level-1)
      return [-negMax[0]] + negMax[1:]
   negMax = sorted([negamax(makeMove(game,player,move),opp,level-1) + [move] for move in moves])
   best = negMax[0]
   return [-best[0]] + best[1:]

def makeMove(game,player,pos):
   game[int(pos)] = player
   opp = "O" if player == "X" else "X" 
   game = flipTokens(game,pos,row,player,opp)
   game = flipTokens(game,pos,col,player,opp)
   game = flipTokens(game,pos,diag,player,opp)
   return game

def evalGame(game,player):
   total = 0
   opp = "O" if player == "X" else "X"
   for i in range(len(game)):
      if game[i] == player:
         total += points[i]
      elif game[i] == opp:
         total -= points[i]
   return total   

def rows(game,player):
   if player == "X":
      sets = ["XO.","XOO.","XOOO.","XOOOO.","XOOOOO.","XOOOOOO."]
      sets2 = [".OX",".OOX",".OOOOX",".OOOOOX",".OOOOOOX",".OOOX"]
   else:
      sets = ["OX.","OXX.","OXXX.","OXXXX.","OXXXXX.","OXXXXXX."]
      sets2 = [".XO",".XXO",".XXXO",".XXXXO",".XXXXXO",".XXXXXXO"]
   moves = set()
   for i in row:
      sequence = [game[x] for x in i]
      seqstring = ''.join(sequence)   
      for a in sets:
         if a in seqstring:
            moves.add(i[seqstring.index(a)+len(a)-1])
      for b in sets2:
         if b in seqstring:
            moves.add(i[seqstring.index(b)])
   return moves  
      
col = [[0,8,16,24,32,40,48,56],[1,9,17,25,33,41,49,57],
      [2,10,18,26,34,42,50,58],[3,11,19,27,35,43,51,59],
      [4,12,20,28,36,44,52,60],[5,13,21,29,37,45,53,61],
      [6,14,22,30,38,46,54,62],[7,15,23,31,39,47,55,63]]
row = [
      [0,1,2,3,4,5,6,7],[8,9,10,11,12,13,14,15],
      [16,17,18,19,20,21,22,23],[24,25,26,27,28,29,30,31],
      [32,33,34,35,36,37,38,39],[40,41,42,43,44,45,46,47],
      [48,49,50,51,52,53,54,55],[56,57,58,59,60,61,62,63]]
diag = [
      [0],[8,1],[16,9,2],[24,17,10,3],[32,25,18,11,4],
      [40,33,26,19,12,5],[48,41,34,27,20,13,6],
      [56,49,42,35,28,21,14,7],[57,50,43,36,29,22,15],
      [58,51,44,37,30,23],[59,52,45,38,31],[60,53,46,39],
      [61,54,47],[62,58],[63],[7],[6,15],[5,14,23],
      [4,13,22,31],[3,12,21,30,39],[2,11,20,29,38,47],
      [1,10,19,28,37,46,55],[0,9,18,27,36,45,54,63],
      [8,17,26,35,44,53,62],[16,25,34,43,52,61],[56],
      [24,33,42,51,60],[32,41,50,59],[40,49,58],[48,57]]
       
points = {0:7,1:2,2:5,3:4,4:4,5:5,6:2,7:7,
         8:2,9:1,10:3,11:3,12:3,13:3,14:1,15:2,
         16:5,17:3,18:6,19:5,20:5,21:6,22:3,23:5,
         24:4,25:3,26:5,27:6,28:6,29:5,30:3,31:4,
         32:4,33:3,34:5,35:6,36:6,37:5,38:3,39:4,
         40:5,41:3,42:6,43:5,44:5,45:6,46:3,47:5,
         48:2,49:1,50:3,51:3,52:3,53:3,54:1,55:2,
         56:7,57:2,58:5,59:4,60:4,61:5,62:2,63:7}
         
def main():
   #code command line shit
   game = list(''.join(sys.argv[1]))
   player = sys.argv[2].upper()
   opp = "X" if player == "O" else "O"
   if game.count(".") == 6:   
      negMax = negamax(game,player,1)
      move = negMax[-1]
      moves = partitionMoves(game,player)
      if move in moves:
         bestt = 11 + (move//8)*10 + (move%8)
         print(bestt)
      else:
         print(moves.pop())
   else:
      moves = partitionMoves(game,player)
      choice = chooseBest(moves,player,game,opp)
      print(choice)

if __name__ == "__main__":
   main()