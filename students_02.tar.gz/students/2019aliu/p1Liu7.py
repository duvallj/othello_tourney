# @author ALiu
# @date 1/23/18
# Smartly play a move

import sys
import random
import time

inittime = time.clock()

game = ""
player = ""
if len(sys.argv) == 1:
    game = "." * 27 + "OX" + "." * 6 + "XO" + "." * 27
    player = "X"
elif len(sys.argv) == 2:
    game = sys.argv[1].upper()
    nbrPeriods = sum([1 for myC in game if myC == '.'])
    if nbrPeriods % 2 == 0:
        player = "X"
    else:
        player = "O"
elif len(sys.argv) == 3:
    game = sys.argv[1].upper()
    player = sys.argv[2].upper()

# Checks whether a space is adjacent to an opponent's piece
# If the position is adjacent to an opponent, return True
def nextToOpponent(game, index):
    neighbors = set()
    up, down, left, right = index >= 8, index <= 55, index % 8 > 0, index % 8 < 7
    # This can be cleaned up
    if up:  # up
        neighbors.add(game[index-8])
    if down:  # down
        neighbors.add(game[index+8])
    if left:  # left
        neighbors.add(game[index-1])
    if right:  # right
        neighbors.add(game[index+1])
    if up and left:  # upper left
        neighbors.add(game[index-9])
    if up and right:  # upper right
        neighbors.add(game[index-7])
    if down and left:  # lower left
        neighbors.add(game[index+7])
    if down and right:  # lower right
        neighbors.add(game[index+9])
    if player == "X":
        return "O" in neighbors
    else:  # this means the player is an O
        return "X" in neighbors

def flanksOpp(game, index):
    # Process the row
    row = int(index / 8)
    column = index % 8

    # To the left
    left = []
    for i in range(column):
        current = game[index - i - 1]
        if current == player:
            if left and not ("." in set(left) or player in set(left)):
                return True
            else:
                break
        else:
            left.append(current)

    right = []
    for i in range(8 - column - 1):
        current = game[index + i + 1]
        if current == player:
            if right and not ("." in set(right) or player in set(right)):
                return True
            else:
                break
        else:
            right.append(current)

    up = []
    for i in range(row):
        current = game[(row - i - 1) * 8 + column]
        if current == player:
            if up and not ("." in set(up) or player in set(up)):
                return True
            else:
                break
        else:
            up.append(current)

    down = []
    for i in range(row + 1, 8):
        current = game[i * 8 + column]
        if current == player:
            if down and not ("." in set(down) or player in set(down)):
                return True
            else:
                break
        else:
            down.append(current)


    # To the upper left (northwest)
    upperLeft = []
    tempR = row - 1
    tempC = column - 1
    while tempR >= 0 and tempC >= 0:
        current = game[tempR * 8 + tempC]
        if current == player:
            if upperLeft and not ("." in set(upperLeft) or player in set(upperLeft)):
                return True
            else:
                break
        else:
            upperLeft.append(current)
        tempR -= 1
        tempC -= 1

    lowerRight = []
    tempR = row + 1
    tempC = column + 1
    while tempR < 8 and tempC < 8:
        current = game[tempR * 8 + tempC]
        if current == player:
            if lowerRight and not ("." in set(lowerRight) or player in set(lowerRight)):
                return True
            else:
                break
        else:
            lowerRight.append(current)
        tempR += 1
        tempC += 1

    # Diagonal from top-right to bottom-left
    upperRight = []
    tempR = row - 1
    tempC = column + 1
    while tempR >= 0 and tempC < 8:
        current = game[tempR * 8 + tempC]
        if current == player:
            if upperRight and not ("." in set(upperRight) or player in set(upperRight)):
                return True
            else:
                break
        else:
            upperRight.append(current)
        tempR -= 1
        tempC += 1

    lowerLeft = []
    tempR = row + 1
    tempC = column - 1
    while tempR < 8 and tempC >= 0:
        current = game[tempR * 8 + tempC]
        if current == player:
            if lowerLeft and not ("." in set(lowerLeft) or player in set(lowerLeft)):
                return True
            else:
                break
        else:
            lowerLeft.append(game[tempR * 8 + tempC])
        tempR += 1
        tempC -= 1

# Display the game
print("\n".join('\t'.join(game[i*8:i*8+8]) for i in range(int(len(game) ** 0.5))))

validMoves = set()
for i, char in enumerate(game):
    if char == "." and nextToOpponent(game, i) and flanksOpp(game, i):
        validMoves.add(i)
# print(validMoves)

####################################################################################################
####################################################################################################

# Lab 6 strategies

corners = {0, 7, 56, 63}
edges = {}
move = -1
mademove = False

# Strategy 1: Play to corner if at all possible
if validMoves & corners:
    move = random.sample(validMoves & corners, 1)[0]
    mademove = True

# Strategy 2: Play to edge if it makes a path with own token to the corners
directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]  # (x, y) --> down, right, up, down
def secureEdge(index):  # any move that passes through here will automatically be an edge
    myStack = []
    for direction in directions:
        row = int(index / 8)
        column = index % 8
        row += direction[0]
        column += direction[1]
        while row >= 0 and row < 8 and column >= 0 and column < 8:
            tIndex = row*8+column
            if game[tIndex] == player and myStack and "." not in myStack and player not in myStack:
                return True
            myStack.append(game[tIndex])
            row += direction[0]
            column += direction[1]
    return False

edges = {1, 2, 3, 4, 5, 6, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 57, 58, 59, 60, 61, 62}
if not mademove:
    for pos in validMoves:
        if pos in edges and secureEdge(pos):
            move = pos
            mademove = True
            break

# Strategy 3: Don't play C or X the corresponding corner is unprotected (of course, if this is an available option)
dictC = {0: (1, 8), 7: (6, 15), 56: (48, 57), 63: (55, 62)}
setC = {1, 8, 6, 15, 48, 57, 55, 62}
dictX = {0: 9, 7: 14, 56: 49, 63: 54}
setX = {9, 14, 49, 54}

noCX = validMoves - setC
noCX = noCX - setX
if len(noCX) > 0:
    for corner in corners:
        if game[corner] != player:
            validMoves = validMoves - {dictC[corner][0], dictC[corner][1], dictX[corner]}

# Strategy 4: If Strategies 1 and 2 don't apply, then try not to move on an edge
if not mademove:
    noEdges = validMoves - edges
    if len(noEdges) > 0:
        validMove = noEdges
        move = random.sample(validMoves, 1)[0]
    elif len(validMoves) > 0:
        move = random.sample(validMoves, 1)[0]

print("Time taken for heuristic move:", time.clock() - inittime)

if move >= 0:
    print("My heuristic choice is {}".format(move))
    mademove = True
else:
    print("Pass")

####################################################################################################
####################################################################################################

# Lab 7 addition: Negamax

def negamax(board, token, depth):
    if not depth:
        return [evalBoard(board, token)]
    lm = validMoves
    enemy = "X" if token == "O" else "O"
    if not lm:
        nm = negamax(board, enemy, depth-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makeMove(board, token, mv), enemy, depth-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]

def evalBoard(board, token):
    playerCount = 0
    opponentCount = 0
    for char in board:
        if char == token:
            playerCount += 1
        else:
            opponentCount += 1
    return playerCount - opponentCount

def validMoveSet(game, player):
    validMoves = []
    for i, char in enumerate(game):
        if char == "." and nextToOpponent(game, i) and flanksOpp(game, i):
            validMoves.append(i)
    return validMoves

def makeMove(game, player, move):
    if move in validMoveSet(game, player):  # If the current move is valid
        game = game[:move] + player + game[move + 1:]  # Place the player's piece there
        row = int(move / 8)
        column = move % 8
        for i in (-1, 0, 1):  # changes column (horizontal direction)
            for j in (-1, 0, 1):  # changes row (vertical) direction)
                stack = []  # to store all indexes
                temp = move  # like a temporary counter for each direction
                row = int(move / 8)
                column = move % 8
                while row >= 0 and row < 8 and column >= 0 and column < 8:  # while not out of bounds
                    if temp % 8 + i < 0 or temp % 8 + i > 7 or int(temp / 8) + j < 0 or int(temp / 8) + j > 7:
                        break
                    temp = temp + j * 8 + i  # move the temp counter
                    row = int(temp / 8)
                    column = temp % 8
                    if temp < 0 or temp > 63 or row < 0 or row >= 8 and column < 0 and column >= 8:
                        break
                    if game[temp] == ".":
                        break
                    if game[temp] == player:  # if the current player's piece is next, flip the pieces
                        while len(stack) > 0:
                            removed = stack.pop(-1)
                            game = game[:removed] + player + game[removed + 1:]
                        break
                    else:
                        stack.append(temp)
    return game

if mademove and game.count('.') <= 8:
    level = 7
#    while time.clock() - inittime < 5:
    nm = negamax(game, player, level)
    print("Time taken:", time.clock()-inittime)
    print("The score for this move is:", nm[0])
    print("At level {}, negamax gives {}, and I choose to move at {}".format(level, nm, nm[-1]))
    print()
#    level += 1

# # level = -1
# level = 5
# nm = negamax(game, player, level)
# print("Time taken:", time.clock()-inittime)
# print("At level {}, negamax gives {}, and I choose to move at {}".format(level, nm, nm[-1]))

# OXXXXXXXOXXXOXXXOXXOOOXXOXOXOXXXOXXOX.XXOOOOXXXX.OOOOOOX....X..X
