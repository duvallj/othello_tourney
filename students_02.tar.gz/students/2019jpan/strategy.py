#Joshua Pan Due 3/5

from __future__ import print_function
import sys
import time
import random
TOKENS = "XO"
CORNERS = [0, 7, 63, 56] #rotate CW
X = [9, 14, 54, 49]
C = [[1, 6], [15, 55], [62, 57], [48, 8]]
EDGES = [[1, 2, 3, 4, 5, 6], [15, 23, 31, 39, 47, 55], [62, 61, 60, 59, 58, 57], [48, 40, 32, 24, 16, 8]]

#Add opening book and mobility heuristic

def legalMoves(game, whoseMove):
   moves = set()
   oppToken = (whoseMove == TOKENS[0] and TOKENS[1]) or TOKENS[0]
   myTokens = {pos for pos, tkn in enumerate(game) if tkn==whoseMove}
   for pos in myTokens:
      for idx in range(64):
         if idx in moves or game[idx] != '.':
            continue
         diff = idx - pos
         invalid = False
         extraconstraint = (not diff % 7 or not diff % 9) and abs(pos % 8 - idx % 8) != abs(pos // 8 - idx // 8)
         if (not diff or abs(diff) == 1 or abs(diff) == 8 or abs(diff) == 9 or (abs(diff) == 7 or diff % 9 and diff % 7 and diff % 8 or extraconstraint) and idx // 8 != pos // 8) and not abs(diff) == 56:
            invalid = True
         elif not diff % 7 and diff % 8 and diff % 9 and idx // 8 != pos // 8:
            for i in range(min(idx, pos) + 7, max(idx, pos), 7):
               if game[i] != oppToken:
                  invalid = True
                  break
         elif not diff % 9:
            for i in range(min(idx, pos) + 9, max(idx, pos), 9):
               if game[i] != oppToken:
                  invalid = True
                  break
         elif not diff % 8:
            for i in range(min(idx, pos) + 8, max(idx, pos), 8):
               if game[i] != oppToken:
                  invalid = True
                  break
         elif idx // 8 == pos // 8:
            for i in range(min(idx, pos) + 1, max(idx, pos)):
               if game[i] != oppToken:
                  invalid = True
                  break
         if not invalid:
            moves.add(idx)
   return moves

def makeMove(game, whoseMove, move):
   oppToken = (whoseMove == TOKENS[0] and TOKENS[1]) or TOKENS[0]
   flips = set()
   myTokens = {pos for pos, tkn in enumerate(game) if tkn==whoseMove}
   for pos in myTokens:
      if pos == -1:
         break
      diff = pos - move
      factor = -1
      currentFlips = set()
      if pos // 8 == move // 8:
         factor = 1
      elif not diff % 7 and not abs(diff) == 7 and abs(pos % 8 - move % 8) == abs(pos // 8 - move // 8):
         factor = 7
      elif not diff % 8 and not abs(diff) == 8:
         factor = 8
      elif not diff % 9 and not abs(diff) == 9 and abs(pos % 8 - move % 8) == abs(pos // 8 - move // 8):
         factor = 9
      for i in range(min(move, pos) + factor, max(move, pos), factor):
         if factor == -1:
            break
         if game[i] == oppToken:
            currentFlips.add(i)
         else:
            currentFlips = set()
            break
      if len(currentFlips) == abs(diff) // factor - 1:
         flips.update(currentFlips)
   newGame = ''.join([(move == i and whoseMove) or (i in flips and whoseMove) or game[i] for i in range(64)])
   return newGame
            
def moveCorner(moves):
   for i in CORNERS:
      if i in moves:
         return i
   return None
   
def safeEdges(game, token):
   safeE = set()
   oppToken = (token == TOKENS[0] and TOKENS[1]) or TOKENS[0]
   for co in range(len(CORNERS)):
      if game[CORNERS[co]] == token:
         sep = False #ran into opp token?
         for e in EDGES[co]:
            if game[e] == oppToken:
               sep = True
            if game[e] == token and sep:
               break
            if game[e] == '.' and e in legalMoves(game, token):
               safeE.add(e)
         sep = False
         for e in EDGES[co - 1][::-1]:
            if game[e] == oppToken:
               sep = True
            if game[e] == token and sep:
               break
            if game[e] == '.' and e in legalMoves(game, token):
               safeE.add(e)  
   return safeE    
   
def restrictCX(game, token, moves):
   oldMoves = {m for m in moves}
   for co in range(len(CORNERS)):
      if game[CORNERS[co]] != token:
         moves.discard(X[co])
         for c in C[co]:
            moves.discard(c)
   return oldMoves
   
def restrictEdges(game, token, moves):
   oldMoves = {m for m in moves}
   for l in EDGES:
      for e in l:
         moves.discard(e)
   return oldMoves
   
def limMob(game, token, moves): #also restrict/weight enemy corners (how about CX?)
   enemy = (token == TOKENS[0] and TOKENS[1]) or TOKENS[0]
   move1 = moves.pop()
   best = (len(legalMoves(makeMove(game, token, move1), enemy)), move1)
   for mv in moves:
      nmeMoves = legalMoves(makeMove(game, token, mv), enemy)
      mobility = len(nmeMoves)
      for move in nmeMoves:
         if move in CORNERS:
            mobility += 3
      if mobility < best[0]:
         best = (mobility, mv)
   return best[1]

def boardEval(board, token):
   return board.count(token) - board.count((token == TOKENS[0] and TOKENS[1]) or TOKENS[0])

def negamax(board, token, levels):
   enemy = (token == TOKENS[0] and TOKENS[1]) or TOKENS[0]
   if not levels or '.' not in board:
      return[boardEval(board, token)]
   lm = list(legalMoves(board, token))
   if not lm:
      nm = negamax(board, enemy, levels - 1) + [-1]
      return [-nm[0]] + nm[1:]
   nmList = sorted([negamax(makeMove(board, token, mv), enemy, levels - 1) + [mv] for mv in lm])
   best = nmList[0]
   return [-best[0]] + best[1:]

def negamaxTerminal(board, token, improvable, hardBound):
   enemy = (token == TOKENS[0] and TOKENS[1]) or TOKENS[0]
   lm = legalMoves(board, token)
   if not lm:
      lm = legalMoves(board, enemy)
      if not lm:
         return [boardEval(board, token), -3]
      nm = negamaxTerminal(board, enemy, -hardBound, -improvable) + [-1]
      return [-nm[0]] + nm [1:]
   best = []
   newHB = -improvable
   for mv in lm:
      nm = negamaxTerminal(makeMove(board, token, mv), enemy, -hardBound, newHB) + [mv]
      if not best or nm[0] < newHB:
         best = nm
         if nm[0] < newHB:
            newHB = nm[0]
            if -newHB >= hardBound:
               return [-best[0]] + best[1:]
   return [-best[0]] + best[1:]

if __name__ == '__main__':
   game = "...........................OX......XO..........................."
   whoseMove = "x"
   arg = 1
   passed = 0
   if len(sys.argv) > 1:
      while not arg == len(sys.argv) and not sys.argv[arg].isdigit() and not len(sys.argv[arg]) == 2:
         if len(sys.argv[arg]) == 64:
            game = sys.argv[arg].upper()
         else:
            whoseMove = sys.argv[arg].upper()
         arg += 1
   if whoseMove.islower():
      whoseMove = TOKENS[game.count('.') % 2]

   while arg < len(sys.argv): 
      move = ''   
      if arg != len(sys.argv) and sys.argv[arg].isdigit():
         move = int(sys.argv[arg])
      elif arg != len(sys.argv):
         move = (int(sys.argv[arg][1]) - 1) * 8 + int(sys.argv[arg][0], 36) - 10
      if not len(legalMoves(game, whoseMove)):
         if passed % 2:
            break
         whoseMove = (whoseMove == TOKENS[0] and TOKENS[1]) or TOKENS[0]
         passed += 1
         arg -= 1
      elif len(sys.argv) != 1 and move in legalMoves(game, whoseMove):
         game = makeMove(game, whoseMove, move)
         whoseMove = (whoseMove == TOKENS[0] and TOKENS[1]) or TOKENS[0]
         if passed % 2:
            passed += 1
      elif len(sys.argv) != 1 and move != '':
         print("Invalid move", move, legalMoves(game, whoseMove))
      arg += 1
            
   moves = legalMoves(game, whoseMove)
   move = None
   print()
   for i in range(8):
      for j in range(8):
         print(i * 8 + j == move and '+' or i * 8 + j in moves and '*' or game[i * 8 + j], end = ' ')
      print()
   print()
   print(game)
   print("Legal moves: {}".format(moves))
   #print("Last resort move: {}".format(min(moves)))
   cornerMove = moveCorner(moves)
   if len(moves) == 1:
      move = min(moves)
   else:
      if cornerMove != None:
         move = cornerMove
      else:
         oldMoves = restrictEdges(game, whoseMove, moves)
         if not moves:
            moves = oldMoves
         safeE = safeEdges(game, whoseMove)
         if safeE:
            move = limMob(game, whoseMove, safeE)
         else:
            oldMoves = restrictCX(game, whoseMove, moves)
            if not moves:
               moves = oldMoves
            if moves:
               move = limMob(game, whoseMove, moves) 
            else:
               print("No legal moves")
               exit()   
   print("My heuristic move is {}".format(move)) #("Move using Lab6 corner, safe edges, avoid edges, avoid CX, random {}".format(move))
   if game.count('.') <= 11: #10 to be safe or 11?
      nm = negamaxTerminal(game, whoseMove, -65, 65) #extraneous -3?
      move = nm[-1] 
      print("Negamax a-b {} and my move is {}".format(nm[0], move)) #("Move using negamax {}".format(move))   

class Strategy():
   def best_strategy(self, board, player, best_move, still_running):
      playerToToken = {'@' : 'X', 'o' : 'O'}
      game = ''.join(board)
      game = game.replace('?', '')
      game = game.replace('@', 'X')
      game = game.replace('o', 'O')
      whoseMove = playerToToken[player]
      #raise ValueError("{}, {}".format(game, whoseMove)) #debugging
      moves = legalMoves(game, whoseMove)
      move = None
      cornerMove = moveCorner(moves)
      if len(moves) == 1:
         move = min(moves)
      else:
         if cornerMove != None:
            move = cornerMove
         else:
            oldMoves = restrictEdges(game, whoseMove, moves)
            if not moves:
               moves = oldMoves
            safeE = safeEdges(game, whoseMove)
            if safeE:
               move = limMob(game, whoseMove, safeE)
            else:
               oldMoves = restrictCX(game, whoseMove, moves)
               if not moves:
                  moves = oldMoves
               if moves:
                  move = limMob(game, whoseMove, moves) 
               else:
                  print("No legal moves")
                  exit()
      theirMove = 11 + (move // 8) * 10 + (move % 8)
      best_move.value = theirMove
      print("My heuristic move is {}".format(move)) #("Move using Lab6 corner, safe edges, avoid edges, avoid CX, random {}".format(move))
      if game.count('.') <= 11: #12 in 5 s? 14 for turnin and variable for experiment
         nm = negamaxTerminal(game, whoseMove, -65, 65) #extraneous -3?
         move = nm[-1]  
         theirMove = 11 + (move // 8) * 10 + (move % 8)
         best_move.value = theirMove