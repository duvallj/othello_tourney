import sys
import random


sys.setrecursionlimit(1500)

class Strategy():
	def best_strategy(self,board,player,best_move,still_running):
		brd = ''.join(board).replace('?','').replace('@','x')
		token = "x" if player == '@' else "o"
		if(token == "x"):
			oppToken = "o"
		else:
			oppToken = "x"
		legalMoves = legalMoves2(brd,token,oppToken)
		mv = movePlayed(brd,token,legalMoves)
		mv1 = 11 + (mv//8) * 10 + (mv%8)
		best_move.value = mv1

edges = {1,2,3,4,5,6,8,16,24,32,40,48,15,23,31,39,47,55,57,58,59,60,61,62}
def displayBoard(board):
 print(("\n"+board[0:8] + "\n" + board[8:16] + "\n" + board[16:24] + "\n" + board[24:32] + "\n" + board[32:40]+ "\n" + board[40:48] + "\n" + board[48:56]+ "\n" + board[56:64]))

def displayBoardwithAsterisks(board,legalMoves):
 
 lboard = list(board)
 for i in legalMoves:
  lboard[i] = "*"
 board = ''.join(lboard)
 print(board)
 print("\n"+board[0:8] + "\n" + board[8:16] + "\n" + board[16:24] + "\n" + board[24:32] + "\n" + board[32:40]+ "\n" + board[40:48] + "\n" + board[48:56]+ "\n" + board[56:64])
def legalMoves(board):
	lstofLegalMoves = set()
	#get indexes of the current token 
	indexesOfToken = [pos for pos, char in enumerate(board) if char == nextToken]
	# iterate through those indexes  for x in indexes
	for y in {1,-1,-7,7,9,-9,8,-8}:
		#iterate through all directions for y in {1,-1,-7,7,9,-9,8,-8} 
		for x in indexesOfToken:
			col = int(x % 8)
			row = x // 8
			cIndex = x+y 
			if y in{-7,1,9}:
				col=col+1
			elif y in{-9,-1,7}:
				col=col-1
			while cIndex < 64 and cIndex > -1 and board[cIndex] == oppToken and col > -1 and col < 8:
				cIndex=cIndex+y
				if y in{-7,1,9}:
					col=col+1
				elif y in{-9,-1,7}:
					col=col-1
				if cIndex > 63 or cIndex < 0 or col < 0 or col > 7:
					break
				if board[cIndex] == ".":
					lstofLegalMoves.add(cIndex) 
					break

	return lstofLegalMoves

def legalMoves2(board,nextToken,oppToken):
	lstofLegalMoves = set()

	#get indexes of the current token

	indexesOfToken = [pos for pos, char in enumerate(board) if char == nextToken]


	# iterate through those indexes  for x in indexes
	for y in {1,-1,-7,7,9,-9,8,-8}:
		#iterate through all directions for y in {1,-1,-7,7,9,-9,8,-8} 
		for x in indexesOfToken:
			col = int(x % 8)
			row = x // 8
			cIndex = x+y 
			if y in{-7,1,9}:
				col=col+1
			elif y in{-9,-1,7}:
				col=col-1
			while cIndex < 64 and cIndex > -1 and board[cIndex] == oppToken and col > -1 and col < 8:
				cIndex=cIndex+y
				if y in{-7,1,9}:
					col=col+1
				elif y in{-9,-1,7}:
					col=col-1
				if cIndex > 63 or cIndex < 0 or col < 0 or col > 7:
					break
				if board[cIndex] == ".":
					lstofLegalMoves.add(cIndex) 
					break

	return lstofLegalMoves
def needToBeFlipped(board,index):	
	flipped = []
	col = int(index % 8)
	for r in [1,-1,-7,7,9,-9,8,-8]:
		cIndex = index
		cIndex = cIndex + r
		col = int(index % 8)
		#print("Visiting ", index, " ", r,  " making sure it the oppisite Token")
		if r in[-7,1,9]:
			col=col+1
		elif r in[-9,-1,7]:
			col=col-1
		if cIndex < 64 and cIndex > -1 and col > -1 and col < 8 and board[cIndex] == oppToken: 
			#print("oppisite token found at ",cIndex)
			cIndex = cIndex + r
			if r in[-7,1,9]:
				col=col+1
			elif r in[-9,-1,7]:
				col=col-1
			while cIndex < 64 and cIndex > -1 and col > -1 and col < 8 and board[cIndex] == oppToken:
				if r in[-7,1,9]:
					col=col+1
				elif r in[-9,-1,7]:
					col=col-1
				#print("more oppisite token found at ",cIndex)
				cIndex = cIndex + r
				if cIndex > 63 or cIndex < 0 or col < 0 or col > 7:
					break
			if cIndex > 63 or cIndex < 0 or col < 0 or col > 7:
				#print("breaked at ", r)
				continue
			elif board[cIndex] == nextToken:
				#print("The Sandwhich became ", index, " to ", cIndex)
				while cIndex != index:
						cIndex = cIndex - r
						flipped.append(cIndex)
	while index in flipped:				
		flipped.remove(index)
	return flipped

def needToBeFlipped2(board,index,nextToken,oppToken):	
	flipped = []
	col = int(index % 8)
	for r in [1,-1,-7,7,9,-9,8,-8]:
		cIndex = index
		cIndex = cIndex + r
		col = int(index % 8)
		#print("Visiting ", index, " ", r,  " making sure it the oppisite Token")
		if r in[-7,1,9]:
			col=col+1
		elif r in[-9,-1,7]:
			col=col-1
		if cIndex < 64 and cIndex > -1 and col > -1 and col < 8 and board[cIndex] == oppToken: 
			#print("oppisite token found at ",cIndex)
			cIndex = cIndex + r
			if r in[-7,1,9]:
				col=col+1
			elif r in[-9,-1,7]:
				col=col-1
			while cIndex < 64 and cIndex > -1 and col > -1 and col < 8 and board[cIndex] == oppToken:
				if r in[-7,1,9]:
					col=col+1
				elif r in[-9,-1,7]:
					col=col-1
				#print("more oppisite token found at ",cIndex)
				cIndex = cIndex + r
				if cIndex > 63 or cIndex < 0 or col < 0 or col > 7:
					break
			if cIndex > 63 or cIndex < 0 or col < 0 or col > 7:
				#print("breaked at ", r)
				continue
			elif board[cIndex] == nextToken:
				#print("The Sandwhich became ", index, " to ", cIndex)
				while cIndex != index:
						cIndex = cIndex - r
						flipped.append(cIndex)
	while index in flipped:				
		flipped.remove(index)
	return flipped

def flipper(board,flip,nT,i):
	board = board[:i]+nT+board[i+1:]
	for f in flip:
		board = board[:f]+nT+board[f+1:]
	return board

def evalBoard(board, player, otherplayer): 
	return board.count(player)-board.count(otherplayer);

def evalBoard2(board, player, otherplayer): 
	return len(legalMoves2(board,player,otherplayer)) - len(legalMoves2(board,otherplayer,player));

def makeMove(board, player, i,otherplayer):
	#print(player, " playing at ", i)
	#print("Playing at: ", i)
	#print("NEEDS TO BE FLIPPED: ", needToBeFlipped2(board,i,player,otherplayer))
	board = flipper(board,needToBeFlipped2(board,i,player,otherplayer),player,i)
	#displayBoard(board)
	return board;

def negaMax(board, player, otherplayer, levels,legal,periods):
	#displayBoard(board)
	legal = legalMoves2(board,player,otherplayer)
	legal2 = legalMoves2(board,otherplayer,player)


	'''
	if(player == nextToken):
		print("simulating my move".upper())
	else:
		print("simulating opponent's move".upper())
	'''
	lM  = set(legal)
	lM2 = set(legal2)
	sumL = len(lM) + len(lM2)
	if periods == 0 or sumL == 0: 
		#print("DIFFERENCE: ", [evalBoard(board, nextToken, oppToken)])
		#print("---------------------------------------------------")
		return [evalBoard(board, player, otherplayer)]
	#if board.count(".") == 0:
		#return [evalBoard(board, player, otherplayer)]
	
	if not lM: 
		#print("EMPTY SET...SIMULATING NEXT MOVE")
		nm = negaMax(board, otherplayer, player, levels-1,legal,periods) + [-1]
		#print(otherplayer,player)
		return [-nm[0]] + nm[1:]
	nmList = sorted([negaMax(makeMove(board, player, move,otherplayer), otherplayer,player, levels-1 ,lM,periods-1) + [move] for move in lM])
	best = nmList[0]
	#print("BEST: ", best)
	#print("BEST: ", best)
	return [-best[0]] + best[1:]

def negaMax2(board, player, otherplayer, levels,legal):
	#displayBoard(board)
	legal = legalMoves2(board,player,otherplayer)
	legal2 = legalMoves2(board,otherplayer,player)


	'''
	if(player == nextToken):
		print("simulating my move".upper())
	else:
		print("simulating opponent's move".upper())
	'''
	lM  = set(removeCX(board,legal,player))
	lM2 = set(removeCX(board,legal2,otherplayer))
	sumL = len(lM) + len(lM2)
	if levels == 0 or sumL == 0: 
		#print("DIFFERENCE: ", [evalBoard(board, nextToken, oppToken)])
		#print("---------------------------------------------------")
		return [evalBoard2(board, player, otherplayer)]
	#if board.count(".") == 0:
		#return [evalBoard(board, player, otherplayer)]
	
	if not lM: 
		#print("EMPTY SET...SIMULATING NEXT MOVE")
		nm = negaMax2(board, otherplayer, player, levels-1,legal) + [-1]
		#print(otherplayer,player)
		return [-nm[0]] + nm[1:]
	nmList = sorted([negaMax2(makeMove(board, player, move,otherplayer), otherplayer,player, levels-1 ,lM) + [move] for move in lM])
	best = nmList[0]
	#print("BEST: ", best)
	#print("BEST: ", best)
	return [-best[0]] + best[1:]

def negamaxTerminal1(brd, token, improvable, hardBound):
	if token=='x':oppToken='o'
	else: oppToken='x'
	ls = legalMoves2(brd, token,oppToken)
	lm = list(ls)

	if not lm:
		lm2 = legalMoves2(brd, oppToken,token)
		if not lm2:
			return[evalBoard(brd,token,oppToken), -3]
		nm = negamaxTerminal1(brd, oppToken, -hardBound, -improvable)+[-1]
		return [-nm[0]]+nm[1:]

	best, newHB =[], -improvable #what gets returned

	for mv in lm:
	  nm = negamaxTerminal1(makeMove(brd,token,mv,oppToken), oppToken, -hardBound, newHB) +[mv]

	  if not best or nm[0] < newHB:
	      best=nm
	      if nm[0]< newHB:
	        newHB=nm[0]
	        if -newHB > hardBound: return [-best[0]]+best[1:] #pruning
	return [-best[0]]+best[1:]

 

def removeCX(board,legalMoves,nextToken):
	lm = list(legalMoves.intersection(set([1,8,9,6,14,15,48,49,57,54,55,62])))
	lmk = legalMoves.copy()
	lst = legalMoves.copy()
	for l in lm:
		lmk.remove(l)

	if(len(lmk) != 0):
		if(1 in legalMoves and board[0] != nextToken):
			lst.remove(1)
		if(8 in legalMoves and board[0] != nextToken):
			lst.remove(8)
		if(9 in legalMoves and board[0] != nextToken):
			lst.remove(9)
		if(6 in legalMoves and board[7] != nextToken):
			lst.remove(6)
		if(14 in legalMoves and board[7] != nextToken):
			lst.remove(14)
		if(15 in legalMoves and board[7] != nextToken):
			lst.remove(15)
		if(48 in legalMoves and board[56] != nextToken):
			lst.remove(48)
		if(49 in legalMoves and board[56] != nextToken):
			lst.remove(49)
		if(57 in legalMoves and board[56] != nextToken):
			lst.remove(57)
		if(54 in legalMoves and board[63] != nextToken):
			lst.remove(54)
		if(55 in legalMoves and board[63] != nextToken):
			lst.remove(55)
		if(62 in legalMoves and board[63] != nextToken):
			lst.remove(62)
		return lst
	else:
		return legalMoves





def movePlayed(board,nextToken,legalMoves):

	if(nextToken == "x"):
		oppToken = "o"
	else:
		oppToken = "x"

	lst = removeCX(board,legalMoves,nextToken)
	l01 = list(legalMoves.intersection(set([1,2,3,4,5,6])))
	l02 = list(legalMoves.intersection(set([8,16,24,32,40,48])))
	l71 = l01[::-1]
	l72 = list(legalMoves.intersection(set([15,23,31,39,47,55])))
	l561 = l02[::-1]
	l562 = list(legalMoves.intersection(set([57,58,59,60,61,62])))
	l631 = l72[::-1]
	l632 = l562[::-1]





	str = "not found"
	dep = 12

	if(board.count(".") > 8):
		if(0 in lst): 
			return(0)
			str = "found"
		elif(7 in lst):
			return(7)
			str = "found"
		elif(56 in lst):
			return(56)
			str = "found"
		elif(63 in lst):
			return(63)
			str = "found"
		elif(16 in lst and board[8] == oppToken and board[24] == oppToken):
			print("WEDGE")
			return(16)
			str = "found"
		elif(2 in lst and board[1] == oppToken and board[3] == oppToken):
			return(2)
			str = "found"
		elif(23 in lst and board[15] == oppToken and board[31] == oppToken):
			return(23)
			str = "found"
		elif(5 in lst and board[4] == oppToken and board[6] == oppToken):
			return(5)
			str = "found"
		elif(40 in lst and board[32] == oppToken and board[48] == oppToken):
			return(40)
			str = "found"
		elif(58 in lst and board[57] == oppToken and board[59] == oppToken):
			return(58)
			str = "found"
		elif(47 in lst and board[55] == oppToken and board[39] == oppToken):
			return(47)
			str = "found"
		elif(61 in lst and board[60] == oppToken and board[62] == oppToken):
			return(61)
			str = "found"
		else:
			if(board[0] == nextToken):
				arg = 0
				for l in l01:
					for i in range(1,l):
						if board[i] != oppToken or board[i] != nextToken:
							arg = 1
							break
					if(arg == 1):
						break
					if(arg == 0):
						return(l)
						str = "found"
						strD = "done"
						break
			if(str == "not found"):
				if(board[0] == nextToken):
					arg = 0
					for l in l02:
						for i in range(8,l,8):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break

						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(board[7] == nextToken):
					arg = 0
					for l in l71:
						for i in range(l+1,7):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(board[7] == nextToken):
					arg = 0
					for l in l72:
						for i in range(15,l,8):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(board[56] == nextToken):
					arg = 0
					for l in l561:
						for i in range(l+8,56,8):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(board[56] == nextToken):
					arg = 0
					for l in l562:
						for i in range(57,l):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(board[63] == nextToken):
					arg = 0
					for l in l631:
						for i in range(l+8,63,8):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(board[63] == nextToken):
					arg = 0
					for l in l632:
						for i in range(l+1,63):
							if board[i] != oppToken or board[i] != nextToken:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				lk = lst.copy()
				for s in edges:
					if(s in lk):
						lk.remove(s)
				lt = list(lk)
				if(len(lt) != 0):
					move = negaMax2(board, nextToken, oppToken, 3,legalMoves)
					return move[len(move)-1]
					#return(lt[random.randint(0,len(lt)-1)])
				else:
					la = lst.copy()
					ll = list(la)
					move = negaMax2(board, nextToken, oppToken, 3,legalMoves)
					return move[len(move)-1]
					#return(ll[random.randint(0,len(ll)-1)])


	#if(board.count(".") <= dep):
	else:
		move = negaMax(board, nextToken, oppToken, -1,legalMoves,board.count("."))
		return move[len(move)-1]

	

	
'''
if(1 in legalMoves(board) and board[0] != nextToken):
	lst.remove(1)
	print(lst[random.randint(0,len(lst)-1)])
elif(8 in legalMoves(board) and board[0] != nextToken):
	lst.remove(8)
	print(lst[random.randint(0,len(lst)-1)])
elif(9 in legalMoves(board) and board[0] != nextToken):
	lst.remove(9)
	print(lst[random.randint(0,len(lst)-1)])
elif(6 in legalMoves(board) and board[7] != nextToken):
	lst.remove(6)
	print(lst[random.randint(0,len(lst)-1)])
elif(14 in legalMoves(board) and board[7] != nextToken):
	lst.remove(14)
	print(lst[random.randint(0,len(lst)-1)])
elif(15 in legalMoves(board) and board[7] != nextToken):
	lst.remove(15)
	print(lst[random.randint(0,len(lst)-1)])
elif(48 in legalMoves(board) and board[56] != nextToken):
	lst.remove(48)
	print(lst[random.randint(0,len(lst)-1)])
elif(49 in legalMoves(board) and board[56] != nextToken):
	lst.remove(49)
	print(lst[random.randint(0,len(lst)-1)])
elif(57 in legalMoves(board) and board[56] != nextToken):
	lst.remove(57)
	print(lst[random.randint(0,len(lst)-1)])
elif(54 in legalMoves(board) and board[63] != nextToken):
	lst.remove(54)
	print(lst[random.randint(0,len(lst)-1)])
elif(55 in legalMoves(board) and board[63] != nextToken):
	lst.remove(55)
	print(lst[random.randint(0,len(lst)-1)])
elif(62 in legalMoves(board) and board[63] != nextToken):
	lst.remove(62)
	print(lst[random.randint(0,len(lst)-1)])
'''


'''
elif(list(legalMoves(board).intersection(set([1,2,3,4,5,6])))):
	arg = 0
	if board[0] == nextToken:
		for l in list(legalMoves(board).intersection(set([1,2,3,4,5,6]))):
			for i in range(1,l):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	elif board[7] == nextToken:
		for l in list(legalMoves(board).intersection(set([1,2,3,4,5,6]))):
			for i in range(l+1,7):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	else:
		for l in legalMoves(board).intersection(set([8,16,24,32,40,48])):
			lst.remove(l)
		print(lst[random.randint(0,len(lst)-1)])


elif(list(legalMoves(board).intersection(set([57,58,59,60,61,62])))):
	arg = 0
	if board[56] == nextToken:
		for l in list(legalMoves(board).intersection(set([57,58,59,60,61,62]))):
			for i in range(57,l):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	elif board[63] == nextToken:
		for l in list(legalMoves(board).intersection(set([57,58,59,60,61,62]))):
			for i in range(l+1,63):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	else:
		for l in legalMoves(board).intersection(set([8,16,24,32,40,48])):
			lst.remove(l)
		print(lst[random.randint(0,len(lst)-1)])


elif(list(legalMoves(board).intersection(set([8,16,24,32,40,48])))):
	arg = 0
	if board[0] == nextToken:
		for l in list(legalMoves(board).intersection(set([8,16,24,32,40,48]))):
			for i in range(8,l,8):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	elif board[56] == nextToken:
		for l in list(legalMoves(board).intersection(set([8,16,24,32,40,48]))):
			for i in range(l+8,56,8):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	else:
		for l in legalMoves(board).intersection(set([8,16,24,32,40,48])):
			lst.remove(l)
		print(lst[random.randint(0,len(lst)-1)])



elif(list(legalMoves(board).intersection(set([15,23,31,39,47,55])))):
	arg = 0
	if board[7] == nextToken:
		for l in list(legalMoves(board).intersection(set([15,23,31,39,47,55]))):
			for i in range(15,l,8):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	elif board[63] == nextToken:
		for l in list(legalMoves(board).intersection(set([15,23,31,39,47,55]))):
			for i in range(l+8,63,8):
				if board[i] != oppToken:
					arg = 1
		if arg == 0:
			print(l)
		else:
			lst.remove(l)
			print(lst[random.randint(0,len(lst)-1)])
	else:
		for l in legalMoves(board).intersection(set([8,16,24,32,40,48])):
			lst.remove(l)
		print(lst[random.randint(0,len(lst)-1)])
'''





#displayBoard(board.lower())
#print "\n"
#displayBoardwithAsterisks(board.lower(),legalMoves(board.lower()))
#print "\n"
#print board
#print ("\n")
#print((legalMoves(board.lower())))