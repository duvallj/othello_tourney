import sys, time, random
weights = [0,   0,   0,   0,   0,   0,   0,   0,   0,   0,\
           0,  120,  -50,  11,   8,   8,  11,  -50,  120,   0,\
           0,  -50,-110,  -3,   1,   1,  -3,-110,  -50,   0,\
           0,  11,  -5,   2,   2,   2,   2,  -3,  11,   0,\
           0,   8,   1,   2,  -3,  -3,   2,  1,    8,   0,\
           0,   8,   1,   2,  -3,  -3,   2,  1,    8,   0,\
           0,  11,  -3,   2,   2,   2,   2,  -3,  11,   0,\
           0,  -50,  -110,-3,   1,   1,  -3,-110,  -50,   0,\
           0,  120,  -50,  11,   8,   8,  11,  -50,  120,   0,\
           0,   0,   0,   0,   0,   0,   0,   0,   0,   0]
def alphabeta(node, player, depth, alpha, beta, moves):
    board = node.board
    if depth == 0:
        node.score = evalBoard(board, player, moves)
        return node
    best = -float("INF") if player == "O" else float("INF")
    bestNode = Node(board, None, best)
    for move in moves:
        next_board = makeMove(board.copy(), player, moves[move])
        next_player = "X" if player == "O" else "O"
        nextMoves = getValidMoves(next_board, next_player)
        if len(nextMoves) == 0:
            next_player = "X" if next_player == "O" else "O"
            nextMoves = getValidMoves(next_board, next_player)
            if len(nextMoves) == 0: #game over -- not specific enough?
                return Node(next_board, move, score=1000*finalEval(next_board))
        c = Node(next_board, move)
        c.score = alphabeta(c, next_player, depth-1, alpha, beta, nextMoves).score
        if best == c.score: #randomize in event of scores being the same
            bestNode = max(bestNode, c)
        else:
            best = max(best, c.score) if player == "O" else min(best, c.score)
            if best == c.score:
                bestNode = c
        if player == "O":
            alpha = max(best, alpha)
        else:
            beta = min(best, beta)
        if alpha>beta:
            break
    return bestNode
def getValidMoves(board, token):
    moves = {}
    for move in range(len(board)):
        tiles = isValid(board, move, token)
        if len(tiles):
            moves[move] = tiles
    return moves
def evalBoard(board, token, moves): #sum of valid moves*-1?             best O move - best X move            sum of valid moves - sum of valid opponent moves //// sum own moves/2 - sum opponent moves
    total = 0
    for i in range(len(board)):
        if board[i] == "O":
            total += weights[i]
        if board[i] == "X":
            total -= weights[i]
    return total
def finalEval(board):
    return len([i for i in board if i=="O"])-len([i for i in board if i=="X"])
def isValid(game, pos, token):
    master = set()
    opposite = "X"
    if token == "X":
        opposite = "O"
    increments = [1, -1, 9, -9, 11, -11, 10, -10]
    if game[pos]!=".":
        return set()
    for i in range(len(increments)):
        tempSet = {pos}
        nextPos = pos+increments[i]
        tempSet.add(nextPos)
        if i>1 and abs(nextPos//10-pos//10)!=1:
            continue
        if i<2 and abs(nextPos//10-pos//10)!=0:
            continue
        if game[nextPos] != opposite:
            continue
        while game[nextPos] != token:
            prevPos = nextPos
            nextPos += increments[i]
            if i>1 and abs(nextPos//10-prevPos//10)!=1:
                break
            if i<2 and abs(nextPos//10-prevPos//10)!=0:
                break
            if game[nextPos] == "?" or game[nextPos] == ".":
                break
            if game[nextPos] == token:
                master.update(tempSet)
            tempSet.add(nextPos)
    return master
def makeMove(game, turn, indexes):
    for move in indexes:
        game[move] = turn
    return game
def getArgs():
    board = "???????????........??........??........??...OX...??...XO...??........??........??........???????????"  #"...........................OX......XO..........................."
    turn = "X"
    if len(sys.argv) >= 2:
        board = sys.argv[1].upper()
    if len([x for x in board if x!="."])%2:
        turn = "O"
    if len(sys.argv) >= 3:
        turn = sys.argv[2].upper()
    return board, turn
def findBestMove2(board, token):
    board = list(board)
    moves = getValidMoves(board, token)
    print(moves)
    mv = alphabeta(Node(board, None), token, 5, -float("INF"), float("INF"), moves).move
    print(mv)
def printBoard(board):
    for i in range(10):
        print(board[10*i:10*(i+1)])
class Node():
    def __init__(self, board, move, score=None):
        self.board = board
        self.move = move
        self.score = score
    def __lt__(self, other):
        return random.random()<.5
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        brd = list("".join(board).replace("@","X").upper())
        token = "X" if player == "@" else "O"
        moves = getValidMoves(brd, token)
        if len([i for i in brd if i=="."])<10:
            best_move.value = alphabeta(Node(brd, None), token, 1000, -float("INF"), float("INF"), moves).move
        depth = 3
        moves = getValidMoves(brd, token)
        while True:
            best_move.value = alphabeta(Node(brd, None), token, depth, -float("INF"), float("INF"), moves).move #if depth>=5 else -1
        #best_move.value=alphabeta(Node(brd, None), token, 5, -float("INF"), float("INF"), moves).move# if depth>=7 else -1
            depth += 2
def main():
    findBestMove2(*getArgs())
if __name__ == "__main__":
    main()
