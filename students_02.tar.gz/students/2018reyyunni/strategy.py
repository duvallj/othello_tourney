# Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

scoring_matrix = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [OUTER] * 100
        for i in [i for i in range(11, 89) if 1 <= (i % 10) <= 8]:
            board[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        strboard = ''.join(board)
        return strboard

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        str = ""
        for i in range(0, 100):
            if i > 0 and i % 10 == 0:
                str = str + '\n'
            str = str + board[i]
        return str

    def opponent(self, player):
        """Get player's opponent."""
        if player == WHITE:
            return BLACK
        else:
            return WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        #opp = self.opponent(player)
        if board[square + direction] == player:  # if adjacent to player
            return None
        i = square
        while not board[i] == player:
            i += direction
            if board[i] == EMPTY or board[i] == OUTER:
                return None

        return i

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        for d in DIRECTIONS:
            match = self.find_match(board, player, move, d)
            if match is not None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        s = list(board)

        # s[move] = player
        dirs = []
        # endpoints = []
        for d in DIRECTIONS:
            possiblem = self.find_match(board, player, move, d)
            if possiblem is not None:
                dirs.append(d)
                # endpoints.append(possiblem)
        # endpoints and dirs will have same length-
        for n in dirs:
            i = move
            while s[i] is not player:
                s[i] = player
                i += n

        board2 = ''.join(s)

        return board2

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""

        moves = list()
        for i in range(0, len(board)):
            if board[i] is EMPTY:
                valid = self.is_move_valid(board, player, i)
                if valid is True:
                    moves.append(i)
        return moves

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        for i in range(0, len(board)):
            if board[i] is EMPTY:
                valid = self.is_move_valid(board, player, i)
                if valid is True:
                    return True
        return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        player = self.opponent(prev_player)
        v1 = self.has_any_valid_moves(board, player)
        if v1 is True:
            return player
        else:
            v2 = self.has_any_valid_moves(board, prev_player)
            if v2 is True:
                return prev_player
        return None

    def gscore(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        blacks = 0
        whites = 0
        for i in range(0, len(board)):
            if board[i] == BLACK:
                blacks += 1
            elif board[i] == WHITE:
                whites += 1
        game_score = blacks - whites

        return game_score
    def score(self, board, player=BLACK):
        blacks = 0
        whites = 0
        for i in range(0, len(board)):
            if board[i] == BLACK:
                blacks += scoring_matrix[i]
            elif board[i] == WHITE:
                whites += scoring_matrix[i]
        game_score = blacks - whites
        return game_score

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        player_turn = self.next_player(board, player)
        if player_turn is None:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth, a, b):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if self.game_over(board, player):
          g_score = self.gscore(board, player=BLACK) * 1000000
          return g_score
        if depth == 0:
            s = self.score(board, player=BLACK)
            return s

        possiblemoves = self.get_valid_moves(board, player)
        children = set()
        for m in possiblemoves:
            if a > b:
              break
            newboard = self.make_move(board, player, m)
            nextp = self.next_player(newboard, player)
            if nextp is None: #game over
                score = self.score(newboard, player=BLACK)
                children.add((score, m))
            else:
                new_depth = depth - 1
                score = self.minmax_search(newboard, nextp, new_depth, a, b)
                if score > a:
                  a = score
                elif score < b:
                  b = score
                children.add((score, m))
        #if player == BLACK: return max(children, key=lambda c: c)
        #if player == WHITE: return min(children, key=lambda c: c)
        if player == BLACK:
            tup = max(children)
            return tup[1]
        if player == WHITE:
            tup = min(children)
            return tup[1]



    def minmax_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(board, player, depth, -math.inf,math.inf)

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        if(isinstance(board, list)):
          board = "".join(board)
        
        best_move.value = self.random_strategy(board, player)
          
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player)
            depth += 1

    standard_strategy = minmax_strategy

###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.random_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.gscore(board), end=" ")
        print("%s wins" % ("Black" if ref.gscore(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


        # game =  ParallelPlayer(0.1)


game = StandardPlayer()
game.play()