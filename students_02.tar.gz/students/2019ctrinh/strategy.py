import sys, heapq, random

alpha = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5, "G": 6, "H": 7}
dct = {}


class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		brd = ''.join(board).replace('?', '').replace('@', 'X')
		token = "X" if player == '@' else 'o'
		mv = findBestMove(brd, token)
		mv1 = 11 + (mv // 8) * 10 + (mv % 8)
		best_move.value = mv1


def findBestMove(board, token):
	moves = legalMoves(board, token)
	choices = []
	for move in moves.keys():
		if move == 0 or move == 7 or move == 56 or move == 63:
			if board.count(".") > 18:
				print("My Heuristic choice is {}".format(move))
				return move
			heapq.heappush(choices, (move, 1))
		else:
			new = makeMove(board, token, move)
			if int(move / 8) == 0 or int(move / 8) == 7:
				# check to the left
				temp = move - 1
				while temp % 8 >= 0:
					if new[temp] != token:
						break
					elif temp == 0 or temp == 56:
						if (move != 1 and move != 57) or new[move - 1] == token:
							heapq.heappush(choices, (move, 2))
						else:  # c
							heapq.heappush(choices, (move, 5))
						break
					temp -= 1
				# check to the right
				temp = move + 1
				while temp % 8 <= 7:
					if new[temp] != token:
						break
					elif temp == 7 or temp == 63:
						if (move != 6 and move != 62) or new[move + 1] == token:
							heapq.heappush(choices, (move, 2))
						else:  # c
							heapq.heappush(choices, (move, 5))
						break
					if temp % 8 == 7:
						break
					temp += 1
			elif move % 8 == 0 or move % 8 == 7:
				# check above
				temp = move - 8
				while temp >= 0:
					if new[temp] != token:
						break
					elif temp == 0 or temp == 7:
						if (move != 8 and move != 15) or new[move - 8] == token:
							heapq.heappush(choices, (move, 2))
						else:
							heapq.heappush(choices, (move, 5))
						break
					temp -= 8
				# check below
				temp = move + 8
				while temp < 64:
					if new[temp] != token:
						break
					elif temp == 56 or temp == 63:
						if (move != 48 and move != 55) or new[move + 8] == token:
							heapq.heappush(choices, (move, 2))
						else:  # c
							heapq.heappush(choices, (move, 5))
						break
					temp += 8
			elif 0 < move // 8 < 7 and 0 < move % 8 < 7:
				if 1 < move // 8 < 6 or 1 < move % 8 < 6:
					heapq.heappush(choices, (move, 3))
				elif (move == 9 and new[0] == token) or (move == 14 and new[7] == token) or (
							move == 49 and new[56] == token) or (move == 54 and new[63] == token):
					heapq.heappush(choices, (move, 3))
				else:  # x
					heapq.heappush(choices, (move, 5))
			else:
				heapq.heappush(choices, (move, 4))
	if len(choices) > 0:
		choice = heapq.heappop(choices)[0]
	else:
		choice = random.choice([*moves.keys()])
	print("My Heuristic choice is {}".format(choice))
	if board.count(".") > 18:
		return choice
	else:
		nm = negamaxTerminal(board, token, -65, 65)
		print("negamaxTerminal returns {} and I choose move {}".format(nm, nm[-1]))
		return nm[-1]


def legalMoves(board, t):
	if (board, t) in dct:
		return dct[(board, t)]
	legal = {}
	enemies = []
	for i in range(64):
		if board[i] != t and board[i] != ".":
			enemies.append(i)
	for pos in enemies:
		# place piece to the left of an enemy
		if 0 < pos % 8 < 7:
			if board[pos - 1] == ".":
				temp = pos + 1
				while temp % 8 <= 7 and temp < 64:
					if board[temp] == ".":
						break
					elif board[temp] == t:
						if pos - 1 not in legal:
							legal[pos - 1] = []
						legal[pos - 1].append(("L", temp))
						break
					if temp % 8 == 7:
						break
					temp += 1
		# place piece to the right of an enemy
		if 0 < pos % 8 < 7:
			if board[pos + 1] == ".":
				temp = pos - 1
				while temp % 8 >= 0 and temp >= 0:
					if board[temp] == ".":
						break
					elif board[temp] == t:
						if pos + 1 not in legal:
							legal[pos + 1] = []
						legal[pos + 1].append(("R", temp))
						break
					if temp % 8 == 0:
						break
					temp -= 1
		# place piece above an enemy
		if pos > 7:
			if board[pos - 8] == ".":
				temp = pos + 8
				while temp < 64:
					if board[temp] == ".":
						break
					elif board[temp] == t:
						if pos - 8 not in legal:
							legal[pos - 8] = []
						legal[pos - 8].append(("A", temp))
						break
					temp += 8
			# diag above, moves LR
			if 8 < pos < 56 and 0 < pos % 8 < 7:
				if board[pos - 9] == ".":
					temp = pos + 9
					while temp < 64:
						if board[temp] == ".":
							break
						elif board[temp] == t:
							if pos - 9 not in legal:
								legal[pos - 9] = []
							legal[pos - 9].append(("ALR", temp))
							break
						if temp % 8 == 7:
							break
						temp += 9
			# diag above, moves RL
			if 8 < pos < 56 and 7 > pos % 8 > 0:
				if board[pos - 7] == ".":
					temp = pos + 7
					while temp < 64:
						if board[temp] == ".":
							break
						elif board[temp] == t:
							if pos - 7 not in legal:
								legal[pos - 7] = []
							legal[pos - 7].append(("ARL", temp))
							break
						if temp % 8 == 0:
							break
						temp += 7
		# place piece below enemy
		if pos < 56:
			if board[pos + 8] == ".":
				temp = pos - 8
				while temp >= 0:
					if board[temp] == ".":
						break
					elif board[temp] == t:
						if pos + 8 not in legal:
							legal[pos + 8] = []
						legal[pos + 8].append(("B", temp))
						break
					temp -= 8
			# diag below, moves RL
			if 56 > pos > 8 and 7 > pos % 8 > 0:
				if board[pos + 9] == ".":
					temp = pos - 9
					while temp >= 0:
						if board[temp] == ".":
							break
						elif board[temp] == t:
							if pos + 9 not in legal:
								legal[pos + 9] = []
							legal[pos + 9].append(("BRL", temp))
							break
						if temp % 8 == 0:
							break
						temp -= 9
			# diag below, moves LR
			if 56 > pos > 8 and 0 < pos % 8 < 7:
				if board[pos + 7] == ".":
					temp = pos - 7
					while temp >= 0:
						if board[temp] == ".":
							break
						elif board[temp] == t:
							if pos + 7 not in legal:
								legal[pos + 7] = []
							legal[pos + 7].append(("BLR", temp))
							break
						if temp % 8 == 7:
							break
						temp -= 7
	dct[(board, t)] = legal
	return legal


def makeMove(board, t, pos):
	moves = legalMoves(board, t)
	if len(moves) == 0 or pos not in moves:
		return board
	pb = board[:pos] + t + board[pos + 1:]
	flips = []
	for rel, end in moves[pos]:
		if rel == "L":
			flips.extend([*range(pos, end)])
		elif rel == "R":
			flips.extend([*range(end, pos)])
		elif rel == "A":
			flips.extend([*range(pos, end, 8)])
		elif rel == "B":
			flips.extend([*range(end, pos, 8)])
		elif rel == "ALR":
			flips.extend([*range(pos, end, 9)])
		elif rel == "ARL":
			flips.extend([*range(pos, end, 7)])
		elif rel == "BLR":
			flips.extend([*range(end, pos, 7)])
		else:  # BRL
			flips.extend([*range(end, pos, 9)])
	final = ''.join(t if i in flips else char for i, char, in enumerate(pb))
	return final


def negamaxTerminal(brd, token, improvable, hardBound):
	if token == "X":
		enemy = "O"
	else:
		enemy = "X"
	lm = legalMoves(brd, token)
	if not lm:
		lm = legalMoves(brd, enemy)
		if not lm:
			return [evalBoard(brd, token), -3]
		nm = negamaxTerminal(brd, enemy, -hardBound, -improvable) + [-1]
		return [-nm[0]] + nm[1:]
	best = []
	newHB = -improvable
	for mv in lm:
		nm = negamaxTerminal(makeMove(brd, token, mv), enemy, -hardBound, newHB) + [mv]
		if not best or nm[0] < newHB:
			best = nm
			if nm[0] < newHB:
				newHB = nm[0]
				if -newHB > hardBound:
					return [-best[0]] + best[1:]
	return [-best[0]] + best[1:]


def evalBoard(board, token):
	if token == "X":
		enemy = "O"
	else:
		enemy = "X"
	return board.count(token) - board.count(enemy)


def main():
	board = "." * 27 + "OX" + "." * 6 + "XO" + "." * 27
	token = "X"
	for arg in sys.argv[1:]:
		if len(arg) > 1:
			board = arg.upper()
			if board.count(".") % 2 == 0:
				token = "X"
			else:
				token = "O"
		else:
			token = arg.upper()
	print("\n".join(board[i:i + 8] for i in range(0, 57, 8)))
	print("Possible Moves: ", {*legalMoves(board, token).keys()})
	mv = findBestMove(board, token)
	# print(mv)
	sys.exit(0)


if __name__ == "__main__":
	main()
	
	# XXXXXXXOXOXXOOOOXOXXXOO.XOXXOOX.XOOOOXXOXXOOOOO.XO.XOO.......... X