import Othello_Core as core
import random
import math
#Vibhu Kundeti
class Strategy(core.OthelloCore):

    def initial_board(self):
        board = [OUTER] * 100
        for i in self.squares():
            board[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        return board

    def is_valid(self, move):
        
        return isinstance(move, int) and move in self.squares()


    def opponent(self, player):
        
        if player == 'o':
            return '@'
        return 'o'


    def find_bracket(self, square, player, board, direction):
        
        bracket = square + direction
        if board[bracket] == player:
            return None
        opp = self.opponent(player)
        while board[bracket] == opp:
            bracket += direction
        return None if board[bracket] in (core.OUTER, core.EMPTY) else bracket


    def is_legal(self, move, player, board):
        hasbracket = lambda direction: self.find_bracket(move, player, board, direction)
        return board[move] == core.EMPTY and any(map(hasbracket, core.DIRECTIONS))


    ### Making moves

    # When the player makes a move, we need to update the board and flip all the
    # bracketed pieces.

    def make_move(self, move, player, board):
        
        if not self.is_legal(move, player, board):
            raise self.IllegalMoveError(player, move, board)
        board[move] = player
        for d in core.DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board


    def make_flips(self, move, player, board, direction):
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction


  

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (core.PLAYERS[self.player], self.move)


    def legal_moves(self, player, board):
        
        x = []
        for row in range(1, 9):
            for column in range(10 * row +1, 10 * row +9):
               if self.is_legal( column, player, board):
                   x.append(column)
                                
        return x
        

    def any_legal_move(self, player, board):
     
        if len(self.legal_moves( player, board)) > 0:
                return True
        return False


    def next_player(self,board, prev_player):
        if prev_player == '@':
            if self.any_legal_move( 'o', board):
                return 'o'
            if self.any_legal_move( '@', board):
                return '@'
        if prev_player == 'o':
            if self.any_legal_move( '@', board):
                return '@'
            if self.any_legal_move( 'o', board):
                return 'o'
        return None

    def score(self,player, board):
      
        score = 0
        
        for x in board:
            
                
            if x == player:
                score = score +1
            if x == '.' or '?':
                score = score
            else:
                score = score -1
            return score

     

    M = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    def weighted_score(self, player, board):
        
        opp = self.opponent(player)
        total = 0
        for sq in self.squares():
            if board[sq] == player:
                total += self.M[sq]
            elif board[sq] == opp:
                total -= self.M[sq]
        return total
    def final_value(self, player, board):
        
        diff = self.score(player, board)
        if diff < 0:
            return -999999
        elif diff > 0:
            return 999999
        return diff
    def alphabeta(self, player, board, alpha, beta, depth, evaluate):
        
        if depth == 0:
            return evaluate(player, board), None

        def value(board, alpha, beta):
           
            return -self.alphabeta(self.opponent(player), board, -beta, -alpha, depth - 1, evaluate)[0]

        moves = self.legal_moves(player, board)
        if not moves:
            if not self.any_legal_move(self.opponent(player), board):
                return self.final_value(player, board), None
            return value(board, alpha, beta), None

        best_move = moves[0]
        for move in moves:
            if alpha >= beta:
               
                break
            val = value(self.make_move(move, player, list(board)), alpha, beta)
            if val > alpha:
                alpha = val
                best_move = move
        return alpha, best_move

    
        
   

    

    def best_strategy(self, board, player, best_move, still_running):
            depth = 4
            
            while(True):
                best_move.value = self.alphabeta(player, board,-999999, 999999, 4, self.weighted_score)[1]
                depth += 1
