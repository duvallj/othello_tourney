import sys, random

class Strategy():
    def best_strategy(self, board, player, best_move, running):
        game = "".join(board)
        game = game.replace("?", "")
        game = game.replace("@", "X")
        game = game.replace("o", "O")
        playerToToken = {"@": "X", "o": "O"}
        player = playerToToken[player]
        opposite = "O" if player == "X" else "X"
        possSets = legalMoves(game, player, opposite)
        flag = True
        corners = {0, 7, 56, 63}
        edges = set().union({*range(8)}, {*range(56, 64)}, {8 * i for i in range(8)}, {7 + 8 * i for i in range(8)})
        cornerSet = corners & possSets
        if len(cornerSet) > 0:  # 1. you can play to a corner
            flag = False
            best_move.value = random.choice([*cornerSet])

        if flag:  # 2
            playingSet = set()
            for i in possSets:
                if i in edges:
                    nextGame = placeToken(game, player, opposite, i)
                    for xdir, ydir in [[1, 0], [0, 1], [-1, 0], [0, -1]]:
                        currentX, currentY = i % 8, i // 8
                        currentX += xdir
                        currentY += ydir
                        currentIndex = 8 * currentY + currentX
                        if currentX in range(8) and currentY in range(8) and currentIndex in edges and \
                                nextGame[currentIndex] == player:
                            while currentX in range(8) and currentY in range(8) and currentIndex in edges and \
                                    currentIndex not in corners and nextGame[currentIndex] == player:
                                currentX += xdir
                                currentY += ydir
                                currentIndex = 8 * currentY + currentX
                            if currentX in range(8) and currentY in range(8) and currentIndex in corners and \
                                    nextGame[currentIndex] == player:
                                playingSet.add(i)
            if len(playingSet) > 0:
                flag = False
                best_move.value = random.choice([*playingSet])

        if flag:  # 3. don't play to unprotected C or X
            cxLookupTable = {1: 0, 6: 7, 8: 0, 9: 0, 14: 7, 15: 7, 48: 56, 49: 56, 54: 63, 55: 63, 57: 56, 62: 63}
            for i in cxLookupTable:
                if i in possSets and len(possSets) > 1 and (game[cxLookupTable[i]] == "." or game[cxLookupTable[i]] == opposite):
                    possSets.remove(i)
            for i in edges:
                if i in possSets and len(possSets) > 1:
                    possSets.remove(i)
            best_move.value = random.choice([*possSets])

        if flag:
            best_move.value = random.choice([*possSets])

        if game.count(".") <= 8:
            best_move.value = negamax(game, player, opposite)

def main():
    game, player = "", ""
    tempList = []
    posList = []
    for i in sys.argv[1::]:
        tempList.append(i)

    for i in tempList:
        if len(i) > 10:
            game = i.upper()
        elif i[0] in "0123456789":
            posList.append(int(i))
        elif i[0].lower() in "abcdefgh":
            letter = i[0].lower()
            number = int(i[1])
            howFarX = 0 if letter == "a" else 1 if letter == "b" else 2 if letter == "c" else 3 if letter == "d" else 4 if letter == "e" else 5 if letter == "f" else 6 if letter == "g" else 7 if letter == "h" else "not valid"
            position = 8 * (number - 1) + howFarX
            posList.append(position)
        else:
            player = i.upper()

    opposite = "O" if player == "X" else "X"

    possSets = legalMoves(game, player, opposite)
    print("".join([(sym + "\n") if (i + 1) % 8 is 0 else sym + " " for i, sym in enumerate(game)]))
    print("Legal moves: " + str(possSets))

    flag = True
    corners = {0, 7, 56, 63}
    edges = set().union({*range(8)}, {*range(56, 64)}, {8 * i for i in range(8)}, {7 + 8 * i for i in range(8)})

    cornerSet = corners & possSets
    if len(cornerSet) > 0:  # 1. you can play to a corner
        flag = False
        print("My heuristic is safe corners and produces the move: " + str(random.choice([*cornerSet])))

    if flag:  # 2
        playingSet = set()
        for i in possSets:
            if i in edges:
                nextGame = placeToken(game, player, opposite, i)
                for xdir, ydir in [[1, 0], [0, 1], [-1, 0], [0, -1]]:
                    currentX, currentY = i % 8, i // 8
                    currentX += xdir
                    currentY += ydir
                    currentIndex = 8 * currentY + currentX
                    if currentX in range(8) and currentY in range(8) and currentIndex in edges and nextGame[
                        currentIndex] == player:
                        while currentX in range(8) and currentY in range(
                                8) and currentIndex in edges and currentIndex not in corners and nextGame[currentIndex] == player:
                            currentX += xdir
                            currentY += ydir
                            currentIndex = 8 * currentY + currentX
                        if currentX in range(8) and currentY in range(8) and currentIndex in corners and nextGame[
                            currentIndex] == player:
                            playingSet.add(i)
        if len(playingSet) > 0:
            flag = False
            print("My heuristic is safe edges and produces the move: " + str(random.choice([*playingSet])))

    if flag:  # 3. don't play to unprotected C or X
        cxLookupTable = {1: 0, 6: 7, 8: 0, 9: 0, 14: 7, 15: 7, 48: 56, 49: 56, 54: 63, 55: 63, 57: 56, 62: 63}
        for i in cxLookupTable:
            if i in possSets and len(possSets) > 1 and (
                    game[cxLookupTable[i]] == "." or game[cxLookupTable[i]] == opposite):
                possSets.remove(i)
        for i in edges:
            if i in possSets and len(possSets) > 1:
                possSets.remove(i)
        if len(possSets) > 1:
            flag = False
            print("My heuristic is don't play to an unsafe edge or c or x and produces the move: " + str(random.choice([*possSets])))

    if flag:
        print("My heuristic is nothing and produces the move: " + str(random.choice([*possSets])))

    if game.count(".") <= 7:
        negaOutput = negamax(game, player, opposite)
        print("Negamax score: " + str(negaOutput[0]) + ", and my move is " + str(negaOutput[-1]))

def negamax(board, player, opposite):
    playerLegalMoves = legalMoves(board, player, opposite)
    oppositeLegalMoves = legalMoves(board, opposite, player)
    if len(playerLegalMoves) == 0 and len(oppositeLegalMoves) == 0: #game is over
        return [board.count(player) - board.count(opposite)]
    if len(playerLegalMoves) == 0:
        nm = negamax(board, opposite, player) + [-1]
        return [-nm[0]] + nm[1::]
    nmList = [negamax(placeToken(board, player, opposite, move), opposite, player) + [move] for move in playerLegalMoves]
    best = sorted(nmList)[0]
    return [-best[0]] + best[1::]

def legalMoves(game, player, opposite):
    possSets = set()
    dotSet = {i for i, sym in enumerate(game) if sym == player}
    for index in dotSet:
        for xdirection, ydirection in [[1, 0], [-1, -1], [0, 1], [1, -1], [0, -1], [1, 1], [-1, 1], [-1, 0]]:
            currentX, currentY = index % 8, index // 8
            currentX += xdirection
            currentY += ydirection
            currentIndex = 8 * currentY + currentX
            if currentX in range(8) and currentY in range(8) and game[currentIndex] == opposite:
                while currentX in range(8) and currentY in range(8) and game[currentIndex] == opposite:
                    currentX += xdirection
                    currentY += ydirection
                    currentIndex = 8 * currentY + currentX
                if currentX in range(8) and currentY in range(8) and game[currentIndex] == ".":
                    possSets.add(currentIndex)
    return possSets

def placeToken(myGame, player, opposite, position):
    newGame = myGame[0:position] + player + myGame[position + 1::]
    for xdirection, ydirection in [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]:
        currentX, currentY = position % 8, position // 8
        currentX += xdirection
        currentY += ydirection
        currentIndex = 8 * currentY + currentX
        if currentX in range(8) and currentY in range(8) and newGame[currentIndex] == opposite:
            while currentX in range(8) and currentY in range(8) and myGame[currentIndex] == opposite:
                currentX += xdirection
                currentY += ydirection
                currentIndex = 8 * currentY + currentX
            if currentX in range(8) and currentY in range(8) and newGame[currentIndex] == player:
                newXDirection, newYDirection = xdirection * -1, ydirection * -1
                currentX += newXDirection
                currentY += newYDirection
                currentIndex = 8 * currentY + currentX
                while currentX in range(8) and currentY in range(8) and newGame[currentIndex] == opposite:
                    newGame = newGame[0:currentIndex] + player + newGame[currentIndex + 1::]
                    currentX += newXDirection
                    currentY += newYDirection
                    currentIndex = 8 * currentY + currentX
    return newGame

if __name__ == "__main__":
    main()
