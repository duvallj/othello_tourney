# Author: Suresh Patil
# Date: 2/06/18
# Period: 7
import sys,math,random, time

dBoardLength, dNumRows, dNumCols = 64, 8, 8
cacheDict = {}


nbrIndices = [[]]*64 # Controversial Code
tpos = -1

# NegaMax minimum number of blanks left in the string
minBlanksNegaMax = 13


for pos in range(dBoardLength):

	row, col = pos//dNumRows, pos%dNumCols

	nbrIndices[pos] = []

	#North
	trow, tcol = row - 1, col
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#North-West
	trow, tcol = row - 1, col - 1
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#West
	trow, tcol = row, col - 1
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#South-West
	trow, tcol = row + 1, col - 1
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#South
	trow, tcol = row + 1, col
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#South-East
	trow, tcol = row + 1, col + 1
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#East
	trow, tcol = row, col + 1
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

	#North-East
	trow, tcol = row - 1, col + 1
	if trow >= 0 and tcol >= 0 and trow < dNumRows and tcol < dNumCols: tpos = (trow*8) + tcol
	else: tpos = -1
	nbrIndices[pos].append(tpos)

def traverse(board, pos, passiveSymbol, direction, endSymbol):
	hopCount = 0
	tpos = pos
	while True:
		tpos = nbrIndices[tpos][direction]
		if tpos < 0: return 0, -1
		#elif board[tpos] != passiveColor:
		elif board[tpos] != passiveSymbol:
			if board[tpos] not in endSymbol: return 0, -1
			elif hopCount < 1: return 0, -1
			else: return hopCount, tpos
		else: hopCount += 1


def insertMove(currentBoard, nxtPlayer, nxtMove, toFill):

#Directional Hopcount List
	dirCountList = [0]*8

	if nxtPlayer == 'X': passiveColor = 'O'
	else: passiveColor = 'X' 

	for direction in range(8):
		#hopCount, termPos = (traverse(currentBoard, nxtMove, direction, nxtPlayer))
		hopCount, termPos = (traverse(currentBoard, nxtMove, passiveColor, direction, nxtPlayer))
		dirCountList[direction] += hopCount
	
	totalHopCount = sum(dirCountList)

	if (toFill and (totalHopCount > 0)):

		listBoard = list(currentBoard)

		listBoard[nxtMove] = nxtPlayer
		for direction in range(8):
			hopCount = dirCountList[direction]
			tpos = nxtMove
			while hopCount > 0:
				tpos = nbrIndices[tpos][direction]
				listBoard[tpos] = nxtPlayer
				hopCount -= 1    

		return totalHopCount, ''.join(listBoard) 


	else: return totalHopCount, currentBoard

def computePossibleMoves(board, activeColor):
	countList = [0]*64

	if activeColor == 'X': passiveColor = 'O'
	else: passiveColor = 'X'

	for pos in range(dBoardLength):
		if board[pos] == activeColor:
			possibilityList = []
			for direction in range(8):
				#hopCount, movePos = (traverse(board, pos, direction, '.'))
				hopCount, movePos = (traverse(board, pos, passiveColor, direction, '.'))
				countList[movePos] += hopCount

	posList = []
	for pos in range(dBoardLength):
		if countList[pos] > 0:
			# board = board[0:pos] + "*" + board[board+1:64]
			posList.append(pos)

	return posList, countList


# Redefined computePossibleMoves for negamax
def computePossibleMovesA(board, activeSymbol):
	countList = [0]*64
	if activeSymbol == 'X': passiveSymbol = 'O'
	else: passiveSymbol = 'X'

	if board+activeSymbol in cacheDict:
		return cacheDict[board+activeSymbol]

	for pos in range(dBoardLength):
		if board[pos] == activeSymbol:
			possibilityList = []
			for direction in range(8):
				#hopCount, movePos = (traverse(board, pos, direction, '.'))
				hopCount, movePos = (traverse(board, pos, passiveSymbol, direction, '.'))
				countList[movePos] += hopCount

	posList = []
	for pos in range(dBoardLength):
		if countList[pos] > 0:
			# board = board[0:pos] + "*" + board[board+1:64]
			posList.append(pos)

	cacheDict[board+activeSymbol] = posList

	return posList #, countList



def boardEval(board,token):
	if token == 'X':
		enemy = 'O'
	else: enemy = 'X'
	return board.count(token) - board.count(enemy)


# Redefined insertMove for negaMax
def insertMoveA(currentBoard, nxtPlayer, nxtMove):

#Directional Hopcount List
	dirCountList = [0]*8

	toFill = True

	if nxtPlayer == 'X': passiveSymbol = 'O'
	else: passiveSymbol = 'X'

	for direction in range(8):
		#hopCount, termPos = (traverse(currentBoard, nxtMove, direction, nxtPlayer))
		#hopCount, termPos = (traverse(currentBoard, nxtMove, passiveColor, direction, nxtPlayer))
		hopCount, termPos = (traverse(currentBoard, nxtMove, passiveSymbol, direction, nxtPlayer))
		dirCountList[direction] += hopCount
	
	totalHopCount = sum(dirCountList)

	if (toFill and (totalHopCount > 0)):

		listBoard = list(currentBoard)

		listBoard[nxtMove] = nxtPlayer
		for direction in range(8):
			hopCount = dirCountList[direction]
			tpos = nxtMove
			while hopCount > 0:
				tpos = nbrIndices[tpos][direction]
				listBoard[tpos] = nxtPlayer
				hopCount -= 1    

		return  ''.join(listBoard) #totalHopCount,


	else: return currentBoard #totalHopCount,

def negamax(board, token, levels, isPrevPass):
	if token == 'X':
		enemy = 'O'
	else: enemy = 'X'
	if not levels:
		return [boardEval(board,token)]
	lm = computePossibleMovesA(board, token)
	if not lm:
				# if isPrevPass is true; Game over
		if isPrevPass: return [boardEval(board,token)]
		nm = negamax(board, enemy, levels, True) + [-1]
		return [-nm[0]] + nm[1:]
        
	#nmList = sorted([negamax(insertMoveA(board,token, mv), enemy, levels-1) + [mv] for mv in lm])
	nmList = sorted([negamax(insertMoveA(board,token, mv), enemy, levels-1, False) + [mv] for mv in lm])
	# print("Token:", token, "Level:", levels, "nmList:", nmList)
	# time.sleep(10) # Debugging

	# if levels == maxLevels:
	# 	print(nmList)

	best = nmList[0]
	return [-best[0]] + best[1:]

def negamaxTerminal(board, token, improvable, hardBound, isPrevPass):
	if token == 'X':
		enemy = 'O'
	else: enemy = 'X'
	lm = computePossibleMovesA(board, token)
	if not lm:
		if isPrevPass: return [boardEval(board,token)] + [-3]
		nm = negamaxTerminal(board, enemy, -hardBound, -improvable, True) + [-1]
		return [-nm[0]] + nm[1:]
	best = []
	newHB = -improvable
	for mv in lm:
		nm = negamaxTerminal(insertMoveA(board,token, mv), enemy, -hardBound, newHB, False) + [mv]
		if not best or nm[0] < newHB:
			best = nm
			if nm[0] < newHB:
				newHB = nm[0]
				if -newHB >= hardBound: return [-best[0]] + best[1:]
	return [-best[0]] + best[1:]

#strategy.py
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
class Strategy():

#def traverse(board, pos, direction, endSymbol):
	traverse = traverse
	insertMove = insertMove
	computePossibleMoves = computePossibleMoves
	computePossibleMovesA = computePossibleMovesA
	boardEval = boardEval
	insertMoveA = insertMoveA
	negamax = negamax

	def my_search_strategy(self,board,player,depth):
		dBoardLength, dNumRows, dNumCols = 64, 8, 8

		# INDEPENDENT VARIABLE: How many unfilled spaces are left
		# Strictly for negamax
		maxLevels = depth

		activeColor = player
		if activeColor == 'X': passiveColor = 'O'
		else: passiveColor = 'X'


		start = time.time()

		posList, countList = computePossibleMoves(board, activeColor)
		posSet = set(posList)
		# print(posSet)
		corners = {0,7,56,63}

		if board.count('.') <= (depth):

			nm = negamaxTerminal(board, activeColor, -65, 65, False)
			finalStr = ''
			for x in nm:
				finalStr += (str(x) + ' ')
			return nm[-1]

		if len(corners&posSet) != 0:
			return (corners&posSet).pop()

		edges = [ [0, 1, 2, 3, 4, 5, 6, 7]
			, [0, 8, 16, 24, 32, 40, 48, 56]
			, [56, 57, 58, 59, 60, 61, 62, 63]
			, [7, 15, 23, 31, 39, 47, 55, 63]
			]

		for edge in edges:
			edgePosSet = set(edge) & posSet

			while len(edgePosSet) > 0:
				possPos = edgePosSet.pop()
				hc, tmpBoard = insertMove(board, activeColor, possPos, True)

				for edgePos in edge:
					if (edgePos == possPos):
						return possPos 
						
					if tmpBoard[edgePos] != activeColor: break
					
				revEdge = edge[::-1]

				for edgePos in revEdge:
					if (edgePos == possPos):
						return possPos
						
					if tmpBoard[edgePos] != activeColor: break

		avoid = set()
		for corner in corners:
			if board[corner] != activeColor:
				for nbr in nbrIndices[corner]:
					if nbr != -1:
						avoid.add(nbr)
		interPossSet = posSet-avoid

		if len(interPossSet) == 0:
			return posSet.pop()

		avoid = set()

		for pos in interPossSet:
			if -1 in nbrIndices[pos]:
				avoid.add(pos)
		finalPossSet = interPossSet - avoid

		if len(finalPossSet) == 0:
			finalPossSet = interPossSet	

		return finalPossSet.pop()



	def best_strategy(self, board, player, best_move, still_running):
		depth = 1
		while(True):
			playerToToken = {'@':'X', 'o':'O'}
			board = ''.join(board)
			board = board.replace('?', '')
			board = board.replace(BLACK, playerToToken[BLACK])
			board = board.replace(WHITE, playerToToken[WHITE])
			token = playerToToken[player]
			mv = self.my_search_strategy(board, token, depth)
			mxMove = 11+(mv//8)*10 + (mv%8)
			best_move.value = mxMove
			depth += 1


def printGrid(board):
	for i in range(dNumRows):
		print(board[i*dNumRows: (i+1)*dNumRows])

def printPosGrid(board, posList):
	printStr = board
	for pos in posList:
		printStr = printStr[0:pos] + '*' + printStr[pos + 1:]
	printGrid(printStr)

def main():
	dBoardLength, dNumRows, dNumCols = 64, 8, 8

	# INDEPENDENT VARIABLE: How many levels should negamax explore
	# Strictly for negamax
	# maxLevels = 14
	start = time.time()

	# board = '..................XXXO.X.OXXXXX..XXOOXOO...OXX....O.X...........'

	# activeColor = 'O'
	if len(sys.argv) == 1:
		board = "...........................OX......XO..........................."
		activeColor = 'X'
		passiveColor = 'O'
	elif len(sys.argv) == 2:
		if len(sys.argv[1]) == 64:
			board = sys.argv[1].upper()
			if board.count(".") % 2 == 0:
				activeColor = "X"
				passiveColor = "O"
			else:
				activeColor = "O"
				passiveColor = "X"
		else:
			board = "...........................OX......XO..........................."
			activeColor = sys.argv[1].upper()
			passiveColor = activeColor
			if activeColor == 'X': passiveColor = 'O'
			else: passiveColor = 'X'
	else:
		board = sys.argv[1].upper()
		activeColor = sys.argv[2].upper()
		passiveColor = activeColor
		if activeColor == 'X': passiveColor = 'O'
		else: passiveColor = 'X'


	start = time.time()
	#nbrIndices Initialization

	posList, countList = computePossibleMoves(board, activeColor)

	printPosGrid(board, posList)
	print()
	print("Legal Moves:", posList)
	print()


	posSet = set(posList)
	print(posSet)
	corners = {0,7,56,63}
	boolean = False
	string = ''

	if board.count('.') <= (minBlanksNegaMax):

		nm = negamaxTerminal(board, activeColor, -65, 65, False)
		finalStr = ''
		for x in nm:
			finalStr += (str(x) + ' ')
		string = ("Negamax Terminal: " + finalStr + " and my move is " + str(nm[-1]))
		boolean = True

	if len(corners&posSet) != 0:
		print("My Heuristic move is", str((corners&posSet).pop()))
		if boolean:
			print(string)
			print("Time taken: ", time.time() - start)
		sys.exit(0)

	edges = [ [0, 1, 2, 3, 4, 5, 6, 7]
		, [0, 8, 16, 24, 32, 40, 48, 56]
		, [56, 57, 58, 59, 60, 61, 62, 63]
		, [7, 15, 23, 31, 39, 47, 55, 63]
		]

	for edge in edges:
		edgePosSet = set(edge) & posSet

		while len(edgePosSet) > 0:
			possPos = edgePosSet.pop()
			hc, tmpBoard = insertMove(board, activeColor, possPos, True)

			for edgePos in edge:
				if (edgePos == possPos):
					print("My Heuristic move is", possPos) 
					if boolean:
						print(string)
						print("Time taken: ", time.time() - start)
					sys.exit(0)
					
				if tmpBoard[edgePos] != activeColor: break
				
			revEdge = edge[::-1]

			for edgePos in revEdge:
				if (edgePos == possPos):
					print("My Heuristic move is", possPos) 
					if boolean:
						print(string)
						print("Time taken: ", time.time() - start)
					sys.exit(0)
					
				if tmpBoard[edgePos] != activeColor: break

	avoid = set()
	for corner in corners:
		if board[corner] != activeColor:
			for nbr in nbrIndices[corner]:
				if nbr != -1:
					avoid.add(nbr)
	interPossSet = posSet-avoid

	if len(interPossSet) == 0:
		print("My Heuristic move is", posSet.pop())
		if boolean:
			print(string) 
			print("Time taken: ", time.time() - start)
		sys.exit(0)

	avoid = set()

	for pos in interPossSet:
		if -1 in nbrIndices[pos]:
			avoid.add(pos)
	finalPossSet = interPossSet - avoid

	if len(finalPossSet) == 0:
		finalPossSet = interPossSet	

	print("My Heuristic move is", finalPossSet.pop())
	if boolean:
		print(string)

	print("Time taken: ", time.time() - start)

if __name__ == "__main__":
    main()

#end of python file