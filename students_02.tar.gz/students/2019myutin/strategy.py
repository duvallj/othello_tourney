import sys
import random
import re

flip = {'x':'o','o':'x'}
adj = [-9, -8, -7, -1, 1, 7, 8, 9]
corn = {0, 7, 56, 63}
edges = [range(8), range(0, 57, 8), range(7, 64, 8), range(56, 64)]
setEdges = set().union(*[{*i} for i in edges])
neigh = [0]*64
for i in range(64):
  neigh[i] = [i+k if i+k >= 0 and i+k < 64 and (i%8 - (i+k)%8)**2 <= 1 else None for k in adj]
cxdict = {n:i for i in corn for n in neigh[i]}
n = 9

class Strategy():
  def best_strategy(self, board, player, best_move, still_running):
    board = list("".join(board).translate({ord('?'):'',ord('@'):'x'}))
    reset = board[:]
    player = player.replace('@','x')
    ret = hardcode(board, player)
    best_move.value = ret + 2 * (ret // 8) + 11
    board = reset[:]
    if board.count('.') <= n:
      ret = minimax(board, player, diffTile, float('-inf'), float('inf'), -1)[0]
      best_move.value = ret + 2 * (ret // 8) + 11
      
    
def legalMoves(board, turn):
  ret = []
  for i in range(64):
    if board[i] != '.':
      continue
    for dr in range(len(neigh[i])):
      if checkDir(board, turn, i, dr):
        ret.append(i)
        break
  return ret

def checkDir(board, turn, mov, dr):
  j = neigh[mov][dr]
  count = 0
  while True:
    if j == None:
      return False
    if board[j] == '.':
      return False
    if board[j] == turn:
      return count > 0
    count += 1
    j = neigh[j][dr]
  """if j == None:
    return False
  if board[j] == flip[turn]:
    k = neigh[j][dr]
    while k != None:
      if board[k] == '.':
        break
      if board[k] == turn:
        return True
      k = neigh[k][dr]"""

def tellTurn(board):
  return {0:'x',1:'o'}[board.count('.') % 2]

def disp(board, turn, mov = []):
  move = legalMoves(board, turn)
  prep = "".join(['+' if i in mov else '*' if i in move else board[i] for i in range(64)])
  print("\n".join([prep[i:i+8] for i in range(0,64,8)]))
  print("".join(board))
  print("x/o: " + str(board.count('x')) + '/' + str(board.count('o')))

def move(board, turn, mov):
  if board[mov] != '.':
    return False
  bad = True
  for dr in range(8):
    if checkDir(board, turn, mov, dr):
      j = neigh[mov][dr]
      while True:
        if board[j] == turn:
          break
        board[j] = turn
        j = neigh[j][dr]
      bad = False
  if not bad:
    board[mov] = turn
    return True
  return False

def diffTile(board, turn):
  return board.count(turn) - board.count(flip[turn])

def diffSafe(board, turn):
  return safeEdge(board, turn) - safeEdge(board, flip[turn])

def safeEdge(board, turn):
  return sum([countEdge(board, turn, edge) for edge in edges])
  """ret = 0
  for edge in edges:
    ret += countEdge(board, turn, edge)
  return ret# - len([1 for i in corn if board[i] == turn])"""

def countEdge(board, turn, edge):
  row = "".join([board[i] for i in edge])
  match = '\\.|' + flip[turn]
  try:
    return re.search(match, row).pos + re.search(match, row[::-1]).pos
  except:
    return len(row)
  """for i, ind in enumerate(edge):
    if board[ind] != turn:
      ret = i
      for j, jnd in enumerate(edge[::-1]):
        if board[jnd] != turn:
          return ret + j
  else:
    return len(edge)"""

def minimax(board, turn, huer, depth, alpha, beta, ghost = False):
  if depth == 0:
    return -1, huer(board, turn)
  mov = legalMoves(board, turn)
  if len(mov) == 0:
    if ghost:
      return -1, huer(board, turn)
    return -1, -1 * minimax(board, flip[turn], huer, depth, -1*beta, -1*alpha, ghost = True)[1]
  random.shuffle(mov)
  reset = board[:]
  maxDiff = -9001
  ret = mov[0]
  for i in mov:
    move(board, turn, i)
    diff = -1 * minimax(board, flip[turn], huer, -1*beta, -1*alpha, depth - 1)[1]
    if diff >= maxDiff:
      ret = i
      maxDiff = diff
      if ret > alpha:
        aplha = ret
        if alpha > beta:
          return ret, maxDiff
    board = reset[:]
  return ret, maxDiff

def hardcode(b, hum):
  reset = b[:]
  mov = legalMoves(b, hum)
  random.shuffle(mov)
  maxedge = -1
  minedge = safeEdge(b, hum)
  try:
    mem = mov[0]
  except:
    return -1
  ret = mov[0]
  for i in mov:
    if i in corn: #greedy corner
      return i
    move(b, hum, i)
    edge = safeEdge(b, hum)
    if edge >= maxedge: #safer-than-previous edge (might not be an edge)
      if edge > minedge: #safe edge (guaranteed to not give corner)
        ret = i
        maxedge = edge
      elif not i in cxdict or b[cxdict[i]] == hum: #C/X
        if i in setEdges: #avoid edges
          mem = i
        else:
          ret = i
          maxedge = edge
    b = reset[:]
  if maxedge == -1:
    return mem
  else:
    return ret

if __name__ == '__main__':
  b, hum = list('.'*27 + 'ox......xo' + '.'*27), 'x'
  index = 1
  for var in ['b', 'hum']:
    if index >= len(sys.argv):
      break
    if var == 'b':
      if len(sys.argv[index]) == 64:
        b = list(sys.argv[index].lower())
        hum = tellTurn(b)
        index += 1
    elif var == 'hum':
      if sys.argv[index].lower() in flip:
        hum = sys.argv[index].lower()
        index += 1
  r = b[:]
  disp(b, hum)
  print("legal moves: " + ", ".join([*map(str, legalMoves(b, hum))]))
  print("Heuristic: " + str(hardcode(b, hum)))
  b = r[:]
  if b.count('.') <= n:
      temp = minimax(b, hum, diffTile, float('-inf'), float('inf'), -1)
      print("Minimax: " + str(temp[1]) + ", move: " + str(temp[0]))
