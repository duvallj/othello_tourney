from multiprocessing import Value

class Strategy:
    def squares(self):
        return [11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 31, 32, 33, 34, 35, 36, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 51, 52, 53, 54, 55, 56, 57, 58, 61, 62, 63, 64, 65, 66, 67, 68, 71, 72, 73, 74, 75, 76, 77, 78, 81, 82, 83, 84, 85, 86, 87, 88]

    def initial_board(self):
        return ['?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '.', '.', '.', '.', '.', '.', '.', '.', '?', '?', '.', '.', '.', '.', '.', '.', '.', '.', '?', '?', '.', '.', '.', '.', '.', '.', '.', '.', '?', '?', '.', '.', '.', 'o', '@', '.', '.', '.', '?', '?', '.', '.', '.', '@', 'o', '.', '.', '.', '?', '?', '.', '.', '.', '.', '.', '.', '.', '.', '?', '?', '.', '.', '.', '.', '.', '.', '.', '.', '?', '?', '.', '.', '.', '.', '.', '.', '.', '.', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?']

    def opponent(self, player):
        return '@' if player == 'o' else 'o'

    def find_bracket(self, square, player, board, direction):
        bracket = square + direction
        if board[bracket] == player:
            return None
        opp = self.opponent(player)
        while board[bracket] == opp:
            bracket += direction
        return None if board[bracket] in ('?', '.') else bracket

    def is_legal(self, move, player, board):
        if board[move]!='.':
            return False
        if self.find_bracket(move, player, board, 1):
            return True
        if self.find_bracket(move, player, board, -1):
            return True
        if self.find_bracket(move, player, board, 10):
            return True
        if self.find_bracket(move, player, board, -10):
            return True
        if self.find_bracket(move, player, board, 9):
            return True
        if self.find_bracket(move, player, board, 11):
            return True
        if self.find_bracket(move, player, board, -11):
            return True
        if self.find_bracket(move, player, board, -9):
            return True
        return False

    def make_move(self, move, player, board):
        board[move] = player
        for d in [1, -1, 11, -11, 9, -9, 10, -10]:
            bracket = self.find_bracket(move, player, board, d)
            if bracket:
                square = move + d
                while square != bracket:
                    board[square] = player
                    square += d
        return board

    def stability(self, player, board):
        count = 0
        opponent = self.opponent(player)
        if board[11] == player:
            count = count + 100
            if board[12] == player:
                count = count + 1
                if board[13] == player:
                    count = count + 1
                    if board[14] == player:
                        count = count + 1
                        if board[15] == player:
                            count = count + 1
                            if board[16] == player:
                                count = count + 1
                                if board[17] == player:
                                    count = count + 1
                                    if board[18] == player:
                                        count = count + 1
        if board[81] == player:
            count = count + 100
            if board[82] == player:
                count = count + 1
                if board[83] == player:
                    count = count + 1
                    if board[84] == player:
                        count = count + 1
                        if board[85] == player:
                            count = count + 1
                            if board[86] == player:
                                count = count + 1
                                if board[87] == player:
                                    count = count + 1
                                    if board[88] == player:
                                        count = count + 1
        if board[11] == player:
            count = count + 100
            if board[21] == player:
                count = count + 1
                if board[31] == player:
                    count = count + 1
                    if board[41] == player:
                        count = count + 1
                        if board[51] == player:
                            count = count + 1
                            if board[61] == player:
                                count = count + 1
                                if board[71] == player:
                                    count = count + 1
                                    if board[81] == player:
                                        count = count + 1
        if board[18] == player:
            count = count + 100
            if board[28] == player:
                count = count + 1
                if board[38] == player:
                    count = count + 1
                    if board[48] == player:
                        count = count + 1
                        if board[58] == player:
                            count = count + 1
                            if board[68] == player:
                                count = count + 1
                                if board[78] == player:
                                    count = count + 1
                                    if board[88] == player:
                                        count = count + 1
        if board[18] == player:
            count = count + 100
            if board[17] == player:
                count = count + 1
                if board[16] == player:
                    count = count + 1
                    if board[15] == player:
                        count = count + 1
                        if board[14] == player:
                            count = count + 1
                            if board[13] == player:
                                count = count + 1
                                if board[12] == player:
                                    count = count + 1
                                    if board[11] == player:
                                        count = count + 1
        if board[88] == player:
            count = count + 100
            if board[87] == player:
                count = count + 1
                if board[86] == player:
                    count = count + 1
                    if board[85] == player:
                        count = count + 1
                        if board[84] == player:
                            count = count + 1
                            if board[83] == player:
                                count = count + 1
                                if board[82] == player:
                                    count = count + 1
                                    if board[81] == player:
                                        count = count + 1
        if board[81] == player:
            count = count + 100
            if board[71] == player:
                count = count + 1
                if board[61] == player:
                    count = count + 1
                    if board[51] == player:
                        count = count + 1
                        if board[41] == player:
                            count = count + 1
                            if board[31] == player:
                                count = count + 1
                                if board[21] == player:
                                    count = count + 1
                                    if board[11] == player:
                                        count = count + 1
        if board[88] == player:
            count = count + 100
            if board[78] == player:
                count = count + 1
                if board[68] == player:
                    count = count + 1
                    if board[58] == player:
                        count = count + 1
                        if board[48] == player:
                            count = count + 1
                            if board[38] == player:
                                count = count + 1
                                if board[28] == player:
                                    count = count + 1
                                    if board[18] == player:
                                        count = count + 1

        if board[11] == opponent:
            count = count - 1000
            if board[12] == opponent:
                count = count - 10
                if board[13] == opponent:
                    count = count - 10
                    if board[14] == opponent:
                        count = count - 10
                        if board[15] == opponent:
                            count = count - 10
                            if board[16] == opponent:
                                count = count - 10
                                if board[17] == opponent:
                                    count = count - 10
                                    if board[18] == opponent:
                                        count = count - 10
        if board[81] == opponent:
            count = count - 1000
            if board[82] == opponent:
                count = count - 10
                if board[83] == opponent:
                    count = count - 10
                    if board[84] == opponent:
                        count = count - 10
                        if board[85] == opponent:
                            count = count - 10
                            if board[86] == opponent:
                                count = count - 10
                                if board[87] == opponent:
                                    count = count - 10
                                    if board[88] == opponent:
                                        count = count - 10
        if board[11] == opponent:
            count = count - 1000
            if board[21] == opponent:
                count = count - 10
                if board[31] == opponent:
                    count = count - 10
                    if board[41] == opponent:
                        count = count - 10
                        if board[51] == opponent:
                            count = count - 10
                            if board[61] == opponent:
                                count = count - 10
                                if board[71] == opponent:
                                    count = count - 10
                                    if board[81] == opponent:
                                        count = count - 10
        if board[18] == opponent:
            count = count - 1000
            if board[28] == opponent:
                count = count - 10
                if board[38] == opponent:
                    count = count - 10
                    if board[48] == opponent:
                        count = count - 10
                        if board[58] == opponent:
                            count = count - 10
                            if board[68] == opponent:
                                count = count - 10
                                if board[78] == opponent:
                                    count = count - 10
                                    if board[88] == opponent:
                                        count = count - 10
        if board[18] == opponent:
            count = count - 1000
            if board[17] == opponent:
                count = count - 10
                if board[16] == opponent:
                    count = count - 10
                    if board[15] == opponent:
                        count = count - 10
                        if board[14] == opponent:
                            count = count - 10
                            if board[13] == opponent:
                                count = count - 10
                                if board[12] == opponent:
                                    count = count - 10
                                    if board[11] == opponent:
                                        count = count - 10
        if board[88] == opponent:
            count = count - 1000
            if board[87] == opponent:
                count = count - 10
                if board[86] == opponent:
                    count = count - 10
                    if board[85] == opponent:
                        count = count - 10
                        if board[84] == opponent:
                            count = count - 10
                            if board[83] == opponent:
                                count = count - 10
                                if board[82] == opponent:
                                    count = count - 10
                                    if board[81] == opponent:
                                        count = count - 10
        if board[81] == opponent:
            count = count - 1000
            if board[71] == opponent:
                count = count - 10
                if board[61] == opponent:
                    count = count - 10
                    if board[51] == opponent:
                        count = count - 10
                        if board[41] == opponent:
                            count = count - 10
                            if board[31] == opponent:
                                count = count - 10
                                if board[21] == opponent:
                                    count = count - 10
                                    if board[11] == opponent:
                                        count = count - 10
        if board[88] == opponent:
            count = count - 1000
            if board[78] == opponent:
                count = count - 10
                if board[68] == opponent:
                    count = count - 10
                    if board[58] == opponent:
                        count = count - 10
                        if board[48] == opponent:
                            count = count - 10
                            if board[38] == opponent:
                                count = count - 10
                                if board[28] == opponent:
                                    count = count - 10
                                    if board[18] == opponent:
                                        count = count - 10
        for x in [11, 12, 13, 14, 15, 16, 17, 18, 21, 28, 31, 38, 41, 48, 51, 58, 61, 68, 71, 78, 81, 82, 83, 84, 85,
                  86, 87, 88]:
            if board[x] == player:
                count += 1
            elif board[x] == opponent:
                count -= 10
        return count
    def legal_moves(self, player, board):
        return self.insertionSort([sq for sq in self.squares() if self.is_legal(sq, player, board)], player, board)

    def insertionSort(self, moves, player, board):
        heuristics = {}
        for x in moves:
            heuristics[x]=self.stability(player, self.make_move(x, player, board[:]))
        for index in range(1, len(moves)):
            currentvalue = moves[index]
            position = index
            while position > 0 and heuristics[moves[position-1]] < heuristics[moves[index]]:
                moves[position] = moves[position - 1]
                position = position - 1
            moves[position] = currentvalue
        return moves

    def any_legal_move(self, player, board):
        for x in self.squares():
            if self.is_legal(x, player, board):
                return True
        return False

    def next_player(self,board, prev_player):
        opponent = self.opponent(prev_player)
        if self.any_legal_move(opponent, board):
            return opponent
        if self.any_legal_move(prev_player, board):
            return prev_player
        return None

    def score(self,player, board):
        me = 0
        for x in self.squares():
            if board[x]!='.':
                if board[x]==player:
                    me+=1
                else:
                    me-=1
        return me

    def myStrategy(self, player, board, best_move, still_running):
        moves = self.legal_moves(player, board)
        opponent = self.opponent(player)
        for x in moves:
            board1 = self.make_move(x, player, board[:])
            if not self.next_player(board1, player):
                if self.score(player, board1) > 0:
                    return x
        blanks = board.count(".")
        if blanks<=12:
            return self.alphabeta(player, board, -999999, 999999, 12, best_move, still_running, 12)[1]
        if blanks<=60:
            return self.weightedAlphabeta(player, board, -999999, 999999, 7, best_move, still_running, 7)[1]

    currentBest = -1
    def alphabeta(self, player, board, alpha, beta, depth, best_move, still_running, originalDepth):
        if still_running.value==0:
            best_move.value = self.currentBest
        if depth == 0:
            return self.score(player, board), None
        moves = self.legal_moves(player, board)
        if not moves:
            if not self.any_legal_move(self.opponent(player), board):
                return self.score(player, board), None
            return -self.alphabeta(self.opponent(player), board, -beta, -alpha, depth - 1, best_move, still_running, originalDepth)[0], None
        best_move1 = moves[0]
        if depth == originalDepth:
            self.currentBest = best_move1
        for move in moves:
            if alpha >= beta:
                break
            val = -self.alphabeta(self.opponent(player), self.make_move(move, player, board[:]), -beta, -alpha, depth - 1, best_move, still_running, originalDepth)[0]
            if val > alpha:
                alpha = val
                best_move1 = move
                if depth==originalDepth:
                    self.currentBest = best_move1
        return alpha, best_move1

    def weightedAlphabeta(self, player, board, alpha, beta, depth, best_move, still_running, originalDepth):
        if still_running.value==0:
            best_move.value = self.currentBest
        if depth == 0:
            return self.stability(player, board), None
        moves = self.legal_moves(player, board)
        if not moves:
            if not self.any_legal_move(self.opponent(player), board):
                return self.stability(player, board), None
            return -self.weightedAlphabeta(self.opponent(player), board, -beta, -alpha, depth - 1, best_move, still_running, originalDepth)[0], None
        best_move1 = moves[0]
        if len(moves)>7 and depth<3:
            moves = moves[:7]
        if depth == originalDepth:
            self.currentBest = best_move1
        for move in moves:
            if alpha >= beta:
                break
            val = -self.weightedAlphabeta(self.opponent(player), self.make_move(move, player, board[:]), -beta, -alpha, depth - 1, best_move, still_running, originalDepth)[0]
            if val > alpha:
                alpha = val
                best_move1 = move
                if depth==originalDepth:
                    self.currentBest = best_move1
        return alpha, best_move1

    def best_strategy(self, board, player, best_move, still_running):
        if still_running.value:
            best_move.value = self.myStrategy(player, board, best_move, still_running)
