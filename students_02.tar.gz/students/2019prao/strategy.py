import sys, math, random

class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		brd = ''.join(board).replace('?', '').replace('@', 'X').replace('o', 'O')
		token = 'X' if player == '@' else 'O'
		otherplayer = 'X' if token == 'O' else 'O'
		best_move.value = 0
		mv = findBestMove(brd, token, otherplayer)
		mv1 = 11 + (mv//8) * 10 +(mv%8)
		best_move.value = mv1
lettertonumber = {'A': 0, 'B': 1, 'C': 2, 'D':3, 'E':4, 'F':5, 'G': 6, 'H':7}
ply = '777'
brd = list("...........................OX......XO...........................")
for i in sys.argv[1:]:
	if(len(i) == 64):
		brd = list(i.upper())
	if(len(i) == 1 and not i.isdigit()):
		ply = i.upper()
if(ply == '777'):
	ply = 'X' if brd.count('.')%2 == 0 else 'O'
oply = 'X' if ply == 'O' else 'O'
toprowindexes, bottomrowindexes, leftsideindexes, rightsideindexes = [*range(8)], [*range(56,64)], [*range(0, 64, 8)], [*range(7, 71, 8)]
csandxs = {1,6,8,9,14,15,48,49,54,55,57,62}
topconnections = {8: [0], 9: [1], 10: [2], 11: [3], 12: [4], 13: [5], 14: [6], 15: [7], 16: [8, 0], 17: [9, 1], 18: [10, 2], 19: [11, 3], 20: [12, 4], 21: [13, 5], 22: [14, 6], 23: [15, 7], 24: [16, 8, 0], 25: [17, 9, 1], 26: [18, 10, 2], 27: [19, 11, 3], 28: [20, 12, 4], 29: [21, 13, 5], 30: [22, 14, 6], 31: [23, 15, 7], 32: [24, 16, 8, 0], 33: [25, 17, 9, 1], 34: [26, 18, 10, 2], 35: [27, 19, 11, 3], 36: [28, 20, 12, 4], 37: [29, 21, 13, 5], 38: [30, 22, 14, 6], 39: [31, 23, 15, 7], 40: [32, 24, 16, 8, 0], 41: [33, 25, 17, 9, 1], 42: [34, 26, 18, 10, 2], 43: [35, 27, 19, 11, 3], 44: [36, 28, 20, 12, 4], 45: [37, 29, 21, 13, 5], 46: [38, 30, 22, 14, 6], 47: [39, 31, 23, 15, 7], 48: [40, 32, 24, 16, 8, 0], 49: [41, 33, 25, 17, 9, 1], 50: [42, 34, 26, 18, 10, 2], 51: [43, 35, 27, 19, 11, 3], 52: [44, 36, 28, 20, 12, 4], 53: [45, 37, 29, 21, 13, 5], 54: [46, 38, 30, 22, 14, 6], 55: [47, 39, 31, 23, 15, 7], 56: [48, 40, 32, 24, 16, 8, 0], 57: [49, 41, 33, 25, 17, 9, 1], 58: [50, 42, 34, 26, 18, 10, 2], 59: [51, 43, 35, 27, 19, 11, 3], 60: [52, 44, 36, 28, 20, 12, 4], 61: [53, 45, 37, 29, 21, 13, 5], 62: [54, 46, 38, 30, 22, 14, 6], 63: [55, 47, 39, 31, 23, 15, 7]}
bottomconnections = {0: [8, 16, 24, 32, 40, 48, 56], 1: [9, 17, 25, 33, 41, 49, 57], 2: [10, 18, 26, 34, 42, 50, 58], 3: [11, 19, 27, 35, 43, 51, 59], 4: [12, 20, 28, 36, 44, 52, 60], 5: [13, 21, 29, 37, 45, 53, 61], 6: [14, 22, 30, 38, 46, 54, 62], 7: [15, 23, 31, 39, 47, 55, 63], 8: [16, 24, 32, 40, 48, 56], 9: [17, 25, 33, 41, 49, 57], 10: [18, 26, 34, 42, 50, 58], 11: [19, 27, 35, 43, 51, 59], 12: [20, 28, 36, 44, 52, 60], 13: [21, 29, 37, 45, 53, 61], 14: [22, 30, 38, 46, 54, 62], 15: [23, 31, 39, 47, 55, 63], 16: [24, 32, 40, 48, 56], 17: [25, 33, 41, 49, 57], 18: [26, 34, 42, 50, 58], 19: [27, 35, 43, 51, 59], 20: [28, 36, 44, 52, 60], 21: [29, 37, 45, 53, 61], 22: [30, 38, 46, 54, 62], 23: [31, 39, 47, 55, 63], 24: [32, 40, 48, 56], 25: [33, 41, 49, 57], 26: [34, 42, 50, 58], 27: [35, 43, 51, 59], 28: [36, 44, 52, 60], 29: [37, 45, 53, 61], 30: [38, 46, 54, 62], 31: [39, 47, 55, 63], 32: [40, 48, 56], 33: [41, 49, 57], 34: [42, 50, 58], 35: [43, 51, 59], 36: [44, 52, 60], 37: [45, 53, 61], 38: [46, 54, 62], 39: [47, 55, 63], 40: [48, 56], 41: [49, 57], 42: [50, 58], 43: [51, 59], 44: [52, 60], 45: [53, 61], 46: [54, 62], 47: [55, 63], 48: [56], 49: [57], 50: [58], 51: [59], 52: [60], 53: [61], 54: [62], 55: [63]}
leftconnections = {1: [0], 2: [1, 0], 3: [2, 1, 0], 4: [3, 2, 1, 0], 5: [4, 3, 2, 1, 0], 6: [5, 4, 3, 2, 1, 0], 7: [6, 5, 4, 3, 2, 1, 0], 9: [8], 10: [9, 8], 11: [10, 9, 8], 12: [11, 10, 9, 8], 13: [12, 11, 10, 9, 8], 14: [13, 12, 11, 10, 9, 8], 15: [14, 13, 12, 11, 10, 9, 8], 17: [16], 18: [17, 16], 19: [18, 17, 16], 20: [19, 18, 17, 16], 21: [20, 19, 18, 17, 16], 22: [21, 20, 19, 18, 17, 16], 23: [22, 21, 20, 19, 18, 17, 16], 25: [24], 26: [25, 24], 27: [26, 25, 24], 28: [27, 26, 25, 24], 29: [28, 27, 26, 25, 24], 30: [29, 28, 27, 26, 25, 24], 31: [30, 29, 28, 27, 26, 25, 24], 33: [32], 34: [33, 32], 35: [34, 33, 32], 36: [35, 34, 33, 32], 37: [36, 35, 34, 33, 32], 38: [37, 36, 35, 34, 33, 32], 39: [38, 37, 36, 35, 34, 33, 32], 41: [40], 42: [41, 40], 43: [42, 41, 40], 44: [43, 42, 41, 40], 45: [44, 43, 42, 41, 40], 46: [45, 44, 43, 42, 41, 40], 47: [46, 45, 44, 43, 42, 41, 40], 49: [48], 50: [49, 48], 51: [50, 49, 48], 52: [51, 50, 49, 48], 53: [52, 51, 50, 49, 48], 54: [53, 52, 51, 50, 49, 48], 55: [54, 53, 52, 51, 50, 49, 48], 57: [56], 58: [57, 56], 59: [58, 57, 56], 60: [59, 58, 57, 56], 61: [60, 59, 58, 57, 56], 62: [61, 60, 59, 58, 57, 56], 63: [62, 61, 60, 59, 58, 57, 56]}
rightconnections = {0: [1, 2, 3, 4, 5, 6, 7], 1: [2, 3, 4, 5, 6, 7], 2: [3, 4, 5, 6, 7], 3: [4, 5, 6, 7], 4: [5, 6, 7], 5: [6, 7], 6: [7], 8: [9, 10, 11, 12, 13, 14, 15], 9: [10, 11, 12, 13, 14, 15], 10: [11, 12, 13, 14, 15], 11: [12, 13, 14, 15], 12: [13, 14, 15], 13: [14, 15], 14: [15], 16: [17, 18, 19, 20, 21, 22, 23], 17: [18, 19, 20, 21, 22, 23], 18: [19, 20, 21, 22, 23], 19: [20, 21, 22, 23], 20: [21, 22, 23], 21: [22, 23], 22: [23], 24: [25, 26, 27, 28, 29, 30, 31], 25: [26, 27, 28, 29, 30, 31], 26: [27, 28, 29, 30, 31], 27: [28, 29, 30, 31], 28: [29, 30, 31], 29: [30, 31], 30: [31], 32: [33, 34, 35, 36, 37, 38, 39], 33: [34, 35, 36, 37, 38, 39], 34: [35, 36, 37, 38, 39], 35: [36, 37, 38, 39], 36: [37, 38, 39], 37: [38, 39], 38: [39], 40: [41, 42, 43, 44, 45, 46, 47], 41: [42, 43, 44, 45, 46, 47], 42: [43, 44, 45, 46, 47], 43: [44, 45, 46, 47], 44: [45, 46, 47], 45: [46, 47], 46: [47], 48: [49, 50, 51, 52, 53, 54, 55], 49: [50, 51, 52, 53, 54, 55], 50: [51, 52, 53, 54, 55], 51: [52, 53, 54, 55], 52: [53, 54, 55], 53: [54, 55], 54: [55], 56: [57, 58, 59, 60, 61, 62, 63], 57: [58, 59, 60, 61, 62, 63], 58: [59, 60, 61, 62, 63], 59: [60, 61, 62, 63], 60: [61, 62, 63], 61: [62, 63], 62: [63]}
toprightconnections = {8: [1], 9: [2], 10: [3], 11: [4], 12: [5], 13: [6], 14: [7], 16: [9, 2], 17: [10, 3], 18: [11, 4], 19: [12, 5], 20: [13, 6], 21: [14, 7], 22: [15], 24: [17, 10, 3], 25: [18, 11, 4], 26: [19, 12, 5], 27: [20, 13, 6], 28: [21, 14, 7], 29: [22, 15], 30: [23], 32: [25, 18, 11, 4], 33: [26, 19, 12, 5], 34: [27, 20, 13, 6], 35: [28, 21, 14, 7], 36: [29, 22, 15], 37: [30, 23], 38: [31], 40: [33, 26, 19, 12, 5], 41: [34, 27, 20, 13, 6], 42: [35, 28, 21, 14, 7], 43: [36, 29, 22, 15], 44: [37, 30, 23], 45: [38, 31], 46: [39], 48: [41, 34, 27, 20, 13, 6], 49: [42, 35, 28, 21, 14, 7], 50: [43, 36, 29, 22, 15], 51: [44, 37, 30, 23], 52: [45, 38, 31], 53: [46, 39], 54: [47], 56: [49, 42, 35, 28, 21, 14, 7], 57: [50, 43, 36, 29, 22, 15], 58: [51, 44, 37, 30, 23], 59: [52, 45, 38, 31], 60: [53, 46, 39], 61: [54, 47], 62: [55]}
topleftconnections = {9: [0], 10: [1], 11: [2], 12: [3], 13: [4], 14: [5], 15: [6], 17: [8], 18: [9, 0], 19: [10, 1], 20: [11, 2], 21: [12, 3], 22: [13, 4], 23: [14, 5], 25: [16], 26: [17, 8], 27: [18, 9, 0], 28: [19, 10, 1], 29: [20, 11, 2], 30: [21, 12, 3], 31: [22, 13, 4], 33: [24], 34: [25, 16], 35: [26, 17, 8], 36: [27, 18, 9, 0], 37: [28, 19, 10, 1], 38: [29, 20, 11, 2], 39: [30, 21, 12, 3], 41: [32], 42: [33, 24], 43: [34, 25, 16], 44: [35, 26, 17, 8], 45: [36, 27, 18, 9, 0], 46: [37, 28, 19, 10, 1], 47: [38, 29, 20, 11, 2], 49: [40], 50: [41, 32], 51: [42, 33, 24], 52: [43, 34, 25, 16], 53: [44, 35, 26, 17, 8], 54: [45, 36, 27, 18, 9, 0], 55: [46, 37, 28, 19, 10, 1], 57: [48], 58: [49, 40], 59: [50, 41, 32], 60: [51, 42, 33, 24], 61: [52, 43, 34, 25, 16], 62: [53, 44, 35, 26, 17, 8], 63: [54, 45, 36, 27, 18, 9, 0]}
bottomleftconnections = {1: [8], 2: [9, 16], 3: [10, 17, 24], 4: [11, 18, 25, 32], 5: [12, 19, 26, 33, 40], 6: [13, 20, 27, 34, 41, 48], 7: [14, 21, 28, 35, 42, 49, 56], 9: [16], 10: [17, 24], 11: [18, 25, 32], 12: [19, 26, 33, 40], 13: [20, 27, 34, 41, 48], 14: [21, 28, 35, 42, 49, 56], 15: [22, 29, 36, 43, 50, 57], 17: [24], 18: [25, 32], 19: [26, 33, 40], 20: [27, 34, 41, 48], 21: [28, 35, 42, 49, 56], 22: [29, 36, 43, 50, 57], 23: [30, 37, 44, 51, 58], 25: [32], 26: [33, 40], 27: [34, 41, 48], 28: [35, 42, 49, 56], 29: [36, 43, 50, 57], 30: [37, 44, 51, 58], 31: [38, 45, 52, 59], 33: [40], 34: [41, 48], 35: [42, 49, 56], 36: [43, 50, 57], 37: [44, 51, 58], 38: [45, 52, 59], 39: [46, 53, 60], 41: [48], 42: [49, 56], 43: [50, 57], 44: [51, 58], 45: [52, 59], 46: [53, 60], 47: [54, 61], 49: [56], 50: [57], 51: [58], 52: [59], 53: [60], 54: [61], 55: [62]}
bottomrightconnections = {0: [9, 18, 27, 36, 45, 54, 63], 1: [10, 19, 28, 37, 46, 55], 2: [11, 20, 29, 38, 47], 3: [12, 21, 30, 39], 4: [13, 22, 31], 5: [14, 23], 6: [15], 8: [17, 26, 35, 44, 53, 62], 9: [18, 27, 36, 45, 54, 63], 10: [19, 28, 37, 46, 55], 11: [20, 29, 38, 47], 12: [21, 30, 39], 13: [22, 31], 14: [23], 16: [25, 34, 43, 52, 61], 17: [26, 35, 44, 53, 62], 18: [27, 36, 45, 54, 63], 19: [28, 37, 46, 55], 20: [29, 38, 47], 21: [30, 39], 22: [31], 24: [33, 42, 51, 60], 25: [34, 43, 52, 61], 26: [35, 44, 53, 62], 27: [36, 45, 54, 63], 28: [37, 46, 55], 29: [38, 47], 30: [39], 32: [41, 50, 59], 33: [42, 51, 60], 34: [43, 52, 61], 35: [44, 53, 62], 36: [45, 54, 63], 37: [46, 55], 38: [47], 40: [49, 58], 41: [50, 59], 42: [51, 60], 43: [52, 61], 44: [53, 62], 45: [54, 63], 46: [55], 48: [57], 49: [58], 50: [59], 51: [60], 52: [61], 53: [62], 54: [63]}

storelegalmoves = dict()

def legalMoves(board, player, otherplayer):
	playerpositions = [i  for i in range(0, 64) if board[i] == player]
	possiblepositions = dict()
	for playerindex in playerpositions:
		if( playerindex in rightconnections and board[playerindex+1] == otherplayer  ):
			temp = []
			for index in sorted(rightconnections[playerindex]):
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if(playerindex in leftconnections and board[playerindex-1] == otherplayer):
			temp = []
			for index in leftconnections[playerindex]:
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if( playerindex in topconnections and board[playerindex-8] == otherplayer):
			temp = []
			for index in topconnections[playerindex]:
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if(playerindex in bottomconnections and board[playerindex+8] == otherplayer):
			temp = []
			for index in sorted(bottomconnections[playerindex]):
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if( playerindex in bottomrightconnections and board[playerindex+9] == otherplayer ):
			temp = []
			for index in sorted(bottomrightconnections[playerindex]):
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if( playerindex in bottomleftconnections and board[playerindex+7] == otherplayer):
			temp = []
			for index in sorted(bottomleftconnections[playerindex]):
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if( playerindex in topleftconnections and board[playerindex-9] == otherplayer  ):
			temp = []
			for index in topleftconnections[playerindex]:
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
		if(playerindex in toprightconnections and board[playerindex-7] == otherplayer ):
			temp = []
			for index in toprightconnections[playerindex]:
				if(board[index] == player):
					break;
				temp.append(index)
				if(board[index] == '.'):
					if(index in possiblepositions):
						for thing in temp:
							possiblepositions[index].append(thing)
					else:
						possiblepositions[index] = temp
					break;
	return possiblepositions;


def checkH2(board,position, player, otherplayer):
	move = 'some'
	if position in toprowindexes and board[0] == player:
		b = True;
		for thing in leftconnections[position]:
			if board[thing] == '.':
				b = False;
				break;
		if(b): move = position
	elif position in toprowindexes and board[7] == player:
		b = True;
		for thing in rightconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	elif position in leftsideindexes and board[0] == player:
		b = True;
		for thing in topconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	elif position in leftsideindexes and board[56] == player:
		b = True;
		for thing in bottomconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	elif position in rightsideindexes and board[7] == player:
		b = True;
		for thing in topconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	elif position in rightsideindexes and board[63] == player:
		b = True;
		for thing in bottomconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	elif position in bottomrowindexes and board[63] == player:
		b = True;
		for thing in rightconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	elif position in bottomrowindexes and board[56] == player:
		b = True;
		for thing in leftconnections[position]:
			if board[thing]  == '.':
				b = False;
				break;
		if(b): move = position
	return move;

def evalBoard(board, player, otherplayer): return board.count(player)-board.count(otherplayer);

def minimizePlayer(board, possiblepositions, player, otherplayer):
	minimum = 10000
	for item in possiblepositions:
		if(len(legalmoves(makeMove(board, player, item, possiblepositions), otherplayer, player).keys()) < minimum):
			minimum = item
	return minimum


def makeMove(board, player, index, possiblepositions):
	game = board[:]
	game = list(game)
	game[index] = player
	for item in possiblepositions[index]:
		game[item] = player
	game = "".join(game)
	return game
	
def toString(brd):
	s = ""
	for item in brd:
		s += item
	return s;

def negamaxTerminal (brd, token, improvable, hardbound):
	othertoken = 'X' if token == 'O' else 'O'
	if(toString(brd), token) in storelegalmoves: lm = storelegalmoves[(toString(brd), token)]
	else:
		lm = legalMoves(brd, token, othertoken)
		storelegalmoves[(toString(brd), token)] = lm
	if not lm:
		if(toString(brd), othertoken) in storelegalmoves: lm = storelegalmoves[(toString(brd), othertoken)]
		else:
			lm = legalMoves(toString(brd), othertoken, token)
			storelegalmoves[(toString(brd), othertoken)] = lm
		if not lm: return[evalBoard(brd, token, othertoken),-3]  ##The -3 means game is over
		nm = negamaxTerminal(brd, othertoken, hardbound, -improvable) + [-1]
		return [-nm[0]] + nm[1:]
	best = []  #what gets returned
	newHB = -improvable
	for mv in lm:
		nm = negamaxTerminal(makeMove(brd, token, mv, lm), othertoken, -hardbound, newHB) + [mv]
		if not best or nm[0] < newHB:    #######Both nm[0] && newHB are negative
			best = nm
			if nm[0] < newHB:
				newHB = nm[0]
				if -newHB > hardbound: return [-best[0]] + best[1:]
	return [-best[0]] + best[1:]
	
def minimizePlayer(board, player, otherplayer, possiblepositions):
	minimum = 1000000
	minimumindex = 0
	for item in possiblepositions:
		thing = len(legalMoves(makeMove(board, player, item, possiblepositions), otherplayer, player).keys())
		if thing < minimum:
			minimum = thing
			minimumindex = item
	return minimumindex



def findBestMove(board, player, otherplayer):
	possiblepositionsfull = legalMoves(board, player, otherplayer)
	possiblepositions = set(possiblepositionsfull.keys())
	if(board.count('.')   >  13):
		domove = 'temp'
		if 0 in possiblepositions:
			domove = 0
			possiblepositions.remove(0)
		elif 7 in possiblepositions:
			domove = 7
			possiblepositions.remove(7)
		elif 56 in possiblepositions:
			domove = 56
			possiblepositions.remove(56)
		elif 63 in possiblepositions:
			domove = 63
			possiblepositions.remove(63)
		if(domove == 'temp'):
			for thing in possiblepositions:
					if ((thing in toprowindexes or thing in leftsideindexes) and board[0] == player) or ((thing in toprowindexes or thing in rightsideindexes) and board[7] == player) or ((thing in bottomrowindexes or thing in leftsideindexes) and board[56] == player) or ((thing in bottomrowindexes or thing in rightsideindexes) and board[63] == player):
						t = checkH2(board, thing, player, otherplayer)
						if(t != 'some'):
							domove = t
							break;
		if(domove == 'temp'):
			if(board.count('.') < 20):
				domove = minimizePlayer(board, player, otherplayer, possiblepositionsfull)
			else:
				domove = random.choice(list(possiblepositions))
		return domove
	nm = negamaxTerminal(board, player, -65, 65)
	return nm[-1]


mv = findBestMove(brd, ply,oply)
print(mv)
