#
#Mark Dulaney, Period 3

import sys, time

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        board = ''.join(board).replace('?','').replace('@','X')
        token = "X" if player == '@' else "O"
        mv = legalMoves(board, token)
        mv1 = 11+(mv//8)*10+(mv%8)
        print(mv1)
        best_move.value = mv1


def makeMove(board, token):
    move = -1
    displayBoard(board)
    moves = allMoves(board, token)
    print("Legal Moves ", moves)
    move = legalMoves(board, token)
    board = board[:move] + token + board[move+1:]
    board = swapTokens(board, token, move)

def coordToInt(coord):
    if "A" in coord:
        return (int(coord[1])-1)*8
    if "B" in coord:
        return (int(coord[1])-1)*8+1
    if "C" in coord:
        return (int(coord[1])-1)*8+2
    if "D" in coord:
        return (int(coord[1])-1)*8+3
    if "E" in coord:
        return (int(coord[1])-1)*8+4
    if "F" in coord:
        return (int(coord[1])-1)*8+5
    if "G" in coord:
        return (int(coord[1])-1)*8+6
    if "H" in coord:
        return (int(coord[1])-1)*8+7

def score(board, token):
    #print("In Score - Token: ", token)
    #print("In Score - Enemy Count: ", board.count({"X", "O"}.difference(token).pop()))
    return (board.count(token) - board.count("O" if token=="X" else "X"))
    #return int(64 - board.count({"X", "O"}.difference(token).pop()) - board.count("."))

def swapTokens(board, token, move):
    #print ("About to move: brd: {}; token: {}; move: {}".format(board, token, move))
    board = board[:move] + token + board[move+1:]
    count = move+1
    # RIGHT
    #print("RIGHT INITIAL: ", count)
    while (count) < 64:
        if (count) % 8 != 0:
            #print("RIGHT COUNT: ", count)
            if board[count] == ".":
                break
            if board[count] == token:
                while board[count-1] != token:
                    #print("RIGHT IN COUNT: ", count)
                    if board[count-1] != ".":
                        #print(count)
                        board = board[:count - 1] + token + board[count:]
                        count -= 1
                    else:
                        #print(count)
                        board = board[:count-1] + token + board[count:]
                        break
                break
            count += 1
        else:
            break
    count = move-1
    # LEFT
    while (count) >= 0:
        #print(count)
        if (count)%8 !=7:
            if board[count] == ".":
                break
            if board[count] == token:
                while board[count + 1] != token:
                    #print("LEFT IN COUNT: ", count)
                    if board[count+1] != ".":
                        board = board[:count + 1] + token + board[count+2:]
                        count += 1
                    else:
                        board = board[:count+1] + token + board[count+2:]
                        break
                break
            count -= 1
        else:
            break
    # DOWN
    count = move+8
    while not (count) >= 64:
        if board[count] == ".":
            break
        elif board[count] == token:
            while board[count - 8] != token:
                if board[count-8] != ".":
                    board = board[:count - 8] + token + board[count - 7:]
                    count -= 8
                else:
                    board = board[:count-8] + token + board[count-7:]
                    break
            break
        count += 8
    # UP
    count = move-8
    while count >= 0:
        #print(count)
        if board[count] == ".":
            break
        elif board[count] == token:
            while board[count + 8] != token:
                if board[count+8] != ".":
                    board = board[:count + 8] + token + board[count + 9:]
                    count += 8
                else:
                    board = board[:count+8] + token + board[count+9:]
                    break
            break
        count -= 8
    # DIAGONALUPLEFT
    count = move-9
    #print("\n")
    #displayBoard(board)
    while not (count) < 0:
        if (count) % 8 != 7:
            #print("UPLEFT COUNT: ", count)
            if board[count] == ".":
                break
            elif board[count] == token:
                #print("IN UPLEFT ELIF: ")
                #displayBoard(board)
                while board[count + 9] != token:
                    #print("UPLEFT IN COUNT: ", count, " ", board[count])
                    if board[count + 9] != ".":
                        board = board[:count + 9] + token + board[count + 10:]
                        count += 9
                    else:
                        board = board[:count+9]+token+board[count+10:]
                        break
                break
            count -= 9
        else:
            break
    # DIAGONALDOWNRIGHT
    count = move+9
    #displayBoard(board)
    while not (count) >= 64:
        if (count) % 8 != 0:
            #print(count)
            if board[count] == ".":
                break
            elif board[count] == token:
                while board[count - 9] != token:
                    #print("DR COUNT: ", count)
                    if board[count - 9] != ".":
                        board = board[:count - 9] + token + board[count - 8:]
                        count -= 9
                    else:
                        board = board[:count - 9] + token + board[count - 8:]
                        break
                break
            count += 9
        else:
            break
    # DIAGONALDOWNLEFT
    count = move+7
    while not (count) >= 64:
        if (count) % 8 != 7:
            if board[count] == ".":
                break
            elif board[count] == token:
                while board[count - 7] != token:
                   # print("DL COUNT: ", count)
                    if board[count - 7] != ".":
                        board = board[:count - 7] + token + board[count - 6:]
                        count -= 7
                    else:
                        board = board[:count - 7] + token + board[count - 6:]
                        break
                break
            count += 7
        else:
            break
    # DIAGONALUPRIGHT
    count = move-7
    while not (count) < 0:
        if (count) % 8 != 0:
            if board[count] == ".":
                break
            elif board[count] == token:
                while board[count + 7] != token:
                    #print("UPRIGHT COUNT: ", count)
                    if board[count+7] != ".":
                        board = board[:count + 7] + token + board[count + 8:]
                        count += 7
                    else:
                        board = board[:count+7]+token+board[count+8:]
                        break
                break
            count -= 7
        else:
            break
    #print("move made: {}".format(board))
    #print("\n")
    #print("Moves finished: ")
    #displayBoard(board)
    return board

def allMoves(board, token):
    moves = set([])
    for x in range(0, 64):
        count = x
        if board[x] == token:
            while (count + 1) % 8 != 0 and board[count + 1] != "." and board[count + 1] != token and board[
                        count + 1] != "*":  # Right
                count += 1
            if count != x and not (count + 1) > 63 and board[count + 1] == "." and (count + 1) % 8 != 0:
                board = board[:count + 1] + "*" + board[count + 2:]
                moves.add(count + 1)
            count = x
            while (count - 1) % 8 != 7 and board[count - 1] != "." and board[count - 1] != token and board[
                        count - 1] != "*":  # Left
                count -= 1
            if count != x and not (count - 1) < 0 and board[count - 1] == "." and (count - 1) % 8 != 7:
                board = board[:count - 1] + "*" + board[count:]
                moves.add(count - 1)
            count = x
            while not (count + 8) > 63 and board[count + 8] != "." and board[count + 8] != token and board[
                        count + 8] != "*":  # Down
                count += 8
            if count != x and not (count + 8) > 63 and board[count + 8] == ".":
                board = board[:count + 8] + "*" + board[count + 9:]
                moves.add(count + 8)
            count = x
            while not (count - 8) < 0 and board[count - 8] != "." and board[count - 8] != token and board[
                        count - 8] != "*":  # Up
                count -= 8
            if count != x and not (count - 8) < 0 and board[count - 8] == "." and board[count + 8] != "*":
                board = board[:count - 8] + "*" + board[count - 7:]
                moves.add(count - 8)
            count = x
            while not (count + 9) > 63 and (count + 9) % 8 != 0 and board[count + 9] != "." and board[
                        count + 9] != token and board[count + 9] != "*":  # DownRight
                count += 9
            if count != x and not (count + 9) > 63 and board[count + 9] == "." and (count + 9) % 8 != 0 and board[
                        count - 9] != "*":
                board = board[:count + 9] + "*" + board[count + 10:]
                moves.add(count + 9)
            count = x
            while not (count + 7) > 63 and (count + 7) % 8 != 7 and board[count + 7] != "." and board[
                        count + 7] != token and board[count + 7] != "*":  # DownLeft
                count += 7
            if count != x and not (count + 7) > 63 and board[count + 7] == "." and (count + 7) % 8 != 7 and board[
                        count + 7] != "*":
                board = board[:count + 7] + "*" + board[count + 8:]
                moves.add(count + 7)
            count = x
            while not (count - 7) < 0 and (count - 7) % 8 != 0 and board[count - 7] != "." and board[
                        count - 7] != token and board[count - 7] != "*":  # UpRight
                count -= 7
            if count != x and not (count - 7) < 0 and board[count - 7] == "." and (count - 7) % 8 != 0 and board[
                        count + 7] != "*":
                board = board[:count - 7] + "*" + board[count - 6:]
                moves.add(count - 7)
            count = x
            while not (count - 9) < 0 and (count - 9) % 8 != 7 and board[count - 9] != "." and board[
                        count - 9] != token and board[count - 9] != "*":  # UpLeft
                count -= 9
            if count != x and not (count - 9) < 0 and board[count - 9] == "." and (count - 9) % 8 != 7 and board[
                        count + 9] != "*":
                board = board[:count - 9] + "*" + board[count - 8:]
                moves.add(count - 9)
    #print("\n")
    #displayBoard(board)
    #print("\n")
    return moves

def legalMoves(board, token):
    allmoves = allMoves(board, token)
    if allmoves:
        print("My Heuristic Move is: ", allMoves(board, token).pop())
    if board.count(".") <= 11:
        nm = negamaxTerminal(board, token, -65, 65)
        #print(nm)
        print("Negamax - my score is ", nm[0], " and my move is ", nm[-1][-1])
        #print(time.time()-starttime)
        return nm[-1][-1]
    starttime = time.time()
    moves = set([])
    for x in range (0, 64):
        count = x
        if board[x] == token:
            while (count+1)%8 != 0 and board[count+1] != "." and board[count+1] != token and board[count+1]!="*": #Right
                count+=1
            if count != x and not (count+1) > 63 and board[count+1] == "." and (count+1)%8 != 0:
                board = board[:count+1] + "*" + board[count+2:]
                moves.add(count+1)
            count = x
            while (count-1)%8 != 7 and board[count-1] != "." and board[count-1] != token and board[count-1]!="*": #Left
                count-=1
            if count != x and not (count-1) < 0 and board[count-1] =="." and (count-1)%8 != 7:
                board = board[:count-1] + "*" + board[count:]
                moves.add(count-1)
            count = x
            while not (count+8) > 63 and board[count+8] != "." and board[count+8] != token and board[count+8]!="*": #Down
                count+=8
            if count != x and not (count+8) > 63 and board[count+8] == ".":
                board = board[:count+8] + "*" + board[count+9:]
                moves.add(count+8)
            count = x
            while not (count-8) < 0 and board[count-8] != "." and board[count-8] != token and board[count-8]!="*": #Up
                count-=8
            if count != x and not (count-8) < 0 and board[count-8] =="." and board[count+8] != "*":
                board = board[:count-8] + "*" + board[count-7:]
                moves.add(count-8)
            count=x
            while not (count+9) > 63 and (count+9)%8 != 0 and board[count+9] != "." and board[count+9] != token and board[count+9]!="*": #DownRight
                count+=9
            if count != x and not (count+9) > 63 and board[count+9] == "." and (count+9)%8 != 0 and board[count-9] != "*":
                board = board[:count+9] + "*" + board[count+10:]
                moves.add(count+9)
            count = x
            while not (count+7) >63 and (count+7)%8 != 7 and board[count+7] != "." and board[count+7] != token and board[count+7]!="*": #DownLeft
                count+=7
            if count != x and not (count+7) > 63 and board[count+7] == "." and (count+7)%8 != 7 and board[count+7] != "*":
                board = board[:count+7] + "*" + board[count+8:]
                moves.add(count+7)
            count = x
            while not (count-7) < 0 and (count-7)%8 != 0 and board[count-7] != "." and board[count-7] != token and board[count-7]!="*": #UpRight
                count-=7
            if count != x and not (count-7) < 0 and board[count-7] =="." and (count-7)%8 != 0 and board[count+7] != "*":
                board = board[:count-7] + "*" + board[count-6:]
                moves.add(count-7)
            count = x
            while not (count-9) < 0 and (count-9)%8 != 7 and board[count-9] != "." and board[count-9] != token and board[count-9]!="*": #UpLeft
                count-=9
            if count != x and not (count-9) < 0 and board[count-9] =="." and (count-9)%8 != 7 and board[count+9] != "*":
                board = board[:count-9] + "*" + board[count-8:]
                moves.add(count-9)
    for x in range (0, len(board)):
        if board[x] == "*":
            board = board[:x] + "." + board[x+1:]
    #print(board)
    originalmoves = moves
    leftedge = {8, 16, 24, 32, 40, 48}
    rightedge = {15, 23, 31, 39, 47, 55}
    topedge = {1, 2, 3, 4, 5, 6}
    bottomedge = {57, 58, 59, 60, 61, 62}
    for num in [0, 7, 63, 56]:
        if num in moves:
            print("My Move Is Greedy Corners and my move is", num)
            return num #If there is a corner available
    #Returns a square on an edge if corner is controlled
    if board[0] == token:
        newset = moves.intersection(leftedge) | moves.intersection(topedge)
        if newset:
            for spot in newset:
                if spot in leftedge:
                    for x in range (0, 57, 8):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
                if spot in topedge:
                    for x in range (0, 8):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
    if board[7] == token:
        newset = moves.intersection(rightedge) | moves.intersection(topedge)
        if newset:
            for spot in newset:
                if spot in rightedge:
                    for x in range (7, 64, 8):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
                if spot in topedge:
                    for x in range (7, -1, -1):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
    if board[56] == token:
        newset = moves.intersection(leftedge) | moves.intersection(bottomedge)
        if newset:
            for spot in newset:
                if spot in leftedge:
                    for x in range (57, -1, -8):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
                if spot in bottomedge:
                    for x in range (56, 64):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
    if board[63] == token:
        newset = moves.intersection(rightedge) | moves.intersection(bottomedge)
        if newset:
            for spot in newset:
                if spot in rightedge:
                    for x in range (63, 0, -8):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
                if spot in bottomedge:
                    for x in range (63, 55, -1):
                        if board[x] == "." and x == spot:
                            move = newset.pop()
                            print("My Move Is Secured Edge and my move is", move)
                            return move
                        elif board[x] == ".":
                            break
    #Removes all X and C spaces if corner is not in possession
    if board[0] != token:
        moves = moves.difference({1, 8, 9})
    if board[7] != token:
        moves = moves.difference({6,15, 14})
    if board[56] != token:
        moves = moves.difference({48, 57, 49})
    if board[63] != token:
        moves = moves.difference({55, 62, 54})
    nosides = moves.difference(leftedge) | moves.difference(rightedge) | moves.difference(topedge) | moves.difference(bottomedge)
    if nosides:
        return nosides.pop()
    nm = negamax(board, token, 5)
    print(nm)
    #print("Time: ", time.time()-starttime)
    print("My Move Is Negamax and my move is ",nm[-1])
    #print(nm)
    return nm[-1]

def negamax(board, token, levels):
    #print("\n", "Board for level ", levels)
    enemy = {"X", "O"}.difference(token).pop()
    if not levels:
        return [score(board, token)]
    if not allMoves(board, token):
        if not allMoves(board, enemy):
            return [score(board, token)]
    lm = allMoves(board, token).difference({1, 8, 9, 6, 15, 14, 48, 57, 49, 55, 62, 54})
    if not lm:
        lm = allMoves(board, token)
    if not lm:
        nm = negamax(board, enemy, levels-1)+[-1]
        return [-nm[0]]+nm[1:]
    nmlist = sorted([negamax(swapTokens(board, token, mv), enemy, levels-1)+[mv] for mv in lm])
    best = nmlist[0]
    #print(nmlist)
    return [-best[0]]+best[1:]

def negamaxTerminal(board, token, improvable, hardBound):
    lm = allMoves(board, token)
    enemy = {"X", "O"}.difference(token).pop()
    #print("Token: ", token, " Enemy: ", enemy)
    #print("------------------------")
    #print(board)
    if not lm:
        #print("IN")
        lm = allMoves(board, enemy)
        #print(lm)
        if not lm: return [score(board, token), -3]
        #print("I")
        nm = negamaxTerminal(board, enemy, -hardBound, -improvable)+[-1]
        return[-nm[0]]+nm[1:]
    best = []
    newHB = -improvable
    #print("Here")
    for mv in lm:
        #print(lm)
        #print(mv)
        newboard = swapTokens(board, token, mv)
        #print(newboard)
        nm = negamaxTerminal(newboard, enemy, -hardBound, newHB)+[mv]
        #print(nm)
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound: return [-best[0]]+best[1:]
    return [-best[0]]+[best[1:]]

def evalBoard(board, token):
    tokens = {"X", "O"}-{token}
    enemy = tokens.pop()
    return board.count(token)-board.count(enemy)

def findTurn(board):
    count = board.count(".")
    if count%2 == 0:
        return "X"
    else:
        return "O"

def displayBoard(board):
    print("",board[0:8],"\n",board[8:16],"\n",board[16:24],"\n",board[24:32],"\n",board[32:40],"\n",board[40:48],"\n",board[48:56],"\n",board[56:64])

def main():
    input = sys.argv[1:]
    board = "...........................OX......XO..........................."
    token = 0
    for arg in input:
        if isinstance(arg, str):
            arg = arg.upper()
        if len(arg) == 64:
            board = arg
        if arg in {"X", "O"}:
            token = arg
    if not token:
        token = findTurn(board)
    makeMove(board, token)

if __name__ == "__main__":
    main()

