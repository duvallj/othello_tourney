#Jan 12, 0952 version
# vals = {11: 500, 12: 0, 13: 2, 14: 2, 15: 2, 16: 2, 17: 0, 18: 500, \
#                 21: 0, 22: 0, 23: 0, 24: 0, 25: 0, 26: 0, 27: 0, 28: 0, \
#                 31: 2, 32: 0, 33: 1, 34: 1, 35: 1, 36: 1, 37: 0, 38: 2, \
#                 41: 2, 42: 0, 43: 1, 44: 1, 45: 1, 46: 1, 47: 0, 48: 2, \
#                 51: 2, 52: 0, 53: 1, 54: 1, 55: 1, 56: 1, 57: 0, 58: 2, \
#                 61: 2, 62: 0, 63: 1, 64: 1, 65: 1, 66: 1, 67: 0, 68: 2, \
#                 71: 0, 72: 0, 73: 0, 74: 0, 75: 0, 76: 0, 77: 0, 78: 0, \
#                 81: 500, 82: 0, 83: 2, 84: 2, 85: 2, 86: 2, 87: 0, 88: 500, \
#                 }


#### Othello Shell
#### P. White 2016-2018
# EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'


# To refer to neighbor squares we can add a direction to a square.


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
from multiprocessing import Value, Process
class Strategy():
    def __init__(self):
        self.standard_strategy=self.minmax_strategy
        ONECORNER, ONECE, ONEE1, ONEE2, ONECM, ONEM1, ONEM2, ONECM2, ONEMM1, ONECENTER = [50, -30, 10, 10, -30, 5, 5,
                                                                                          -1, -1, -1]
        self.vals = {11: ONECORNER, 12: ONECE, 13: ONEE1, 14: ONEE2, 15: ONEE2, 16: ONEE1, 17: ONECE, 18: ONECORNER, \
                   21: ONECE, 22: ONECM, 23: ONEM1, 24: ONEM2, 25: ONEM2, 26: ONEM1, 27: ONECM, 28: ONECE, \
                   31: ONEE1, 32: ONEM1, 33: ONECM2, 34: ONEMM1, 35: ONEMM1, 36: ONECM2, 37: ONEM1, 38: ONEE1, \
                   41: ONEE2, 42: ONEM2, 43: ONEMM1, 44: ONECENTER, 45: ONECENTER, 46: ONEMM1, 47: ONEM2, 48: ONEE2, \
                   51: ONEE2, 52: ONEM2, 53: ONEMM1, 54: ONECENTER, 55: ONECENTER, 56: ONEMM1, 57: ONEM2, 58: ONEE2, \
                   61: ONEE1, 62: ONEM1, 63: ONECM2, 64: ONEMM1, 65: ONEMM1, 66: ONECM2, 67: ONEM1, 68: ONEE1, \
                   71: ONECE, 72: ONECM, 73: ONEM1, 74: ONEM2, 75: ONEM2, 76: ONEM1, 77: ONECM, 78: ONECE, \
                   81: ONECORNER, 82: ONECE, 83: ONEE1, 84: ONEE2, 85: ONEE2, 86: ONEE1, 87: ONECE, 88: ONECORNER, \
                   }
        self.fweight = 70
        count=0
        open = []
        for i in self.get_starting_board():
            if not i == "?":
                open.append(count)
            count+=1
        self.open = open
        self.transTable = {}

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return ("???????????........??........??........??...o@...??...@o...??........??........??........???????????")

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        count = 0
        ret = ""
        for i in board:
            if(i is not "?"):
                ret += (i+"")
        return ret

    def opponent(self, player):
        """Get player's opponent."""
        if player == "@":
            return "o"
        return "@"

    def find_match(self,board,piece,dir,index):
        count = 0
        index+=dir
        while board[index] == piece:
            count+=1
            index+=dir
        if(board[index] == "?" or board[index] == "." or count<1):
            return 0
        return count

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def score_board_heuristic(self, board, player, update = True, who = None):
        if board in self.transTable:
            loss, score = self.transTable[board]
            return score
        score = 0
        opp = self.opponent(player)
        for i in self.open:
            if board[i] == player:
                score+=self.vals[i]
            elif board[i] == opp:
                score-=self.vals[i]

        if update:
            score += (self.fweight * self.count_no_flip(board, player))
            score -= (self.fweight * self.count_no_flip(board, opp))
            score += (10 * self.countSurr(board, player))
            score -= (10 * self.countSurr(board, opp))
            score -= (20 * self.countParity(board, player))
            score += (20 * self.countParity(board, opp))
            self.transTable.update({board:(0,score)})
        return score


    def make_move(self,board,player,index):
        boardArr = list(board)
        boardArr[index] = player
        directions = [1,-1,10,-10,9,-9,11,-11]
        for i in directions:
            count = self.find_match(board,self.opponent(player),i,index)
            temp= index+i
            for k in range(0,count):
                boardArr[temp] = player
                temp+=i
        newBoard = ''.join(boardArr)
        return newBoard

    def getEdges(self,board):
        edges = set()
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        for k in self.open:
            if board[k] == ".":
                index = 0
                found = False
                while index < 8 and found == False:
                    on = directions[index]
                    if board[on+k] == "o" or board[on+k] == "@":
                        found = True
                    index += 1
                if found == True:
                    edges.add(k)
        return edges

    def get_valid_moves(self, board, player, stop = False, edges = None):
        moves = []
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        opp = self.opponent(player)
        if edges is None:
            edges = set()
            for i in self.open:
                edges.add(i)
        for i in edges:
            if board[i] == ".":
                index = 0
                found = False
                while index<8 and found == False:
                    on = directions[index]
                    number = self.find_match(board,opp,on,i)
                    if number > 0:
                        found = True
                    index+=1
                if found == True:
                    moves.append(i)
                    if stop:
                        return moves
        return moves

    def has_any_valid_moves(self, board, player, edges = None):
        moves = self.get_valid_moves(board,player,stop = True,edges = edges)
        return len(moves)!=0

    def next_player(self, board, prev_player,edges = None):
        """Which player should move next?  Returns None if no legal moves exist."""
        next = self.opponent(prev_player)
        if self.has_any_valid_moves(board,next,edges):
            return next
        if self.has_any_valid_moves(board,prev_player,edges):
            return prev_player
        return None



    def score(self, board, player="@"):
        """Compute player's score (number of player's pieces minus opponent's)."""
        val = 0
        oppPlayer = self.opponent(player)
        for i in board:
            if i == player:
                val+=1
            if i == oppPlayer:
                val-=1
        return val

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        pass

    # class IllegalMoveError(Exception):
    #     def __init__(self, player, move, board):
    #         self.player = player
    #         self.move = move
    #         self.board = board
    #
    #     def __str__(self):
    #         return '%s cannot move to square %d' % ("@", self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth, who, alpha, beta, edges,myMoves,theirMoves):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if player == None:
            return (0,1000*self.score(board,who))
        if(depth == 0):
            return (0, self.score_board_heuristic(board,who,who=who))
        if board in self.transTable:
            return self.transTable[board]

        moves = (self.get_valid_moves(board,player,edges = edges))
        if depth > 3:
            moves = sorted(moves,key=lambda x: -self.score_board_heuristic(self.make_move(board,player,x),player, update = False,who=who))
        # else:
        #     random.shuffle(moves)
        bestmove = -1
        bestscore = None
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        add = len(moves)
        if player ==who:
            if myMoves == [0]:
                myMoves = [add]
            myMoves.append(add)
        else:
            if theirMoves == [0]:
                theirMoves = [add]
            theirMoves.append(add)
        if player == who:
            for i in moves:
                newBoard = self.make_move(board,player,i)
                newEdges = edges.copy()
                newEdges.remove(i)
                for k in directions:
                    newEdges.add(k+i)
                next = self.next_player(newBoard, player, edges = newEdges)

                loss,score = self.minmax_search(newBoard,next,depth-1,who,alpha,beta,newEdges,myMoves,theirMoves)
                if bestscore == None:
                    bestscore = score
                if score > alpha:
                    alpha = score
                    bestmove = i
                    bestscore = score
                    if(alpha >= beta):
                        return i,score
            self.transTable.update({board:(bestmove,bestscore)})
            return bestmove,bestscore

        for i in moves:
            newBoard = self.make_move(board, player, i)
            newEdges = edges.copy()
            newEdges.remove(i)
            for k in directions:
                newEdges.add(k + i)
            next = self.next_player(newBoard, player, edges=newEdges)
            loss,score = self.minmax_search(newBoard, next, depth - 1, who,alpha,beta, newEdges,myMoves,theirMoves)
            if bestscore == None:
                bestscore = score
            if (score) < (beta):
                bestmove = i
                bestscore = score
                beta = score
                if (alpha >= beta):
                    return bestmove,bestscore
        self.transTable.update({board: (bestmove,bestscore)})
        return bestmove,bestscore


    def minmax_strategy(self, board, player, depth):
        self.transTable = {}
        move,loss =  self.minmax_search(board,player,depth,player,-6500000,6500000,self.getEdges(board),[0],[0])
        self.transTable = {}
        return move

    def count_no_flip(self,board,player):
        corner = [11,18,81,88]
        corDir = {11:[10,1],18:[-1,10],81:[-10,1],88:[-10,-1]}
        been = set()
        count = 0
        for i in corner:
            if board[i] == player:
                new = set()
                new.add(i)
                remove = set()
                while len(new) != 0:

                    old = new.copy()
                    new = set()
                    for k in old:
                        if board[k] == player and board[k] != "?":
                            if not k in been:
                                count+=1
                            new.add(k + (corDir[i])[1])
                            new.add(k + (corDir[i])[0])
                            been.add(k)
                        else:
                            remove.add(k)
                    oldRemove = remove.copy()
                    for k in oldRemove:
                        new.discard(k + (corDir[i])[0])
                        new.discard(k + (corDir[i])[1])
                        remove.add(k + (corDir[i])[1])
                        remove.add(k + (corDir[i])[0])
        return count

    def countSurr(self,board,player):
        count = 0
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        on = 0
        for i in board:
            if i == player:
                dirNumber = 0
                found = False
                while(not found) and dirNumber<8:
                    k = directions[dirNumber]
                    index = on+k
                    while(board[index] == player):
                        index+=k
                    if(board[index] == "."):
                        found = True
                    dirNumber+=1
                if not found:
                    count+=1
            on+=1
        return count

    def countParity(self,board,player):
        corner = [1,8]
        count = 0
        for i in corner:
            last1 = None
            last2 = None
            for k in range(1,9):
                if board[int(str(k)+str(i))] == player:
                    if last1 is None:
                        last1 = k
                    else:
                        if last1+1!=k:

                            count+=1
                            if(k-last1)%2 == 1:
                                count-=2
                        last1 = k
                if board[int(str(i)+str(k))] == player:
                    if last2 is None:
                        last2 = k
                    else:
                        if last2+1!=k:
                            count+=1
                            if(k-last2)%2 == 1:
                                count-=2
                        last2=k
        return count

    def best_strategy(self, board, player, best_move, running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1

        while True:
            ## doing random in a loop is pointless but it's just an example
            test = self.minmax_strategy(board,player,depth)
            best_move.value = test
            depth += 2

    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False
#
# #################################################
# # ParallelPlayer simulated tournament play
# # With parallel processes and time limits
# # this may not work on Windows, because, Windows is lame
# # This calls Strategy.best_strategy(board, player, best_shared, running)
# ##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = "@"

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == "@" else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))



if __name__ == "__main__":
    game =  ParallelPlayer()
    game.play()

