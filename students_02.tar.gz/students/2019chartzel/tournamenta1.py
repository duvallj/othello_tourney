#ssh 2019chartzel@remote.tjhsst.edu
#cp <filename> ~pcgabor/dropbox/othello-lab<num>/p<period><first 3 letters lastname lowercase>.py
import sys, random
#b1 = "...........................OX......XO..........................."#X turn
#b2 = "..................X........XX......OXX.....O...................."#O turn, sol={19,21,29,38}
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        board = "".join(board).replace("?", "").replace("@", "X").replace("o", "O")
        turn = ""
        if player=="@":
            turn = "X"
        else:
            turn = "O"
        ofm = -1
        if len(legalmoves(board, turn)) == 1:
            ofm = legalmoves(board, turn).pop()
        else:
            rm = random.choice(tuple(legalmoves(board, turn)))
            best_move.value = 11 + (rm // 8) * 10 + (rm % 8)
            if board.count(".") < 13:
                ofm = negamax(board, turn, 5)[-1]
            else:
                ofm = selamove(board, turn)
        best_move.value = 11 + (ofm // 8) * 10 + (ofm % 8)
"""
if True:
    board, turn = "", ""
    cla = sys.argv[1:]
    if cla and isaboard(cla[0]):
        board = cla.pop(0).upper()
    else:
        board = "...........................OX......XO..........................."
    if cla and (cla[0].upper()=="X" or cla[0].upper()=="O"):
        turn = cla.pop(0).upper()
    else:
        turn = whosturnnopasses(board)
    if len(legalmoves(board, turn)) == 1:
        print(legalmoves(board, turn).pop())
    else:
        print(random.choice(tuple(legalmoves(board, turn))))
        if board.count(".") < 13:
            print(negamax(board, turn, 5)[-1])
        else:
            print(selamove(board, turn))
"""
convdictlet = dict(zip(["a", "b", "c", "d", "e", "f", "g", "h"], [0, 1, 2, 3, 4, 5, 6, 7]))
postoneigh = dict()
for x in range(64):
    ta = [None]*8
    abv,bel,lef,rgt=False,False,False,False
    if x+8<64:
        ta[0] = x+8
        bel=True
    if x-8>-1:
        ta[1] = x-8
        abv=True
    if (x-1)//8==x//8:
        ta[2] = (x-1)
        lef=True
    if (x+1)//8==x//8:
        ta[3] = (x+1)
        rgt=True
    if bel and rgt:
        ta[4] = (x+8+1)
    if bel and lef:
        ta[5] = (x+8-1)
    if abv and rgt:
        ta[6] = (x-8+1)
    if abv and lef:
        ta[7] = (x-8-1)
    postoneigh[x] = ta
#below, above, left, right, br, bl, ur, ul
def whosturnnopasses(board):
    return "O" if (board.count("X") + board.count("O"))%2 else "X"
def invertturn(let):
    if let == "X":
        return "O"
    return "X"
def legalmoves(board, whosturn):
    opp = invertturn(whosturn)
    oppinds = {ind for ind, ltr in enumerate(board) if ltr == opp}
    blankinds = {ind for ind, ltr in enumerate(board) if ltr == "."}
    tocheck = set()
    for bind in blankinds:
        for oppi in set(postoneigh[bind]) & oppinds:
            tocheck.add((bind, postoneigh[bind].index(oppi)))
    tr = set()
    for tup in tocheck:
        spot, dir = tup[0], tup[1]
        spot = postoneigh[spot][dir]
        spot = postoneigh[spot][dir]
        while spot is not None:
            val = board[spot]
            if val==whosturn:
                tr.add(tup[0])
                break
            if val==".":
                break
            spot = postoneigh[spot][dir]
            if not spot:
                break
    return tr
def convpos(position):
    return convdictlet[position[0].lower()] + int(position[1])* 8 - 8
def makemoveF(board, token, position): #assumes everything formatted and position is an int and a valid move
    tr = board
    opptoken = invertturn(token)
    tf = [position]
    for mydir in range(8):
        pos = postoneigh[position][mydir]
        tpf = []
        while pos is not None and tr[pos] == opptoken:
            tpf.append(pos)
            pos = postoneigh[pos][mydir]
        if pos is not None and tr[pos] == token:
            tf = tf + tpf
    tm = list(tr)
    for mf in tf:
        tm[mf] = token
    tr = "".join(tm)
    return tr
def makemoveUF(board, token, position): #board must be formatted though
    tr = board
    if not position.isdigit():
        position = convpos(position)
    else:
        position = int(position)
    token = token.upper()
    opptoken = invertturn(token)
    #if position not in legalmoves(tr, token): return None #comment out if unneccessary
    tf = [position]
    for mydir in range(8):
        pos = postoneigh[position][mydir]
        tpf = []
        while pos is not None and tr[pos] == opptoken:
            tpf.append(pos)
            pos = postoneigh[pos][mydir]
        if pos is not None and tr[pos] == token:
            tf = tf + tpf
    tm = list(tr)
    for mf in tf:
        tm[mf] = token
    tr = "".join(tm)
    return tr
def isamove(str):
    return str.isdigit() or (str[0].lower() in "abcdefgh" and str[1] in "12345678")
def isaboard(str):
    return len(str) == 64
def edgewithcornercheck(board, move, turn):
    ll = [0, 8,16,24,32,40,48,56]
    tl = [0,1,2,3,4,5,6,7]
    bl = [56,57,58,59,60,61,62,63]
    rl = [7,15,23,31,39,47,55,63]
    s1, s2 = "", ""
    if move in ll:
        s1, s2 = "".join([board[i] for i in ll[0:ll.index(move)+1]]), "".join([board[i] for i in ll[ll.index(move):]])
    elif move in tl:
        s1, s2 = "".join([board[i] for i in tl[0:tl.index(move) + 1]]), "".join([board[i] for i in tl[tl.index(move):]])
    elif move in bl:
        s1, s2 = "".join([board[i] for i in bl[0:bl.index(move) + 1]]), "".join([board[i] for i in bl[bl.index(move):]])
    else:
        s1, s2 = "".join([board[i] for i in rl[0:rl.index(move) + 1]]), "".join([board[i] for i in rl[rl.index(move):]])
    if not len(s1.replace(turn, "")) or not len(s2.replace(turn, "")):
        return True
    return False
def selamove(board, turn):
    lm = legalmoves(board, turn)
    rm = random.choice(tuple(lm))
    if {0,7,56,63} & lm:
        return random.choice(tuple({0,7,56,63}.intersection(lm)))
    ewcl = []
    for move in lm & {1,2,3,4,5,6,8,15,16,23,24,31,32,39,40,47,48,55,57,58,59,60,61,62}:
        nb = makemoveF(board, turn, move)
        if edgewithcornercheck(nb, move, turn):
            ewcl.append(move)
    if ewcl:
        return random.choice(ewcl)
    if board[0] is not turn:
        lm = lm - {1,8,9}
    if board[7] is not turn:
        lm = lm - {6,14,15}
    if board[56] is not turn:
        lm = lm - {48,49,57}
    if board[63] is not turn:
        lm = lm - {54,55,62}
    if not lm:
        return rm
    rm = random.choice(tuple(lm))
    lm = lm - {1,2,3,4,5,6,8,15,16,23,24,31,32,39,40,47,48,55,57,58,59,60,61,62}
    if not lm:
        return rm
    return random.choice(tuple(lm))
def boardeval(board, token):
    return board.count(token) - board.count(invertturn(token))
def negamax(board, token, levels):
    invtok = invertturn(token)
    if not levels:
        return [boardeval(board, token)]
    lm = legalmoves(board, token)
    if not lm:
        nm = negamax(board, invtok, levels-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makemoveF(board, token, mv),invtok,levels-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]