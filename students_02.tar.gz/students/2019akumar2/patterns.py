# This script loads all of the files into array.array
# Reading bytes is much faster than any other method.
# It also keeps file sizes down. The information is 
# Stored as base2To3(patternPlayer) - base2To3(patternOpponent)
# Pattern values found using hill climbing.
#   https://skatgame.net/mburo/ps/evalfunc.pdf
import array, os

diag4  = [None] * 13 # Diagonals of length 4
diag5  = [None] * 13 # Diagonals of length 5
diag6  = [None] * 13 # Diagonals of length 6
diag7  = [None] * 13 # Diagonals of length 7
diag8  = [None] * 13 # Diagonals of length 8
lc1    = [None] * 13 # Row/Col 1
lc2    = [None] * 13 # Row/Col 2
lc3    = [None] * 13 # Row/Col 3
lc4    = [None] * 13 # Row/Col 4
corn   = [None] * 13 # Corners
parity = [None] * 13 # Parity

cwd = os.getcwd() # Current folder
for s in range(13): # 13 stages of the game
    diag4[s] = array.array('i')
    diag4[s].fromfile(open(os.path.join(cwd, 'diag4_{}.pkl'.format(s)), 'rb'), 81)

    diag5[s] = array.array('i')
    diag5[s].fromfile(open(os.path.join(cwd, 'diag5_{}.pkl'.format(s)), 'rb'), 243)

    diag6[s] = array.array('i')
    diag6[s].fromfile(open(os.path.join(cwd, 'diag6_{}.pkl'.format(s)), 'rb'), 729)

    diag7[s] = array.array('i')
    diag7[s].fromfile(open(os.path.join(cwd, 'diag7_{}.pkl'.format(s)), 'rb'), 2187)

    diag8[s] = array.array('i')
    diag8[s].fromfile(open(os.path.join(cwd, 'diag8_{}.pkl'.format(s)), 'rb'), 6561)

    lc1[s] = array.array('i')
    lc1[s].fromfile(open(os.path.join(cwd, 'lc1_{}.pkl'.format(s)), 'rb'), 6561)

    lc2[s] = array.array('i')
    lc2[s].fromfile(open(os.path.join(cwd, 'lc2_{}.pkl'.format(s)), 'rb'), 6561)

    lc3[s] = array.array('i')
    lc3[s].fromfile(open(os.path.join(cwd, 'lc3_{}.pkl'.format(s)), 'rb'), 6561)

    lc4[s] = array.array('i')
    lc4[s].fromfile(open(os.path.join(cwd, 'lc4_{}.pkl'.format(s)), 'rb'), 6561)

    corn[s] = array.array('i')
    corn[s].fromfile(open(os.path.join(cwd, 'corn_{}.pkl'.format(s)), 'rb'), 6561)

    parity[s] = array.array('i')
    parity[s].fromfile(open(os.path.join(cwd, 'parity_{}.pkl'.format(s)), 'rb'), 2)