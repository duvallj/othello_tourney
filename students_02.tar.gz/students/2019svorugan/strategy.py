import random
import math
import time

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

WS =  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
       0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
       0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
       0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
       0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
       0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
       0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
       0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ]

START_BOARD = '???????????........??........??........??...o@...??...@o...??........??........??........???????????'
INDICES = [i for i in range(len(START_BOARD)) if START_BOARD[i] != OUTER]
# CORNERS = [12, 19, 82, 89]
CORNERS = [11, 18, 81, 88]
# ADJ_CORNERS = [13, 22, 23, 18, 28, 29, 72, 73, 83, 78, 79, 88]        # OLD!
ADJ_CORNERS = [12, 21, 22, 17, 27, 28, 71, 72, 82, 77, 78, 87]
ADJ_C_DICT = {12:11, 21:11, 22:11, 17:18, 27:18, 28:18, 71:81, 72:81, 82:81, 77:88, 78:88, 87:88}
B_VALID = 0
W_VALID = 0

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class node:
    def __init__(self, board, move, score=0):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self,other):
        return self.score < other.score


class Strategy():

    def get_starting_board(self):       # WORKS
        """Create a new board with the initial black and white positions filled."""
        return START_BOARD

    def __init__(self):
        pass

    def get_pretty_board(self, board):      # WORKS
        """Get a string representation of the board."""
        temp = board
        for x in range(0,len(temp)):
            if x % 10 == 0 and x != 0:
                temp = temp[0:x] + "\n" + temp[x+1:len(board)]
        for x in board:
            if x == "?":
                temp = temp.replace("?", "")
        return temp

    def opponent(self, player): # WORKS
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        if player == WHITE:
            return BLACK

    def find_match(self, board, player, square, direction): # WORKS
        """Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists."""
        square += direction
        while board[square] == self.opponent(player):
            square += direction

            if board[square] == player:
                return square
        return None

    def is_move_valid(self, board, player, move):   # WORKS
        """Is this a legal move for the player?"""
        for dir in DIRECTIONS:
            if self.find_match(board, player, move, dir) is not None:
                return True
        return False

    def make_move(self, board, player, move):   # WORKS
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        valid_directions = []
        for dir in DIRECTIONS:  # loop through, find all directions w/ matches
            if self.find_match(board, player, move, dir) is not None:
                valid_directions.append(dir)

        board = list(board)         # list FASTER THAN string
        for x in valid_directions:  # loop through valid directions & change squares until match
            i = move
            board[i] = self.opponent(player)
            while board[i] != player:
                board[i] = player                                           # list version
                i += x
                # board = board[0:i] + player + board[i+1:len(board)]       # string version
        board = "".join(board)                                              # change it back into a string
        return board

    def get_valid_moves(self, board, player): # WORKS
        global B_VALID
        global W_VALID
        #################################################################
        """Get a list of all legal moves for player."""
        valid_moves = []
        for x in range(len(board)):
            if board[x] == "." and self.is_move_valid(board, player, x):
                valid_moves.append(x)
        #################################################################
        if player == BLACK:
            B_VALID = len(valid_moves)
        else:
            W_VALID = len(valid_moves)
        return valid_moves

    def has_any_valid_moves(self, board, player):   # WORKS
        """Can player make any moves?"""
        if self.get_valid_moves(board, player) == []:
            return False
        return True

    def next_player(self, board, prev_player):  # WORKS
        """Which player should move next?  Returns None if no legal moves exist."""
        opp = self.opponent(prev_player)
        if self.has_any_valid_moves(board, opp):
            return opp
        # return prev_player
        if self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):   # WORKS
        """Compute player's score (number of player's pieces minus opponent's)."""
        b_count = 0
        w_count = 0
        for x in board:
            if x == BLACK:
                b_count += 1
            if x == WHITE:
                w_count += 1
        return b_count - w_count

    def basic_wscore(self, board):
            score = 0
            for i in INDICES:
                if board[i] == BLACK:
                        score += WS[i]
                elif board[i] == WHITE:
                        score -= (WS[i])
            return score

    # def weighted_score(self, board, player=BLACK):
    #     score = 0
    #     for i in INDICES:   # gives it a list of indexes of all squares != ?, so no looping through ?s
    #         adjcd = i in ADJ_C_DICT
    #         # adj = i in ADJ
    #         if board[i] == BLACK:
    #             if adjcd and board[ADJ_C_DICT[i]] == BLACK and board[i] == EMPTY:
    #                 score -= WS[i]
    #             else:
    #                 score += WS[i]
    #         elif board[i] == WHITE:
    #             if adjcd and board[ADJ_C_DICT[i]] == WHITE and board[i] == EMPTY:
    #                 score += WS[i]
    #             else:
    #                 score -= WS[i]
    #     return score

    # def test_wscore(self, board, player):
    #     tic = time.time()
    #     for i in range(50000):
    #         self.weighted_score(board, player)
    #     toc = time.time()
    #     print(toc-tic)

    def best_score(self, board, player=BLACK):
        # 1 - WEIGHTED SCORE
        ws = 50*(self.basic_wscore(board))

        # 2 - MOBILITY
        b = B_VALID
        w = W_VALID

        if b == w or b == 0 or w == 0:  # equal moves
            m = 0
        elif b > w:  # black has more moves
            m = 100*(b / (b + w))
        elif b < w:  # white has more moves
            m = -100*(w / (b + w))
            # print("m: ", m)
        # # 3 - CORNER OCCUPANCY
        # b = 0
        # w = 0
        # for x in CORNERS:
        #     if board[x] == BLACK:
        #         b += 1
        #     if board[x] == WHITE:
        #         w += 1
        # c = 50 * b - 50 * w
        # # print("c: ", c)
        #
        # # 4 - CORNER CLOSENESS
        # b = 0
        # w = 0
        # for x in ADJ_C_DICT:
        #     if ADJ_C_DICT[x] == EMPTY:
        #         if board[x] == BLACK:
        #             b += 1
        #         if board[x] == WHITE:
        #             w += 1
        # l = -50 * b + 50 * w
        # # print("l: ", l)

        score = ws + m      # + c + l
        # print(score)
        return score

    def game_over(self, board, player):    # WORKS
        """Return true if player and opponent have no valid moves"""
        if self.next_player(board, player) is None:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, n, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        board = n.board
        if depth == 0:
            n.score = self.score(board)     # STRATEGIC SCORE HERE: normal
            return n
        children = []
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            next_p = self.next_player(next_board, player)
            if next_p is None:
                c = node(next_board, move, score=1000*self.score(next_board))   # NORMAL SCORE HERE
                children.append(c)
            else:
                c = node(next_board, move)
                c.score = self.minmax_search(c, next_p, depth=depth-1).score
                children.append(c)

        winner = best[player](children)
        node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=3):
        # calls minmax_search, returns an integer move
        start_node = node(board, None)
        result = self.minmax_search(start_node, player, depth)
        move = result.move
        return move

    def alpha_beta_search(self, n, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = n.board
        if depth == 0:
            n.score = self.best_score(board)     # STRATEGIC SCORE HERE: best
            return n
        children = []
        for move in self.get_valid_moves(board, player):
            # if move in CORNERS:
            next_board = self.make_move(board, player, move)
            next_p = self.next_player(next_board, player)
            if next_p is None:
                c = node(next_board, move, score=1000*self.score(next_board))   # NORMAL SCORE HERE
                children.append(c)
            else:
                c = node(next_board, move)
                c.score = self.alpha_beta_search(c, next_p, depth-1, a, b).score
                children.append(c)
                if player == BLACK:
                    a = max(a, c.score)
                if player == WHITE:
                    b = min(b, c.score)
                if a >= b:
                    break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta_strategy(self, board, player, depth=5, a=-1000000, b=1000000):
        # calls alpha_beta_search, returns an integer move
        start_node = node(board, None)
        result = self.alpha_beta_search(start_node, player, depth, a, b)
        move = result.move
        return move

    def ab2_search(self, n, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = n.board
        if depth == 0:
            n.score = self.basic_wscore(board)     # STRATEGIC SCORE HERE: basic weighted
            return n
        children = []
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            next_p = self.next_player(next_board, player)
            if next_p is None:
                c = node(next_board, move, score=1000*self.score(next_board))   # NORMAL SCORE HERE
                children.append(c)
            else:
                c = node(next_board, move)
                c.score = self.alpha_beta_search(c, next_p, depth-1, a, b).score
                children.append(c)
                if player == BLACK:
                    a = max(a, c.score)
                if player == WHITE:
                    b = min(b, c.score)
                if a >= b:
                    break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def ab2_strategy(self, board, player, depth=5, a=-1000000, b=1000000):
        # calls alpha_beta_search, returns an integer move
        start_node = node(board, None)
        result = self.ab2_search(start_node, player, depth, a, b)
        move = result.move
        return move
    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        # THIS IS the public function you must implement
        # Run your best search in a loop and update best_move.value
        depth = 1
        while True:
            # best_move.value = self.random_strategy(board, player)
            # best_move.value = self.minmax_strategy(board, player, depth)
            best_move.value = self.alpha_beta_strategy(board, player, depth)
            depth += 1

    # standard_strategy = random_strategy
    # standard_strategy = minmax_strategy
    standard_strategy = alpha_beta_strategy

###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        # strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        strategy = {BLACK: black.standard_strategy, WHITE: white.ab2_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        s = ref.score(board)
        print("Final Score %i." % s, end=" ")
        print("%s wins" % ("Black" if s>0 else "White"))

        # print("Final Score %i." % ref.score(board), end=" ")
        # print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))



if __name__ == "__main__":

    tic = time.time()
    game = ParallelPlayer(1)
    game.play()
    toc = time.time()
    print("TIME: ", toc-tic)

    # tic = time.time()
    # game = StandardPlayer()
    # game.play()
    # toc = time.time()
    # print("TIME: ", toc-tic)

    # print(WEIGHTED_SCORES)
    # test = Strategy()
    # Strategy.test_wscore(test,"???????????o@@@@@@@??oo@@@@@@??ooo@o@@@??ooo@oo@@??@oo@@o@@??o@o@@@oo??oo@@@ooo??.oo@@@@o???????????", BLACK)


    # print(Strategy.get_valid_moves(test, '???????????........??........??........??...o@...??...@o...??........??........??........???????????', '@'))
    # print(Strategy.get_valid_moves(test, '???????????........??........??..@.....??...@oo..??...@@o..??....ooo.??........??........???????????', '@',))
    # print(Strategy.get_pretty_board(test, '???????????........??........??........??...o@...??...@o...??........??........??........???????????'))