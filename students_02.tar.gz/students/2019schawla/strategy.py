import sys

othello = "." * 27 + "ox" + "." * 6 + "xo" + "." * 27
spaceTile, placeHolder = {*range(64)}, {"x": set(), "o": set()}
config = (-8, 8, -1, 1, -7, -9, 9, 7)


def dual(myT):
    if myT == "x": return "o"
    return "x"


def adDual(index, myT):
    thisList = set()
    for i in config:
        if index + i in placeHolder[dual(myT)] and index + i not in {0, 8, 16, 24, 32, 40, 48, 56, 7, 15, 23, 31, 39,
                                                                     47, 55, 63}:
            thisList.add((index + i, i))
    return thisList


def uni(index, myT, orientation):
    while index in placeHolder[myT] and index + orientation not in {0, 8, 16, 24, 32, 40, 48, 56, 7, 15, 23, 31, 39, 47,
                                                                    55, 63}:
        index += orientation
    if index in placeHolder[myT] and index + orientation in {0, 8, 16, 24, 32, 40, 48, 56, 7, 15, 23, 31, 39, 47, 55,
                                                             63}:
        index += orientation
    if index in spaceTile:
        return index


def flipped(board, token, index, direc):
    variable = index
    count = 0
    while True:
        variable += config[direc]
        if not variable in spaceTile or not (variable - config[direc]) % 8 - variable % 8 in (0, -1, 1):
            return False
        if board[variable] == '.':
            return False
        if board[variable] == token:
            if count > 0:
                return True
            else:
                return False
        count += 1


def checkEight(board, token, index):
    x = False
    for i in range(8):
        if flipped(board, token, index, i):
            variable = index
            x = True
            while True:
                variable += config[i]
                if token == board[variable]:
                    break
                board[variable] = token
    if x:
        board[index] = token
    return x


def print_board(puz):
    for i in range(8):
        print(puz[i * 8:i * 8 + 8])


def possib(myT):
    thisList = set()
    for i in placeHolder[myT]:
        for j in adDual(i, myT):
            apply = uni(j[0], dual(myT), j[1])
            if apply:
                thisList.add(apply)
    return thisList




# myPosib = possib(taker)
# for i in (0,7,56,63):
#     if i in myPosib:
#         print(i)
#         break
# else:
#     for i in myPosib:
#         for direction in [0,1,2,3]:
#             if flipped(othello,taker,i,direction):
#                 var = 0
#                 while True:
#                     var += config[direction]
#                     if othello[var] == '.':
#                         break
#                 else:
#                     print(i)




def negamax(board, token, levels):
    if not levels:
        return [evalBoard(board, token)]
    lm = possib(token)
    if not lm:
        nm = negamax(board, dual(token), levels - 1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(checkEight(board, token, mv), dual(token, levels - 1)) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]


def evalBoard(board, token):
    return board.count(dual(token))

# nm = negamax(othello,taker,3)
# print("At level {} nm gives {} and I pich move {}".format(3,nm,nm[-1]))
#

class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = ''.join(board).replace('?','').replace('@','x')
        token = 'x' if player == '@' else 'o'
        for level in range(1,10,2):
            mv = negamax(brd,token,level)
            print("My choice is {}".format(mv))
        mv1 = 11 + (mv//8)*10 + (mv%8)
        best_move.value = mv1

if __name__ == "__main__":
    if len(sys.argv) == 1:
        taker = "x"
    elif len(sys.argv) == 2:
        othello = sys.argv[1].lower()
        if sum([1 for i in range(len(othello)) if othello[i] == "."]) & 1:
            taker = "o"
        else:
            taker = "x"
    else:
        othello = sys.argv[1].lower()
        taker = sys.argv[2].lower()
    for x in placeHolder:
        for y in range(64):
            if othello[y] == x:
                placeHolder[x].add(y)
                spaceTile -= {y}
    print(list(possib(taker))[0])


