import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
WEIGHTED = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, -20, 20, 5, 5, 20, -20, 120, 0, 0, -20, -40, -5, -5, -5, -5, -40, -20, 0, 0, 20, -5, 15, 3, 3, 15, -5, 20, 0, 0, 5, -5, 3, 3, 3, 3, -5, 5, 0, 0, 5, -5, 3, 3, 3, 3, -5, 5, 0, 0, 20, -5, 15, 3, 3, 15, -5, 20, 0, 0, -20, -40, -5, -5, -5, -5, -40, -20, 0, 0, 120, -20, 20, 5, 5, 20, -20, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Node():
    def __init__(self, board, move, score = 0):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self, other):
        return self.score < other.score

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        edge = '??????????'
        standard = '?........?'
        center_1 = '?...o@...?'
        center_2 = '?...@o...?'
        return edge + standard + standard + standard + center_1 + center_2 + standard + standard + standard + edge

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pretty_board = ''
        for x in range(0, 100, 10):
            pretty_board += board[x:x+10] + "\n"
        return pretty_board

    def opponent(self, player):
        return BLACK if player == WHITE else WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        count = 0
        found = None

        while count < 1:
            square = square + direction
            next_square = board[square]
            if next_square == OUTER or next_square == EMPTY:
                count = count + 1
            elif next_square == player:
                found = square+direction
                count = count + 1
        return found

    def is_move_valid(self, board, player, move, move_list):
        """Is this a legal move for the player?"""
        if move in move_list:
            return True
        else:
            return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        b_list = list(board)
        b_list[move] = player
        temp_square = move
        for dir in DIRECTIONS:
            final = self.find_match(board, player, move, dir)
            if final is not None:
                while temp_square != final:
                    b_list[temp_square] = player
                    temp_square = temp_square + dir
            temp_square = move
        return ''.join(b_list)


    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        empty_list = []
        opponent = self.opponent(player)
        for x in range(len(board)):
            if board[x] == EMPTY:
                empty_list.append(x)
        matches = []
        valid_moves = []
        for index in empty_list:
            for dir in DIRECTIONS:
                if board[index + dir] == opponent:
                    result = self.find_match(board, player, index, dir)
                    if result is not None and index not in valid_moves:
                        matches.append(result)
                        valid_moves.append(index)
        return valid_moves

    def has_any_valid_moves(self, board, player, move_list):
        """Can player make any moves?"""
        if len(move_list) > 0:
            return True
        else:
            return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""

        next_player = self.opponent(prev_player)
        move_list = self.get_valid_moves(board, next_player)
        if self.game_over(board, prev_player):
            return None
        elif self.has_any_valid_moves(board, next_player, move_list) is False:
            return prev_player
        else:
            return next_player

    def weighted_score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        black_counter = 0
        white_counter = 0
        for x in range(100):
            if board[x] == WHITE:
                white_counter = white_counter + WEIGHTED[x]
            elif board[x] == BLACK:
                black_counter = black_counter + WEIGHTED[x]
        return black_counter - white_counter

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        black_counter = 0
        white_counter = 0
        for c in board:
            if c == WHITE:
                white_counter = white_counter + 1
            elif c == BLACK:
                black_counter = black_counter + 1
        return black_counter - white_counter

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if len(self.get_valid_moves(board, player)) == 0 and len(self.get_valid_moves(board, self.opponent(player))) == 0:
            return True
        else:
            return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    def alphabeta_search(self, board, player, depth, a, b):
        node = Node(board, None)
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        moves = self.get_valid_moves(board, player)
        if player == BLACK:
            v = -float("inf")
            dummy_node = Node(board, None, v)

            for move in moves:
                dummy_node.move=move
                next_board = self.make_move(board, player, move)
                n_player = self.next_player(next_board, player)
                c = Node(next_board, move)
                if n_player is None:
                    c.score = self.score(next_board)
                else:
                    c = self.alphabeta_search(next_board, n_player, depth-1, a, b)
                v = max(v, c.score)
                a = max(a, v)
                if b <= a:
                    break
            return dummy_node
        else:
            v = float("inf")
            dummy_node = Node(board, None, v)
            for move in moves:
                dummy_node.move = move
                next_board = self.make_move(board, player, move)
                n_player = self.next_player(next_board, player)
                c = Node(next_board, move)
                if n_player is None:
                    c.score = self.score(next_board)
                else:
                    c = self.alphabeta_search(next_board, n_player, depth - 1, a, b)
                v = min(v, c.score)
                b = min(b, v)
                if b <= a:
                    break
            return dummy_node

    def alphabeta_strategy(self, node, player, depth):
        move = self.alphabeta_search(node, player, depth, -float("inf"), float("inf"))
        return move.move

    def minmax_search(self, board, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        node = Node(board, None)
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        moves = self.get_valid_moves(board, player)
        children = []
        for move in moves:
            next_board = self.make_move(board, player, move)
            n_player = self.next_player(next_board, player)
            if n_player is None:
                c = Node(next_board, move, score = 1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(next_board, n_player, depth=depth - 1).score
                children.append(c)
        winner = max(children) if player == BLACK else min(children)
        node.score = winner.score
        return winner

    def minmax_strategy(self, node, player, depth):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        move = self.minmax_search(node, player, depth)
        return move.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        board = ''.join(board)
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board, player, depth)
            depth += 1

    def white_best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        board = ''.join(board)
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.random_strategy(board, player)
            depth += 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.minmax_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player, 4)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit= 3):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    #game = StandardPlayer()
    game = ParallelPlayer()
    game.play()
