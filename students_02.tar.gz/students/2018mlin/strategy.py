#Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
CORNERS={11,18,81,88}
SPECIAL=[13,83,31,38,16,86,61,68]
ROW_START={11,81,13,83,41,51}
COL_START={11,81,31,38,14,15}
ROW_END={18,88,16,86,48,58}
COL_END={18,88,61,68,84,85}
BAD={11:[12,21,22],18:[17,27,28],81:[82,72,71],88:[87,78,77]}
SQUARE_WEIGHTS = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 150, -60,  20,   5,   5,  20, -60, 150,   0,
    0, -60,-100,  -5,  -5,  -5,  -5,-100, -60,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -60,-100,  -5,  -5,  -5,  -5,-100, -60,   0,
    0, 150, -60,  20,   5,   5,  20, -60, 150,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
X_WEIGHTS=[
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 250,-200,  10,  30,  30,  10,-200, 250,   0,
    0,-200,-150,  -5,  -5,  -5,  -5,-150,-200,   0,
    0,  10,  -5,   3,   5,   5,   3,  -5,  10,   0,
    0,  30,  -5,   5,  15,  15,   5,  -5,  30,   0,
    0,  30,  -5,   5,  15,  15,   5,  -5,  30,   0,
    0,  10,  -5,   3,   5,   5,   3,  -5,  10,   0,
    0,-200,-150,  -5,  -5,  -5,  -5,-150,-200,   0,
    0, 250,-200,  10,   30, 30,  10,-200, 250,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class node():
    def __init__(self, board, move):
        self.board=board
        self.move=move
        self.score=0
        self.isLeaf=False

    def __lt__(self, other):
        return self.score<=other.score

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        s = "?"*10+("?"+"."*8+"?")*3+"?...o@...?"+"?...@o...?"+("?"+"."*8+"?")*3+"?"*10
        return s

    def get_pretty_board(self, board):
        prettyboard=board.replace("?","")
        prettyboard=prettyboard.replace("@","B")
        prettyboard=prettyboard.replace("o","W")
        return("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s" % (prettyboard[0:8], prettyboard[8:16], prettyboard[16:24], prettyboard[24:32], prettyboard[32:40], prettyboard[40:48], prettyboard[48:56], prettyboard[56:64]))


    def opponent(self, player):
        if player is BLACK:
            return WHITE
        return BLACK

    def find_match(self, board, player, square, direction):
        btwn=0
        opp=self.opponent(player)
        while square>11 and square<89:
            square+=direction
            look=board[square]

            if look==opp:
                btwn+=1
            elif look is OUTER:
                return None
            elif look is player:
                return None
            elif look is EMPTY:
                if btwn>0:
                    return square
                else:
                    return None
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def flip_match(self, board, player, square, direction):
        btwn=0
        opp=self.opponent(player)
        while square>0 and square<100:
            square+=direction
            look=board[square]

            if look==opp:
                btwn+=1
            elif look is OUTER:
                return None
            elif look is player:
                if btwn>0:
                    return square
                else:
                    return None
            elif look is EMPTY:
                return None

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board=board[0:move]+player+board[(move+1):]
        for dir in DIRECTIONS:
            match=self.flip_match(board, player, move, dir)
            if match is not None:
                flip=move+dir
                while board[flip] is not player:
                    board=board[0:flip]+player+board[(flip+1):]
                    flip+=dir
        return board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        legal_moves=[]
        for i in range(11,90):
            if board[i] is player:
                for dir in DIRECTIONS:
                    match=self.find_match(board,player,i,dir)
                    if match is not None:
                        #legal_moves.append(self.make_move(board,player,dir))
                        legal_moves.append(match)
        return legal_moves

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player))>0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opp=self.opponent(prev_player)
        if self.has_any_valid_moves(board, opp):
            return opp
        if self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def corners_taken(self, board, player):
        for sq in CORNERS:
            if board[sq] is player:
                return True
        return False

    def stability_search(self, board, player):
        score=0
        opp = self.opponent(player)
        for sq in CORNERS:
            empty_checked=[]
            if board[sq] is opp:
                score-=self.stable_score(board, sq, opp,empty_checked)
            elif board[sq] is player:
                score+=self.stable_score(board, sq, player,empty_checked)
        return score

    def stable_score(self, board, sq, player, checked):
        score=0
        if sq not in checked:
            checked.append(sq)
            if board[sq] is not player:
                return 0
            else:
                score+=1
                for dir in DIRECTIONS:
                    score+=self.stable_score(board, sq+dir, player, checked)
        return score

    def line_score(self, board, player):
        score=self.line_iterate_score(board, player, ROW_START, 1)
        score+=self.line_iterate_score(board, player, COL_START,10)

        score+=self.line_iterate_score(board, player, ROW_START, NE)
        score+= self.line_iterate_score(board, player, ROW_START, SE)

        score+=self.line_iterate_score(board, player, COL_START,NE)
        score += self.line_iterate_score(board, player, COL_START, SE)

        score+=self.line_iterate_score(board, player, ROW_END,-1)
        score+=self.line_iterate_score(board, player, COL_END,-10)

        score+= self.line_iterate_score(board, player, ROW_END, NE)
        score+= self.line_iterate_score(board, player, ROW_END, SE)

        score += self.line_iterate_score(board, player, COL_END, NE)
        score += self.line_iterate_score(board, player, COL_END, SE)
        return score

    def line_iterate_score(self, board, player, start_sq, move):
        score=0
        opp = self.opponent(player)
        for sq in start_sq:
            piece=board[sq]
            if piece is player or piece is opp:
                line = True
                for i in range(sq,sq+move):
                    if board[i] is not piece:
                        break
                if line is True:
                    if piece is player:
                        score+=1
                        if sq in SPECIAL:
                            score+=5
                    elif piece is opp:
                        score-=1
                        if sq in SPECIAL:
                            score-=5
        return score

    def weighted_score(self, board):
        total = 0
        weight=SQUARE_WEIGHTS
        corner_filled=(self.corners_taken(board,BLACK)or self.corners_taken(board,WHITE))
        black_moves=self.get_valid_moves(board, BLACK)
        white_moves = self.get_valid_moves(board, WHITE)
        if corner_filled is False:
            weight=X_WEIGHTS
            total+= 3 * self.line_score(board, BLACK) - 5 * self.line_score(board, WHITE)
        else:
            total += 2 * self.line_score(board, BLACK) - 2 * self.line_score(board, WHITE)
            total =total*(len(black_moves)+1)
            total = total/(len(white_moves)+1)

        for key in BAD.keys():
            p=board[key]
            if p is BLACK:
                for c in BAD.get(key):
                    if c is WHITE:
                        total+=5
            if p is WHITE:
                for c in BAD.get(key):
                    if c is BLACK:
                        total-=5


        for sq in range(11,90):
            if board[sq] == BLACK:
                total += weight[sq]
            elif board[sq] == WHITE:
                total -= weight[sq]
        # if self.corners_taken(board, player):
        #     total+=5*self.stability_search(board, player)
        return total

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        black=0
        white=0
        for i in range(11,90):
            if board[i] is BLACK:
                black+=1
            elif board[i] is WHITE:
                white+=1
        if player is BLACK:
            return (black-white)
        else:
            return white-black
    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return self.has_any_valid_moves(board, player) is False and self.has_any_valid_moves(board,self.opponent(player)) is False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    def alphabeta_search(self, base_node, player, depth, alpha, beta):
        board = base_node.board
        if depth == 0:
            base_node.score = self.weighted_score(board)
            return base_node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            child_node = node(next_board, move)
            if next_player is None:
                child_node.isLeaf = True
                child_node.score = self.weighted_score(child_node.board) * 1000
                children.append(child_node)
            else:
                new_node=self.alphabeta_search(child_node, next_player, depth-1, alpha, beta)
                child_node.score = new_node.score
                children.append(child_node)
            if player is BLACK:  # max
                alpha = max(alpha, child_node.score)
            if player is WHITE:  # min
                beta = min(beta, child_node.score)
            if alpha >= beta:
                break
        if player is BLACK:
            best_node = max(children)
            base_node.score = best_node.score
            return best_node
        elif player is WHITE:
            best_node = min(children)
            base_node.score = best_node.score
            return best_node

    def alphabeta_strategy(self, board, player, depth=2):
        base_node=node(board, None)
        move_node=self.alphabeta_search(base_node, player, depth, -math.inf, math.inf)
        return move_node.move

    def minmax_search(self, base_node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board=base_node.board
        if depth==0:
            base_node.score=self.weighted_score(board)
            return base_node
        my_moves=self.get_valid_moves(board, player)
        children=[]
        for move in my_moves:
            next_board=self.make_move(board, player, move)
            next_player=self.next_player(next_board, player)
            child_node = node(next_board, move)
            if next_player is None:
                child_node.isLeaf=True
                child_node.score=self.weighted_score(child_node.board) * 1000
                children.append(child_node)
            else:
                child_node.score = self.minmax_search(child_node, next_player, depth-1).score
                children.append(child_node)
        best_node=max(children)
        base_node.score=best_node.score
        return best_node


    def minmax_strategy(self, board, player, depth=2):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        base_node=node(board, None)
        move_node=self.minmax_search(base_node, player, depth)
        return move_node.move
    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an example
            board = ''.join(board)
            best_move.value = self.alphabeta_strategy(board, player)
            depth += 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.alphabeta_strategy, WHITE: white.minmax_strategy}
        #(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            #print("Player %s chooses %s" % (player, move))
            board = ref.make_move(board, player, move)
            #print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    for i in range(0,30):
        game = StandardPlayer()
        game.play()
