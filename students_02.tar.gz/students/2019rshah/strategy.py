#Rahil Shah
#3rd period
import sys
import random
cs={1,8,6,15,55,62,48,57}
xs={9,14,54,49}
corner={0,63,7,56}
edges={0,1,2,3,4,5,6,7,8,16,24,32,40,48,56,15,23,31,39,47,55,63,62,61,60,59,58,57}
dict={0:{8,1,9},7:{6,14,15},56:{57,48,49},63:{62,54,55}}
default = '...........................ox......xo...........................'
indexdict={0:'a1',1:'b1',2:'c1',3:'d1',4:'e1',5:'f1',6:'g1',7:'h1',8:'a2',9:'b2',10:'c2',11:'d2',12:'e2',13:'f2',14:'g2'
  ,15: 'h2',16:'a3',17:'b3',18:'c3',19:'d3',20:'e3',21:'f3',22:'g3',23:'h3',24:'a4',25:'b4',26:'c4',27:'d4',28:'e4',
  29:'f4',30:'g4',31:'h4',32:'a5',33:'b5',34:'c5',35:'d5',36:'e5', 37: 'f5', 38:'g5',39:'h5',40:'a6',41:'b6',42:'c6',
43:'d6',44:'e6',45:'f6',46:'g6',47:'h6',48:'a7',49:'b7',50:'c7',51:'d7',52:'e7',53:'f7',54:'g7',55:'h7',56:'a8',
57:'b8', 58: 'c8', 59: 'd8', 60: 'e8', 61: 'f8', 62: 'g8', 63: 'h8'}

class Strategy():
  def best_strategy(self, board, player, best_move, still_running):
    brd = ''.join(board).replace('?','').replace('@','x')
    token ='x' if player =='@' else 'o'
    if brd==default: moveFile = open("movefile.txt","w+")

    if brd.count('.')<=9:
        nm = negamaxTerminal(brd,token,-65,65)
        d = nm[-1]
        best_move.value = 11 + (d//8)*10+(d%8)

    vm, bb = validMoves(brd, token), list(brd)
    fm = {x for x in vm if len(vm[x]) > 0}
    mv = bestMove(brd,token,fm)
    if token=='x': ot='o'
    else: ot='x'
    bm = bestMove(brd, token, fm)


    bm2 = {x for x in bm if x in cs or x in xs}
    for v in bm2:
      if (brd[v] == ot or brd[v] == '.'): bm.remove(v)

    else:
        max, maxl, maxM, maxML,mv1 = 0, set(), 0, set(),0
        for v in fm:
            flip = makeMove(bb, vm[v], v, token)
            fc = flip.count(token)
            if fc > max: max, maxl = fc, {v}
            elif fc == max: maxl.add(v)
            vm2 = validMoves(flip, token)
            vm2c = len({x for x in vm2 if len(vm2[x]) > 0})
            if vm2c> maxM: maxM, maxML = vm2c, {v}
            elif vm2c == maxM: maxML.add(v)
        fm2={x for x in fm}
        for x in fm2:
            if x in cs or x in xs: fm.remove(x)
        bmaxl = bm.intersection(maxl)
        bmaxml = bm.intersection(maxML)
        if bmaxml: mv1 = random.choice(list(bmaxml))
        elif bmaxl: mv1 = random.choice(list(bmaxl))
        elif bm: mv1 = random.choice(list(bm))
        elif len(maxML) > 0: mv1 = random.choice(list(maxML))
        elif len(maxl) > 0: mv1 = random.choice(list(maxl))
        elif fm: mv1 = random.choice(list(fm))
        else: mv1 = random.choice(list(fm2))
        best_move.value = 11 + (mv1//8)*10+(mv1%8)

##############################################
def validMoves(pzl, t):
  if t=='x': ot ='o'
  else: ot='x'
  ct,possibleMoves={i for i, ltr in enumerate(pzl) if ltr==t},{}
  for x in range(64):
    possibleMoves[x] = set()
  for y in {8,-8,1,-1,9,-9,7,-7}:
    for x in ct:
      c, col = x+y, x%8
      if y in {7, -9, -1}: col = col - 1
      elif y in {-7, 9, 1}: col = col + 1
      while c<64 and c>-1 and pzl[c]==ot and col<=7 and col>=0:
        c=c+y
        if y in {7,-9,-1}: col=col-1
        elif y in {-7,9,1}: col=col+1
        if col > 7 or col < 0: break #### check for problem here
        if c<64 and c>-1 and pzl[c]=='.':
          possibleMoves[c].add((x,y))
          break
  return possibleMoves

def evalBoard(b,t):
  if t=='x': ot='o'
  else: ot='x'
  return b.count(t)-b.count(ot)

def bestMove(b,t,moves):
  s=set()
  if t=='x':ot='o'
  else:ot='x'
  for x in moves:
    if x in {0,63,7,56}: s.add(x)
  if s: return s

  for x in moves:
    if x in edges:
      if t==b[0] and (x%8==0 or x//8==0):
        c, d = 1, 8
        if x//8==0:
          while b[c] == ot:
            c = c+1
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
        if x%8==0:
          while b[d] == ot:
            d = d+8
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break

      if t== b[7] and (x%8 == 7 or x // 8 == 0):
        c, d = 6, 15
        if x//8==0:
          while b[c] == ot:
            c = c-1
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
        if x%8==7:
          while b[d] == ot:
            d = d+8
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
      if t == b[56] and (x%8 == 0 or x//8==7):
        c, d = 57, 48
        if x//8 == 7:
          while b[c] == ot:
            c = c+1
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
        if x%8==0:
          while b[d] == ot:
            d = d-8
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
      if t == b[63] and (x%8==7 or x//8==7):
        c,d = 62, 55
        if x//8==7:
          while b[c]==ot:
            c=c-1
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
        if x%8==7:
          while b[d]==ot:
            d=d-8
            if b[d] == '.' and d==x: s.add(x)
            if b[d] == t: break
  if s: return s

  for y in moves:
    if y//8==0 and (b[0] or b[7]==t): s.add(y)
    elif y//8==7 and (b[56] or b[63]==t): s.add(y)
  if s: return s

  moves2={x for x in moves}
  for q in moves:
    if q in {0,1,2,3,4,5,6,7,8,16,24,32,40,48,56,15,23,31,39,47,55,63,62,61,60,59,58,57}: moves2.remove(q)

  moves3={x for x in moves2}
  for v in moves3:
    for i in dict:
      if v in cs and v in dict[i] and (b[i]==ot or b[i]=='.'):
        s.add(v)
        moves2.remove(v)
      if v in xs and v in dict[i] and (b[i]==ot or b[i]=='.'):
        s.add(v)
        moves2.remove(v)

  if moves2: return moves2
  else: return set()

def display(p,s):
  for x in range(64):
    s += p[x] + " "
    if x % 8 == 7: s += "\n"
  print(s)

def findTurn(p):
  if p.count('.')%2==0: return 'x'
  return 'o'

def makeMove(board,moves,pos, token):
  if len(moves)==0:
    return ""
  board=list(board)
  for x in moves:
    start=x[0]
    while start+x[1]!=pos:
      start+=x[1]
      board[start] = token
    board[start+x[1]]=token
  return ''.join(board)

def negamaxTerminal(brd, token, improvable, hardBound):
  if token=='x':enemy='o'
  else: enemy='x'
  vm = validMoves(brd, token)
  lm={x for x in vm if len(vm[x])>0}

  if not lm:
    vm2 = validMoves(brd, enemy)
    lm2 = {x for x in vm2 if len(vm[x]) > 0}
    if not lm2:return[evalBoard(brd,token), -3]
    nm = negamaxTerminal(brd, enemy, -hardBound, -improvable)+[-1]
    return [-nm[0]+nm[1:]]

  best, newHB =[], -improvable #what gets returned

  for mv in lm:
      nm = negamaxTerminal(makeMove(brd,vm[mv],mv,token), enemy, -hardBound, newHB) +[mv]

      if not best or nm[0] < newHB:
          best=nm
          if nm[0]< newHB:
            newHB=nm[0]
            if -newHB > hardBound: return [-best[0]]+best[1:] #pruning
  return [-best[0]]+best[1:]
#
#
# def main():
#   default, n = '...........................ox......xo...........................', 8
#   if len(sys.argv)==2 and len(sys.argv[1].lower())!=1:b,t= sys.argv[1].lower(), findTurn(sys.argv[1].lower())
#   elif len(sys.argv)==2:b,t = default,sys.argv[1].lower()
#   elif len(sys.argv)==3:b,t=sys.argv[1].lower(),sys.argv[2].lower()
#   else: b,t = default,'x'
#   if 'x'==t: ot='o'
#   else: ot='x'
#   vm, bb = validMoves(b, t), list(b)
#   display(''.join(bb),'')
#   fm ={x for x in vm if len(vm[x])>0}
#   print('Legal moves: '+str(fm))
#
#   #fm={x for x in vm if len(vm[x])>0}
#   bm=bestMove(b,t,fm)
#   for v in fm:
#     max, maxl,maxM,maxML=0,[],0,[]
#     flip = makeMove(bb, vm[v], v, t)
#     if flip.count(t)>max: max, maxl = flip.count(t), {v}
#     elif flip.count(t)==max: maxl.add(v)
#     if  len(validMoves(flip,t)) > maxM : maxM,maxML = len(validMoves(flip,t)), {v}
#     elif len(validMoves(flip,t)) == maxM: maxML.add(v)
#
#   # for i in dict:
#   #   if v in cs and v in dict[i] and (b[i] == ot or b[i] == '.'): fm.remove(v)
#   #   if v in xs and v in dict[i] and (b[i] == ot or b[i] == '.'): fm.remove(v)
#   bmaxl=bm.intersection(maxl)
#   bmaxml=bm.intersection(maxML)
#   if bmaxml:print("My Heuristic Move is: "+str(random.choice(list(bmaxml))))
#   elif bmaxl:print("My Heuristic Move is: "+str(random.choice(list(bmaxl))))
#   elif bm: print("My Heuristic Move is: "+str(random.choice(list(bm))))
#   elif len(maxML)>0:print("My Heuristic Move is: "+str(random.choice(list(maxML))))
#   elif len(maxl)>0:print("My Heuristic Move is: "+str(random.choice(list(maxl))))
#   elif fm: print("My Heuristic Move is: "+str(random.choice(list(fm))))
#   else: print("No moves are possible.")
#
#   if b.count('.')<=9:
#     n = negamaxTerminal(b, t,-65,65)
#     print("Negamax score "+str(n[0])+" and my move is "+str(n[1:]))
#
# if __name__=='__main__':
#   main()