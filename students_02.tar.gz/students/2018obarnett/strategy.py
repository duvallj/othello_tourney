#Jan 12, 0952 version
# vals = {11: 500, 12: 0, 13: 2, 14: 2, 15: 2, 16: 2, 17: 0, 18: 500, \
#                 21: 0, 22: 0, 23: 0, 24: 0, 25: 0, 26: 0, 27: 0, 28: 0, \
#                 31: 2, 32: 0, 33: 1, 34: 1, 35: 1, 36: 1, 37: 0, 38: 2, \
#                 41: 2, 42: 0, 43: 1, 44: 1, 45: 1, 46: 1, 47: 0, 48: 2, \
#                 51: 2, 52: 0, 53: 1, 54: 1, 55: 1, 56: 1, 57: 0, 58: 2, \
#                 61: 2, 62: 0, 63: 1, 64: 1, 65: 1, 66: 1, 67: 0, 68: 2, \
#                 71: 0, 72: 0, 73: 0, 74: 0, 75: 0, 76: 0, 77: 0, 78: 0, \
#                 81: 500, 82: 0, 83: 2, 84: 2, 85: 2, 86: 2, 87: 0, 88: 500, \
#                 }


#### Othello Shell
#### P. White 2016-2018
# EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'


# To refer to neighbor squares we can add a direction to a square.
NODES=0
import pickle
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
# from multiprocessing import Value, Process
class Strategy():
    def __init__(self):
        # self.preboad = pickle.load(open("predata1.p", "rb"))
        self.standard_strategy=self.minmax_strategy
        ONECORNER, ONECE, ONEE1, ONEE2, ONECM, ONEM1, ONEM2, ONECM2, ONEMM1, ONECENTER = [500, -275, 25,10, -350, -2,-5, 3,1, 0]

        self.vals = {11: ONECORNER, 12: ONECE, 13: ONEE1, 14: ONEE2, 15: ONEE2, 16: ONEE1, 17: ONECE, 18: ONECORNER, \
                   21: ONECE, 22: ONECM, 23: ONEM1, 24: ONEM2, 25: ONEM2, 26: ONEM1, 27: ONECM, 28: ONECE, \
                   31: ONEE1, 32: ONEM1, 33: ONECM2, 34: ONEMM1, 35: ONEMM1, 36: ONECM2, 37: ONEM1, 38: ONEE1, \
                   41: ONEE2, 42: ONEM2, 43: ONEMM1, 44: ONECENTER, 45: ONECENTER, 46: ONEMM1, 47: ONEM2, 48: ONEE2, \
                   51: ONEE2, 52: ONEM2, 53: ONEMM1, 54: ONECENTER, 55: ONECENTER, 56: ONEMM1, 57: ONEM2, 58: ONEE2, \
                   61: ONEE1, 62: ONEM1, 63: ONECM2, 64: ONEMM1, 65: ONEMM1, 66: ONECM2, 67: ONEM1, 68: ONEE1, \
                   71: ONECE, 72: ONECM, 73: ONEM1, 74: ONEM2, 75: ONEM2, 76: ONEM1, 77: ONECM, 78: ONECE, \
                   81: ONECORNER, 82: ONECE, 83: ONEE1, 84: ONEE2, 85: ONEE2, 86: ONEE1, 87: ONECE, 88: ONECORNER, \
                   }
        self.fweight = 1000
        count=0


        self.transTable = {}
        self.parCount = {}
        self.move = 0
        self.testTable = {}
        self.badMove = set()

        openn = []
        for i in self.get_starting_board():
            if not i == "?":
                openn.append(count)
            count += 1
        self.open = openn

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return ("???????????........??........??........??...o@...??...@o...??........??........??........???????????")

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        count = 0
        ret = ""

        for i in board:
            if(i is not "?"):
                ret += (i+" ")

            count+=1
            if(count%10==0):
                ret+="\n"
        return ret

    def opponent(self, player):
        """Get player's opponent."""
        if player == "@":
            return "o"
        return "@"

    def find_match(self,board,piece,dir,index):
        count = 0
        index+=dir
        while board[index] == piece:
            count+=1
            index+=dir
        if(board[index] == "?" or board[index] == "." or count<1):
            return 0
        return count

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def score_board_heuristic(self, board, player, update = True, who = "@"):
        if board in self.transTable:
            loss, score = self.transTable[board]
            return score
        if (not update) and board in self.testTable:
            score,loss = self.testTable[board]
            return score
        minMe, maxMe, min2Me, max2Me, minThey, maxThey, min2They, max2They = 8, 0, 8, 0, 8, 0, 8, 0
        score = 0
        opp = self.opponent(player)
        for i in self.open:
            if board[i] == player:
                score+=self.vals[i]
                if int(str(i)[0]) < minMe:
                    minMe = int(str(i)[0])
                if int(str(i)[1]) < min2Me:
                    min2Me = int(str(i)[1])
                if int(str(i)[0]) > maxMe:
                    maxMe = int(str(i)[0])
                if int(str(i)[1]) > max2Me:
                    max2Me = int(str(i)[1])
            elif board[i] == opp:
                if int(str(i)[0]) < minThey:
                    minThey = int(str(i)[0])
                if int(str(i)[1]) < min2They:
                    min2They = int(str(i)[1])
                if int(str(i)[0]) > maxThey:
                    maxThey = int(str(i)[0])
                if int(str(i)[1]) > max2They:
                    max2They = int(str(i)[1])
                score-=self.vals[i]

        score += (23 * self.countSand(board, player))
        score -= (23 * self.countSand(board, opp))
        score -= 25 * (maxMe - minMe + max2Me - min2Me)
        score += 25 * (maxThey - minThey + max2They - min2They)
        score += (self.fweight * self.count_no_flip(board, player))
        score -= (self.fweight * self.count_no_flip(board, opp))
        score -= (60 * self.countParity(board, player))
        score += (60 * self.countParity(board, opp))
        score -= 20 * (self.getFrontier(player, board,on=True))
        score += 20 * (self.getFrontier(opp, board,on=True))
        score += self.scorePattern(board, player)
        score -= self.scorePattern(board, opp)
        score -= 24*self.countWall(board, player)
        score += 24*self.countWall(board, opp)
        if update:
            self.transTable.update({board:(0,score)})
        return score
        # section = [
        #     board[11]+board[12]+board[13]+board[14]+board[21]+board[22]+board[23]+board[24]+
        #     board[31]+board[32]+board[33]+board[34]+board[41]+board[42]+board[42],
        #     board[18] + board[17] + board[16] + board[15] + board[28] + board[27] + board[26] + board[25] +
        #     board[38] + board[37] + board[36] + board[35] + board[48] + board[47] + board[46],
        #     board[81] + board[82] + board[83] + board[84] + board[71] + board[72] + board[73] + board[74] +
        #     board[61] + board[62] + board[63] + board[64] + board[51] + board[52] + board[52],
        #     board[88] + board[87] + board[86] + board[85] + board[78] + board[77] + board[76] + board[75] +
        #     board[68] + board[67] + board[66] + board[65] + board[58] + board[57] + board[56],
        # ]
        # score = 0
        # for k in section:
        #     score+=self.preboad[k]
        # if player == "o":
        #     return score
        # return -score


    def make_move(self,board,player,index):
        boardArr = list(board)
        boardArr[index] = player
        directions = [1,-1,10,-10,9,-9,11,-11]
        for i in directions:
            count = self.find_match(board,self.opponent(player),i,index)
            temp= index+i
            for k in range(0,count):
                boardArr[temp] = player
                temp+=i
        newBoard = ''.join(boardArr)
        return newBoard

    def getEdges(self,board):
        edges = set()
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        for k in self.open:
            if board[k] == ".":
                index = 0
                found = False
                while index < 8 and found == False:
                    on = directions[index]
                    if board[on+k] == "o" or board[on+k] == "@":
                        found = True
                    index += 1
                if found == True:
                    edges.add(k)
        return edges

    def get_valid_moves(self, board, player, stop = False, edges = None):
        moves = []
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        opp = self.opponent(player)
        if edges is None:
            edges = set()
            for i in self.open:
                edges.add(i)
        for i in edges:
            if board[i] == ".":
                index = 0
                found = False
                while index<8 and found == False:
                    on = directions[index]
                    number = self.find_match(board,opp,on,i)
                    if number > 0:
                        found = True
                    index+=1
                if found == True:
                    moves.append(i)
                    if stop:
                        return moves
        return moves

    def has_any_valid_moves(self, board, player, edges = None):
        moves = self.get_valid_moves(board,player,stop = True,edges = edges)
        return len(moves)!=0

    def next_player(self, board, prev_player,edges = None):
        """Which player should move next?  Returns None if no legal moves exist."""
        next = self.opponent(prev_player)
        if self.has_any_valid_moves(board,next,edges):
            return next
        if self.has_any_valid_moves(board,prev_player,edges):
            return prev_player
        return None



    def score(self, board, player="@"):
        """Compute player's score (number of player's pieces minus opponent's)."""
        val = 0
        oppPlayer = self.opponent(player)
        for i in board:
            if i == player:
                val+=1
            if i == oppPlayer:
                val-=1
        return val

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        pass

    # class IllegalMoveError(Exception):
    #     def __init__(self, player, move, board):
    #         self.player = player
    #         self.move = move
    #         self.board = board
    #
    #     def __str__(self):
    #         return '%s cannot move to square %d' % ("@", self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth, who, alpha, beta, edges,myMoves,theirMoves,startDepth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        global NODES
        NODES+=1
        if player == None:
            return (0,10000*self.score(board,who))
        if(depth == 0):
            # if who == "@":
            return (0, self.score_board_heuristic(board,who,who=who)+((self.score(board,who)*(max(0,(self.move-22))*200))))
            # else:
            #     return (0,self.score_board_heuristic(board,who,who=who))
        # if board in self.transTable:
        #     return self.transTable[board]

        moves = (self.get_valid_moves(board,player,edges = edges))
        if depth > 3:
            moves = sorted(moves,key=lambda x: -self.score_board_heuristic(self.make_move(board,player,x),player, update = False,who=who))
        # else:
        #     random.shuffle(moves)
        bestmove = -1
        bestscore = None
        bestNum = 0
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        add = len(moves)
        if player ==who:
            myMoves=add
        else:
            theirMoves=add
        factor = len(moves)
        # if who == "o":
        #     if startDepth-depth > 1:
        #         factor = len(moves)//4+1

        if player == who:
            for testing in range(0,factor):
                i = moves[testing]
                newBoard = self.make_move(board,player,i)
                newEdges = edges.copy()
                newEdges.remove(i)
                for k in directions:
                    newEdges.add(k+i)
                next = self.next_player(newBoard, player, edges = newEdges)

                loss,score = self.minmax_search(newBoard,next,depth-1,who,alpha,beta,newEdges,myMoves,theirMoves,startDepth)
                # if newBoard in self.testTable.keys():
                #     lasts,lastd = self.testTable[newBoard]
                #     if lastd < depth:
                #         self.testTable[newBoard] = (score,depth)
                # else:
                #     self.testTable.update({newBoard:(score,depth)})
                if bestscore == None:
                    bestscore = score
                    bestNum = testing
                if score > alpha:
                    alpha = score
                    bestmove = i
                    bestscore = score
                    bestNum = testing
                    if(alpha >= beta):
                        return i,score
            self.transTable.update({board:(bestmove,bestscore)})
            return bestmove,bestscore

        for testing in range(0,factor):
            i = moves[testing]
            newBoard = self.make_move(board, player, i)
            newEdges = edges.copy()
            newEdges.remove(i)
            for k in directions:
                newEdges.add(k + i)
            next = self.next_player(newBoard, player, edges=newEdges)
            loss,score = self.minmax_search(newBoard, next, depth - 1, who,alpha,beta, newEdges,myMoves,theirMoves,startDepth)
            # if newBoard in self.testTable.keys():
            #     lasts, lastd = self.testTable[newBoard]
            #     if lastd < depth:
            #         self.testTable[newBoard] = (score, depth)
            # else:
            #     self.testTable.update({newBoard: (score, depth)})
            if bestscore == None:
                bestscore = score
                bestNum = testing
            if (score) < (beta):
                bestmove = i
                bestscore = score
                beta = score
                bestNum = testing
                if (alpha >= beta):
                    return bestmove,bestscore
        self.transTable.update({board: (bestmove,bestscore)})
        # if (bestNum > 2*(factor//3)+1):
        #     print("test")
        return bestmove,bestscore


    def minmax_strategy(self, board, player, depth):
        self.transTable = {}

        global NODES
        move,loss =  self.minmax_search(board,player,depth,player,-6500000,6500000,self.getEdges(board),0,0,depth)
        self.transTable = {}
        print(NODES)
        return move

    def count_no_flip(self,board,player):
        corner = [11,18,81,88]
        corDir = {11:[10,1],18:[-1,10],81:[-10,1],88:[-10,-1]}
        been = set()
        count = 0
        for i in corner:
            if board[i] == player:
                new = set()
                new.add(i)
                remove = set()
                while len(new) != 0:

                    old = new.copy()
                    new = set()
                    for k in old:
                        if board[k] == player and board[k] != "?":
                            if not k in been:
                                count+=1
                            new.add(k + (corDir[i])[1])
                            new.add(k + (corDir[i])[0])
                            been.add(k)
                        else:
                            remove.add(k)
                    oldRemove = remove.copy()
                    for k in oldRemove:
                        new.discard(k + (corDir[i])[0])
                        new.discard(k + (corDir[i])[1])
                        remove.add(k + (corDir[i])[1])
                        remove.add(k + (corDir[i])[0])
        return count

    def getFrontier(self,player,board, on = True):
        front = set()
        secondCount = 0
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        for k in range(0,100):
            if board[k]== ".":
                if (k) // 10 != 1 and (k) // 10 != 8 and (k) % 10 != 1 and (k) % 10 != 8:
                    index = 0
                    while index<8:
                        i = directions[index]
                        if board[k+i] == player:
                            if k+i not in front:
                                front.add(k+i)
                                secondCount+=2
                                if k+i-10 in front:
                                    secondCount+=1
                                    if k + i - 20 in front:
                                        secondCount+=1
                                        if k + i - 30 in front:
                                            secondCount+=1
                                if k+i-1 in front:
                                    secondCount+=1
                                    if k + i - 2 in front:
                                        secondCount+=1
                                        if k + i - 3 in front:
                                            secondCount+=1
                        index+=1
        return int(secondCount/2)


    def countSurr(self,board,player):
        count = 0
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        on = 0
        for i in board:
            if i == player:
                dirNumber = 0
                found = False
                while(not found) and dirNumber<8:
                    k = directions[dirNumber]
                    index = on+k
                    while(board[index] == player):
                        index+=k
                    if(board[index] == "."):
                        found = True
                    dirNumber+=1
                if not found:
                    count+=1
            on+=1
        return count

    def countParity(self,board,player):
        corner = [1,8]
        count = 0
        for i in corner:
            last1 = None
            last2 = None
            for k in range(1,9):
                if board[int(str(k)+str(i))] == player:
                    if last1 is None:
                        last1 = k
                    else:
                        if last1+1!=k:

                            count+=1
                            if(k-last1)%2 == 1:
                                count-=2
                        last1 = k
                if board[int(str(i)+str(k))] == player:
                    if last2 is None:
                        last2 = k
                    else:
                        if last2+1!=k:
                            count+=1
                            if(k-last2)%2 == 1:
                                count-=2
                        last2=k
        return count

    def scorePattern(self,board,player):
        score = 0
        edges = [board[12:18],board[82:88],board[21]+board[31]+board[41]+board[51]+board[51]+board[61]+board[71],board[28]+board[38]+board[48]+board[58]+board[58]+board[68]+board[78]]
        five = str(player*5)
        four = str(player*4)
        three = str(player*3)
        six = str(player * 6)
        anchor = False
        opp = self.opponent(player)
        for k in edges:
            if not anchor:
                if player in k:
                    anchor = True
            if k == "."+five:
                score-=150
            elif k == five + ".":
                score -= 150
            elif k == "."+four+".":
                score+=200
            elif k == "."+opp+three+".":
                score-=20
            elif k == "."+three+opp+".":
                score-=20
            elif k == six:
                score+=550

        if not anchor:
            score-=100
        index = 11
        found = False
        while not found and board[index] != "?":
            if board[index] == player:
                found = True
            index+=11
        if not found:
            score-=70
        index = 18
        found = False
        while not found and board[index] != "?":
            if board[index] == player:
                found = True
            index += 9
        if not found:
            score-=70
        return score

    def countSingle(self,board,player):
        count = 0
        directions = [1, -1, 10, -10, 9, -9, 11, -11]
        for k in range(0,100):
            if board[k] == player:
                found = False
                index = 0
                while index < 8 and found is False:
                    if board[k+directions[index]] == player:
                        found = True
                    index+=1
                if not found:
                    count+=1
        return count

    def countWall(self,board,player):
        wall = set()
        count = 0
        for k in range(0,100):
            if (k) // 10 != 1 and (k) // 10 != 8 and (k) % 10 != 1 and (k) % 10 != 8:
                if board[k] == player:
                    found = False
                    if board[k+11] == ".":
                        if (board[k+1] == ".") and (board[k-9] == "."):
                            found = True
                        if (board[k+10] == ".") and (board[k+9] == "."):
                            found = True
                    if board[k-11] == ".":
                        if (board[k-1] == ".") and (board[k+9] == "."):
                            found = True
                        if (board[k-10] == ".") and (board[k-9] == "."):
                            found = True
                    if found:
                        wall.add(k)
                        count+=1
                        if (k-1) in wall:
                            count+=1
                            if (k - 2) in wall:
                                count += 2
                        if (k-10) in wall:
                            count+=1
                            if (k - 20) in wall:
                                count += 2
        return count

    def countSand(self,board,player):
        count = 0
        opp = self.opponent(player)
        for k in range(0,100):
            if board[k] == player:
                if self.sandHelp(board,player,opp,k,-1) and self.sandHelp(board,player,opp,k,1) == opp:
                    count+=1
                if self.sandHelp(board,player,opp,k,-10) == opp and self.sandHelp(board,player,opp,k,10) == opp:
                    count+=1
                if self.sandHelp(board,player,opp,k,-11) == opp and self.sandHelp(board,player,opp,k,11) == opp:
                    count+=1
                if self.sandHelp(board,player,opp,k,-9) == opp and self.sandHelp(board,player,opp,k,9) == opp:
                    count+=1
        return count

    def sandHelp(self,board,player,opp,index,direction):
        found = False
        while board[index] == player:
            index+=direction
        if board[index] == opp:
            found = True
        return found

    def best_strategy(self, board, player, best_move, running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        self.move+=1
        self.testTable = {}
        # while True:
        #     best_move.value = 56
        board = ''.join(board)
        moves = self.get_valid_moves(board,player)
        if len(moves) == 1:
            best_move.value = moves[0]
            return moves[0]
        global NDOES
        while True and depth<15:
            ## doing random in a loop is pointless but it's just an example
            NODES = 0
            test = self.minmax_strategy(board,player,depth)
            best_move.value = test

            print(depth)
            depth += 1
            if depth < 5:
                depth+=1


    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
# ################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False
#
# #################################################
# # ParallelPlayer simulated tournament play
# # With parallel processes and time limits
# # this may not work on Windows, because, Windows is lame
# # This calls Strategy.best_strategy(board, player, best_shared, running)
# ##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 3):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = "@"

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == "@" else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))
class StandardPlayer():
    def __init__(self):
        pass

    def play(self,blackVals = None, whiteVals = None):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()
        white.standard_strategy = white.minmax_strategy
        black.standard_strategy = black.minmax_strategy
        if whiteVals is not None:
            white.vals = whiteVals
        if blackVals is not None:
            black.vals = blackVals

        #print("Playing Standard Game")
        board = ref.get_starting_board()
        player = "@"
        strategy = {"@": black.standard_strategy, "o": white.standard_strategy}
        #print(ref.get_pretty_board(board))

        while player is not None:

            moveTime = time.time()
            move = strategy[player](board, player, 5)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            # print(board)
            #print(ref.get_pretty_board(board))

            player = ref.next_player(board, player)
            # print(time.time()-moveTime)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))
        return ref.score(board)

if __name__ == "__main__":
    game =  ParallelPlayer()
    game.play()
