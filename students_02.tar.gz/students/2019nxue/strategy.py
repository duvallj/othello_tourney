# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 15:39:42 2018

@author: Nathan
"""
import random
import sys

weight_board = [120, -20,  20,   5,   5,  20, -20, 120, -20, -40,  -5,  -5,  -5,  -5, -40, -20, 20,  -5,  15,   3,   3,  15,  -5,  20,
                5,  -5,   3,   3,   3,   3,  -5,   5, 5,  -5,   3,   3,   3,   3,  -5,   5, 20,  -5,  15,   3,   3,  15,  -5,  20, 
                -20, -40,  -5,  -5,  -5,  -5, -40, -20, 120, -20,  20,   5,   5,  20, -20, 120]

def formatPrint(board):
	print(' ' + '\n '.join([''.join(board[n*8:n*8+8])for n in range(8)]))
def whoseMove(board):
	return ['x', 'o'][len([1 for i in range(64) if board[i]=='.'])%2]
def freePositions(board):
	return [i for i in range(9)if board[i]=='.']
def all_moves(board, turn):
    lul = []
    for x in range(len(board)):
        if board[x]==turn:
            possible = possible_moves(board,turn,x,".")
            for z in possible:
                lul.append(z)
    return lul

def getdirections(board, turn, index):
    row = index//8
    col = index%8
    moves = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
    if col == 1 or col==0:
        moves = [i for i in moves if i[1]!=-1]
    elif col == 7 or col==6:
        moves = [i for i in moves if i[1]!=1]
    if row==0 or row==1:
        moves = [i for i in moves if i[0]!=-1]
    elif row==7 or row == 6:
        moves = [i for i in moves if i[0]!=1]
    return moves

def possible_directions(board,turn,index,stop):
    row = index//8
    col = index%8
    moves = getdirections(board,turn,index)
    directions = []
    for i in moves:
        newrow = row
        newcol = col
        d_row = i[0]
        d_col = i[1]
        changed = False
        while True:
            newrow+=d_row
            newcol+=d_col
            index = newrow*8+newcol
            if newcol < 0 or newcol > 7 or newrow <0 or newrow >7:
                break
            elif changed and board[index]==stop:
                directions.append(i)
                break
            elif (not changed) and board[index] == stop:
                break
            elif board[index] != turn:
                changed = True
            else:
                break
    return directions

def possible_moves(board, turn, index, stop):
    row = index//8
    col = index%8
    moves = getdirections(board,turn,index)
    positions = []
    for i in moves:
        newrow = row
        newcol = col
        d_row = i[0]
        d_col = i[1]
        changed = False
        while True:
            newrow+=d_row
            newcol+=d_col
            index = newrow*8+newcol
            if newcol < 0 or newcol > 7 or newrow <0 or newrow >7:
                break
            elif changed and board[index]==stop:
                positions.append(index)
                break
            elif (not changed) and board[index] == stop:
                break
            elif board[index] != turn:
                changed = True
            else:
                break
    return positions

def my_moves(board,index,moves,stop):
    row = index//8
    col = index%8
    positions = []
    positions.append(index)
    for i in moves:
        newrow = row
        newcol = col
        d_row = i[0]
        d_col = i[1]
        lul =[]
        failed=False
        while True:
            newrow+=d_row
            newcol+=d_col
            index = newrow*8+newcol
            if newcol < 0 or newcol > 7 or newrow <0 or newrow >7:
                failed=True
                break
            elif board[index]==stop:
                break
            elif board[index]==".":
                failed=True
                break
            else:
                lul.append(index)
        if failed == False:
            for x in lul:
                positions.append(x)
    return positions

def evaluate_score(board):
    x=0
    o=0
    for pos in range(len(board)):
        if board[pos]=="x":
            x+=weight_board[pos]
        elif board[pos]=="o":
            o+=weight_board[pos]
    return (x,o)

def change_board(board, positions, token):
    y=""
    for x in range(len(board)):
        if x in positions:
            y+=token
        else:
            y+=board[x]
    return y

def conv_lower(board):
    y=""
    for x in board:
        if x != ".":
            y+=(x.lower())
        else:
            y+=x
    return y

def formatOutput(moves):
    if len(moves)==0:
        print("No Moves are Possible")
    else:
        print("Possible Moves: {}".format(moves))
        
def changeToken(token):
    index = 0
    index += (int(token[1])-1)*8
    col = "abcdefgh".index(token[0].lower())
    index += col
    return index

def numxo(board):
    x=0
    o=0
    for token in board:
        if token=="x":
            x+=1
        elif token=="o":
            o+=1
    return (x,o)

def opposite(token):
    if token=="x":
        return "o"
    elif token=="o":
        return "x"

def make_move(board,turn,place):
    direc = possible_directions(board,turn,place,turn)
    my_places = my_moves(board,place,direc,turn)
    new_board=change_board(board,my_places,turn)
    return new_board

def move_all(board,places,turn):
    new_board = board
    my_turn = turn
    for x in places:
        index = 0
        if x[0].isalpha():
            index = changeToken(x)
        else:
            index = int(x)
        possible = all_moves(new_board,my_turn)
        formatPrint(change_board(new_board, possible,"*"))
        print(my_turn, index, possible)
        if index not in possible:
            my_turn = opposite(my_turn)
        possible = all_moves(new_board,my_turn)
        print(my_turn, index, possible)
        if index not in possible:
            print("ERROR: MOVE IMPOSSIBLE FOR BOTH X AND O")
            break
        direc = possible_directions(new_board,my_turn,index,my_turn)
        my_places = my_moves(new_board,index,direc,my_turn)
        print(my_places)
        new_board=change_board(new_board,my_places,my_turn)
        formatPrint(new_board)
        print("-----------")
        my_turn = opposite(my_turn)
    print(lab3print(new_board))

def preferred_moves(board, turn, moveset):
    
    '''remain_moves = board.count(".")
    if remain_moves < 7:
        return negamax(board,turn,10)'''
    
    if 0 in moveset:
        return 0
    elif 7 in moveset:
        return 7
    elif 56 in moveset:
        return 56
    elif 63 in moveset:
        return 63
    
    good_moves=[]
    meh_moves=[]
    worse_moves=[]
    bad_moves=[]
    for x in moveset:
        row = x//8
        col = x%8
        direc = possible_directions(board,turn,x,turn)
        my_places = my_moves(board,x,direc,turn)
        new_board=change_board(board,my_places,turn)
        if row==0 or row==7:
            if safe_edge(new_board,turn,x,[(0,-1),(0,1)]):
                good_moves.append(x)
            else:
                if x in (1,6,57,62):
                    bad_moves.append(x)
                else:
                    worse_moves.append(x)
        elif col==0 or col==7:
            if safe_edge(new_board,turn,x,[(0,-1),(0,1)]):
                good_moves.append(x)
            else:
                if x in (8,48,15,55):
                    bad_moves.append(x)
                else:
                    worse_moves.append(x)
        else:
            if x in (9,14,49,54) and not corner_satisfied:
                bad_moves.append(x)
            else:
                meh_moves.append(x)
    
    if len(good_moves)>0:
        return best_score(board,turn,good_moves)
        return random_moves(good_moves)
    elif len(meh_moves)>0:
        #return best_score(board,turn,meh_moves)
        return random_moves(meh_moves)
        #return pref2(board, turn, meh_moves)
    elif len(worse_moves)>0:
        return worse_score(board,turn,worse_moves)
        return random_moves(worse_moves)
    elif len(bad_moves)>0:
        return random_moves(bad_moves)
    else:
        return ""

def worse_score(board,turn,moveset):
    move = -1
    orig_score = 1000000
    
    for x in moveset:
        direc = possible_directions(board,turn,x,turn)
        my_places = my_moves(board,x,direc,turn)
        new_board=change_board(board,my_places,turn)
        #board_weight = evaluate_score(new_board)
        board_score = score(new_board,turn)
        my_score=board_score#board_weight[0]-board_weight[1]+board_score
        #if turn=="o":
        #    my_score=-1*my_score
        if my_score < orig_score:
            move = x
            orig_score=my_score
            
    return move

def best_score(board,turn,moveset):
    move = -1
    orig_score = -1000000
    
    for x in moveset:
        direc = possible_directions(board,turn,x,turn)
        my_places = my_moves(board,x,direc,turn)
        new_board=change_board(board,my_places,turn)
        #board_weight = evaluate_score(new_board)
        board_score = score(new_board,turn)
        my_score=board_score#board_weight[0]-board_weight[1]+board_score
        #if turn=="o":
        #    my_score=-1*my_score
        if my_score > orig_score:
            move = x
            orig_score=my_score
            
    return move

def corner_satisfied(board,turn,move):
    if move==9:
        if board[0]==turn:
            return True
    if move==14:
        if board[7]==turn:
            return True
    if move==49:
        if board[56]==turn:
            return True
    if move==54:
        if board[63]==turn:
            return True
    return False
 
def pref2(board, turn, moveset):
    if 0 in moveset:
        return 0
    elif 7 in moveset:
        return 7
    elif 56 in moveset:
        return 56
    elif 63 in moveset:
        return 63
    
    print(moveset)
    
    move = -1
    orig_score = -1000000
    
    for x in moveset:
        direc = possible_directions(board,turn,x,turn)
        my_places = my_moves(board,x,direc,turn)
        new_board=change_board(board,my_places,turn)
        board_weight = evaluate_score(new_board)
        board_score = score(new_board,turn)
        my_score=board_weight[0]-board_weight[1]+board_score
        if turn=="o":
            my_score=-1*my_score
        if my_score > orig_score:
            move = x
            orig_score=my_score
            
    return move

def game_end(board, token):
    my_turn=token
    possible = all_moves(board,my_turn)
    if len(possible)==0:
        my_turn = opposite(my_turn)
    possible = all_moves(board,my_turn)
    if len(possible)==0:
        return True
    return False

def score(board,player):
    me=board.count(player)
    cpu=board.count(opposite(player))
    return me-cpu

def negamax(board,token,levels):
    if not levels or game_end(board,token):
        return [score(board,token)]
    lm = all_moves(board,token)
    if not lm:
        nm = negamax(board,opposite(token),levels-1)+[-1]
        return [-nm[0]]+nm[1:]
    nmlist = sorted([negamax(make_move(board,token,mv),opposite(token),levels-1)+[mv] for mv in lm])
    best = nmlist[0]
    return [-best[0]] + best[1:]

#def negamaxTerminal(board,token,improvable,hardbound)

def random_moves(moves):
    length = len(moves)
    return moves[random.randint(0,length-1)]
    #return moves[0]
    
def safe_edge(board,turn,index,direction):
    for x in direction:
        row = index//8
        col = index%8
        dr=x[0]
        dc=x[1]
        safe=True
        while True:
            row+=dr
            col+=dc
            ind = row*8+col
            if row < 0 or row > 7 or col <0 or col >7:
                break
            elif board[ind]!=turn:
                safe=False
                break
        if safe:
            return True
    return False

def lab3print(board):
    s = board + " "
    xo=numxo(board)
    s=s+str(xo[0])+"/"+str(xo[1])
    return s

def conv_board(board):
    s = ""
    for x in board:
        if x =="X":
            s+="x"
        elif x=="O":
            s+="o"
        else:
            s+=x
    return s

def main():
    board = "...........................ox......xo..........................."
    board = "x.ooooooxoooxxoxoooooxxxoooxxoxxoooxxxoxooooooxxxxxxxoxxxxxxxxox"
    #board = "...oooooox.xoooooxxxxooooxoxxxoooxxxxooooxxoxooooxxxxxoooooooooo"
    move = "x"
    args = sys.argv
    places = []
    changed=False
    if len(args)==1:
        damn = all_moves(board,move)
        formatPrint(board)
        print("LegalMoves: {}".format(damn))
        remain_moves = board.count(".")
        if remain_moves < 7:
            print(negamax(board,move,-1)[-1])
        else:
            print("Heuristic Move: {}".format(preferred_moves(board, move, damn)))
    else:
        for x in range(1,len(args)):
            if args[x].lower()=="x" or args[x].lower()=="o":
                move = args[x].lower()
                changed=True
            elif len(args[x]) <3:
                places.append(args[x])
            else:
                board = conv_board(args[x])
        if changed == False:
            move=whoseMove(board)
        formatPrint(board)
        damn = all_moves(board,move)
        print("Legal Moves: {}".format(damn))
        remain_moves = board.count(".")
        if remain_moves < 7:
            print(negamax(board,move,-1)[-1])
        else:
            print("Heuristic Move: {}".format(preferred_moves(board, move, damn)))
        
if __name__=="__main__":
    main()

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        playerToToken={"@":"x","o":"o"}
        board="".join(board)
        board="".join([board[i:i+8] for i in range(11,91,10)])
        board=board.replace("@","x")
        token = playerToToken[player]
        damn = all_moves(board,token)
        mv = preferred_moves(board,token,damn)
        myMove=11+(mv//8)*10+(mv%8)
        best_move.value=myMove
        remain_moves = board.count(".")
        if remain_moves < 7:
            z=negamax(board,token,-1)[-1]
            myMove=11+(z//8)*10+(z%8)
            best_move.value=myMove
    
    

