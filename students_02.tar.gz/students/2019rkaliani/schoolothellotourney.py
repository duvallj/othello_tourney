import random,time
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = "".join(board.replace('?','').replace('@','x'))
        start = time.time()
        token = 'x' if player=='@' else token = 'o'
        if len([i for i, letter in enumerate(board) if letter == "."])>8:
            mv = findBestMove(brd,token)
            mv1 = 11 + (mv // 8) * 10 + (mv % 8)
            best_move.value = mv1
        else:
            currentLevel=1
            while currentLevel<10:
                mv = negamax(board,token,currentLevel)[-1]
                currentLevel+=2
                mv1 = 11 + (mv//8)*10 + (mv%8)
                best_move.value = mv1

def findBestMove(table,token):
    if len([i for i, letter in enumerate(table) if letter == "."]) > 8:
        moves = possibleMoves(token, table)

        if len(moves)>0:
            for x in [0, 7, 56, 63]:
                if x in moves:
                    return x

            for corner in [(0,[1,8]),(7,[-1,8]),(56,[-8,1]),(63,[-8,-1])]:
                if table[corner[0]]==token:
                    for direction in corner[1]:
                        endSafe = corner[0]
                        while 0<=endSafe+direction<=63 and table[endSafe+direction]==token:
                            endSafe+=direction
                        endOppo =endSafe
                        while 0<=endOppo+direction<=63 and table[endOppo+direction] ==oppToken(token):
                            endOppo+=direction
                        if endOppo in moves:
                            return endOppo
            tempMoves = moves[:]
            for temp in moves:
                if temp in [1,9,8,14,6,15,48,49,37,62,55,54]:
                    tempMoves.remove(temp)
                    # elif temp%8==0 or temp%8==7 or int(temp/8)==0 or int(temp/8)==7:
                    #    tempMoves.remove(temp)
            if len(tempMoves) > 0:
                rand = random.choice(tempMoves)
                if rand in moves:
                    return rand

            else:
                rand = random.choice(moves)
                if rand in moves:
                    return rand
    else:
        currentLevel = 1
        mv = negamax(table, token, currentLevel)
        print(mv[-1])
        return

def move(index, token, board):
    if index in possibleMoves(token, board):
        if token == 'x':
            opptoken = 'o'
        else:
            opptoken = 'x'
        copyBoard = list(board)
        # left,right,up,down,diagupleft,diagupright,diagdownleft,diagdownright = index-1,index+1,index-8,index+8,index-9,index-7,index+7,index+9
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]
        switchedPositions = [index]
        for x in directions:
            tempObj = index + x
            positionsPassed = []
            while 63 >= (tempObj + x) >= 0 and board[tempObj] == opptoken:
                if x == 1 or x == -1:
                    if int((tempObj + x) / 8) != int(index / 8):
                        break
                if x == 7 or x == -9:
                    if tempObj % 8 == 0 or index % 8 == 0:
                        break
                if x == 9 or x == -7:
                    if tempObj % 8 == 7 or index % 8 == 7:
                        break
                positionsPassed.append(tempObj)
                tempObj += x
            if len(positionsPassed) > 0 and board[tempObj] == token:

                for z in positionsPassed:
                    switchedPositions.append(z)
        # print(switchedPositions)
        for pos in switchedPositions:
            copyBoard[pos] = token
        finalBoard = "".join(copyBoard)
        # printBoardShort(finalBoard)
        return finalBoard
    return board
def evalBoard(board, token):
    if token=='x': opptoken = 'o'
    else: opptoken='x'
    num = len([i for i, letter in enumerate(board) if letter == token])-len([a for a, letter in enumerate(board) if letter == opptoken])
    return num
def oppToken(token):
    if token=='x':return 'o'
    return 'x'
def negamax(board, token, levels):

        if not levels: return [evalBoard(board, token)]
        lm = possibleMoves(token,board)
        if not lm:
            mm = negamax(board, oppToken(token), levels - 1) + [1]
            return [-mm[0]] + mm[1:]
        else:
            nmList = sorted([negamax(move(mv,token,board), oppToken(token), levels - 1) + [mv] for mv in lm])
            best = nmList[0]
            return [-best[0]] + best[1:]

    # preferred  # of levels: 3
# Test with only 1 level




def possibleMoves(token,board):
    poss = set()
    for index in [i for i, letter in enumerate(board) if letter == "."]:
        if token == 'x':
            opptoken = 'o'
        else:
            opptoken = 'x'

        # left,right,up,down,diagupleft,diagupright,diagdownleft,diagdownright = index-1,index+1,index-8,index+8,index-9,index-7,index+7,index+9
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]

        for x in directions:
            tempObj = index + x

            while 63 >= (tempObj + x) >= 0:
                if board[tempObj] == opptoken:
                    if x == 1 or x == -1:
                        if int((tempObj + x) / 8) != int(index / 8):
                            break
                    if x == 7 or x == -9:
                        if tempObj % 8 == 0 or index % 8 == 0:
                            break
                    if x == 9 or x == -7:
                        if tempObj % 8 == 7 or index % 8 == 7:
                            break
                    tempObj += x
                else: break
            if 63 >= (tempObj) >= 0 and board[tempObj] == token and tempObj!=index+x:
                poss.add(index)
        # print(switchedPositions)


    return list(poss)

