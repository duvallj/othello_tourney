import sys, math, time
full_board =  0xffffffffffffffff
empty_board = 0x0000000000000000
corners = 0x8100000000000081
masks = {
    1:0x7e7e7e7e7e7e7e7e,
    7:0x007e7e7e7e7e7e00,
    8:0x00ffffffffffff00,
    9:0x007e7e7e7e7e7e00
}
linear_masks = {
    1:{9223372036854775808: 18374686479671623680, 4611686018427387904: 18374686479671623680, 2305843009213693952: 18374686479671623680, 1152921504606846976: 18374686479671623680, 576460752303423488: 18374686479671623680, 288230376151711744: 18374686479671623680, 144115188075855872: 18374686479671623680, 72057594037927936: 18374686479671623680, 36028797018963968: 71776119061217280, 18014398509481984: 71776119061217280, 9007199254740992: 71776119061217280, 4503599627370496: 71776119061217280, 2251799813685248: 71776119061217280, 1125899906842624: 71776119061217280, 562949953421312: 71776119061217280, 281474976710656: 71776119061217280, 140737488355328: 280375465082880, 70368744177664: 280375465082880, 35184372088832: 280375465082880, 17592186044416: 280375465082880, 8796093022208: 280375465082880, 4398046511104: 280375465082880, 2199023255552: 280375465082880, 1099511627776: 280375465082880, 549755813888: 1095216660480, 274877906944: 1095216660480, 137438953472: 1095216660480, 68719476736: 1095216660480, 34359738368: 1095216660480, 17179869184: 1095216660480, 8589934592: 1095216660480, 4294967296: 1095216660480, 2147483648: 4278190080, 1073741824: 4278190080, 536870912: 4278190080, 268435456: 4278190080, 134217728: 4278190080, 67108864: 4278190080, 33554432: 4278190080, 16777216: 4278190080, 8388608: 16711680, 4194304: 16711680, 2097152: 16711680, 1048576: 16711680, 524288: 16711680, 262144: 16711680, 131072: 16711680, 65536: 16711680, 32768: 65280, 16384: 65280, 8192: 65280, 4096: 65280, 2048: 65280, 1024: 65280, 512: 65280, 256: 65280, 128: 255, 64: 255, 32: 255, 16: 255, 8: 255, 4: 255, 2: 255, 1: 255},
    7:{1: 1, 2: 258, 256: 258, 4: 66052, 512: 66052, 65536: 66052, 8: 16909320, 1024: 16909320, 131072: 16909320, 16777216: 16909320, 16: 4328785936, 2048: 4328785936, 262144: 4328785936, 33554432: 4328785936, 4294967296: 4328785936, 32: 1108169199648, 4096: 1108169199648, 524288: 1108169199648, 67108864: 1108169199648, 8589934592: 1108169199648, 1099511627776: 1108169199648, 64: 283691315109952, 8192: 283691315109952, 1048576: 283691315109952, 134217728: 283691315109952, 17179869184: 283691315109952, 2199023255552: 283691315109952, 281474976710656: 283691315109952, 128: 72624976668147840, 16384: 72624976668147840, 2097152: 72624976668147840, 268435456: 72624976668147840, 34359738368: 72624976668147840, 4398046511104: 72624976668147840, 562949953421312: 72624976668147840, 72057594037927936: 72624976668147840, 32768: 145249953336295424, 4194304: 145249953336295424, 536870912: 145249953336295424, 68719476736: 145249953336295424, 8796093022208: 145249953336295424, 1125899906842624: 145249953336295424, 144115188075855872: 145249953336295424, 8388608: 290499906672525312, 1073741824: 290499906672525312, 137438953472: 290499906672525312, 17592186044416: 290499906672525312, 2251799813685248: 290499906672525312, 288230376151711744: 290499906672525312, 2147483648: 580999813328273408, 274877906944: 580999813328273408, 35184372088832: 580999813328273408, 4503599627370496: 580999813328273408, 576460752303423488: 580999813328273408, 549755813888: 1161999622361579520, 70368744177664: 1161999622361579520, 9007199254740992: 1161999622361579520, 1152921504606846976: 1161999622361579520, 140737488355328: 2323998145211531264, 18014398509481984: 2323998145211531264, 2305843009213693952: 2323998145211531264, 36028797018963968: 4647714815446351872, 4611686018427387904: 4647714815446351872, 9223372036854775808: 9223372036854775808},
    8:{9223372036854775808: 9259542123273814144, 36028797018963968: 9259542123273814144, 140737488355328: 9259542123273814144, 549755813888: 9259542123273814144, 2147483648: 9259542123273814144, 8388608: 9259542123273814144, 32768: 9259542123273814144, 128: 9259542123273814144, 4611686018427387904: 4629771061636907072, 18014398509481984: 4629771061636907072, 70368744177664: 4629771061636907072, 274877906944: 4629771061636907072, 1073741824: 4629771061636907072, 4194304: 4629771061636907072, 16384: 4629771061636907072, 64: 4629771061636907072, 2305843009213693952: 2314885530818453536, 9007199254740992: 2314885530818453536, 35184372088832: 2314885530818453536, 137438953472: 2314885530818453536, 536870912: 2314885530818453536, 2097152: 2314885530818453536, 8192: 2314885530818453536, 32: 2314885530818453536, 1152921504606846976: 1157442765409226768, 4503599627370496: 1157442765409226768, 17592186044416: 1157442765409226768, 68719476736: 1157442765409226768, 268435456: 1157442765409226768, 1048576: 1157442765409226768, 4096: 1157442765409226768, 16: 1157442765409226768, 576460752303423488: 578721382704613384, 2251799813685248: 578721382704613384, 8796093022208: 578721382704613384, 34359738368: 578721382704613384, 134217728: 578721382704613384, 524288: 578721382704613384, 2048: 578721382704613384, 8: 578721382704613384, 288230376151711744: 289360691352306692, 1125899906842624: 289360691352306692, 4398046511104: 289360691352306692, 17179869184: 289360691352306692, 67108864: 289360691352306692, 262144: 289360691352306692, 1024: 289360691352306692, 4: 289360691352306692, 144115188075855872: 144680345676153346, 562949953421312: 144680345676153346, 2199023255552: 144680345676153346, 8589934592: 144680345676153346, 33554432: 144680345676153346, 131072: 144680345676153346, 512: 144680345676153346, 2: 144680345676153346, 72057594037927936: 72340172838076673, 281474976710656: 72340172838076673, 1099511627776: 72340172838076673, 4294967296: 72340172838076673, 16777216: 72340172838076673, 65536: 72340172838076673, 256: 72340172838076673, 1: 72340172838076673},
    9:{1: 4731607904558235517441, 512: 4731607904558235517441, 262144: 4731607904558235517441, 134217728: 4731607904558235517441, 68719476736: 4731607904558235517441, 35184372088832: 4731607904558235517441, 18014398509481984: 4731607904558235517441, 9223372036854775808: 4731607904558235517441, 4722366482869645213696: 4731607904558235517441, 2: 36099303471055874, 1024: 36099303471055874, 524288: 36099303471055874, 268435456: 36099303471055874, 137438953472: 36099303471055874, 70368744177664: 36099303471055874, 36028797018963968: 36099303471055874, 4: 141012904183812, 2048: 141012904183812, 1048576: 141012904183812, 536870912: 141012904183812, 274877906944: 141012904183812, 140737488355328: 141012904183812, 8: 550831656968, 4096: 550831656968, 2097152: 550831656968, 1073741824: 550831656968, 549755813888: 550831656968, 16: 2151686160, 8192: 2151686160, 4194304: 2151686160, 2147483648: 2151686160, 32: 8405024, 16384: 8405024, 8388608: 8405024, 64: 32832, 32768: 32832, 128: 128, 256: 4620710844295151872, 131072: 4620710844295151872, 67108864: 4620710844295151872, 34359738368: 4620710844295151872, 17592186044416: 4620710844295151872, 9007199254740992: 4620710844295151872, 4611686018427387904: 4620710844295151872, 65536: 2310355422147575808, 33554432: 2310355422147575808, 17179869184: 2310355422147575808, 8796093022208: 2310355422147575808, 4503599627370496: 2310355422147575808, 2305843009213693952: 2310355422147575808, 16777216: 1155177711073755136, 8589934592: 1155177711073755136, 4398046511104: 1155177711073755136, 2251799813685248: 1155177711073755136, 1152921504606846976: 1155177711073755136, 4294967296: 577588855528488960, 2199023255552: 577588855528488960, 1125899906842624: 577588855528488960, 576460752303423488: 577588855528488960, 1099511627776: 288794425616760832, 562949953421312: 288794425616760832, 288230376151711744: 288794425616760832, 281474976710656: 144396663052566528, 144115188075855872: 144396663052566528, 72057594037927936: 72057594037927936}
}
masks_inverse = {
    1:0x8181818181818181,
    7:0xff818181818181ff,
    8:0xff000000000000ff,
    9:0xff818181818181ff
}

HORIZONTAL =  1
RIGHT_DIAG =  7
VERTICAL =    8
LEFT_DIAG =   9

def display(board):
    length = int(len(board)**0.5)
    print("\n".join([" ".join([i for i in board[length*x:length*x+length]]) for x in range(length)]).upper()+'\n')
def next_token(board):
    if sum([1 for i in board if i == '.'])&1:
        return 'o'
    return 'x'
def display_bits(bit_rep):
    bit_rep = bin(bit_rep)
    padding = 64 - len(bit_rep[2:])
    display('0'*padding+bit_rep[2:])
def convert_to_bits(board, own_token):
    # return format: [X tiles, O tiles] represented by individual bitboards
    bitboards = [0x0,0x0]
    for i in range(len(board)):
        if board[i] == 'x':
            bitboards[0] += 1<<i
        elif board[i] == 'o':
            bitboards[1] += 1<<i
    if own_token == 'x':
        return bitboards
    return bitboards[::-1]
def find_on_bits(representation, size):
    possible_indices = []
    for i in reversed(range(size)):
        if 2 ** i <= representation:
            representation -= 2 ** i
            possible_indices.append(i)
    return possible_indices
def find_highest_set_bit(n):
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    n |= n >> 32
    n += 1
    return (n >> 1)
def popcount(x):
    return bin(x).count('1')
def popcount_weighted(x):
    return popcount(x)+popcount(x & corners)
def uni_poss(own, opp, direction):
    w = opp & masks[direction]
    t = w & ((own >> direction)|(own << direction))
    t |= w & ((t >> direction)|(t << direction))
    t |= w & ((t >> direction)|(t << direction))
    t |= w & ((t >> direction)|(t << direction))
    t |= w & ((t >> direction)|(t << direction))
    t |= w & ((t >> direction)|(t << direction))
    return (~(own | opp) & ((t >> direction)|(t << direction)))
def possible_moves_rep(own, opp):
    return uni_poss(own, opp, 1) | uni_poss(own, opp, 7) | uni_poss(own, opp, 8) | uni_poss(own, opp, 9)
def uni_flip(own, opp, direction, mv):
    own_intersect = ((own << direction) | (own >> direction)) & opp
    mv_intersect = ((mv << direction) | (mv >> direction)) & opp

    own_intersect|= ((own_intersect << direction)| (own_intersect >> direction))& opp
    mv_intersect |= ((mv_intersect << direction) | (mv_intersect >> direction)) & opp
    own_intersect|= ((own_intersect << direction)| (own_intersect >> direction))& opp
    mv_intersect |= ((mv_intersect << direction) | (mv_intersect >> direction)) & opp
    own_intersect|= ((own_intersect << direction)| (own_intersect >> direction))& opp
    mv_intersect |= ((mv_intersect << direction) | (mv_intersect >> direction)) & opp
    own_intersect|= ((own_intersect << direction)| (own_intersect >> direction))& opp
    mv_intersect |= ((mv_intersect << direction) | (mv_intersect >> direction)) & opp
    own_intersect|= ((own_intersect << direction)| (own_intersect >> direction))& opp
    mv_intersect |= ((mv_intersect << direction) | (mv_intersect >> direction)) & opp

    return own_intersect & mv_intersect
def make_move(own, opp, mv):
    opp_masked = opp & masks[HORIZONTAL]
    flipped = uni_flip(own, opp_masked, HORIZONTAL, mv) | uni_flip(own, opp, VERTICAL, mv) | uni_flip(own, opp_masked, RIGHT_DIAG, mv) | uni_flip(own, opp_masked, LEFT_DIAG, mv)
    return own | flipped | mv, opp^flipped
def uni_stable(n, own, direction):
    n |= own & ((n >> direction) | (n << direction))
    n |= own & ((n >> direction) | (n << direction))
    n |= own & ((n >> direction) | (n << direction))
    n |= own & ((n >> direction) | (n << direction))
    n |= own & ((n >> direction) | (n << direction))
    n |= own & ((n >> direction) | (n << direction))
    n |= own & ((n >> direction) | (n << direction))
    return n & masks_inverse[direction]
def stable(own):
    w = own
    count = 0
    while w:
        curr = find_highest_set_bit(w)
        w -= curr
        if(uni_stable(curr, own, HORIZONTAL) and uni_stable(curr, own, VERTICAL) and uni_stable(curr, own, LEFT_DIAG) and uni_stable(curr, own, RIGHT_DIAG)):
            count += 1
    return count
def corners_captured(own, opp):
    return popcount(own & corners) - popcount(opp & corners)
def frontier(own, opp):
    empty = ~(own | opp)
    own_shifted = own & 0x007e7e7e7e7e7e00
    n = (own_shifted >> 1) | (own_shifted >> 7) | (own_shifted >> 8) | (own_shifted >> 9) | (own_shifted << 1) | (own_shifted << 7) | (own_shifted << 8) | (own_shifted << 9)
    return popcount_weighted(n & empty)
def mobility(own, opp):
    return frontier(own,opp) - frontier(opp,own)
def stable_heuristic(own, opp):
    return stable(own) - stable(opp)
def coin_parity(own, opp):
    return popcount_weighted(own) - popcount_weighted(opp)
def eval_mid(own, opp):
    return 2500*corners_captured(own, opp) + 500*mobility(own, opp) + 500*coin_parity(own, opp) + 5000*stable_heuristic(own, opp)
def eval_end(own, opp):
    return popcount(own)-popcount(opp)
def heuristic(own, opp):
    corner_edge_orientations = {
        0x8000000000000000:0x4080000000000000,
        0x0100000000000000:0x0201000000000000,
        0x0000000000000080:0x0000000000008040,
        0x0000000000000001:0x0000000000000102
    }
    pm = possible_moves_rep(own, opp)
    available_corners = pm & corners
    if(available_corners):
        return find_highest_set_bit(available_corners)
    for corner in corner_edge_orientations:
        stable_edge_h = linear_masks[1][corner] & pm
        stable_edge_v = linear_masks[8][corner] & pm
        if stable_edge_h:
            return stable_edge_h
        if stable_edge_v:
            return stable_edge_v
    return find_highest_set_bit(pm)
def negamax_terminal(rep_states, improvable, hardBound, levels, eval):
    if not levels: return [eval(rep_states[0], rep_states[1])]
    lm = possible_moves_rep(rep_states[0],rep_states[1])
    if not lm:
        if not possible_moves_rep(rep_states[1], rep_states[0]):
            return [eval(rep_states[0], rep_states[1]), -3]
        nm = negamax_terminal([rep_states[1],rep_states[0]], -hardBound, -improvable, levels-1, eval) + [-1]
        return [-nm[0]]+nm[1:]
    best = []
    newHB = -improvable
    while lm:
        mv = find_highest_set_bit(lm)
        lm ^= mv
        nm = negamax_terminal(make_move(rep_states[0], rep_states[1], mv)[::-1], -hardBound, newHB, levels-1, eval) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardBound: return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]

class Strategy:
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?', '').replace('@', 'x')
        token = 'x' if player == '@' else 'o'

        bits = convert_to_bits(brd, token)

        depth = 4

        while True:
            ng = negamax_terminal(bits, -65, 65, depth, eval_mid)
            seq = [int(math.log2((find_highest_set_bit(n)))) if n >= 0 else n for n in ng[1:]]
            mv = seq[-1]
            mv1 = 11 + (mv // 8) * 10 + (mv % 8)
            best_move.value = mv1
            depth += 1
def main():

    board = '.'*27+'ox'+'.'*6+'xo'+'.'*27
    token = ''

    for i in sys.argv[1:]:
        if len(i) == 64:
            board = i.lower()
        elif i.lower() == 'x' or i.lower() == 'o':
            token = i.lower()

    if not token:
        token = next_token(board)

    bits = convert_to_bits(board, token)

    display(board)

    print('Possible Moves: ' + str(find_on_bits(possible_moves_rep(bits[0], bits[1]), 64)))
    #print('Heuristic Move: ' + str(math.log2(heuristic(bits[0], bits[1]))))
    print('Heuristic Move: ' + str(int(math.log2(negamax_terminal(bits, -65, 65, 14, eval_mid)[-1]))))

    if board.count('.') < 14:
        ng = negamax_terminal(bits, -65, 65, -1, eval_end)
        seq = [int(math.log2((find_highest_set_bit(n)))) if n >= 0 else n for n in ng[1:]]
        print('Negamax Score: ' + str(ng[0]) + ' ' + str(seq) + 'My move: ' + str(seq[-1]))

if __name__ == "__main__":
    main()