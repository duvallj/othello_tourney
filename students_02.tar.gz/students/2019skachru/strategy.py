import Othello_Core as core
""""SJ Kachru Period 1 Zacharias"""
import random
import math
import copy

class Strategy(core.OthelloCore):

    EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
    PIECES = (EMPTY, BLACK, WHITE, OUTER)
    PLAYERS = {BLACK: 'Black', WHITE: 'White'}
    UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
    UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
    DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)
    C1, C2, C3, C4 = 11, 18, 81, 88
    CORNERS = (C1, C2, C3, C4)


    def is_valid(self, move):
        """Is move a square on the board?"""
        if move in self.squares():
            return True
        return False

    def opponent(self, player):
        """Get player's opponent piece."""
        if player == self.BLACK:
            return self.WHITE
        else:
            return self.BLACK

    def numDisks(self, board):
        """Find the number of disks currently on the board"""
        num=0
        for s in self.squares():
            if board[s] in [self.BLACK, self.WHITE]:
                num+=1
        return num

    def find_bracket(self, square, player, board, direction):
        """
        Find a square that forms a bracket with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        Returns the index of the bracketing square if found
        """
        bracket = square + direction
        opp = self.opponent(player)
        while board[bracket] == opp:
            bracket += direction
            if board[bracket] == player:
                return bracket
        return None

    def len_bracket(self, square, player, board, direction):
        """Finds number of tile that do not form a bracket for a player in a
        given direction. Used to find number of stable tiles from a corner"""
        num=0
        bracket = square + direction
        opp = self.opponent(player)
        while board[bracket] == player:
            num+=1
            bracket+=direction
            if board[bracket] == opp:
                return num
        return num

    def is_legal(self, move, player, board):
        """Is this a legal move for the player?"""
        opp=self.opponent(player)
        tiles=[]
	#For loop through every direction away from tentative index
        for addDirection in self.DIRECTIONS:
            check=self.find_bracket(move, player, board, addDirection)
            if check and board[move] == self.EMPTY:
                tiles.append(check)
        if len(tiles) == 0:
            return False
        #Kept tiles in case want to implement a heuristic based on mobility
        return True

    def legal_moves(self, player, board):
        """Get a list of all legal moves for player, as a list of integers"""
        moves=[]
        for x in self.squares():
            if self.is_legal(x, player, board):
                    moves.append(x)
        return moves

    def any_legal_move(self, player, board):
        """Can player make any moves? Returns a boolean"""
        if self.legal_moves(player, board) and len(self.legal_moves(player, board)) > 0:
            return True
        return False

    def next_player(self,board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opp = self.opponent(prev_player)
        if self.any_legal_move(board, opp):
            return opp
        elif self.any_legal_move(board, prev_player):
            return prev_player
        return None

    def score(self,player, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        score=0
        opp=self.opponent(player)
        for s in self.squares():
            i=board[s]
            if i == player:
                score+=1
            elif i == opp:
                score-=1
        return score

    def weighted_score(self, player, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        score=0
        opp=self.opponent(player)
        for s in self.squares():
            i=board[s]
            if i == player:
                score+=self.SECOND_WEIGHTS[s]
            elif i == opp:
                score-=self.SECOND_WEIGHTS[s]
        return score

    def mobility(self, player, board):
        """Find relative mobility of player over opponent for this state"""
        playerMoves = len(self.legal_moves(player, board))
        oppMoves=len(self.legal_moves(self.opponent(player), board))
        if (playerMoves + oppMoves) !=0:
            return 100 * (playerMoves - oppMoves) / (playerMoves+ oppMoves)
        else:
            return 0

    def corners(self, player, board):
        """Find how many corners player has relative to opponent"""
        opp=self.opponent(player)
        playerC=0
        oppC=0
        for c in self.CORNERS:
            if board[c]==player:
                playerC+=1
            if board[c]==opp:
                oppC+=1
        if (playerC + oppC) != 0:
            return 100 * (playerC - oppC) / (playerC + oppC + 1)
        else:
            return 0

    def stability(self, player, board):
        """Find how many stable/unflippable tiles there are from corners of player minus opponent"""
        playerStable = 0
        opp = self.opponent(player)
        oppStable = 0

        for c in self.CORNERS:
            for addDirection in self.DIRECTIONS:
                checkPlayer=self.len_bracket(move, player, board, addDirection)
                checkOpp=self.len_bracket(move, opp, board, addDirection)
                playerStable+=checkPlayer
                oppStable+=checkOpp
        return playerStable - oppStable


    def parity(self, player, board):
        """Find who will have the last move in the late game-idk if 1 and -1 work"""
        squaresLeft = 64 - self.numDisks(board)
        if squaresLeft % 2 == 0:
            return -1
        else:
            return 1

    def difference(self, player, board):
        playerNum=0
        opp = self.opponent(player)
        oppNum=0
        for s in self.squares():
            if board[s] == player:
                playerNum+=1
            if board[s] == opp:
                oppNum+=1
        return 100 * (playerNum - oppNum) / (playerNum + oppNum)

    def heuristicEarly(self, player, board):
        """Determine different move value depending on stage of game"""
        return 5 * self.mobility(player, board)
        + 20 * self.weighted_score(player, board)
        + 1300 * self.corners(player, board)
        + 1000 * self.stability(player, board)

    def heuristicMid(self, player, board):
        """Determine different move value depending on stage of game"""
        return 10 * self.difference(player, board)
        + 50 * self.mobility(player, board)
        + 10 * self.weighted_score(player, board)
        + 100 * self.parity(player, board)
        + 1300 * self.corners(player, board)
        + 1000 * self.stability(player, board)

    def heuristicLate(self, player, board):
        """Determine different move value depending on stage of game"""
        return 500 * self.difference(player, board)
        + 500 * self.parity(player, board)
        + 10000 * self.corners(player, board)
        + 10000 * self.stability(player, board)


    def random(self, player, board):
        print(self.print_board(board))
        return random.choice(self.legal_moves(player, board))

    SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    NEG_SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, -120, 20, -20, -5, -5, -20, 20, -120, 0,
        0, 20, 40, 5, 5, 5, 5, 40, 20, 0,
        0, -20, 5, -15, -3, -3, -15, 5, -20, 0,
        0, -5, 5, -3, -3, -3, -3, 5, -5, 0,
        0, -5, 5, -3, -3, -3, -3, 5, -5, 0,
        0, -20, 5, -15, -3, -3, -15, 5, -20, 0,
        0, 20, 40, 5, 5, 5, 5, 40, 20, 0,
        0, -120, 20, -20, -5, -5, -20, 20, -120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    THIRD_WEIGHTS = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 130, -20, 20, 5, 5, 20, -20, 130, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 130, -20, 20, 5, 5, 20, -20, 130, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]

    SECOND_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 1000, -100, 100,  50,  50, 100, -100,  1000, 0,
        0, -100, -200, -50, -50, -50, -50, -200, -100, 0,
        0, 100,  -50, 100,   0,   0, 100,  -50,  100, 0,
        0, 50,  -50,   0,   0,   0,   0,  -50,   50, 0,
        0, 50,  -50,   0,   0,   0,   0,  -50,   50, 0,
        0, 100,  -50, 100,   0,   0, 100,  -50,  100, 0,
        0, -100, -200, -50, -50, -50, -50, -200, -100, 0,
        0, 1000, -100, 100,  50,  50, 100, -100,  1000, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    MAX_VALUE = sum(map(abs, SECOND_WEIGHTS))
    MIN_VALUE = -MAX_VALUE

    def weighted_moves(self, board, player):
        moves=self.legal_moves(player, board)
        moves.sort(key = lambda val: self.SECOND_WEIGHTS[val])
        return moves[0]

    def minimax(self, maxPlayer, board, depth, player, evaluate):
        if depth == 0:
            return evaluate(player, board)
        if player==maxPlayer:
            bestVal=self.MIN_VALUE
            moves=self.legal_moves(player, board)
            if not moves:
                if not self.any_legal_move(self.opponent(player), board):
                    return self.score(player, board)
                return evaluate(player, board)
            for move in moves:
                moved_board=self.make_move(move, player, copy.deepcopy(board))
                v = self.minimax(self.opponent(maxPlayer), moved_board, depth-1, player, evaluate)
                bestVal = max(bestVal, v)
            return bestVal
        else:
            opp=self.opponent(player)
            bestVal=self.MAX_VALUE
            moves=self.legal_moves(opp, board)
            if not moves:
                if not self.any_legal_move(self.opponent(opp), board):
                    return self.score(opp, board)
                return evaluate(opp, board)
            for move in moves:
                moved_board=self.make_move(move, opp, copy.deepcopy(board))
                v = self.minimax(self.opponent(maxPlayer), moved_board, depth-1, opp, evaluate)
                bestVal = min(bestVal, v)
            return bestVal

    def alphabeta(self, maxPlayer, player, board, alpha, beta, depth, evaluate):
        if depth==0:
            return evaluate(player, board), None
        if player==maxPlayer:
            #bestVal=self.MIN_VALUE
            moves=self.legal_moves(player, board)
            if not moves:
                if not self.any_legal_move(self.opponent(player), board):
                    return self.score(player, board), None
                return evaluate(player, board), None
            moves.sort(key = lambda x: self.SECOND_WEIGHTS[x], reverse=True)
            best=moves[0]
            for move in moves:
                if alpha >=beta:
                    break
                moved_board=self.make_move(move, player, copy.deepcopy(board))
                v = self.alphabeta(self.opponent(maxPlayer), player, moved_board, alpha, beta, depth-1, evaluate)[0]
                #bestVal = max(bestVal, v)
                if v > alpha:
                    best=move
                    alpha=v
            return alpha, best
        else:
            bestVal=self.MAX_VALUE
            moves=self.legal_moves(player, board)
            if not moves:
                if not self.any_legal_move(self.opponent(player), board):
                    return self.score(player, board), None
                return evaluate(player, board), None
            moves.sort(key = lambda x: self.SECOND_WEIGHTS[x], reverse=True)
            best=moves[0]
            for move in moves:
                if alpha >=beta:
                    break
                moved_board=self.make_move(move, player, copy.deepcopy(board))
                v = self.alphabeta(self.opponent(maxPlayer), player, moved_board, alpha, beta, depth-1, evaluate)[0]
                #bestVal = min(bestVal, v)
                if v < beta:
                    best=move
                    beta=v
            return beta, best

    def negamax_alphabeta(self, player, board, alpha, beta, depth, evaluate):
        if depth==0:
            return evaluate(player, board), None
        moves=self.legal_moves(player, board)
        moves.sort(key = lambda x: self.SQUARE_WEIGHTS[x], reverse=True)

        if not moves:
            if not self.any_legal_move(self.opponent(player), board):
                #return self.score(player, board), None
                return self.final_value(player, board), None
            return -self.negamax_alphabeta(self.opponent(player), board, -beta, -alpha, depth - 1, evaluate)[0], None
        best=moves[0]
        for move in moves:
            if alpha >= beta:
                break
            val = -self.negamax_alphabeta(self.opponent(player), board, -beta, -alpha, depth - 1, evaluate)[0]
            if val > alpha:
                alpha=val
                best=move
        return alpha, best

    def best_strategy(self, board, player, best_move, still_running):
        """
        :param board: a length 100 list representing the board state
        :param player: WHITE or BLACK
        :param best_move: shared multiprocessing.Value containing an int of
                the current best move
        :param still_running: shared multiprocessing.Value containing an int
                that is 0 iff the parent process intends to kill this process
        :return: best move as an int in [11,88] or possibly 0 for 'unknown'
        """
        depth=4
        evaluate = self.weighted_score
        global transpositionTable
        transpositionTable = dict()
        while still_running.value !=0:
            if(self.numDisks(board) <=10):
                """start game"""
                best_move.value=self.alphabeta(player, player, board, self.MIN_VALUE, self.MAX_VALUE, depth, self.heuristicEarly)[1]
            elif(self.numDisks(board) <= 58):
                """midgame"""
                best_move.value=self.alphabeta(player, player, board, self.MIN_VALUE, self.MAX_VALUE, depth, self.heuristicMid)[1]
            else:
                """lategame"""
                best_move.value=self.alphabeta(player, player, board, self.MIN_VALUE, self.MAX_VALUE, depth, self.heuristicLate)[1]
            #best_move.value=self.random(player, board)
            #best_move.value=self.minimax(player, board, depth, player, evaluate)
            #best_move.value=self.alphabeta(player, player, board, self.MIN_VALUE, self.MAX_VALUE, depth, evaluate)[1]
            #best_move.value=self.negamax_alphabeta(player, board, self.MIN_VALUE, self.MAX_VALUE, depth, evaluate)[1]
            depth+=1
        return best_move.value
