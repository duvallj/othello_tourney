
import random
import math
import time

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,S,E,W,NE,NW,SE,SW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__ (self, board, move, score = 0):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self,other):
        return self.score < other.score

class Strategy():

    def __init__(self):
        self.switch = {BLACK: WHITE, WHITE: BLACK}
        self.funct = {BLACK: max, WHITE: min}
        self.corners = {11: (S, E), 18: (S, W), 81: (N, E), 88: (N, W)}
        self.inner = {22: 11, 27: 18, 72: 82, 77: 88}

    def get_starting_board(self):
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        for x in range(90, -1, -10):
            board = board[0:x] + "\n" + board[x::]
        return board

    def find_match(self, board, player, direct, r):
        if board[r] == self.switch[player]:
            while board[r] == self.switch[player]:
                r += direct
            if board[r] == player:
                return True
        return False

    def make_move(self, board, player, move):
        board = str(board)
        board = board[0:move] + player + board[move + 1::]  # place

        for d in DIRECTIONS:
            r = move + d
            while board[r] == self.switch[player]:
                r += d
            if board[r] == player:
                r -= d
                while board[r] == self.switch[player]:
                    board = board[0:r] + player + board[r + 1::]
                    r -= d
        return (board)

    def get_valid_moves(self, board, player):
        moves = []
        for x in range(11,91):
            m = board[x]
            if m == ".":
                for d in DIRECTIONS:
                    if self.find_match(board, player, d, x + d):
                        moves.append(x)

        #return moves
        moves = list(set(moves))
        sect = set(moves).intersection(self.corners.keys())
        if len(sect) > 0:
            return list(sect)
        else:
            if board.count(EMPTY) > 15:  ### NEW   (CHECK how many spaces are empty)
                sect = list(set(moves).intersection(self.inner.keys()))
                if len(moves) > len(sect):
                    for x in sect:
                        if not self.inner[x] == player:
                            moves.remove(x)
            return (moves)

    def next_player(self, board, prev_player):
        if len(self.get_valid_moves(board, self.switch[prev_player])) > 0:
            return self.switch[prev_player]
        if len(self.get_valid_moves(board, prev_player)) > 0:
            return prev_player
        return None

    def score(self, board, player=None):
        """Compute player's score (number of player's pieces minus opponent's)."""
        cp = 70
        m = 150
        mx = 300
        st = 80
        if board.count(EMPTY) < 20:
            cp = 200
            m = 60
            mx = 125
            st = 170

        if player == None:
            # print("SCORE: " + str(board.count(BLACK) - board.count(WHITE)))
            return (board.count(BLACK) - board.count(WHITE))
        mat_sub = 0

        matrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1500, -300, 300, 300, 300, 300, -300, 1500, 0,
            0, -300, -750, -55, -55, -55, -55, -750, -300, 0,
            0, 300, -55, 10, -3, -3, 10, -55, 300, 0,
            0, 300, -55, -3, -3, -3, -3, -55, 300, 0,
            0, 300, -55, -3, -3, -3, -3, -55, 300, 0,
            0, 300, -55, 10, -3, -3, 10, -55, 300, 0,
            0, -300, -750, -55, -55, -55, -55, -750, -300, 0,
            0, 1500, -300, 300, 300, 300, 300, -300, 1500, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        '''
        matrix = [
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
            0, 750, -20,  50,  20,  20,  50, -20, 750,   0,
            0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
            0,  50,  -5,  15,   3,   3,  15,  -5,  50,   0,
            0,  20,  -5,   3,   3,   3,   3,  -5,  20,   0,
            0,  20,  -5,   3,   3,   3,   3,  -5,  20,   0,
            0,  50,  -5,  15,   3,   3,  15,  -5,  50,   0,
            0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
            0, 750, -20,  50,  20,  20,  50, -20, 750,   0,
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        ]'''
        '''edges = board[11:19] + board[11:99:10] + board[18:99:10] + board[81:89]
        check = board.count(EMPTY) < 25 or edges.count(player) > 13  ############################
        if check:  ###     NEW
            matrix = [
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 400, -150, 90, 90, 90, 90, -150, 400, 0,
                0, -150, -50, 10, 10, 10, 10, -50, -150, 0,
                0, 90, 10, 15, 5, 5, 15, 10, 90, 0,
                0, 90, 10, 5, 5, 5, 5, 10, 90, 0,
                0, 90, 10, 5, 5, 5, 5, 10, 90, 0,
                0, 90, 10, 15, 5, 5, 15, 10, 90, 0,
                0, -150, -50, 10, 10, 10, 10, -50, -150, 0,
                0, 400, -150, 90, 90, 90, 90, -150, 400, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            ]'''
        for c in self.corners.keys():
            if board[c] == player:
                sum = 0
                for d in self.corners[c]:
                    cur = c + d
                    sum += d
                    # while not cur in self.corners.keys():
                    matrix[cur] = 200
                    while not cur + d in self.corners.keys():
                        cur += d
                        matrix[cur] += 75

                matrix[c + sum] = 100
        blk_mat = 0
        whi_mat = 0

        #blk_stab = 0
        #whi_stab = 0

        '''for d in DIRECTIONS:
            if board[i+d] == EMPTY:
                whi_stab+=1
                break
            if i in inte[11:19] + inte[11:99:10] + inte[18:99:10] + inte[81:99]:
                whi_stab-=4
                break'''
        inte = list(range(0,100))
        for i in range(11,90):
            if board[i] == BLACK:
                blk_mat += matrix[i]
            elif board[i] == WHITE:
                whi_mat += matrix[i]

        if not blk_mat + whi_mat == 0:
            mat_sub = mx * ((blk_mat - whi_mat) / ((blk_mat + whi_mat) * 1.0))

        '''stability = 0
        if not blk_stab + whi_stab == 0:
            stability = st*((blk_stab - whi_stab)/((blk_stab + whi_stab)*1.0))'''

        coin_p = cp * ((board.count(BLACK) - board.count(WHITE)) / ((board.count(BLACK) + board.count(WHITE)) * 1.0))

        blk_move = len(self.get_valid_moves(board, BLACK))  ###     MOBILITY
        whi_move = len(self.get_valid_moves(board, WHITE))

        mobility = m * (blk_move - whi_move) / ((blk_move + whi_move) * 1.0)

        return mat_sub + mobility + coin_p #- stability

    def alphabeta(self, node, player, depth, alpha, beta):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if (depth == 0):
            node.score = self.score(board, player) + random.random()  # self.weight(board, player, node.move)
            return node

        children = []
        for m in self.get_valid_moves(board, player):
            nextBoard = self.make_move(board, player, m)
            nextPlayer = self.next_player(nextBoard, player)
            if (nextPlayer == None):
                c = Node(nextBoard, m, self.score(nextBoard, None) * 100000000)
                children.append(c)
            else:
                c = Node(nextBoard, m)
                c.score = self.alphabeta(c, nextPlayer, depth - 1, alpha, beta).score
                children.append(c)

            if (player == BLACK):
                alpha = max(alpha, c.score)
            else:
                beta = min(beta, c.score)
            if (alpha >= beta):
                break

        winner = best[player](children)
        node.score = winner.score
        return (winner)

    def ab_strategy(self, board, player, depth=3):
        beg = Node(board, 0)
        winner = self.alphabeta(beg, player, depth, -math.inf, math.inf)
        return winner.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        while (True):
            board = "".join(board)
            best_move.value = self.ab_strategy(board, player, depth)
            depth += 1
            print(depth)
    standard_strategy = ab_strategy