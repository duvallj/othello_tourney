from multiprocessing import Value
from copy import deepcopy
import time
import math
import random
#
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]
UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)

class Strategy():
  def squares(self):
        """List all the valid squares on the board."""
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]
  def initial_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [OUTER] * 100
        for i in self.squares():
            board[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        return board
  def print_board(self,board):
        """Get a string representation of the board."""
        rep = ''
        rep += '  %s\n' % ' '.join(map(str, list(range(1, 9))))
        for row in range(1, 9):
            begin, end = 10 * row + 1, 10 * row + 9
            rep += '%d %s\n' % (row, ' '.join(board[begin:end]))
        return rep
  def is_valid(self, move):
        """Is move a square on the board?"""
        x1 = int(move/10)
        y1 = int(move%10)
        return (1<=x1<=8) and (1<=y1<=8)
  def opponent(self, player):
        """Get player's opponent piece."""
        if player == WHITE:
          return BLACK
        if player == BLACK:
          return WHITE
  def find_bracket(self, square, player, board, direction):
        """
        Find a square that forms a bracket with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        Returns the index of the bracketing square if found
        """
        # move = square + direction
        # if board[move] == player:
        #   return None
        # while board[move] == (self.opponent(player) and self.is_valid(move)):
        #   move += direction
        # return move
        bracket = square + direction
        if board[bracket] == player:
            return None
        opp = self.opponent(player)
        while board[bracket] == opp:
            bracket += direction
        return None if board[bracket] in (OUTER, EMPTY) else bracket
  def is_legal(self, move, player, board):
      """Is this a legal move for the player?"""
      for direction in DIRECTIONS:
        current = move
        current = current + direction
        if self.is_valid(current) and board[current] == self.opponent(player):
          current = current + direction
          if not self.is_valid(current):
            continue
          while board[current] == self.opponent(player):
            current = current+ direction
            if not self.is_valid(current):
              break
          if not self.is_valid(current):
            continue
          if board[current] == player:
            if abs((move/10)-(current/10)) > 0 or abs((move%10) -(current%10)) > 0:
              return True
      return False
  def make_move(self, move, player, board):
        """Update the board to reflect the move by the specified player."""
        if not self.is_legal(move, player, board):
            raise self.IllegalMoveError(player, move, board)
            #print ("not")
        board[move] = player
        for d in DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board
  def make_flips(self, move, player, board, direction):
        """Flip pieces in the given direction as a result of the move by player."""
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction
  def legal_moves(self, player, board):
        """Get a list of all legal moves for player, as a list of integers"""
        legalmoves = []
        for i in range(0,100):
          if board[i] == EMPTY:
            if self.is_legal(i, player, board) ==  True:
              legalmoves.append(i)
        return legalmoves
  def next_player(self,board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.any_legal_move(self.opponent(prev_player), board):
          return self.opponent(prev_player)
        else:
          return None
  def any_legal_move(self, player, board):
        """Can player make any moves? Returns a boolean"""
        moves = self.legal_moves(player, board)
        if len(moves) == 0:
          return False
        return True
  def score(self,player, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        pscore = 0
        oscore = 0
        for i in range(0,100):
          if board[i] == player:
            pscore = pscore + 1
          if board[i] == self.opponent(player):
            oscore = oscore + 1
        return (pscore - oscore)
  def weightedScore(self, player, board):
      score = 0
      for i in self.squares():
        if board[i] == player:
          score += SQUARE_WEIGHTS[i]
        elif board[i] == self.opponent(player):
          score -= SQUARE_WEIGHTS[i]
      return score
  def heuristic(self, move, player, board):
        initalScore = self.weightedScore(player, board)
        newBoard = deepcopy(board)
        newBoard = self.make_move(move, player, newBoard)
        finalScore = self.weightedScore(player, newBoard)
        return (finalScore - initalScore)
  def myStrategy(self, board, player):
      moves = self.legal_moves(player, board)
      toReturn = moves[0]
      maxscore = 0
      for move1 in moves:
        if (self.heuristic(move1, player, board)>maxscore):
          maxscore = self.heuristic(move1, player, board)
          toReturn = move1
      return toReturn
      
  def minimax(self, board, depth,player, maximizingPlayer):
    if depth == 0 or not self.any_legal_move(player, board):
      return self.weightedScore(player, board)
    if maximizingPlayer:
      bestValue = float("-inf")
      for move in self.legal_moves(player, board):
        tempBoard = deepcopy(board)
        tempBoard = self.make_move(move, player, tempBoard)
        v = self.minimax(tempBoard, depth -1, self.opponent(player), False)
        bestValue = max(bestValue, v)
      return bestValue
    else:
      bestValue = float("inf")
      for move in self.legal_moves(player, board):
        tempBoard = deepcopy(board)
        tempBoard = self.make_move(move, player, tempBoard)
        v = self.minimax(tempBoard, depth-1, self.opponent(player),True)
        bestValue = min(bestValue, v)
      return bestValue
  def minimaxSearch(self, board, player, depth):
    bestMove = float("-inf")
    best = 0
    for move in self.legal_moves(player, board):
      tempBoard = deepcopy(board)
      tempBoard = self.make_move(move, player, tempBoard)
      v = self.minimax(tempBoard, depth, player, True)
      if (v > bestMove):
        bestMove = v
        best = move
    return best
  def best_strategy(self, board, player, best_move, still_running):
        """
        :param board: a length 100 list representing the board state
        :param player: WHITE or BLACK
        :param best_move: shared multiptocessing.Value containing an int of
                the current best move
        :param still_running: shared multiprocessing.Value containing an int
                that is 0 iff the parent process intends to kill this process
        :return: best move as an int in [11,88] or possibly 0 for 'unknown'
        """
        time.sleep(1)
        depth = 3
        if still_running.value:
          best_move.value = self.minimaxSearch(board, player, depth)
        afjalkfjalkfjl;ka
  class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)
            
##x = Strategy()
##initialBoard = x.initial_board()
##PLAYER1 = BLACK
##print (x.print_board(initialBoard))
##while (True):
##  myMove = x.minimaxSearch(initialBoard, PLAYER1, 2)
##  print (int(myMove/10), int(myMove%10))
##  initialBoard = x.make_move(myMove, PLAYER1, initialBoard)
##  yourMove = int(input("What move?"))
##  initialBoard = x.make_move(yourMove, x.opponent(PLAYER1), initialBoard)
##  print (x.print_board(initialBoard))

  
  
