"""
alpha-beta, use knowledge of what is above in the tree to cut out actual calculations of certain parts
upper and lower bound
For negamax upper bound is hard bound, lower bound changes
Score will be negative because perspective changes; if 42 is the current best, ignore anything from minimizer greater than -42
alpha = lower bound = improvable
beta = upper bound = hardBound
if using <=, start with -65 to 65
negamaxTerminal(brd, token, improvable, hardBound)
    if not lm:# we have to pass
        lm = legalMoves(brd, enemy)
        if not lm: return [score, -3] #end of game signifier
        nm = negamax(brd, enemy, -hardBound, - improvable) +[-1] #reflect across y axis, hardBound becomes improvable, improvable becomes hardBouund
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(brd, token, mv), enemy, -hardBound, newHB) + [mv]
        if not best or nm[0] < newHb: #if this is the first call or there is an improvement in score but negated
        best = nm
        if nm[0] < newHB:
            newHB = nm[0]
            if -newHB > hardBound: return [-best[0]] + best[1:] #stops and returns, pruning out branch
    return [-best[0] + best[1:]
""""""
lab 6  modification
Given board, token
    Show 2D board
    SHow possible moves
    print ("My heuristic ichoice is %s" % heuristicChoice(possibleMoves))
    def main():
        stuff to be done from command line
    if __name__ == "__main__":
        main()
    CHANGE FROM STATEGY
    if game.count(".")<= n: #n ~= 8
        run negamax with levels = -1
        will terminate once game ends #when game is close to end, check all possibilities with negamax instead of using heuristics
        print("negamax returns {} and I choose move {}")
        ASSIGNMENT: determine largest n such that negamax takes less then 5 seconds
        #increasing n should increase capture rate; maximize
        TO TURN IN:
        #show a graph of average capture rate vs n on one side of paper play 20 games for each n
        #code improvements for lab6 (grab corner, edges, etc)
"""
# Capture 75% of the tokens for an A
# Algorithm:
# 1: Move to corner if possible
# 2: If you can play a token along an edge so that your tokens connect along an edge all the way to a corner
# 3: Do not play in a c or x square if the corner is not protected
# 4: If one and two do not apply, do not play along an edge
# C-square: Squares along an edge next to a corner
# X-square: Squares not along an edge next to a corner
# A-square: Next to C squares along edge
# B-square: Next to A along edge
# use random.choice()
import sys, random, time
pmDict = {}
scoreDict = {}

def findAdjacent(position, max):
    ret = []
    rowLen = int(max ** .5)
    if (position + 1) < max and position // rowLen == (position + 1) // rowLen:  # right
        ret.append(position + 1)
    if (position - 1) >= 0 and position // rowLen == (position - 1) // rowLen:  # left
        ret.append(position - 1)
    if (position + rowLen) < max:  # below
        ret.append(position + rowLen)
    if position - rowLen >= 0:  # above
        ret.append(position - rowLen)
    if position + rowLen + 1 < max and abs(
            (position // rowLen) - ((position + rowLen + 1) // rowLen)) == 1:  # bottom right
        ret.append(position + rowLen + 1)
    if position + rowLen - 1 < max and abs(
            (position // rowLen) - ((position + rowLen - 1) // rowLen)) == 1:  # bottom left
        ret.append(position + rowLen - 1)
    if position - rowLen + 1 >= 0 and abs((position // rowLen) - ((position - rowLen + 1) // rowLen)) == 1:  # top right
        ret.append(position - rowLen + 1)
    if position - rowLen - 1 >= 0 and abs((position // rowLen) - ((position - rowLen - 1) // rowLen)) == 1:  # top left
        ret.append(position - rowLen - 1)
    return ret


def makeReadable(pzl):
    return "\n".join([pzl[8 * n:8 * n + 8] for n in range(8)])


def findMoves(board, turn, adj):
    if (board,turn) in pmDict:
        return pmDict[(board, turn)][0], pmDict[(board, turn)][1]
    max, rowLen = 64, 8
    ret = []
    opponentChar = ({"X", "O"} - {turn}).pop()
    possibleIndices = [i for i, v in enumerate(board) if v == "." and opponentChar in [board[k] for k in adj[i]]]
    swaps = {}
    for i in possibleIndices:
        currentAdjacent = [j for j in adj[i] if board[j] == opponentChar]
        for otherPiece in currentAdjacent:
            finalSpot = -1
            tempChar = i
            tryList = []
            hasPassed = False
            if i - otherPiece == 1:  # piece is to the left of the opponent, keep going left
                tempChar -= 1
                while tempChar >= 0 and (tempChar // rowLen == i // rowLen):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar -= 1
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            elif i - otherPiece == -1:  # piece is to the right of the opponent, keep right
                tempChar += 1
                while tempChar < max and (tempChar // rowLen == i // rowLen):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += 1
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        finalSpot = i
                        ret.append(i)
                        break
                    else:
                        break
            elif i - otherPiece == rowLen:  # piece is above of the opponent, go up
                tempChar -= rowLen
                while tempChar >= 0:
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar -= rowLen
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            elif i - otherPiece == -rowLen:  # piece is below the opponent, go down
                tempChar += rowLen
                while tempChar < max:
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += rowLen
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            elif i - otherPiece == rowLen - 1:  # piece is daig right and up
                tempChar += -rowLen + 1
                while tempChar >= 0 and (
                        (tempChar - rowLen + 1) // rowLen - tempChar // rowLen == -1 or board[tempChar] == "."):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += -rowLen + 1
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            elif i - otherPiece == -rowLen + 1:  # piece is diag left and down
                tempChar += rowLen - 1
                while tempChar < max and (
                        (tempChar + rowLen - 1) // rowLen - tempChar // rowLen == 1 or board[tempChar] == "."):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += rowLen - 1
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            elif i - otherPiece == (rowLen + 1):  # piece is diag left and up
                tempChar += -rowLen - 1
                while tempChar >= 0 and (
                        (tempChar - rowLen - 1) // rowLen - tempChar // rowLen == -1 or board[tempChar] == "."):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += -rowLen - 1
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            elif i - otherPiece == (-rowLen - 1):  # piece is diag right and down
                # print("here")
                tempChar += rowLen + 1
                while tempChar < max and (
                        (tempChar + rowLen + 1) // rowLen - tempChar // rowLen == 1 or board[tempChar] == "."):
                    # print(tempChar)
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += rowLen + 1
                        hasPassed = True
                    elif board[tempChar] == turn and hasPassed:
                        ret.append(i)
                        finalSpot = i
                        break
                    else:
                        break
            if finalSpot >= 0 and finalSpot in swaps.keys():
                swaps[finalSpot] += tryList
            elif finalSpot >= 0:
                swaps[finalSpot] = tryList
    pmDict[(board, turn)] = (list(set(ret)),swaps)
    return sorted(list(set(ret))), swaps


def negamax(board, token, levels, adjacent):  #will guarantee best result for given number of levels, recursive; lm list of possiblemoves
    lm, places = findMoves(board, token, adjacent)
    enemy = "XO".replace(token,"")
    if not levels or "." not in board:  # at end of evaluation
        return [len(lm) - len(findMoves(board,enemy,adjacent)[0])]  # evalBoard yourTokens-theirTokens
    if not lm:  # passing
        nm = negamax(board, enemy, levels - 1, adjacent) + [-1]  # -1 indicates a pass
        return [-nm[0]] + nm[1:]  # flips score and adds move
    nmList = sorted([negamax(makeMove(board, token, mv, places), enemy, levels - 1, adjacent) + [mv] for mv in lm])
    # returns[score, lastmove,secondtolastmove,etc..., first move] want the lowest score because negamax returns from enemy's POV
    best = nmList[0]
    return [-best[0]] + best[1:]
    #return nmList


def evalBoard(b, t):
    return b.count(t) - b.count("".join({"X", "O"} - {t}))


def bestMove(game, possibleMoves, places, turnChar, adj):
    edges = list({*range(0, 8), *range(0, 56, 8), *range(7, 63, 8), *range(56, 63)})
    notSafe = [9,14]
    weightMat = {}
    corners = {0, 7, 56, 63}
    opponentChar = "XO".replace(turnChar, "")
    finalMove = -1
    if len(possibleMoves) > 0:
        goodMoves = possibleMoves
        safeEdges = []
        edgeCanBeGood = False
        if [i for i in possibleMoves if i in corners]:  # corner
            finalMove = random.choice([i for i in possibleMoves if i in corners])
            safeEdges += [i for i in possibleMoves if i in corners]
        temp = []
        if [i for i in possibleMoves if i in edges]:
            edgeMoves = [i for i in possibleMoves if i in edges]
            for move in edgeMoves:
                for j in [0, 56]:  # go right from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    #print([v for v in list(places.values())])
                    while tempIndex // 8 == j // 8 and game[j] == turnChar and tempIndex < 64:
                        if game[tempIndex] == turnChar:
                            tempIndex += 1
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex += 1
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
                for j in [7, 63]:  # go left from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    while tempIndex // 8 == j // 8 and game[j] == turnChar and tempIndex >= 0:
                        if game[tempIndex] == turnChar:
                            tempIndex -= 1
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex -= 1
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
                for j in [0, 7]:  # go down from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    while tempIndex % 8 == j % 8 and tempIndex < 64 and game[j] == turnChar:
                        if game[tempIndex] == turnChar:
                            tempIndex += 8
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex += 8
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
                for j in [56, 63]:  # go up from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    while tempIndex % 8 == j % 8 and tempIndex >= 0 and game[j] == turnChar:
                        if game[tempIndex] == turnChar:
                            tempIndex -= 8
                            # print([j for j in i for i in list(places.values())])
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex -= 8
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
        if temp:
            goodMoves = temp
            safeEdges += temp
        for pos in corners:
            if game[pos] == turnChar:
                safeEdges += adj[pos]
            else:
                edges += adj[pos]
        goodMoves = [i for i in goodMoves if i not in edges or i in safeEdges]
        print(goodMoves)
        if goodMoves and finalMove < 0:
            finalMove = random.choice(goodMoves)
        elif finalMove < 0:
            finalMove = random.choice(possibleMoves)
    return finalMove


def makeMove(b, t, m, places):
    b = list(b)
    for spot in [*places[m],m]:
        b[spot] = t
    return "".join(b)

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        adj = {i: findAdjacent(i, 64) for i in range(64)}
        fixedBoard = "".join(board).replace("?", "").replace("@", "X").replace("o","O")
        token = "X" if player == "@" else "O"
        possiblemoves, places = findMoves(fixedBoard, token, adj)
        mv = -1
        mv = bestMove(fixedBoard, possiblemoves, places, token, adj)
        mv1 = 11 + (mv // 8) * 10 + mv % 8
        best_move.value = mv1
        if fixedBoard.count(".") <=14:
            mv = negamaxTerminal(fixedBoard, token, -65, 65, adj)[-1]
            mv1 = 11 + (mv // 8) * 10 + mv % 8
            best_move.value = mv1
        else:
            #nm = negamax(fixedBoard,token, 5, adj)
            nm = alphaBeta(fixedBoard,token,-65,65,adj,5)
            #print("NM: "+", ".join(str(i) for i in nm))
            mv1 = 11 + (nm[-1] // 8) * 10 + nm[-1] % 8
            best_move.value = mv1
            print("USED NEGAMAX VALUE!!!!!!!!!!!!!!!!!!")


def negamaxTerminal(brd, token, improvable, hardBound, adjacent):
    enemy = "XO".replace(token, "")
    lm, places = findMoves(brd, token, adjacent)

    if not lm:  #we have to pass
        lm, places = findMoves(brd, enemy, adjacent)
        if not lm:
            try:
                storedScore = scoreDict[(brd,token)]
                return [storedScore, -3]  #end of game signifier
            except KeyError:
                storedScore = evalBoard(brd,token)
                scoreDict[(brd,token)] = storedScore
                scoreDict[(brd,enemy)] = -storedScore
                return [storedScore, -3]
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable, adjacent) + [-1]  #reflect across y axis, hardBound becomes improvable, improvable becomes hardBouund
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    #print(lm)
    #print("Improve: %s  Hard %s"%(improvable, hardBound))
    for mv in sorted(lm, key=lambda x: places[x]):  #80 sec
        nm = negamaxTerminal(makeMove(brd, token, mv, places), enemy, -hardBound, newHB, adjacent) + [mv]
        #print("NM for %s, %s"%(mv,nm))
        if not best or nm[0] < newHB:  #if this is the first call or there is an improvement in score but negated
            best = nm
        if nm[0] < newHB:
            newHB = nm[0]
            if -newHB > hardBound: return [-best[0]] + best[1:]  #stops and returns, pruning out branch
    return [-best[0]] + best[1:]


def alphaBeta(brd, token, improvable, hardBound, adjacent,levels):
    enemy = "XO".replace(token, "")
    lm, places = findMoves(brd, token, adjacent)
    if not levels or "." not in brd:  # at end of evaluation
        return [len(lm) - len(findMoves(brd,enemy,adjacent)[0])]
    if not lm:  #we have to pass
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable, adjacent) + [-1]  #reflect across y axis, hardBound becomes improvable, improvable becomes hardBouund
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    #print(lm)
    #print("Improve: %s  Hard %s"%(improvable, hardBound))
    for mv in lm:  #80 sec
        nm = alphaBeta(makeMove(brd, token, mv, places), enemy, -hardBound, newHB, adjacent,levels-1) + [mv]
        #print("NM for %s, %s"%(mv,nm))
        if not best or nm[0] < newHB:  #if this is the first call or there is an improvement in score but negated
            best = nm
        if nm[0] < newHB:
            newHB = nm[0]
            if -newHB > hardBound: return [-best[0]] + best[1:]  #stops and returns, pruning out branch
    return [-best[0]] + best[1:]

def main():
    start = time.time()
    game = "...........................OX......XO..........................."
    turnChar = ""
    adj = {i: findAdjacent(i, len(game)) for i in range(64)}
    if len(sys.argv) > 1:
        if len(sys.argv[1]) >= 64:
            game = "".join(i.upper() for i in sys.argv[1] if i in "xoXO.")
        elif not sys.argv[1].isdigit():
            turnChar = sys.argv[1].upper()
    if len(sys.argv) > 2 and sys.argv[2] in ("x", "o", "X", "O"):
        turnChar = sys.argv[2].upper()
    if not turnChar:
        turnChar = "X" if not game.count(".") % 2 else "O"
    #game,turnChar = ".............O......OOX....OXOO....XXXO.........................", "X"
    possiblemoves, places = findMoves(game, turnChar, adj)
    pmDict[(game,turnChar)] = (possiblemoves, places)
    n = 10
    #print(game.count("."))
    print(makeReadable(game))
    print("Possible  moves: " + " ".join(str(i) for i in (possiblemoves)))
    move = bestMove(game, possiblemoves, places, turnChar, adj)
    print("My heuristic choice is %d" % move)
    if game.count(".") <= n:
        start = time.time()
        print("Negamax: ", end="")
        print(negamaxTerminal(game, turnChar, -65, 65, adj))
       #print("Time elapsed: %f" % (time.time()-start))
    else:
        nmMove = negamax(game,turnChar,3,adj)
        print(nmMove)
    #print(score)


if __name__ == "__main__":
    main()
"""
listOfTests = [
  ["OOOOOXXXOXOOOOXOOOOXOXX.OOXXXXXOOOXXXXXO.OXXXOXOOOXXOXOOOXXOOOOO x", 2,  {23}],
  ["XXX.OXXX.XXXXXXXXXXXXOXXXXXXOXOXXXXOXOXXXXOXOXXX.XXOXXXXOXXXXXXX o", -6, {3}],
  ["...oooooox.xoooooxxxxooooxoxxxoooxxxxooooxxoxooooxxxxxoooooooooo O", 42, {1}],
  ["oooooo..xoxxoo..xxooooxxxxxoooxxxxoxooxxxxxoxoox.xxxxxxxxxxxxxxx o", 0, {48}],
  ["O.X.O.XOXO..O.OXXOOOOOXXXOXOOXXXXOOXXXXXXOOXXXXXXXXXXXXXXXXXXXXX x", 50, {5}],
  ["XXXXXXXOXXXXXXXOXXXXXXXOXXOXXX.OXOXOOO..XOOXO...XXXXXXX.XXXXXXXX X", 47, {30}],
  ["....OOOOO...XXOOOOXXX.OOOXOXXOOOOOOOXOOOOOOOXXOOOOOOOOXOOOOOOOOO O", 60, {21, 9}],           # 21, 11, 9 ...
]

listOfTests = [
  ["OOOOOOOOO.XXXXO.OOXXXXX.OOXXXXO.OOXXXXXXOOOOOX..XXXXOOO.XXXXXXX. x", 0,  {9}],                     # 8 free
  ["OX.O.XX.OXXXXXXOOOXOOOOXOOXXOOX.OOOXOXXOO.OOOXXX.OOOOOXXXOO.OX.. o", 14, {7}],                     # 9 free
  ["X.OXXX..X.OOXXX.XOOXOXOOXXOOXOOOXXOXOXOOXOXOOXOOOOOOOO....OOOOO. X", 4,  {9}],                     # 10 free
  ["...OOOOO..XXXXXO.XOOOOXOXOOOOOXOXOOOXOXOXOOXOXOO..OOOOXO..OOOO.X O", 7,  {62}],                    # 11 free
  ["..XXXXXX.OOXXOOXXXOXOOOX..OOOXOX..OOOXOX.OOOXOOXOOOXXOOX..OXXO.. x", 26, {8, 25, 40, 57, 62}],     # 12 free
  ["XXXXOOOOOXXXOXO.OXXOOXOXOXXXOX.XOOXXX..XOOOXXX..OOOOOX..OOO..... o", -6, {46, 30}],                # 13 free
  ["XXXXXXXXXXXXOXXXXXXOXOXXXXOXOOOXXXOOOO.XXXOO.O.XXXO..O..X....... x", 61, {58}],                    # 14 free
#  [".........O.X...O.OOXXOOOXXXOXXXOXXXOOXXOXXXXXOXOXXXXXOOOXXXXXXXO X", 16, {12, 13}],                # 14 free
]
"""

