import random
#Nira Nair
import sys
import time
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        board = ''.join(board).replace('?','').replace('@','X').replace('o','O')
        myChar = "X" if player == '@' else 'O'
        if myChar == "X":
            oppChar = "O"
        else:
            oppChar = "X"
        mv = findBestMove(board,myChar)
        mv1 = 11 + (mv//8) * 10 + (mv % 8)
        best_move.value = mv1


def display(board):
    for x in range(0,64,8):
        print(board[x:x+8])

def main(board, myChar):
    if myChar == "X":
        oppChar = "O"
    else:
        oppChar = "X"
    return findBestMove(board, myChar)

surroundingPos = {}
for x in range(64):
    surroundingPos[x] = [x-9,x+9,x-1,x+1,x-8,x+8,x-7,x+7]
for x in range(8):
    surroundingPos[x] = [x+1,x-1,x+7,x+8,x+9]
for x in range(0,57,8):
    surroundingPos[x] = [x-8,x+8,x-7,x+9,x+1]
for x in range(7,64,8):
    surroundingPos[x] = [x-8,x-9,x+8,x+7,x-1]
for x in range(56,64,1):
    surroundingPos[x] = [x-8,x+1,x-1,x-9,x-7]
surroundingPos[0] = [1,9,8]
surroundingPos[7] = [6,14,15]
surroundingPos[56] = [48,49,57]
surroundingPos[63] = [55,54,62]
vertical = []
for x in range(8):
    l = []
    for y in range(8):
        l.append(x+(y*8))
    vertical.append(l)

horizontal = []
for x in range(0,57,8):
    l = []
    for y in range(8):
        l.append(x+y)
    horizontal.append(l)

diagonal1 = [[56],[48,57],[40,49,58],[32,41,50,59],[24,33,42,51,60],[16,25,34,43,52,61],[8,17,26,35,44,53,62],[0,9,18,27,36,45,54,63],[1,10,19,28,37,46,55],[2,11,20,29,38,47],[3,12,21,30,39],[4,13,22,31],[5,14,23],[6,15],[7]]
diagonal2 = [[0],[1,8],[2,9,16],[3,10,17,24],[4,11,18,25,32],[5,12,19,26,33,40],[6,13,20,27,34,41,48],[7,14,21,28,35,42,49,56],[15,22,29,36,43,50,57],[23,30,37,44,51,58],[31,38,45,52,59],[39,46,53,60],[47,54,61],[55,62],[63]]

def possibleMoves(board,myChar):
    if myChar == "X":
        oppChar = "O"
    else:
        oppChar = "X"
    possibleMoves = {}
    posOfMyChar = []
    intermed = []
    for x in range(len(board)):
        if board[x] == myChar:
            posOfMyChar.append(x)
    for myPos in posOfMyChar:
        vert = vertical[myPos%8]
        pos = vert.index(myPos)
        vert1 = vert[:pos]
        vert1 = vert1[::-1]
        vert2 = vert[pos+1:]
        count = 0
        if len(vert1) > count:
            nex = board[vert1[count]]
        else:
            nex = ""
        intermed = []
        while nex == oppChar:
            intermed.append(vert1[count])
            count+=1
            if len(vert1) > count:
                nex = board[vert1[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if vert1[count] not in possibleMoves:
                    possibleMoves[vert1[count]] = intermed
                else:
                    possibleMoves[vert1[count]] = possibleMoves[vert1[count]] + intermed
        intermed = []
        count = 0
        if len(vert2) > count:
            nex = board[vert2[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(vert2[count])
            count+=1
            if len(vert2) > count:
                nex = board[vert2[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if vert2[count] not in possibleMoves:
                    possibleMoves[vert2[count]] = intermed
                else:
                    possibleMoves[vert2[count]] = possibleMoves[vert2[count]] + intermed
        intermed = []

    for myPos in posOfMyChar:
        hor = horizontal[myPos//8]
        pos = hor.index(myPos)
        hor1 = hor[:pos]
        hor1 = hor1[::-1]
        hor2 = hor[pos+1:]
        count = 0
        if len(hor1) > count:
            nex = board[hor1[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(hor1[count])
            count+=1
            if len(hor1) > count:
                nex = board[hor1[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if hor1[count] not in possibleMoves:
                    possibleMoves[hor1[count]] = intermed
                else:
                    possibleMoves[hor1[count]] = possibleMoves[hor1[count]] + intermed
        intermed = []

        count = 0
        if len(hor2) > count:
            nex = board[hor2[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(hor2[count])
            count+=1
            if len(hor2) > count:
                # print(hor2[count])
                nex = board[hor2[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if hor2[count] not in possibleMoves:
                    possibleMoves[hor2[count]] = intermed
                else:
                    possibleMoves[hor2[count]] = possibleMoves[hor2[count]] + intermed
        intermed = []


    for myPos in posOfMyChar:
        for x in range(len(diagonal1)):
            tempL = diagonal1[x]
            for y in tempL:
                if y == myPos:
                    diag = tempL
        pos = diag.index(myPos)
        d1 = diag[:pos]
        d1 = d1[::-1]
        d2 = diag[pos+1:]
        count = 0
        if len(d1) > count:
            nex = board[d1[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(d1[count])
            count+=1
            if len(d1) > count:
                nex = board[d1[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if d1[count] not in possibleMoves:
                    possibleMoves[d1[count]] = intermed
                else:
                    possibleMoves[d1[count]] = possibleMoves[d1[count]] + intermed
        intermed = []
        count = 0
        if len(d2) > count:
            nex = board[d2[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(d2[count])
            count+=1
            if len(d2) > count:
                nex = board[d2[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if d2[count] not in possibleMoves:
                    possibleMoves[d2[count]] = intermed
                else:
                    possibleMoves[d2[count]] = possibleMoves[d2[count]] + intermed
        intermed = []
        for x in range(len(diagonal2)):
            tempL = diagonal2[x]
            for y in tempL:
                if y == myPos:
                    diag = tempL
        pos = diag.index(myPos)
        d1 = diag[:pos]
        d1 = d1[::-1]
        d2 = diag[pos+1:]
        count = 0
        if len(d1) > count:
            nex = board[d1[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(d1[count])
            count+=1
            if len(d1) > count:
                nex = board[d1[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if d1[count] not in possibleMoves:
                    possibleMoves[d1[count]] = intermed
                else:
                    possibleMoves[d1[count]] = possibleMoves[d1[count]] + intermed
        intermed = []
        count = 0
        if len(d2) > count:
            nex = board[d2[count]]
        else:
            nex = ""
        while nex == oppChar:
            intermed.append(d2[count])
            count+=1
            if len(d2) > count:
                nex = board[d2[count]]
            else:
                nex = ""
        if count>=1:
            if nex == ".":
                if d2[count] not in possibleMoves:
                    possibleMoves[d2[count]] = intermed
                else:
                    possibleMoves[d2[count]] = possibleMoves[d2[count]] + intermed
        intermed = []
    return possibleMoves #returns dictionary
def legalMoves(board, myChar): #returns list
    if myChar == "X":
        oppChar = "O"
    else:
        oppChar = "X"
    if len(board) == 64:
        possibleMoves = []
        posOfMyChar = []
        for x in range(len(board)):
            if board[x] == myChar:
                posOfMyChar.append(x)
        for myPos in posOfMyChar:
            vert = vertical[myPos%8]
            pos = vert.index(myPos)
            vert1 = vert[:pos]
            vert1 = vert1[::-1]
            vert2 = vert[pos+1:]
            count = 0
            if len(vert1) > count:
                nex = board[vert1[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(vert1) > count:
                    nex = board[vert1[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(vert1[count])
            count = 0
            if len(vert2) > count:
                nex = board[vert2[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(vert2) > count:
                    nex = board[vert2[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(vert2[count])
        for myPos in posOfMyChar:
            hor = horizontal[myPos//8]
            pos = hor.index(myPos)
            hor1 = hor[:pos]
            hor1 = hor1[::-1]
            hor2 = hor[pos+1:]
            count = 0
            if len(hor1) > count:
                nex = board[hor1[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(hor1) > count:
                    nex = board[hor1[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(hor1[count])
            count = 0
            if len(hor2) > count:
                nex = board[hor2[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(hor2) > count:
                    nex = board[hor2[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(hor2[count])
        for myPos in posOfMyChar:
            for x in range(len(diagonal1)):
                tempL = diagonal1[x]
                for y in tempL:
                    if y == myPos:
                        diag = tempL
            pos = diag.index(myPos)
            d1 = diag[:pos]
            d1 = d1[::-1]
            d2 = diag[pos+1:]
            count = 0
            if len(d1) > count:
                nex = board[d1[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(d1) > count:
                    nex = board[d1[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(d1[count])
            count = 0
            if len(d2) > count:
                nex = board[d2[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(d2) > count:
                    nex = board[d2[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(d2[count])
            for x in range(len(diagonal2)):
                tempL = diagonal2[x]
                for y in tempL:
                    if y == myPos:
                        diag = tempL
            pos = diag.index(myPos)
            d1 = diag[:pos]
            d1 = d1[::-1]
            d2 = diag[pos+1:]
            count = 0
            if len(d1) > count:
                nex = board[d1[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(d1) > count:
                    nex = board[d1[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(d1[count])
            count = 0
            if len(d2) > count:
                nex = board[d2[count]]
            else:
                nex = ""
            while nex == oppChar:
                count+=1
                if len(d2) > count:
                    nex = board[d2[count]]
                else:
                    nex = ""
            if count>=1:
                if nex == ".":
                    possibleMoves.append(d2[count])
        return possibleMoves

    else:
        print(set([]))

def flip(board, myChar,position):
    x = position
    pM = possibleMoves(board,myChar)
    if x in pM:
        board = list(board)
        l = pM[x]
        for y in l:
            board[y] = myChar
        board[x] = myChar
        board = ''.join(board)
    return board

def evalBoard(board,myChar,oppChar):
    return board.count(myChar) - board.count(oppChar)

start_time = time.time()
def negamax(board,myChar,levels):
    if myChar == "X":
        oppChar = "O"
    else:
        oppChar = "X"
    if "." not in board or (legalMoves(board, myChar) == [] and legalMoves(board, oppChar) == []):
        return [evalBoard(board,myChar,oppChar)]
    lm = legalMoves(board,myChar)
    if not lm:
        best = negamax(board,oppChar,levels-1) + [-1]
    else:
        best = sorted([negamax(flip(board,myChar,move), \
                            oppChar,levels-1) + [move] for move in lm])[0]
    return [-best[0]] + best[1:]

def findBestMove(board,myChar):
    countSpaces = 0
    for x in range(len(board)):
        if board[x] == ".":
            countSpaces +=1
    indCorner = [0,7,56,63]
    if countSpaces > 5:
        possibleMoves = list(set(legalMoves(board,myChar)))
        ogPossibleMoves = possibleMoves[:]
        indCorner = [0,7,56,63]
        #check if corner:
        move = []
        for m in possibleMoves:
            if m in indCorner:
                move = m
                print("from heuristic I choose {}".format(move))
                return move
                break
        #safe edge move
        edgesTop = {0:[6,5,4,3,2], 7:[1,2,3,4,5,6]}
        edgesLeft = {0: [48,40,32,24,16,8], 56:[8,16,24,32,40,48]}
        edgesRight = {7:[55,47,39,31,23,15], 63:[15,23,31,39,47,55]}
        edgesBottom = {56:[61,62,60,59,58,57], 63: [57,58,59,60,61,62]}
        for x in indCorner:
            if board[x] == myChar:
                if x in edgesTop:
                    top = []
                    for pM in possibleMoves:
                        if pM in edgesTop[x]:
                            ind = edgesTop[x].index(pM)
                            b = True
                            for z in range(ind+1,len(edgesTop[x])):
                                if z != myChar:
                                    b = False
                            if b == True:
                                move = pM
                                top.append(pM)
                            if top != []:
                                temp = random.choice(list(top))
                                print("from heuristic I chose {}".format(temp))
                                return temp
                                break
                if x in edgesLeft:
                    for pM in possibleMoves:
                        if pM in edgesLeft[x]:
                            ind = edgesLeft[x].index(pM)
                            b = True
                            for z in range(ind+1,len(edgesLeft[x])):
                                if z != myChar:
                                    b = False
                            if b == True:
                                move = pM
                                print("from heuristic I chose {}".format(move))
                                return pM
                                break
                if x in edgesRight:
                        for pM in possibleMoves:
                            if pM in edgesRight[x]:
                                ind = edgesRight[x].index(pM)
                                b = True
                                for z in range(ind+1,len(edgesRight[x])):
                                    if z != myChar:
                                        b = False
                                if b == True:
                                    move = pM
                                    print("from heuristic I chose {}".format(move))
                                    return pM
                                    break
                if x in edgesBottom:
                        for pM in possibleMoves:
                            if pM in edgesBottom[x]:
                                ind = edgesBottom[x].index(pM)
                                b = True
                                for z in range(ind+1,len(edgesBottom[x])):
                                    if z != myChar:
                                        b = False
                                if b == True:
                                    move = pM
                                    print("from heuristic I chose {}".format(move))
                                    return move
                                    #return pM
                                    break
        #if corner not protected no c or x
        d = {0:[1,8,9], 7:[6,14,15], 56:[48,49,47], 63:[55,54,62]}
        for key in d:
            if board[key] != myChar:
                for v in d[key]:
                    if v in possibleMoves:
                        if len(possibleMoves) > 2:
                            possibleMoves.remove(v)
        edges = [1,2,3,4,5,6,8,16,24,32,40,48,57,58,59,60,61,62,15,23,31,39,47,55]
        if possibleMoves != []:
            print("from heuristic I choose {}".format(random.sample(list(possibleMoves),1)))
            return (random.choice(list(possibleMoves)))
        else:
            print("from heuristic I choose {}".format(random.sample(list(possibleMoves),1)))
            return (random.choice(list(ogPossibleMoves)))

    else:
        levels = 8
        nm = negamax(board,myChar,levels)
        print("negamax score {} and move from {}".format(nm[0],nm[1:]))
        return nm[-1]



if len(sys.argv) == 3:
    b = sys.argv[1]
    # print(b)
    board = b.upper()
    myChar = sys.argv[2].upper()
elif len(sys.argv) == 2:
    temp = sys.argv[1].upper()
    if len(temp) == 1:
        myChar = temp
        board = "...........................OX......XO..........................."
        # print(board)
    else:
        board = temp
        if len([i for i, letter in enumerate(board) if letter == "."]) %2 == 0:
            myChar = "X"
        else:
            myChar = "O"
        # print(sys.argv[1])
else:
    board = "...........................OX......XO..........................." #delete later
    if len([i for i, letter in enumerate(board) if letter == "."]) %2 == 0:
        myChar = "X"
    else:
        myChar = "O"
    # print(board)
if myChar == "X":
    oppChar = "O"
else:
    oppChar = "X"

if __name__ == "__main__":
    main(board, myChar)
