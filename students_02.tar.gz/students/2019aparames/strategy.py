import sys, random, time
from copy import copy, deepcopy
def flip(x1,y1,x2, y2, move, nd):
    #if x2*8 + y2 == 19:
    #    import pdb; pdb.set_trace()
    cx = x2-x1
    cy = y2-y1
    if cx == 0 and cy>0:
        for i in range(0, cy):
            nd[x1][y1+i] = move
        return nd
    if cy == 0 and cx>0:
        for i in range(0, cx):
            nd[x1+i][y1] = move
        return nd
    if cx == 0 and cy<0:
        cy = abs(cy)
        for i in range(0, cy):
            nd[x1][y1-i] = move
        return nd
        cy = y2-y1
    if cy == 0 and cx<0:
        cx = abs(cx)
        for i in range(0, cx):
            nd[x1-i][y1] = move
        return nd
        cx = x2-x1
    if cx>0 and cy>0:
        count = 0
        for i in range(0, cx):
            nd[x1+i][y1+count]= move
            count = count+1
        return nd
    if cy<0 and cx<0:
        count = 0
        cy = abs(cy)
        for i in range(0, cy):
            nd[x1-count][y1-i]= move
            count = count+1
        return nd
        cy = y2-y1
    if cx>0 and cy<0:
        count = 0
        for i in range(0, cx):
            nd[x1+i][y1+count]= move
            count = count-1
        return nd
    if cy>0 and cx<0:
        count = 0
        for i in range(0, cy):
            nd[x1+count][y1+i]= move
            count = count-1
        return nd
def Flip(move, pesto, op, aft):
    change = False
    y = int(pesto % 8)
    x = int(pesto/8)
    for a in range(0, 8):
        for b in range(0, 8):
            if aft[a][b] == move:
                v1 = up(a,b,op,aft)
                if v1 is not False:
                    if aft[v1[0]][v1[1]] is ".":
                        if v1[0] == x and v1[1] == y:
                            #print('Up')
                            #mport pdb; pdb.set_trace()
                            aft = flip(a,b,v1[0],v1[1], move, deepcopy(aft))
                            #Display(aft)
                            #print('Up')
                v2 = upLeft(a,b,op,aft)
                if v2 is not False:
                    if aft[v2[0]][v2[1]] is ".":
                        if v2[0] == x and v2[1] == y:
                            #print('UL')
                            aft = flip(a,b,v2[0],v2[1], move, deepcopy(aft))
                            #Display(aft)
                            #print('UpLeft')
                v3 = upRight(a,b,op,aft)
                if v3 is not False:
                    if aft[v3[0]][v3[1]] is ".":
                        if v3[0] == x and v3[1] == y:
                            #print('Ur')
                            aft = flip(a,b,v3[0],v3[1], move, deepcopy(aft))
                            #Display(aft)
                            #print('UpRight')
                        #print(a,b)
                v4 = left(a,b,op,aft)
                if v4 is not False:
                    if aft[v4[0]][v4[1]] is ".":
                    #    print('l')
                        if v4[0] == x and v4[1] == y:
                            aft = flip(a,b,v4[0],v4[1], move, deepcopy(aft))
                            #Display(aft)
                            #print('left')
                v5 = right(a,b,op,aft)
                if v5 is not False:
                    if aft[v5[0]][v5[1]] is ".":
                    #    print('r')
                        if v5[0] == x and v5[1] == y:
                            aft = flip(a,b,v5[0],v5[1], move, deepcopy(aft))
                            #print('Right')
                            #Display(aft)
                        #print(a,b)
                v6 = down(a,b,op,aft)
                if v6 is not False:
                    if aft[v6[0]][v6[1]] is ".":
                        #print('d')
                        if v6[0] == x and v6[1] == y:
                            aft = flip(a,b,v6[0],v6[1], move, deepcopy(aft))
                            #print('down')
                            #Display(aft)
                v7 = downLeft(a,b,op,aft)
                if v7 is not False:
                    if aft[v7[0]][v7[1]] is ".":
                        #print('dl')
                        if v7[0] == x and v7[1] == y:
                            aft = flip(a,b,v7[0],v7[1], move, deepcopy(aft))
                            #Display(aft)
                            #print('dl')
                v8 = downRight(a,b,op,aft)
                if v8 is not False:
                    if aft[v8[0]][v8[1]] is ".":
                        #print('dr')
                        if v8[0] == x and v8[1] == y:
                            aft = flip(a,b,v8[0],v8[1], move, deepcopy(aft))
                            #Display(aft)
                            #print('dr')
    #    import pdb; pdb.set_trace()
    aft [x][y] = move
    return aft
def toString(b):
    xc = 0
    yc = 0
    s= ""
    for i in range(0, 8):
        for a in range(0, 8):
            if b[i][a] == "x":
                xc = xc+1
            if b[i][a] == 'o':
                yc = yc+1
            s = s+ b[i][a]
    print(s)
    print("X:",xc)
    print("O:",yc)
    return s
def string(b):
    s = ""
    for i in range(0, 8):
        for a in range(0, 8):
            s = s+ b[i][a]
    return s
def score(b, move):
    temp1 = b[:]
    temp2 = b[:]
    if move == 'x':
        if(temp1.count('x') -  temp1.count('o'))>1:
            return 1
        if(temp1.count('x') -  temp1.count('o'))<1:
            return -1
        else:
            return 0
    else:
        if(temp1.count('o') -  temp1.count('x'))>1:
            return 1
        if(temp1.count('o') -  temp1.count('x'))<1:
            return -1
        else:
            return 0
def pMoves(move, op, nd):
    moves = set()
    for a in range(0, 8):
        for b in range(0, 8):
            if nd[a][b] == move:
                v1 = up(a,b,op,nd)
                if v1 is not False:
                    if nd[v1[0]][v1[1]] is ".":
                        moves.add(v1[0]*8 + v1[1])
                        #print(v1)
                        #print('Up')
                v2 = upLeft(a,b,op,nd)
                if v2 is not False:
                    if nd[v2[0]][v2[1]] is ".":
                        moves.add(v2[0]*8 + v2[1])
                        #print(v2)
                        #print('UpLeft')
                v3 = upRight(a,b,op,nd)
                if v3 is not False:
                    if nd[v3[0]][v3[1]] is ".":
                        moves.add(v3[0]*8 + v3[1])
                        #print(v3)
                        #print('UpRight')
                        #print(a,b)
                v4 = left(a,b,op,nd)
                if v4 is not False:
                    if nd[v4[0]][v4[1]] is ".":
                        moves.add(v4[0]*8 + v4[1])
                        #print(v4)
                        #print('left')
                v5 = right(a,b,op,nd)
                if v5 is not False:
                    if nd[v5[0]][v5[1]] is ".":
                        moves.add(v5[0]*8 + v5[1])
                        #print(v5)
                        #print('Right')
                        #print(a,b)
                v6 = down(a,b,op,nd)
                if v6 is not False:
                    if nd[v6[0]][v6[1]] is ".":
                        moves.add(v6[0]*8 + v6[1])
                        #print(v6)
                        #print('down')
                v7 = downLeft(a,b,op,nd)
                if v7 is not False:
                    if nd[v7[0]][v7[1]] is ".":
                        moves.add(v7[0]*8 + v7[1])
                        #print(v7)
                        #print('dleft')
                v8 = downRight(a,b,op,nd)
                if v8 is not False:
                    if nd[v8[0]][v8[1]] is ".":
                        moves.add(v8[0]*8 + v8[1])
                        #print(v8)
    return moves
def length(x1,y1, x2, y2):
    cx = x2-x1
    cy = y2-y1
    if cx == 0:
        return abs(cy)
    if cy == 0:
        return abs(cx)
    return abs(cx)
def left(x,y,move,pzl):
    #import pdb; pdb.set_trace()
    temp = move
    if y is 0:
        return False
    elif y>0:
        if pzl[x][y-1] != temp:
            return False
        else:
            y = y-2
            while y>= 1 and pzl[x][y] == temp:
                y = y-1
            if y>-1:
                return x,y
    return False
def upLeft(x,y,move,pzl):
    temp = move
    if y is 0 or x is 0:
        return False
    elif y>0 and x>0:
        if pzl[x-1][y-1] != temp:
            return False
        else:
            y = y-2
            x = x-2
            while x>=1 and y>=1 and pzl[x][y] == temp:
                y = y-1
                x = x-1
            if x>-1 and y>-1:
                return x,y
    return False
def downLeft(x,y,move,pzl):
    temp = move
    if y is 0 or x is 7:
        return False
    elif y>0 and x<6:
        if pzl[x+1][y-1] != temp:
            return False
        else:
            y = y-2
            x = x+2
            while x<=6 and y>=1 and pzl[x][y] == temp:
                y = y-1
                x = x+1
            if x<8 and y>-1:
                return x,y
    return False
def up(x,y,move,pzl):
    temp = move
    if x is 0:
        return False
    elif x>0:
        if pzl[x-1][y] != temp:
            return False
        else:
            x = x-2
            while x>=1 and pzl[x][y] == temp:
                x = x-1
            if x>=0:
                return x,y
    return False
def down(x,y,move,pzl):
    temp = move
    if x is 7:
        return False
    elif x<7:
        if pzl[x+1][y] != temp:
            return False
        else:
            x = x+2
            while x<=6 and pzl[x][y] == temp:
                x = x+1
            if x<8:
                return x,y
    return False
def right(x,y,move,pzl):
    temp = move
    if y is 7:
        return False
    elif y<7:
        if pzl[x][y+1] != temp:
            return False
        else:
            y = y+2
            while y<=6 and pzl[x][y] == temp:
                y = y+1
            if y<8:
                return x,y
    return False
def upRight(x,y,move,pzl):
    temp = move
    if y is 7 or x is 0:
        return False
    elif x>0 and y<7:
        #import pdb; pdb.set_trace()
        if pzl[x-1][y+1] != temp:
            return False
        else:
            y = y+2
            x = x-2
            while x>=1 and y<=6 and pzl[x][y] == temp:
                y = y+1
                x = x-1
            if y<8 and x>-1:
                return x,y
    return False
def downRight(x,y,move,pzl):
    temp = move
    if y is 7 or x is 7:
        return False
    elif y<7 and x<7:
        if pzl[x+1][y+1] != temp:
            return False
        else:
            y = y+2
            x = x+2
            while x<=6 and y<=6 and pzl[x][y] == temp:
                y = y+1
                x = x+1
            if x<8 and y<8:
                return x,y
    return False
def Display(board):
    for a in range(0, 8):
        s = ""
        for b in range(0, 8):
            s = s + board[a][b] + " "
            if b is 7:
                print(s)
def negamax(board, move, op, level, beta, alpha):
    if level == 0:
        return [score(string(deepcopy(board)), move)]
    if len(pMoves(move, op, deepcopy(board)))==0 and len(pMoves(op, move, deepcopy(board))) == 0:
        return [score(string(board), move)]
    temp = pMoves(move, op, deepcopy(board))
    if not temp:
        val = negamax(deepcopy(board), op, move, level-1, -alpha, -beta) + [-1]
        return [-val[0]] + val[1:]
    best  = []
    nAlpha = -beta
    actBoard = deepcopy(board)
    for i in temp:
        nBoard = Flip(move, i, op, deepcopy(board))
        tempval = negamax(deepcopy(nBoard), op, move, level-1, -alpha, nAlpha) + [i]
        if not best or tempval[0]<nAlpha:
            best = tempval
            if tempval[0]< nAlpha:
                nAlpha = tempval[0]
                if -nAlpha >= alpha:
                    return [-best[0]] + best[1:]
        board = actBoard
    return [-best[0]] + best[1:]
def bestMove(board, op, move):
    #print(op)
    #print(pesto)
    cornerMoves = set()
    otherMoves = set()
    for a in range(0, 8):
        for b in range(0, 8):
            if board[a][b] == move:
                v1 = up(a,b,op,board)
                if v1 is not False:
                    if board[v1[0]][v1[1]] is ".":
                        if (v1[0] is 0 and v1[1] is 7) or (v1[0] is 7 and v1[1] is 0) or (v1[0] is 0 and v1[1] is 0) or (v1[0] is 7 and v1[1] is 7):
                            cornerMoves.add((a,b,v1[0],v1[1]))
                        else:
                            otherMoves.add((a,b,v1[0],v1[1]))
                v2 = upLeft(a,b,op,board)
                if v2 is not False:
                    if board[v2[0]][v2[1]] is ".":
                        if (v2[0] is 0 and v2[1] is 7) or (v2[0] is 7 and v2[1] is 0) or (v2[0] is 0 and v2[1] is 0) or (v2[0] is 7 and v2[1] is 7):
                            cornerMoves.add((a,b,v2[0],v2[1]))
                        else:
                            otherMoves.add((a,b,v2[0],v2[1]))
                v3 = upRight(a,b,op,board)
                if v3 is not False:
                    if board[v3[0]][v3[1]] is ".":
                        if (v3[0] is 0 and v3[1] is 7) or (v3[0] is 7 and v3[1] is 0) or (v3[0] is 0 and v3[1] is 0) or (v3[0] is 7 and v3[1] is 7):
                            cornerMoves.add((a,b,v3[0],v3[1]))
                        else:
                            otherMoves.add((a,b,v3[0],v3[1]))
                v4 = left(a,b,op,board)
                if v4 is not False:
                    if board[v4[0]][v4[1]] is ".":
                        if (v4[0] is 0 and v4[1] is 7) or (v4[0] is 7 and v4[1] is 0) or (v4[0] is 0 and v4[1] is 0) or (v4[0] is 7 and v4[1] is 7):
                            cornerMoves.add((a,b,v4[0],v4[1]))
                        else:
                            otherMoves.add((a,b,v4[0],v4[1]))
                v5 = right(a,b,op,board)
                if v5 is not False:
                    if board[v5[0]][v5[1]] is ".":
                        if (v5[0] is 0 and v5[1] is 7) or (v5[0] is 7 and v5[1] is 0) or (v5[0] is 0 and v5[1] is 0) or (v5[0] is 7 and v5[1] is 7):
                            cornerMoves.add((a,b,v5[0],v5[1]))
                        else:
                            otherMoves.add((a,b,v5[0],v5[1]))
                v6 = down(a,b,op,board)
                if v6 is not False:
                    if board[v6[0]][v6[1]] is ".":
                        if (v6[0] is 0 and v6[1] is 7) or (v6[0] is 7 and v6[1] is 0) or (v6[0] is 0 and v6[1] is 0) or (v6[0] is 7 and v6[1] is 7):
                            cornerMoves.add((a,b,v6[0],v6[1]))
                        else:
                            otherMoves.add((a,b,v6[0],v6[1]))
                v7 = downLeft(a,b,op,board)
                if v7 is not False:
                    if board[v7[0]][v7[1]] is ".":
                        if (v7[0] is 0 and v7[1] is 7) or (v7[0] is 7 and v7[1] is 0) or (v7[0] is 0 and v7[1] is 0) or (v7[0] is 7 and v7[1] is 7):
                            cornerMoves.add((a,b,v7[0],v7[1]))
                        else:
                            otherMoves.add((a,b,v7[0],v7[1]))
                v8 = downRight(a,b,op,board)
                if v8 is not False:
                    if board[v8[0]][v8[1]] is ".":
                        if (v8[0] is 0 and v8[1] is 7) or (v8[0] is 7 and v8[1] is 0) or (v8[0] is 0 and v8[1] is 0) or (v8[0] is 7 and v8[1] is 7):
                            cornerMoves.add((a,b,v8[0],v8[1]))
                        else:
                            otherMoves.add((a,b,v8[0],v8[1]))
    #print(otherMoves)
    #print(cornerMoves)
    if len(cornerMoves) is 1:
        temp = cornerMoves.pop()
        #print("Move:", temp[2]*8 + temp[3])
        #flip(temp[0],temp[1],temp[2],temp[3],move)
        return [temp[2]*8 + temp[3], 'c']
    if len(cornerMoves)>1:
        ma = 0
        valory = 0
        for i in cornerMoves:
            x = length(i[0],i[1],i[2],i[3])
            if x>ma:
                ma = x
                valory = i
        #print("Move:", valory[2]*8 + valory[3])
        #flip(valory[0],valory[1],valory[2],valory[3],move)
        return [valory[2]*8 + valory[3],'c']
    if len(otherMoves) is 1:
        temp = otherMoves.pop()
        #print("Move:", temp[2]*8 + temp[3])
        #flip(temp[0],temp[1],temp[2],temp[3],move)
        return [temp[2]*8 + temp[3], "n"]
    if len(otherMoves)>1:
        ma = 0
        valory = 0
        for i in otherMoves:
            x = length(i[0],i[1],i[2],i[3])
            if x>ma:
                ma = x
                valory = i
        #print("Move:", valory[2]*8 + valory[3])
        #flip(valory[0],valory[1],valory[2],valory[3],move)
        return [valory[2]*8 + valory[3], "n"]
class Strategy():
    def best_strategy(self, board, player, best_move, running):
        if running.value:
            myBoard = list("".join(board).replace("?", "").replace("@", "x").lower())
            w,h = 8,8
            tempboard = [[0 for x in range(w)] for y in range(h)]
            count = 0
            #print(move)
            for a in range(0, 8):
                for b in range(0, 8):
                    tempboard[a][b] = myBoard[count]
                    count = count+1
            token = player.replace('@', "x").lower()
            op = "o" if token == 'x'else "x"
            bm = bestMove(tempboard, op, token)
            best_move.value = 11+(bm[0]//8)*10 + (bm[0]%8)
            temp5 = string(deepcopy(tempboard))
            if temp5.count('.')>12:
                if len(pMoves(token, op, deepcopy(tempboard)))<4:
                    nm = (negamax(deepcopy(tempboard), token, op, 8, -65, 65)[-1])
                else:
                    nm = (negamax(deepcopy(tempboard), token, op, 7, -65, 65)[-1])
            else:
                nm = (negamax(deepcopy(tempboard), token, op, -1, -65, 65)[-1])
            best_move.value = 11+(nm//8)*10 + (nm%8)
#print(move, op)
#print(pMoves(move, op))
#print(score(string(board), move))
#board = Flip(move, 19, op, board)
#print(nm(board, move, op, -1))
if __name__ == "__main__":
    s1 = "...........................ox......xo..........................."
    move = "x"
    op = "o"
    if len(sys.argv) == 2:
        s1 = sys.argv[1].lower()
        if len(s1) == 1:
            if s1 == 'x':
                move = "x"
                op = "o"
            else:
                move = "o"
                op = "x"
            #print(move)
            s1 = "...........................ox......xo..........................."
        else:
            s2 = s1[:]
            s2 = s2.replace(".", "")
            if len(s2)%2 == 0:
                move = "x"
                op = "o"
            else:
                move = "o"
                op = "x"
    if len(sys.argv) == 3:
        s1 = sys.argv[1].lower()
        move = sys.argv[2].lower()
        if move == 'x':
            op = "o"
        else:
            op = "x"
    w, h = 8, 8
    boardd = [[0 for x in range(w)] for y in range(h)]
    count = 0
    print(move)
    for a in range(0, 8):
        for b in range(0, 8):
            boardd[a][b] = s1[count]
            count = count+1
    Display(boardd)
    print("\n")
    temp10 = s1[:]
    vas = set()
    temp10 = temp10.replace(".", "")
    for a in temp10:
        vas.add(a)
    if len(vas) is 1:
        print("No moves")
        sys.exit()
    temp5 = string(deepcopy(boardd))
    if temp5.count('.')>20:
        if len(pMoves(move, op, deepcopy(boardd)))<3:
            nm = (negamax(deepcopy(boardd), move, op, 12, -65, 65)[-1])
        elif len(pMoves(move, op, deepcopy(boardd)))<4:
            nm = (negamax(deepcopy(boardd), move, op, 11, -65, 65)[-1])
        else:
            nm = (negamax(deepcopy(boardd), move, op, 10, -65, 65)[-1])
    else:
        nm = (negamax(deepcopy(boardd), move, op, -1, -65, 65)[-1])
    print(nm)
