EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
import sys, random, time
oppositeToken = {"x":"o", "o":"x"}
edges = {a for a in range(64) if a%8 == 0 or a%8 == 7 or int(a/8)==0 or int(a/8)== 7}
cSquares = {1, 8, 6, 15, 55, 62, 57, 48}
xSquares = {9, 15, 49, 54}
def display(board):
    return "\n".join([board[a*8:a*8+8] for a in range(8)])
def toMove(board):
    if board.count(".")%2 == 0:
        return "x"
    return "o"
def legalChange(position, change, newPosition):
    if newPosition>63 or newPosition<0:
        return False
    if change == -1 or change == 1:
        return int(position/8) == int(newPosition/8)
    if change == -9 or change == 7 or change==9 or change == -7:
        return abs(position%8 - newPosition%8) == abs(int(position/8) - int(newPosition/8))
    return True
fullNeighbors = {}
for a in range(64):
    fullNeighbors[a] = []
    for b in [-1, 1, -8, 8, -9, -7, 7, 9]:
        newPosition = a + b
        if legalChange(a, b, newPosition):
            path = []
            while legalChange(a, b, newPosition):
                path.append(newPosition)
                newPosition = newPosition + b
            fullNeighbors[a].append(path)
def goodPath(board, pieceToMove, position, path):
    if board[path[0]] == oppositeToken[pieceToMove]:
        for a in path:
            if board[a] == ".":
                break
            elif board[a]== pieceToMove:
                return True
    return False
def findPossibleMoves(board, pieceToMove):
    possibleMoves = []
    for a in range(64):
        if board[a] == ".":
            for b in fullNeighbors[a]:
                if goodPath(board, pieceToMove, a, b):
                    possibleMoves.append(a)
                    break
    return possibleMoves
def evaluateBoard(board, token):
    return board.count(token)- board.count(oppositeToken[token])
def makeMove(board, pieceToMove, position):
    newBoard = board
    newBoard = newBoard[:position] + pieceToMove + newBoard[position + 1:]
    for a in fullNeighbors[position]:
        if goodPath(board, pieceToMove, position, a):
            for b in a:
                if board[b]== oppositeToken[pieceToMove]:
                    newBoard = newBoard[:b] + pieceToMove + newBoard[b+1:]
                else:
                    break
    return newBoard
def negaMax(board, token, levels):
    if not levels:
        return [evaluateBoard(board, token)]
    if not (findPossibleMoves(board, token) or findPossibleMoves(board,oppositeToken[token])):
        return [evaluateBoard(board, token)]
    lm = findPossibleMoves(board, token)
    if not lm:
        nm = negaMax(board, oppositeToken[token], levels-1) +[-1]
        return [-nm[0]]+ nm[1:]
    nmList = sorted([negaMax(makeMove(board, token, mv), oppositeToken[token], levels-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]
closestCorner = {}
for a in edges | xSquares:
    if a%8<4 and int(a/8)<4:
        closestCorner[a] = 0
    if a%8>=4 and int(a/8)<4:
        closestCorner[a] = 7
    if a%8<4 and int(a/8)>=4:
        closestCorner[a] = 56
    if a%8>=4 and int(a/8)>=4:
        closestCorner[a] = 63
def safeEdge(board, token, position):
    for path in fullNeighbors[position]:
        change = position - path[0]
        if abs(change) == 1 or abs(change) == 8:
            pathPieces = {board[a] for a in path}
            pathPiecesMinus = {board[a] for a in path[:-1]}
            if (len(pathPieces) <= 1 and board[path[0]] == token) or (len(pathPiecesMinus) <= 1 and board[path[0]] == oppositeToken[token]):
                return True
    return False
def fourHeur(board, yourToken, possibleMoves):
    if {*possibleMoves} & {0, 7, 56, 63}:
         return random.choice([*({*possibleMoves} & {0, 7, 56, 63})])
    if {*possibleMoves}& edges:
        safeEdges = [a for a in {*possibleMoves}& edges if safeEdge(board, yourToken, a)]
        if safeEdges:
            return random.choice(safeEdges)
    possibleWithoutEdges = [a for a in possibleMoves if a not in edges]
    possibleWithoutUnsafeCX = [a for a in possibleMoves if a not in (cSquares | xSquares) or board[closestCorner[a]].lower() == yourToken]
    if possibleWithoutUnsafeCX:
        return random.choice(possibleWithoutUnsafeCX)
    elif possibleWithoutEdges:
        return random.choice(possibleWithoutEdges)
    return random.choice(possibleMoves)
def pickMove(board, player, depth):
    if board.count(".") <= 9:
        turn = negaMax(board, player, -1)[-1]
        return turn
    return fourHeur(board, player, findPossibleMoves(board, player))
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        board = "".join(board).replace("?", "").replace("@", "x")
        token = "x" if player == "@" else "o"
        while(True):
            mv = pickMove(board, token, depth)
            best_move.value =  11 + (mv//8)*10 + (mv%8)
            depth += 2
def main():
    try:
        root = sys.argv[1].lower()
    except:
        root = "...........................ox......xo..........................."
    try:
        move = sys.argv[2].lower()
    except:
        move = toMove(root)
    possibleMoves = findPossibleMoves(root, move)
    if possibleMoves:
        print(display(root))
        print("Legal Moves" + str(possibleMoves))
        print("Heuristic:" + str(fourHeur(root, move, findPossibleMoves(root, move))))
        if root.count(".") <= 9:
            turn = negaMax(root, move, -1)
            print("NegaMax Score:" + str(turn[0]) + " and Move:" + str(turn[-1]))
    else:
        print("No Possible Moves")
if __name__ == "__main__":
    main()

