import sys, random, time
## 27, 28, 35, 36  O, X, X, O
## Option input of gameboard/who's move

# game = "...........................OX......XO..........................."
#
# whoT = "X"

##This is the option sys.argv stuff
def showBoard(game): #Prints the board
	print("\n".join([game[i:i+8] for i in range(0,64,8)]))

def counting(board,token):
	countT = 0
	countNoT = 0
	for x in range(0,len(board)):
		if board[x] == token:
			countT += 1
		elif board[x] == ".":
			countNoT += 1
	if countT < countNoT:
		return True
	return False

def whoTurn(game): #Figures out who's turn it is
	#A faster way would be to count the number of periods. (Do that in a speed up)
	count = 0
	for each in game:
		if each == ".":
			count += 1
	if count%2 == 0:
		if "x" in game:
			return "x"
		else:
			return "X"
	else:
		if "x" in game:
			return "o"
		else:
			return "O"

def whoOpp(whoT):
	if "x" not in game:
		if whoT == "X":
			return "O"
		else:
			return "X"
	else:
		if whoT == "x":
			return "o"
		else:
			return "x"

def move(game, player, position):
	game[position] = player
	checkUp, checkDown, oppo = {0,6,7,8}, {(54,9),(55,8),(56,7),(63,1)}, whoOpp(player)
	for check in checkUp:
		if position > check:
			if ((not(check == 0 or check == 8 or check == 6)) or (((check == 0 or check == 8) and position%8 != 0) or ((check == 6 and position%8 !=7)))):
				if game[position-(check+1)] == oppo:
					temp = position-(check+1)
					pos = 0
					c = 0
					while temp >= 0:
						if(not(((check == 0 or check == 8) and temp%8 == 0) or ((check == 6 and temp%8 ==7)))):
							if game[temp] == ".":
								break
							elif game[temp] == player:
								c = 1
								pos = temp
								break
						else:
							if game[temp] == player:
								c = 1
								pos = temp
							break
						temp = temp - (check+1)
					pos = temp
					while pos != position:
						if c != 1:
							break
						pos = pos + (check+1)
						game[pos] = player
	for check in checkDown:
		if position < check[0]:
			if ((not(check[0] == 63 or check[0] == 54 or check[0] == 56)) or (((check[0] == 63 or check[0] == 54) and position%8 != 7) or ((check[0] == 56 and position%8 != 0)))):
				if game[position+check[1]] == oppo:
					temp = position+check[1]
					pos = 0
					c = 0
					# print(position)
					while temp <= 63:
						if(not(((check[0] == 63 or check[0] == 54) and temp%8 == 7) or ((check[0] == 56 and temp%8 == 0)))):
							if game[temp] == ".":
								break
							elif game[temp] == player:
								c = 1
								pos = temp
								break
						else:
							if game[temp] == player:
								c = 1
								pos = temp
							break
						temp = temp + check[1]
					pos = temp
					# print(c)
					while pos != position:
						if c != 1:
							break
						pos = pos - check[1]
						game[pos] = player
	game = "".join(game)
	return game

if len(sys.argv) > 1:
	game = sys.argv[1]
	if len(sys.argv) == 3:
		if "x" in game:
			whoT = sys.argv[2].lower()
		else:
			whoT = sys.argv[2].upper()
	else:
		whoT = whoTurn(game)
else:
	whoT = "X"
	game = "...........................OX......XO..........................."


def possibleMoves(game, whoT,legals):
	booL = counting(game, whoT)
	if(booL):
		checkUp, checkDown, poss, oppo = {0,6,7,8}, {(54,9),(55,8),(56,7),(63,1)}, set(), whoOpp(whoT) ##
		for each in range(len(game)):
			if game[each] == whoT:
				for check in checkUp:
					if each > check:
						if ((not(check == 0 or check == 8 or check == 6)) or (((check == 0 or check == 8) and each%8 != 0) or ((check == 6 and each%8 !=7)))):
							if game[each-(check+1)] == oppo:
								temp = each-(check+1)
								while temp >= 0:
									if game[temp] == whoT and temp != each-(check+1):
										break
									if game[temp] == ".":
										poss.add(temp)
										break
									if(not(((check == 0 or check == 8) and temp%8 == 0) or ((check == 6 and temp%8 ==7)))):
										if game[temp] == ".":
											poss.add(temp)
											break
										temp = temp - (check+1)
									else:
										break
				for check in checkDown:
					if each < check[0]:
						if ((not(check[0] == 63 or check[0] == 54 or check[0] == 56)) or (((check[0] == 63 or check[0] == 54) and each%8 != 7) or ((check[0] == 56 and each%8 != 0)))):
							if game[each+check[1]] == oppo:
								temp = each+check[1]
								while temp <= 63:
									if game[temp] == whoT and temp != each+check[1]:
										break
									if game[temp] == ".":
										poss.add(temp)
										break
									if(not( ((check[0] == 63 or check[0] == 54) and temp%8 == 7) or ((check[0] == 56 and temp%8 == 0)))):
										if game[temp] == ".":
											poss.add(temp)
											break
										temp = temp + check[1]
									else:
										break
	else:
		checkUp, checkDown, poss, oppo = {0,6,7,8}, {(54,9),(55,8),(56,7),(63,1)}, set(), whoOpp(whoT) ##
		for each in range(len(game)):
			if game[each] == ".":
				for check in checkUp:
					if each > check:
						if ((not(check == 0 or check == 8 or check == 6)) or (((check == 0 or check == 8) and each%8 != 0) or ((check == 6 and each%8 !=7)))):
							if game[each-(check+1)] == oppo:
								temp = each-(check+1)
								while temp >= 0:
									if game[temp] == "." and temp != each-(check+1):
										break
									if game[temp] == whoT:
										poss.add(each)
										break
									if(not(((check == 0 or check == 8) and temp%8 == 0) or ((check == 6 and temp%8 ==7)))):
										if game[temp] == whoT:
											poss.add(each)
											break
										temp = temp - (check+1)
									else:
										break
				for check in checkDown:
					if each < check[0]:
						if ((not(check[0] == 63 or check[0] == 54 or check[0] == 56)) or (((check[0] == 63 or check[0] == 54) and each%8 != 7) or ((check[0] == 56 and each%8 != 0)))):
							if game[each+check[1]] == oppo:
								temp = each+check[1]
								while temp <= 63:
									if game[temp] == "." and temp != each+check[1]:
										break
									if game[temp] == whoT:
										poss.add(each)
										break
									if(not( ((check[0] == 63 or check[0] == 54) and temp%8 == 7) or ((check[0] == 56 and temp%8 == 0)))):
										if game[temp] == whoT:
											poss.add(each)
											break
										temp = temp + check[1]
									else:
										break
	legals[("".join(game),whoT)] = poss
	return poss


# print("State of game: ")
# print(game)
# print("")
# showBoard(game)
# print("")
# # if len(sys.argv) == 1:
# game = list(game)
# print("Possible Moves: ", end = "")
# moves = possibleMoves(game, whoT)
# if len(moves) == 0:
#     print("No Moves")
# else:
#     print(moves)
# print("")
# for each in moves:
#     game[each] = "*"
# print("")
# showBoard("".join(game))

def evalBoard(board, token):
	#num = number of tokens you have - the number of tokens the enemy has
	countT = 0
	countNoT = 0
	for x in range(0,len(board)):
		if board[x] == token:
			countT += 1
		elif board[x] == whoOpp(token):
			countNoT += 1
	num = countT - countNoT
	return num


def negamaxTerminal2(board, token, improvable, hardBound, legals,levels):
	board = "".join(board)

	if not levels:
		return [evalBoard(board, token)]

	if((board,token) in legals):
		lm = legals[(board,token)]
	else:
		lm = possibleMoves(board, token,legals)
	if not lm:
		nm = negamaxTerminal(board, whoOpp(token), -hardBound, -improvable,legals,levels-1) + [-1]
		return [-nm[0]] + nm[1:]
	board = list(board)
	best = []  #what gets returned
	newHB = -improvable
	for mv in lm:
		nm = negamaxTerminal(move(list(board), token, mv), whoOpp(token), -hardBound, newHB,legals,levels-1) + [mv]
		if not best or nm[0] < newHB:    #######Both nm[0] && newHB are negative
			best = nm
			if nm[0] < newHB:
				newHB = nm[0]
				if -newHB >= hardBound: return [-best[0]] + best[1:]
	return [-best[0]] + best[1:]

def negamaxTerminal(board, token, improvable, hardBound, legals):
	board = "".join(board)

	if((board,token) in legals):
		lm = legals[(board,token)]
	else:
		lm = possibleMoves(board, token,legals)
	if not lm:
		if((board,whoOpp(token)) in legals):
			lm = legals[(board,whoOpp(token))]
		else:
			lm = possibleMoves(board, whoOpp(token),legals)
		board = list(board)
		if not lm:
			return[evalBoard(board,token),-3]  ##The -3 means game is over
		nm = negamaxTerminal(board, whoOpp(token), -hardBound, -improvable,legals) + [-1]
		return [-nm[0]] + nm[1:]
	board = list(board)
	best = []  #what gets returned
	newHB = -improvable
	for mv in lm:
		nm = negamaxTerminal(move(list(board), token, mv), whoOpp(token), -hardBound, newHB,legals) + [mv]
		if not best or nm[0] < newHB:    #######Both nm[0] && newHB are negative
			best = nm
			if nm[0] < newHB:
				newHB = nm[0]
				if -newHB >= hardBound: return [-best[0]] + best[1:]
	return [-best[0]] + best[1:]

##Negamax: assumes the two sides are negatives of  each other
 ## Returns a score together with a move sequence leading to that score.
 #preferred # of levels: 3
 #Test with only 1 level
def negamax(board, token, levels):
  if not levels:
	  # print("")
	  # showBoard("".join(board))
	  # print("")
	  # print(evalBoard(board, token))
	  return [evalBoard(board, token)]

  lm = possibleMoves(board, token)
  # print(lm)
  if not lm:
	  best = negamax(board, whoOpp(token), levels-1) + [-1]
  else:
	  best = sorted([negamax(move(list(board), token, mv,movesD), \
							   whoOpp(token), levels-1) + [mv] for mv in lm])[0]
  return [-best[0]] + best[1:]

def takeCorner(setMoves):
    corners = {0,7,56,63}
    theCorner = set()
    for each in corners:
        if each in setMoves:
            theCorner.add(each)
    if len(theCorner) == 0:
        return set()
    else:
        return theCorner

def notEdge(setMoves):
    edgeL, edgeR  = {0,8,16,24,32,40,48,56}, {7,15,23,31,39,47,55,63}
    edgeUp, edgeD = {0,1,2,3,4,5,6,7}, {56,57,58,59,60,61,62,63}
    possMoves = set()
    for each in setMoves:
        if each not in edgeL and each not in edgeR and each not in edgeUp and each not in edgeD:
            possMoves.add(each)
    if len(possMoves) == 0:
        return set()
    else:
        return possMoves

def noXorC(setMoves,whoT):
    XandC = {((1,9,8),0),((6,14,15),7),((48,49,57),56),((54,55,62),63)}
    lastChance = set(setMoves)
    for each in XandC:
        if game[each[1]] != whoT:
            for some in each[0]:
                if some in setMoves:
                    lastChance.remove(some)
    return lastChance

def trapping(setMoves, whoT, game):
	dontAdd = set()
	edgeL, edgeR  = (8,16,24,32,40,48), (15,23,31,39,47,55)
	edgeUp, edgeD = (1,2,3,4,5,6), (57,58,59,60,61,62)
	for each in setMoves:
		if each in edgeL:
			if each == 8:
				if game[16] == ".":
					if game[24] == whoT:
						dontAdd.add(8)
			elif each == 48:
				if game[40] == ".":
					if game[32] == whoT:
						dontAdd.add(48)
			else:
				if game[each-8] == ".":
					if game[each-16] == whoT:
						if each != 16:
							dontAdd.add(each)
				if game[each+8] == ".":
					if game[each+16] == whoT:
						if each != 40:
							dontAdd.add(each)
		if each in edgeR:
			if each == 15:
				if game[23] == ".":
					if game[31] == whoT:
						dontAdd.add(15)
			elif each == 55:
				if game[47] == ".":
					if game[39] == whoT:
						dontAdd.add(55)
			else:
				if game[each-8] == ".":
					if game[each-16] == whoT:
						if each != 23:
							dontAdd.add(each)
				if game[each+8] == ".":
					if game[each+16] == whoT:
						if each != 47:
							dontAdd.add(each)
		if each in edgeUp:
			if each == 1:
				if game[2] == ".":
					if game[3] == whoT:
						dontAdd.add(1)
			elif each == 6:
				if game[5] == ".":
					if game[4] == whoT:
						dontAdd.add(6)
			else:
				if game[each-1] == ".":
					if game[each-2] == whoT:
						if each != 2:
							dontAdd.add(each)
				if game[each+1] == ".":
					if game[each+2] == whoT:
						if each != 5:
							dontAdd.add(each)
		if each in edgeD:
			if each == 57:
				if game[58] == ".":
					if game[59] == whoT:
						dontAdd.add(57)
			elif each == 62:
				if game[61] == ".":
					if game[60] == whoT:
						dontAdd.add(62)
			else:
				if game[each-1] == ".":
					if game[each-2] == whoT:
						if each != 58:
							dontAdd.add(each)
				if game[each+1] == ".":
					if game[each+2] == whoT:
						if each != 61:
							dontAdd.add(each)
	poss = set()
	for each in setMoves:
		if each  not in dontAdd:
			poss.add(each)
	return poss

def holdEdge2(setMoves,whoT,game):
	thePoss = (2,5,58,61,16,40,23,47)
	enemy = whoOpp(whoT)
	checking = set()
	poss = set()
	for one in thePoss:
		if one in setMoves:
			checking.add(one)
	if len(checking) != 0:
		edgeL, edgeR  = (0,8,16,24,32,40,48,56), (7,15,23,31,39,47,55,63)
		edgeUp, edgeD = (0,1,2,3,4,5,6,7), (56,57,58,59,60,61,62,63)
		for each in checking:
			if each in edgeL:
				if(game[0] != enemy and game[56] != enemy):
					poss.add(each)
			if each in edgeR:
				if(game[7] != enemy and game[63] != enemy):
					poss.add(each)
			if each in edgeUp:
				if(game[0] != enemy and game[7] != enemy):
					poss.add(each)
			if each in edgeD:
				if(game[56] != enemy and game[63] != enemy):
					poss.add(each)
	notFinal = set()
	for each in poss:
		temp = game[:]
		move(temp,whoT,each)
		if(temp[9] == whoT or temp[14] == whoT or temp[49] == whoT or temp[54] == whoT):
			notFinal.add(each)
	final = set()
	for each in poss:
		if each not in notFinal:
			final.add(each)
	return final

def holdEdge(setMoves,whoT,game):
	thePoss = (2,5,58,61,16,40,23,47)
	enemy = whoOpp(whoT)
	checking = set()
	poss = set()
	for one in thePoss:
		if one in setMoves:
			checking.add(one)
	if len(checking) != 0:
		edgeL, edgeR  = (0,8,16,24,32,40,48,56), (7,15,23,31,39,47,55,63)
		edgeUp, edgeD = (0,1,2,3,4,5,6,7), (56,57,58,59,60,61,62,63)
		for each in checking:
			if each in edgeL:
				if(game[each+8] != enemy and game[each-8] != enemy):
					poss.add(each)
			if each in edgeR:
				if(game[each+8] != enemy and game[each-8] != enemy):
					poss.add(each)
			if each in edgeUp:
				if(game[each-1] != enemy and game[each+1] != enemy):
					poss.add(each)
			if each in edgeD:
				if(game[each-1] != enemy and game[each+1] != enemy):
					poss.add(each)
	notFinal = set()
	for each in poss:
		temp = game[:]
		move(temp,whoT,each)
		if(temp[9] == whoT or temp[14] == whoT or temp[49] == whoT or temp[54] == whoT):
			notFinal.add(each)
	final = set()
	for each in poss:
		if each not in notFinal:
			final.add(each)
	return final

def finFour2(setMoves,whoT,game):
	thePoss = (3,4,24,32,31,39,59,60)
	enemy = whoOpp(whoT)
	checking = set()
	poss = set()
	for one in thePoss:
		if one in setMoves:
			checking.add(one)
	if len(checking) != 0:
		edgeL, edgeR  = (0,8,16,24,32,40,48,56), (7,15,23,31,39,47,55,63)
		edgeUp, edgeD = (0,1,2,3,4,5,6,7), (56,57,58,59,60,61,62,63)
		for each in checking:
			if each in edgeL:
				if(game[0] != enemy and game[56] != enemy):
					if(game[16] == whoT and game[40] == whoT):
						poss.add(each)
			if each in edgeR:
				if(game[7] != enemy and game[63] != enemy):
					if(game[23] == whoT and game[47] == whoT):
						poss.add(each)
			if each in edgeUp:
				if(game[0] != enemy and game[7] != enemy):
					if(game[2] == whoT and game[5] == whoT):
						poss.add(each)
			if each in edgeD:
				if(game[56] != enemy and game[63] != enemy):
					if(game[58] == whoT and game[61] == whoT):
						poss.add(each)
	return poss

def finFour(setMoves,whoT,game):
	thePoss = (3,4,24,32,31,39,59,60)
	enemy = whoOpp(whoT)
	checking = set()
	poss = set()
	for one in thePoss:
		if one in setMoves:
			checking.add(one)
	if len(checking) != 0:
		edgeL, edgeR  = (0,8,16,24,32,40,48,56), (7,15,23,31,39,47,55,63)
		edgeUp, edgeD = (0,1,2,3,4,5,6,7), (56,57,58,59,60,61,62,63)
		for each in checking:
			if each in edgeL:
				if(game[0] != enemy and game[56] != enemy):
					if(each == 32):
						if(game[each+8] != enemy and game[each-8] != enemy):
							poss.add(each)
					if(each == 24):
						if(game[each+8] != enemy and game[each-8] != enemy):
							poss.add(each)
			if each in edgeR:
				if(game[7] != enemy and game[63] != enemy):
					if(each == 39):
						if(game[each+8] != enemy and game[each-8] != enemy):
							poss.add(each)
					if(each == 31):
						if(game[each+8] != enemy and game[each-8] != enemy):
							poss.add(each)
			if each in edgeUp:
				if(game[0] != enemy and game[7] != enemy):
					if(each == 4):
						if(game[each-1] != enemy and game[each+1] != enemy):
							poss.add(each)
					if(each == 3):
						if(game[each-1] != enemy and game[each+1] != enemy):
							poss.add(each)
			if each in edgeD:
				if(game[56] != enemy and game[63] != enemy):
					if(each == 59):
						if(game[each-1] != enemy and game[each+1] != enemy):
							poss.add(each)
					if(each == 60):
						if(game[each-1] != enemy and game[each+1] != enemy):
							poss.add(each)
	return poss

def goX2(setMoves,whoT,game):
	thePoss = (1,6,8,48,15,55,57,62)
	enemy = whoOpp(whoT)
	checking = set()
	poss = set()
	for one in thePoss:
		if one in setMoves:
			checking.add(one)
	if len(checking) != 0:
		edgeL, edgeR  = (0,8,16,24,32,40,48,56), (7,15,23,31,39,47,55,63)
		edgeUp, edgeD = (0,1,2,3,4,5,6,7), (56,57,58,59,60,61,62,63)
		for each in checking:
			if each in edgeL:
				if(game[0] != enemy and game[56] != enemy):
					if(game[16] == whoT and game[40] == whoT and game[24] == whoT and game[32] == whoT):
						poss.add(each)
			if each in edgeR:
				if(game[7] != enemy and game[63] != enemy):
					if(game[23] == whoT and game[47] == whoT and game[31] == whoT and game[39] == whoT):
						poss.add(each)
			if each in edgeUp:
				if(game[0] != enemy and game[7] != enemy):
					if(game[2] == whoT and game[5] == whoT and game[3] == whoT and game[4] == whoT):
						poss.add(each)
			if each in edgeD:
				if(game[56] != enemy and game[63] != enemy):
					if(game[58] == whoT and game[61] == whoT and game[59] == whoT and game[60] == whoT):
						poss.add(each)
	return poss

def goX(setMoves,whoT,game): ## THE PROBLEM IS THAT I CAN CHOOSE ANOTHER EDGE THAT HAS NO PROBLEMS - I NEED TO EDIT IT SO IT TAKES THE ONES THAT HAVE PROBLEMS FIRST
	# thePoss = (1,6,8,48,15,55,57,62)
	thePoss = (8,16,24,32,40,48,15,23,31,39,47,55,1,2,3,4,5,6,57,58,59,60,61,62)
	enemy = whoOpp(whoT)
	checking = set()
	poss = set()
	better = set()
	for one in thePoss:
		if one in setMoves:
			checking.add(one)
	if len(checking) != 0:
		edgeL, edgeR  = (0,8,16,24,32,40,48,56), (7,15,23,31,39,47,55,63)
		edgeUp, edgeD = (0,1,2,3,4,5,6,7), (56,57,58,59,60,61,62,63)
		for each in checking:
			temp = game[:]
			temp = move(temp,whoT,each)
			boo = True
			boo2 = False
			if each in edgeL:
				for one in edgeL:
					if enemy == temp[one]:
						boo = False
					if enemy == game[one]:
						boo2 =True
				if(boo == True):
					if(boo2 == True):
						better.add(each)
					else:
						poss.add(each)
			boo = True
			boo2 = False
			if each in edgeR:
				for one in edgeR:
					if enemy == temp[one]:
						boo = False
					if enemy == game[one]:
						boo2 = True
				if(boo == True):
					if(boo2 == True):
						better.add(each)
					else:
						poss.add(each)
			boo = True
			boo2 = False
			if each in edgeUp:
				for one in edgeUp:
					if enemy == temp[one]:
						boo = False
					if enemy == game[one]:
						boo2 = True
				if(boo == True):
					if(boo2 == True):
						better.add(each)
					else:
						poss.add(each)
			boo = True
			boo2 = False
			if each in edgeD:
				for one in edgeD:
					if enemy == temp[one]:
						boo = False
					if enemy == game[one]:
						boo2 = True
				if(boo == True):
					if(boo2 == True):
						better.add(each)
					else:
						poss.add(each)
	print(better)

	if(len(better) > 0):
		notFinal = set()
		for each in better:
			temp = game[:]
			move(temp,whoT,each)
			if((temp[9] == whoT and temp[0] != whoT) or (temp[14] == whoT and temp[7] != whoT) or (temp[49] == whoT and temp[56] != whoT) or (temp[54] == whoT and temp[63] != whoT)):
				notFinal.add(each)
		final = set()
		for each in better:
			if each not in notFinal:
				final.add(each)
		return final
	else:
		notFinal = set()
		for each in poss:
			temp = game[:]
			move(temp,whoT,each)
			if(temp[9] == whoT or temp[14] == whoT or temp[49] == whoT or temp[54] == whoT):
				notFinal.add(each)
		final = set()
		for each in poss:
			if each not in notFinal:
				final.add(each)
		return final

def playEdge(setMoves,whoT,game):
    edgeL, edgeR  = {0,8,16,24,32,40,48,56}, {7,15,23,31,39,47,55,63}
    edgeUp, edgeD = {0,1,2,3,4,5,6,7}, {56,57,58,59,60,61,62,63}
    possMoves = set()
    count = 0
    for each in setMoves:
        tempGame = game[:]
        move(tempGame,whoT,each)
        if each in edgeL:
            if tempGame[0] == whoT:
                temp = each
                while temp >= 0:
                    if tempGame[temp] == whoT:
                        if temp == 0:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 8
            if tempGame[56] == whoT:
                temp = each
                while temp <= 56:
                    if tempGame[temp] == whoT:
                        if temp == 56:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 8
        if each in edgeR:
            if tempGame[7] == whoT:
                temp = each
                while temp >= 7:
                    if tempGame[temp] == whoT:
                        if temp == 7:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 8
            if tempGame[63] == whoT:
                temp = each
                while temp <= 63:
                    if tempGame[temp] == whoT:
                        if temp == 63:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 8
        if each in edgeUp:
            if tempGame[0] == whoT:
                temp = each
                while temp >= 0:
                    if tempGame[temp] == whoT:
                        if temp == 0:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 1
            if tempGame[7] == whoT:
                temp = each
                while temp <= 7:
                    if tempGame[temp] == whoT:
                        if temp == 7:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 1
        if each in edgeD:
            if tempGame[56] == whoT:
                temp = each
                while temp >= 56:
                    if tempGame[temp] == whoT:
                        if temp == 56:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 1
            if tempGame[63] == whoT:
                temp = each
                while temp <= 63:
                    if tempGame[temp] == whoT:
                        if temp == 63:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 1
    if len(possMoves) == 0:
        return set()
    else:
        return possMoves

def spaceCount(game):
	count = 0
	for each in range(0,len(game)-1):
		if game[each] == ".":
			count+=1
	return count

def findBestMove(game, whoT,legals):
	game = list(game)
	moves = possibleMoves(game, whoT,legals)
	myMove = -1
	cornerMoves = takeCorner(moves)
	connEdges = playEdge(moves,whoT,game)
	allowed = noXorC(moves,whoT)
	notEdges = notEdge(allowed)
	notTrapped = trapping(moves,whoT,game)
	edgeStarts = holdEdge(notTrapped,whoT,game)
	edgeMids = finFour(notTrapped,whoT,game)
	lastCase = goX(notTrapped,whoT,game)

	print()
	print(cornerMoves)
	print(connEdges)
	print(allowed)
	print(notEdges)
	print(notTrapped)
	print(edgeStarts)
	print(edgeMids)
	print(lastCase)
	print()


	if len(cornerMoves) > 0:
		myMove = (random.choice(list(cornerMoves)))
		print("Heuristic Move: ", end="")
		print(myMove)
	elif len(connEdges) > 0:
		myMove = (random.choice(list(connEdges)))
		print("Heuristic Move: ", end="")
		print(myMove)
	elif len(edgeStarts) > 0:
		myMove = (random.choice(list(edgeStarts)))
		print("Heuristic Move: ", end="")
		print(int(myMove))
	elif len(edgeMids) > 0:
		myMove = (random.choice(list(edgeMids)))
		print("Heuristic Move: ", end="")
		print(int(myMove))
	elif len(lastCase) > 0:
		myMove = (random.choice(list(lastCase)))
		print("Heuristic Move: ", end="")
		print(myMove)
	elif len(notEdges) > 0:
		myMove = (random.choice(list(notEdges)))
		print("Heuristic Move: ", end="")
		print(myMove)
	elif len(allowed) > 0:
		myMove = (random.choice(list(allowed)))
		print("Heuristic Move: ", end="")
		print(myMove)
	else:
		print("Heuristic Move: ", end="")
		myMove = (random.choice(list(moves)))
		print(myMove)
	if(spaceCount(game) <= 10):
		levels = 7
		# nm = negamax(game,whoT,levels)
		nm = negamaxTerminal(game,whoT,-65,65,legals)
		# print("At level {} nm gives {} and I pick move {}".format(levels,nm,nm[-1]))
		# return(nm[-1])
		print("Negamax (AlphBeta):", end="")
		return(nm[-1])
	return(myMove)

print("")
showBoard("".join(game))
print("Possible Moves: ", end="")
legals = {}
print(possibleMoves(game,whoT,legals))
print(findBestMove(game,whoT,legals))

# start = time.time()
# count = 0
# while time.time()-start < 5:
# 	possibleMoves(game,whoT,movesD)
# 	count += 1
# 	print(count)
		# start = time.time()
		# for _ in range(100000):
		# 	lm = possibleMoves(game, whoT)
		# 	# _ = move(game, whoT, lm.pop())
		# print(time.time() - start)
# class Strategy():
# 	def best_strategy(self, board, player, best_move, still_running):
# 		depth = 1
# 		brd = "".join(board).replace("?","").replace("@","X")
#
# 		token = "X" if player == "@" else "O"
#
# 		mv = findBestMove(brd,token)
# 		move = 11 + (mv || 8)*10 + (mv%8)
#
# 		best_move.value = mv
#
# #
#
#
# print("Move: ", end="")
# print(moves.pop())


class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		depth = 1
		brd = "".join(board).replace("?","").replace("@","X").replace("o","O")
		token = "X" if player == "@" else "O"
		# time.sleep(4)
		legals = {}
		mv = findBestMove(brd,token,legals)
		move = 11 + (mv // 8)*10 + (mv%8)
		best_move.value = move

# Strategy()

if __name__ == "__main__":
    main(game,whoT)
