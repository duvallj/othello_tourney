import random
import math
import re

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
OPPONENT = {BLACK: WHITE, WHITE: BLACK}

class Node:
	def __init__(self, state, player, move=-2000):
		self.state = state
		self.player = player
		self.move = move
		self.children = None
		self.score = 0

class Strategy():
	def __init__(self):
		self.weights = [
			0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			0, 16.16, -3.03,  0.99,   0.43,   0.43,  0.99, -3.03, 16.16,   0,
			0, -4.12, -1.81,  -5,  -5,  -5,  -5, -1.81, -4.12,   0,
			0,  1.33,  -0.04,  0.51,   0.07,   0.07,  0.51,  -0.04,  1.33,   0,
			0,   0.63,  -0.18,   -0.04,   -0.01,   -0.01,   -0.04,  -0.18,   0.63,   0,
			0,   0.63,  -0.18,   -0.04,   -0.01,   -0.01,   -0.04,  -0.18,   0.63,   0,
			0,  1.33,  -0.04,  0.51,   0.07,   0.07,  0.51,  -0.04,  1.33,   0,
			0, -4.12, -1.81,  -5,  -5,  -5,  -5, -1.81, -4.12,   0,
			0, 16.16, -3.03,  0.99,   0.43,   0.43,  0.99, -3.03, 16.16,   0,
			0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
		]

	def get_starting_board(self):
		return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

	def get_pretty_board(self, board):
		return '\n'.join([board[i:i+10] for i in range(0, len(board), 10)])

	def opponent(self, player):
		if player == WHITE:
			return BLACK
		return WHITE

	def is_move_valid(self, board, player, move):
		return move in self.get_valid_moves(board, player)

	def make_move(self, board, player, move):
		if self.is_move_valid(board, player, move):
			x_board = board[:]
			opponent = OPPONENT[player]
			x_board = x_board[:move] + player + x_board[move+1:]
			for DIR in DIRECTIONS:
				new_board = x_board[:]
				new_pos = move + DIR
				if new_board[new_pos] == opponent:
					while True:
						if new_board[new_pos] != opponent:
							break
						new_board = new_board[:new_pos] + player + new_board[new_pos+1:]
						new_pos += DIR
					if new_board[new_pos] == player:
						x_board = new_board
			return x_board
		return board

	def get_valid_moves(self, board, player):
		valid_moves = set()
		for pos in re.finditer(player, board):
			pos = pos.start()
			for DIR in DIRECTIONS:
				new_pos = pos + DIR
				once = False
				while True:
					if board[new_pos] != OPPONENT[player]:
						break
					once = True
					new_pos += DIR
				if board[new_pos] == EMPTY and once:
					valid_moves.add(new_pos)
		return list(valid_moves)

	def has_any_valid_moves(self, board, player):
		return len(self.get_valid_moves(board, player)) > 0

	def next_player(self, board, prev_player):
		if self.has_any_valid_moves(board, self.opponent(prev_player)):
			return self.opponent(prev_player)
		elif self.has_any_valid_moves(board, prev_player):
			return prev_player
		else:
			return None

	def score(self, board, player=BLACK):
		return (board.count(player) - board.count(self.opponent(player)))

	def game_over(self, board, player):
		return (not self.has_any_valid_moves(board, player)) and (self.next_player(board, player) == None)

	class IllegalMoveError(Exception):
		def __init__(self, player, move, board):
			self.player = player
			self.move = move
			self.board = board

		def __str__(self):
			return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)
	
	def weight_score(self, board, player, go):
		if go:
			if (board.count(player) - board.count(self.opponent(player))) > 0:
				return 1000
			else:
				return -1000
		elif board.count(EMPTY) > 36:
			w_score = 0
			for i, weight in enumerate(self.weights):
				if board[i] == player:
					w_score += weight
				elif board[i] == self.opponent(player):
					w_score -= weight
			return -((board.count(player) - board.count(self.opponent(player))) * w_score)
		else:
			c_score = (board.count(player) - board.count(self.opponent(player)))
			return c_score

	def negamax(self, node, depth, alpha, beta, color):
		go = self.game_over(*node)
		if depth == 0 or go:
			return color * self.weight_score(*node, go)
		childNodes = self.get_valid_moves(*node)
		childNodes.sort(key= lambda x: self.weights[x])
		bestMove = -99
		bestValue = -10000
		for child in childNodes:
			v = -self.negamax((self.make_move(*node,child), self.opponent(*node[1])), depth - 1, -beta, -alpha, -color)
			if v > bestValue:
				bestValue = v
				bestMove = child
			if v > alpha:
				alpha = v
			if alpha >= beta:
				break
		return bestMove

	def negamax_strategy(self, board, player, limit):
		return self.negamax((board, player), limit, -10000, 10000, 1)

	def random_strategy(self, board, player):
		return random.choice(self.get_valid_moves(board, player))

	def best_strategy(self, board, player, best_move, still_running):
		if player != WHITE:
			limit = 2
			while still_running:
				best_move.value = self.negamax_strategy(board, player, limit)
				limit += 1
		else:
			best_move.value = self.random_strategy(board, player)

	standard_strategy = random_strategy


import time
from multiprocessing import Value, Process
import os, signal
silent = False


class StandardPlayer():

	def __init__(self):
		pass

	def play(self):

		ref = Strategy()
		black = Strategy()
		white = Strategy()

		print("Playing Standard Game")
		board = ref.get_starting_board()
		player = BLACK
		strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
		print(ref.get_pretty_board(board))

		while player is not None:
			move = strategy[player](board, player)
			print("Player %s chooses %i" % (player, move))
			board = ref.make_move(board, player, move)
			print(ref.get_pretty_board(board))
			player = ref.next_player(board, player)

		print("Final Score %i." % ref.score(board), end=" ")
		print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



class ParallelPlayer():

	def __init__(self, time_limit = 5):
		self.black = Strategy()
		self.white = Strategy()
		self.time_limit = time_limit

	def play(self):
		ref = Strategy()
		print("play")
		board = ref.get_starting_board()
		player = BLACK

		print("Playing Parallel Game")
		strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
		while player is not None:
			best_shared = Value("i", -99)
			best_shared.value = -99
			running = Value("i", 1)

			p = Process(target=strategy(player), args=(board, player, best_shared, running))
			t1 = time.time()
			p.start()
			p.join(self.time_limit)
			running.value = 0
			time.sleep(0.01)
			p.terminate()
			time.sleep(0.01)
			if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
			move = best_shared.value
			if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
			if not silent:print(board, ref.get_valid_moves(board, player))
			board = ref.make_move(board, player, move)
			if not silent: print(ref.get_pretty_board(board))
			player = ref.next_player(board, player)

		print("Final Score %i." % ref.score(board), end=" ")
		print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
	game =  ParallelPlayer(0.3)
	game.play()