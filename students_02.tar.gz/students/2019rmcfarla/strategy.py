import random
import math
import decimal

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

global my_matrix
my_matrix = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
    0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
    0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
    0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
    0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
    0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, board, move, score):
        self.board = board
        self.last_move = move
        self.score = score


class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):  # Done
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
        """Create a new board with the initial black and white positions filled."""

    def get_pretty_board(self, board):
        return ("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n" % (
            board[11:19], board[21:29], board[31:39], board[41:49], board[51:59], board[61:69], board[71:79],
            board[81:89]))
        """Get a string representation of the board."""

    def opponent(self, player):  # Done?
        if player == BLACK:
            return WHITE
        else:
            return BLACK
        """Get player's opponent."""

    def find_match(self, board, player, square, direction):  # Done?
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        original = square
        if board[square] == EMPTY or board[square] == player:
            square += direction
            if board[square] == self.opponent(player):
                square += direction
                while board[square] != OUTER:
                    if board[square] == player:
                        return original, square  # return square + direction / True
                    if board[square] == EMPTY:
                        return False
                    square += direction
        return False

    def is_move_valid(self, board, player, move):  # Done?
        """Is this a legal move for the player?"""
        for direction in DIRECTIONS:
            if self.find_match(board, player, move, direction)[0] != False:
                return True

    def make_move(self, board, player, move):  # Done
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board = self.place(board, player, move)
        for dire in DIRECTIONS:
            curr = move
            match = self.find_match(board, player, move, dire)
            if match != False:
                while curr != match[1]:
                    board = self.place(board, player, curr)
                    curr = curr + dire
        return board

    def place(self, board, player, spot):
        return board[:spot] + player + board[spot + 1:]

    def get_valid_moves(self, board, player):  # Done? pretty inefficient
        """Get a list of all legal moves for player."""
        moves = set()
        for x in range(0, 100):
            if board[x] == EMPTY:
                for direction in DIRECTIONS:
                    move = self.find_match(board, player, x, direction)
                    if move != False:
                        moves.add(move[0])
        the_moves = []
        for move in moves:
            the_moves.append(move)
        return the_moves

    def has_any_valid_moves(self, board, player):  # Done?
        """Can player make any moves?"""
        if len(self.get_valid_moves(board, player)) > 0:
            return True

    def next_player(self, board, prev_player):  # Done?
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        if self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):  # black - white
        points = 0
        for square in board:
            if square == player:
                points += 1
            elif square == self.opponent(player):
                points -= 1
        return points

    def r_score(self, board, player=BLACK):  # black - white
        points = 0
        for square in board:
            if square == player:
                points += 1 + random.random()
            elif square == self.opponent(player):
                points -= 1 - random.random()
        return points

    def weighted_score(self, board, player=BLACK):
        points = 0
        weighting_matrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        for z in range(10, 80, 10):
            for y in range(1, 8):
                x = z + y
                if board[x] == player:
                    points += weighting_matrix[x]
                elif board[x] == self.opponent(player):
                    points -= weighting_matrix[x]
        return points

    def my_score(self, board, player=BLACK):
        points = 0
        for z in range(10, 80, 10):
            for y in range(1, 8):
                x = z + y
                if board[x] == player:
                    points += my_matrix[x]
                elif board[x] == self.opponent(player):
                    points -= my_matrix[x]
            points += (len(self.get_valid_moves(board, player)) - len(self.get_valid_moves(board, self.opponent(player))))*5
            return points

    def is_stable(self, board, player, x, bs, ws):  # checks if this move is stable
        stables = {BLACK: bs, WHITE: ws}
        if board[x] == self.opponent(player) or board[x] == EMPTY:
            return False
        if x in stables[player]:
            return True
        # print("AHLKFJHELKFJHEW")
        if x + N in stables[player] or x + S in stables[player]:
            # print("WAH")
            if x + E in stables[player] or x + W in stables[player]:
                if x + NW in stables[player] or x + SE in stables[player]:
                    if x + NE in stables[player] or x + SW in stables[player]:
                        stables[player].add(x)
                        # print("HECC")
                        return True

        return False

    def game_over(self, board, player):  # Done?
        """Return true if player and opponent have no valid moves"""
        if self.next_player(board, player) is None:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            node.score = self.score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for m in my_moves:
            next_board = self.make_move(board, player, m)
            next_player = self.next_player(next_board, player)
            if next_player == None:  # game is over
                c = Node(next_board, m, 1000 * self.score(next_board))
                children.append(c)
            else:  # game is still going
                c = Node(next_board, m, None)
                c.score = self.minmax_search(c, next_player, depth - 1).score
                children.append(c)
        winner = best[player](children, key=lambda x: x.score)
        node.score = winner.score
        return winner
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters

    def weighted_search(self, node, player, depth):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for m in my_moves:
            next_board = self.make_move(board, player, m)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, m, 1000 * self.score(next_board))
                children.append(c)
            else:  # game is still going
                c = Node(next_board, m, None)
                c.score = self.minmax_search(c, next_player, depth - 1).score
                children.append(c)
        winner = best[player](children, key=lambda x: x.score)
        node.score = winner.score
        return winner

    def pruning_search(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for m in my_moves:
            next_board = self.make_move(board, player, m)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, m, 1000 * self.score(next_board))
                children.append(c)
            else:  # game is still going
                c = Node(next_board, m, None)
                c.score = self.pruning_search(c, next_player, depth - 1, a, b).score
                children.append(c)
                if player == BLACK:
                    a = max(a, c.score)
                else:
                    b = min(b, c.score)
            if a > b: break
        winner = best[player](children, key=lambda x: x.score)
        node.score = winner.score
        return winner

    def my_search(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            node.score = self.my_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for m in my_moves:
            next_board = self.make_move(board, player, m)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, m, 1000 * self.score(next_board))
                children.append(c)
            else:  # game is still going
                c = Node(next_board, m, None)
                c.score = self.my_search(c, next_player, depth - 1, a, b).score
                children.append(c)
                if player == BLACK:
                    a = max(a, c.score)
                else:
                    b = min(b, c.score)
            if a > b: break
        winner = best[player](children, key=lambda x: x.score)
        node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=4):
        return self.minmax_search(Node(board, None, 0), player, depth).last_move  # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move

    def weighted_strategy(self, board, player, depth=4):
        return self.weighted_search(Node(board, None, 0), player, depth).last_move

    def my_strategy(self, board, player, depth=4):
        return self.my_search(Node(board, None, 0), player, depth, -9999, 9999).last_move

    def pruning_strategy(self, board, player, depth=4):
        return self.pruning_search(Node(board, None, 0), player, depth, -9999, 9999).last_move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = ''.join(board)
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.my_strategy(board, player, depth)
            depth += 1

    standard_strategy = random_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.my_strategy, WHITE: white.pruning_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    # game = ParallelPlayer(5)
    game = StandardPlayer()
    game.play()

