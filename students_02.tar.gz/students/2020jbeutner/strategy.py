import random
import time

BLACK = "@"
WHITE = "o"
BLANK = "."

class Board:
    def __init__(self, chars = None):
        if chars is None:
            chars = "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
        self.board = list(map(self.Row, chars.strip("?").split("??")))
        self._legal = {}

    def to_chars(self):
        return "???????????" + "??".join("".join(row.row) for row in self) + "???????????"

    def copy(self):
        return self.__class__(self.to_chars())

    def after_move(self, move, player):
        if self[move.r][move.c] != BLANK:
            return None
        N = len(self)
        copy = self.copy()
        copy[move.r].row[move.c] = player
        ok = False
        for rstep in range(-1, 2):
            for cstep in range(-1, 2):
                r = move.r + rstep
                c = move.c + cstep
                passed = []
                while 0 <= r < N and 0 <= c < N:
                    if self[r][c] == BLANK:
                        break
                    elif self[r][c] == player:
                        for passedr, passedc in passed:
                            copy[passedr].row[passedc] = player
                        break
                    else:
                        passed.append((r, c))
                    r += rstep
                    c += cstep
                ok = ok or bool(passed)
        if not ok:
            return None
        return copy

    def __iter__(self):
        return iter(self.board)
    def __len__(self):
        return len(self.board)

    def __getitem__(self, r):
        return self.board[r]
    
    def count(self, piece):
        return sum(sum(1 for p in row if p == piece) for row in self.board)
    @property
    def black_count(self):
        return self.count(BLACK)
    @property
    def white_count(self):
        return self.count(WHITE)
    @property
    def blank_count(self):
        return self.count(BLANK)
    
    def legal_moves(self, player):
        if player in self._legal:
            return list(self._legal[player])
        moves = []
        N = len(self)
        for origr, row in enumerate(self.board):
            for origc, piece in enumerate(row):
                if self[origr][origc] == BLANK:
                    for rstep in range(-1, 2):
                        for cstep in range(-1, 2):
                            r = origr + rstep
                            c = origc + cstep
                            seen_other = False
                            while 0 <= r < N and 0 <= c < N:
                                if self[r][c] == BLANK:
                                    break
                                elif self[r][c] == player:
                                    if seen_other:
                                        moves.append(Move(origr, origc))
                                    break
                                else:
                                    seen_other = True
                                r += rstep
                                c += cstep
        self._legal[player] = tuple(moves)
        return moves
    def __repr__(self):
        return "\n".join(map(str, self.board))
    def __str__(self):
        return repr(self)
    class Row:
        def __init__(self, row):
            self.row = list(row)
        
        def __getitem__(self, c):
            return self.row[c]
        #def __setitem__(self, c, v):
        #    self.row[c] = v
        def __len__(self):
            return len(self.row)
        def __iter__(self):
            return iter(self.row)
        
        def copy(self):
            return self.__class__(self.row)
        
        def __repr__(self):
            return "|" + " ".join(self.row) + "|"
        def __str__(self):
            return repr(self)
                
        

class Move:
    def __init__(self, r, c):
        self.r = r
        self.c = c
    @classmethod
    def from_integer(cls, x):
        return cls(x // 10 - 1, x % 10 - 1)
    def to_integer(self):
        return (self.r + 1) * 10 + (self.c + 1)
    def __repr__(self):
        return "Move(%r, %r)" %(self.r, self.c)
    def __str__(self):
        return repr(self)

class Strategy:
    def best_strategy(self, board, player, best_move, still_running):
        opponent = (BLACK if player == WHITE else BLACK)
        board = Board("".join(board))
        legal_moves = board.legal_moves(player)
        
        after_counts = {}
        good_moves = []
        best = None
        
        for move in legal_moves:
            after_move = board.after_move(move, player)
            if not after_move.count(opponent): #Immediate win
                best_move.value = move.to_integer()
                return
            elif move.r in [0, 7] and move.c in [0, 7]: #Corner
                best_move.value = move.to_integer()
                return
            elif move.r in [0, 7] or move.c in [0, 7]: #Side
                good_moves.append(move)
            else:
                after_counts[move] = (after_move.count(player), after_move.count(opponent))
        if after_counts:
            max_player = max(counts[0] for counts in after_counts.values())
            min_opponent = min(counts[1] for counts in after_counts.values())
            good_moves.extend(move for move, counts in after_counts.items() if counts[1] == min_opponent)
        best_move.value = random.choice(good_moves).to_integer()
