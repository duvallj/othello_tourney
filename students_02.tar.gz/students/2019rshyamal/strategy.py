# 0  1  2  3  4  5  6  7
# 8  9  10 11 12 13 14 15
# 16 17 18 19 20 21 22 23
# 24 25 26 o  x  29 30 31
# 32 33 34 x  o  37 38 39
# 40 41 42 43 44 45 46 47
# 48 49 50 51 52 53 54 55
# 56 57 58 59 60 61 62 63

def printBoard(board):
    for i in range(8):
        print(*board[(i*8):((i+1)*8)])

def sameRow(one, two):
    return two//8 == one//8

def sameCol(one, two):
    return two%8 == one%8

def sameDiag(one, two):
    diag1, diag2 = getDiag(two)
    return one in diag1 or one in diag2
    
def getRow(move):
    rowNum = move//8
    return list(range(8*rowNum, (8*rowNum)+8))

def getCol(move):
    rowCol = move%8
    return list(range(rowCol, 64-rowCol, 8))

def getDiag(move):
    myDiags = {0: ([0], [0, 9, 18, 27, 36, 45, 54, 63]), 1: ([1, 8], [1, 10, 19, 28, 37, 46, 55]), 2: ([2, 9, 16], [2, 11, 20, 29, 38, 47]), 3: ([3, 10, 17, 24], [3, 12, 21, 30, 39]), 4: ([4, 11, 18, 25, 32], [4, 13, 22, 31]), 5: ([5, 12, 19, 26, 33, 40], [5, 14, 23]), 
    6: ([6, 13, 20, 27, 34, 41, 48], [6, 15]), 7: ([7, 14, 21, 28, 35, 42, 49, 56], [7]), 8: ([1, 8], [8, 17, 26, 35, 44, 53, 62]), 9: ([2, 9, 16], [0, 9, 18, 27, 36, 45, 54, 63]), 10: ([3, 10, 17, 24], [1, 10, 19, 28, 37, 46, 55]), 11: ([4, 11, 18, 25, 32], [2, 11, 20, 29, 38, 47]), 
    12: ([5, 12, 19, 26, 33, 40], [3, 12, 21, 30, 39]), 13: ([6, 13, 20, 27, 34, 41, 48], [4, 13, 22, 31]), 14: ([7, 14, 21, 28, 35, 42, 49, 56], [5, 14, 23]), 15: ([15, 22, 29, 36, 43, 50, 57], [6, 15]), 16: ([2, 9, 16], [16, 25, 34, 43, 52, 61]), 
    17: ([3, 10, 17, 24], [8, 17, 26, 35, 44, 53, 62]), 18: ([4, 11, 18, 25, 32], [0, 9, 18, 27, 36, 45, 54, 63]), 19: ([5, 12, 19, 26, 33, 40], [1, 10, 19, 28, 37, 46, 55]), 20: ([6, 13, 20, 27, 34, 41, 48], [2, 11, 20, 29, 38, 47]), 
    21: ([7, 14, 21, 28, 35, 42, 49, 56], [3, 12, 21, 30, 39]), 22: ([15, 22, 29, 36, 43, 50, 57], [4, 13, 22, 31]), 23: ([23, 30, 37, 44, 51, 58], [5, 14, 23]), 24: ([3, 10, 17, 24], [24, 33, 42, 51, 60]), 25: ([4, 11, 18, 25, 32], [16, 25, 34, 43, 52, 61]), 
    26: ([5, 12, 19, 26, 33, 40], [8, 17, 26, 35, 44, 53, 62]), 27: ([6, 13, 20, 27, 34, 41, 48], [0, 9, 18, 27, 36, 45, 54, 63]), 28: ([7, 14, 21, 28, 35, 42, 49, 56], [1, 10, 19, 28, 37, 46, 55]), 29: ([15, 22, 29, 36, 43, 50, 57], [2, 11, 20, 29, 38, 47]), 
    30: ([23, 30, 37, 44, 51, 58], [3, 12, 21, 30, 39]), 31: ([31, 38, 45, 52, 59], [4, 13, 22, 31]), 32: ([4, 11, 18, 25, 32], [32, 41, 50, 59]), 33: ([5, 12, 19, 26, 33, 40], [24, 33, 42, 51, 60]), 34: ([6, 13, 20, 27, 34, 41, 48], [16, 25, 34, 43, 52, 61]), 
    35: ([7, 14, 21, 28, 35, 42, 49, 56], [8, 17, 26, 35, 44, 53, 62]), 36: ([15, 22, 29, 36, 43, 50, 57], [0, 9, 18, 27, 36, 45, 54, 63]), 37: ([23, 30, 37, 44, 51, 58], [1, 10, 19, 28, 37, 46, 55]), 38: ([31, 38, 45, 52, 59], [2, 11, 20, 29, 38, 47]), 
    39: ([39, 46, 53, 60], [3, 12, 21, 30, 39]), 40: ([5, 12, 19, 26, 33, 40], [40, 49, 58]), 41: ([6, 13, 20, 27, 34, 41, 48], [32, 41, 50, 59]), 42: ([7, 14, 21, 28, 35, 42, 49, 56], [24, 33, 42, 51, 60]), 43: ([15, 22, 29, 36, 43, 50, 57], [16, 25, 34, 43, 52, 61]), 
    44: ([23, 30, 37, 44, 51, 58], [8, 17, 26, 35, 44, 53, 62]), 45: ([31, 38, 45, 52, 59], [0, 9, 18, 27, 36, 45, 54, 63]), 46: ([39, 46, 53, 60], [1, 10, 19, 28, 37, 46, 55]), 47: ([47, 54, 61], [2, 11, 20, 29, 38, 47]), 48: ([6, 13, 20, 27, 34, 41, 48], [48, 57]),
    49: ([7, 14, 21, 28, 35, 42, 49, 56], [40, 49, 58]), 50: ([15, 22, 29, 36, 43, 50, 57], [32, 41, 50, 59]), 51: ([23, 30, 37, 44, 51, 58], [24, 33, 42, 51, 60]), 52: ([31, 38, 45, 52, 59], [16, 25, 34, 43, 52, 61]), 53: ([39, 46, 53, 60], [8, 17, 26, 35, 44, 53, 62]), 
    54: ([47, 54, 61], [0, 9, 18, 27, 36, 45, 54, 63]), 55: ([55, 62], [1, 10, 19, 28, 37, 46, 55]), 56: ([7, 14, 21, 28, 35, 42, 49, 56], [56]), 57: ([15, 22, 29, 36, 43, 50, 57], [48, 57]), 58: ([23, 30, 37, 44, 51, 58], [40, 49, 58]), 59: ([31, 38, 45, 52, 59], [32, 41, 50, 59]), 
    60: ([39, 46, 53, 60], [24, 33, 42, 51, 60]), 61: ([47, 54, 61], [16, 25, 34, 43, 52, 61]), 62: ([55, 62], [8, 17, 26, 35, 44, 53, 62]), 63: ([63], [0, 9, 18, 27, 36, 45, 54, 63])}
    return myDiags[move][0], myDiags[move][1]

def getNeighbors(o):
    if o == 0:
        return [1,8,9]
    elif o == 7:
        return [6,15,14]
    elif o == 56:
        return [57,48,49]
    elif o == 63:
        return [62,55,54]
    elif o<8:
        return [o+1, o-1, o+8, o+7, o+9]
    elif o%8==0:
        return [o+1, o+8, o-8, o-7, o+9]
    elif o%8==7:
        return [o-1, o+8, o-8, o-9, o+7]
    elif o>56:
        return [o+1, o-1, o-8, o-7, o-9]
    else:
        return [o+1, o-1, o+8, o-8, o+7, o-7, o+9, o-9]

def makeMove(board, isXTurn, move):
    if isXTurn: my = 'x'; other = 'o'
    else: my = 'o'; other = 'x'
    flip = flipPieces(board, isXTurn, move)
    newBoard = board[:]
    for num in flip:
        newBoard[num] = my
    return newBoard

def flipPieces(board, isXTurn, move):
    flip = {move}
    if isXTurn:
        mypiece = "x"; other = "o"
    else:
        mypiece = "o"; other = "x"
    row = getRow(move)
    col = getCol(move)
    upDiag, downDiag = getDiag(move)
    own = [x for x,v in enumerate(board) if v==mypiece and (x in row or x in col or x in upDiag or x in downDiag) and x not in getNeighbors(move) and x != move]
    for o in own:
        if o in row:
            change = -1 if o > move else 1
        if o in col:
            change = -8 if o > move else 8
        if o in upDiag:
            change = -7 if o > move else 7
        if o in downDiag:
            change = -9 if o > move else 9
        tmp = o+change
        myset = set()
        flag = True
        while tmp != move:
            if board[tmp] == other:
                myset.add(tmp)
                tmp = tmp+change
            else:
                flag = False; break
        if flag:
            flip = flip | myset
    return flip

def legalMove(board, isXTurn, move):
    legal = False
    left_edge = [0,8,16,24,32,40,48,56]
    right_edge = [7,15,23,31,39,47,55,63]
    own = 'x' if isXTurn else 'o'
    other = 'o' if isXTurn else 'x'
    for neighbor in getNeighbors(move):
        found = False
        change = neighbor - move
        spot = neighbor
        piece = board[neighbor]
        movelist = [spot]
        if piece == '.' or piece == own:
            continue
        else:
            while not found:
                prev = spot
                spot += change
                movelist.append(spot)
                #print("spot", spot)
                if (change == 1 or change == -1) and spot//8 != prev//8:
                    found = True
                    break
                if spot < 0 or spot > 63 or board[spot] == '.':
                    found = True
                    break
                if (prev in left_edge and spot in right_edge) or (spot in left_edge and prev in right_edge):
                    found = True
                    break
                elif board[spot] == own:
                    legal = True
                    found = True
                    return legal
    return legal

def possibleMoves(board, isXTurn):
    if isXTurn:
        opponent = [o for o,val in enumerate(board) if val == 'o']
        own = [x for x,val in enumerate(board) if val == 'x']
        mypiece = 'x'
    else:
        opponent = [x for x,val in enumerate(board) if val == 'x']
        own = [o for o,val in enumerate(board) if val == 'o']
        mypiece = 'o'
    mySet = set()
    for o in opponent:
        for move in getNeighbors(o):
            if board[move] != '.':
                continue
            else:
                if legalMove(board, isXTurn, move):
                    mySet.add(move)
    return mySet

def strategy(board, isXTurn):
    import random
    pm = possibleMoves(board, isXTurn)
    #print(pm)
    corners = [0,7,56,63]
    edges = [0,1,2,3,4,5,6,7,0,8,16,24,32,40,48,56,7,15,23,31,39,47,55,63,56,57,58,59,60,61,62,63]
    bad = [1,8,6,15,48,57,55,62,9,14,49,54]
    for x in corners:
        if x in pm:
            return x
    goodMoves = set(pm)
    for b in bad:
        if b in goodMoves:
            goodMoves.remove(b)
    tmp = {"".join(makeMove(board, isXTurn, m)):m for m in pm}
    for mm in tmp:
        for p in possibleMoves(mm, not isXTurn):
            if (p in corners or p in edges) and tmp[mm] in goodMoves:
                goodMoves.remove(tmp[mm])
    if len(goodMoves) > 0:
        scores = {boardEval(makeMove(board[:], isXTurn, move), isXTurn):move for move in goodMoves}
        mobility = {len(possibleMoves(makeMove(board[:], isXTurn, move), not isXTurn)):move for move in goodMoves}
        sortedScores = sorted(scores)
        sortedMobility = sorted(mobility)
        optimal = {x-y:scores[x] for x in sortedScores for y in sortedMobility if scores[x] == mobility[y]}
        return optimal[max(optimal)]
    else:
        if pm:
            return random.choice(list(pm))
        else:
            return(random.choice([x for x in board if x == '.']))

def negamax(board, isXTurn, level):
    import random
    if level == 0 or 'x' not in board or 'o' not in board or '.' not in board: 
        #printBoard(board)
        #print(getScore(board))
        return [boardEval(board, isXTurn)]
    lm = possibleMoves(board[:], isXTurn)
    #print(lm)
    if not lm:
        nm = negamax(board[:], not isXTurn, level-1) + [-1]
        #print('nm', nm)
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makeMove(board[:], isXTurn, move), not isXTurn, level-1)+[move] for move in lm])
    if level==5:
        winList = [x for x in nmList if x[0] < 0]
        if not winList:
            bestMove = nmList[0]
            return [-bestMove[0]] + bestMove[1:]
        corners = [0,7,56,63]
        edges = [0,1,2,3,4,5,6,7,0,8,16,24,32,40,48,56,7,15,23,31,39,47,55,63,56,57,58,59,60,61,62,63]
        bad = [1,8,6,15,48,57,55,62,9,14,49,54]
        better = [x for x in winList if ((x[-1] in corners or x[-1] in edges)and x[-1] not in bad)]
        if not better:
            newMobility = {len(possibleMoves(makeMove(board[:], isXTurn, move[-1]), not isXTurn)):move for move in winList}
            bestMove = newMobility[min(newMobility)]
            return [-bestMove[0]] + bestMove[1:]
        else:
            mobility = {len(possibleMoves(makeMove(board[:], isXTurn, move[-1]), not isXTurn)):move for move in better}
            bestMove = mobility[min(mobility)]
            return [-bestMove[0]] + bestMove[1:]
    else:
        bestMove = nmList[0]
        return [-bestMove[0]] + bestMove[1:]


def negamaxTerminal(board, isXTurn, improvable, hardBound):
    lm = possibleMoves(board[:], isXTurn)
    if not lm:
        lm = possibleMoves(board[:], not isXTurn)
        if not lm:
            return [boardEval(board[:], isXTurn), -3] #-3 means game over
        nm = negamaxTerminal(board[:], not isXTurn, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHardBound = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(board[:], isXTurn, mv), not isXTurn, -hardBound, newHardBound) + [mv]
        if not best or nm[0]<newHardBound:
            best = nm
            if nm[0] < newHardBound:
                newHardBound = nm[0]
                if -newHardBound >= hardBound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]

def boardEval(board, isXTurn):
    if isXTurn: my = 'x'; other = 'o'
    else: my = 'o'; other = 'x'
    brd = "".join(board)
    return brd.count(my) - brd.count(other)

def getScore(board):
    return "".join(board).count("x"), "".join(board).count("o")

def bestMove(board, isXTurn):
    #return (negamax(board, isXTurn, 5))
    if "".join(board).count(".") <= 11:
        nm = (negamax(board, isXTurn,"".join(board).count('.')*2))
        #print('nm:', nm)
        #print('nm[-1]', nm[-1])
        if board[nm[-1]] != '.' or nm[-1] == -1:
            return strategy(board, isXTurn)
        else:
            return nm[-1]
    else:
        return strategy(board, isXTurn)

class Strategy():
    def best_strategy(self, board, player, best_move, running):
        if running.value:
            myBoard = list("".join(board).replace("?", "").replace("@", "x").lower())
            myPlayer = player.replace("@", "x").lower()
            isXTurn = myPlayer == 'x'
            bm = strategy(myBoard[:], isXTurn)
            best_move.value = 11+(bm//8)*10 + (bm%8)
            mv = negamax(myBoard[:], isXTurn, 5)[-1]
            best_move.value = 11+(mv//8)*10 + (mv%8)

        

if __name__ == '__main__':
    import sys
    import random
    if len(sys.argv) == 1:
        board = list('...........................ox......xo...........................')
        isXTurn = True
    else:
        if len(sys.argv[1]) < 3:
            board = list('...........................ox......xo...........................')
            isXTurn = sys.argv[1].lower() == 'x'
        else:
            board = list(sys.argv[1].lower())
            isXTurn = sys.argv[2].lower() == 'x'
    printBoard(board)
    bm = strategy(board[:], isXTurn)
    print(11+(bm//8)*10 + (bm%8))
    mv = negamax(board[:], isXTurn, 5)[-1]
    print(11+(mv//8)*10 + (mv%8))
