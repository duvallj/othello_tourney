#Jan 12, 0952 version
#Sagar Saxena
import random
import math
import time

#### Othello Shell
#### P. White 2016-2018

#f = open("o.txt","w")

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
OTHER = {BLACK:WHITE, WHITE:BLACK, "T":"T"}
NORM = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
STD = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
OPT = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -50,  20,  15,  15,  20, -50, 120,   0,
    0, -50, -50, -15, -10, -10, -15, -50, -50,   0,
    0,  20, -15,  15,   5,   5,  15, -15,  20,   0,
    0,  15, -10,   5,   5,   5,   5, -10,  15,   0,
    0,  15, -10,   5,   5,   5,   5, -10,  15,   0,
    0,  20, -15,  15,   5,   5,  15, -15,  20,   0,
    0, -50, -50, -15, -10, -10, -15, -50, -50,   0,
    0, 120, -50,  20,  15,  15,  20, -50, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
RD = {-2:(1,13),-1:(2,7),3:(4,12),4:(4,12),5:(5,12)}
assumeMinTime = True
currTime = 5
assumeOppStrat = STD
assumeOppWeight = True
enableGhostMode = False
myWeight = STD
assumeMinMax = False
enableDeception = False
fourCornerStrat = False
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
from collections import deque
class node:
    def __init__(self,board,move,score = -2,moves=[]):
        self.board = board
        self.last_move = move
        self.score = score
        self.moves = moves
        self.finScore = 1

class Strategy():

    def __init__(self,weight_type=NORM):
        self.SCORING = weight_type
        self.SCORING_SET = False
        pass
    def set_weight_type(self,weight_type=NORM):
        self.SCORING_SET = True
        self.SCORING = weight_type
    def get_starting_board(self):
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
        #"""Create a new board with the initial black and white positions filled."""
        #pass
    def get_pretty_board(self,board):
        return ''.join([board[i] if board[i]!="?" else "\n" if i%10!=0 else "" for i in range(10,90)])
        #"""Get a string representation of the board."""
        #pass

    def opponent(self, player):
        return OTHER[player]
        """Get player's opponent."""
        pass

    def find_match(self, board, player, square, direction):
        #print(board,player,square,direction)
        i = square+direction
        while(board[i]==OTHER[player]): i+=direction
        if(board[i] == player and i!=square+direction): return True
        return False

    def is_move_valid(self, board, player, move):
        if(board[move] != EMPTY): return False
        for d in DIRECTIONS:
            if self.find_match(board,player,move,d): return True
        return False
        pass
    def move(self, board, player, move):
        board = board[0:move] + player + board[move+1:100]
        return board
    def make_move(self, board, player, move):
        board = self.move(board,player,move)
        for d in DIRECTIONS:
            if self.find_match(board,player,move,d):
                i = move+d
                while(board[i] == OTHER[player]):
                    board = self.move(board,player,i)
                    i+=d
        return board
        pass

    def get_valid_moves(self, board, player, smart_score = False):
        #print(board,player,smart_score)
        if(smart_score):
            a = [j for j in [11,18,81,88] if board[j] == EMPTY and self.is_move_valid(board,player,j)]
            if(len(a) > 0): return a
        return [j for j in range(11,89) if board[j] == EMPTY and self.is_move_valid(board,player,j)]
        """Get a list of all legal moves for player."""
        pass

    def has_any_valid_moves(self, board, player):
        if len(self.get_valid_moves(board,player))>0: return True
        return False
        """Can player make any moves?"""
        pass

    def next_player(self, board, prev_player):
        if(self.has_any_valid_moves(board,OTHER[prev_player])): return OTHER[prev_player]
        elif(self.has_any_valid_moves(board,prev_player)): return prev_player
        return None
        """Which player should move next?  Returns None if no legal moves exist."""
        pass
    def dots(self,board):
        return len([i for i in board if i == EMPTY])
    def spread(self,score,board,player,ind,dirs,spWeight):
        if(board[ind] != player): return
        count = 1
        req = 1
        lis = set([ind])
        while(len(lis) == req and req<=15):
            temp = set()
            req += 2
            for ind in lis:
                for d in dirs:
                    if(board[ind+d] == player): temp.add(ind+d)
                    score[ind+d] = spWeight
            lis = temp

    def update(self,score,board,player,spWeight):
        self.spread(score,board,player,11,[S,E,SE],spWeight)
        self.spread(score,board,player,18,[S,W,SW],spWeight)
        self.spread(score,board,player,81,[N,E,NE],spWeight)
        self.spread(score,board,player,88,[N,W,NW],spWeight)
        return score
    def check(self,board,locs,player):
        for loc in locs: 
            if(board[loc]!=player): return False
        return True 
    def score(self, board, player=BLACK,scoring=None,weight=False):
        '''if(smart_score): return self.SMART_SCORE[player] - self.SMART_SCORE[OTHER[player]]
        else: return self.SCORE[player] - self.SCORE[OTHER[player]]'''
        if(scoring==None): scoring = self.SCORING
        s = {WHITE:0,BLACK:0}
        if(fourCornerStrat and self.check(board,[11,18,81,88],player)): 
            scoring = NORM
            spWeight = 3
        else: spWeight = 20
        if(weight==True): scoring = self.update([i for i in scoring],board,player,spWeight)
        for i in range(10,100):
            if(board[i] != EMPTY and board[i] != OUTER): 
                s[board[i]]+= scoring[i]
        return s[player] - s[OTHER[player]]
        """Compute player's score (number of player's pieces minus opponent's)."""
        pass

    def game_over(self, board, player):
        if(self.next_player(board,player) == None): return True
        return False
        """Return true if player and opponent have no valid moves"""
        pass

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def negamaxTerminal(self,board,player,improvable,hardbound,weight=False,weight_type=NORM,depth=0,limit=-1):
        if(limit!=-1 and depth>limit): return[self.score(board,player,weight_type,weight)+random.random(),-4]
        if(limit!=-1): #equivalent to master weight
            if(player==self.player):
                self.set_weight_type(weight_type)
                weight = True
            else:
                self.set_weight_type(assumeOppStrat)
                weight = assumeOppWeight

        lm = self.get_valid_moves(board,player,weight)#legalMoves(board,player)
        if len(lm)==0:
            lm = self.get_valid_moves(board,OTHER[player],weight)
            if len(lm)==0: return[self.score(board,player,weight_type,weight)+random.random(),-3] #Game Over
            nm = self.negamaxTerminal(board,OTHER[player],-hardbound,-improvable,weight,weight_type,depth+1,limit) + [-1] #Pass Turn
            return [-nm[0]]+nm[1:] #return -nm to flip score
        best = [] #what gets returned
        newHB = -improvable #hard bound is negative improvable
        for mv in lm:
            nm = self.negamaxTerminal(self.make_move(board,player,mv),OTHER[player],-hardbound,newHB,weight,weight_type,depth+1,limit) + [mv]
            if len(best)==0 or nm[0] < newHB:
                best = nm
                if nm[0] < newHB:
                    newHB = nm[0]
                    if -newHB > hardbound: return[-best[0]] + best[1:] #return -best[0] to flip score
        return[-best[0]] + best[1:] #return -best[0] to flip score

    def minmax_search(self, n, player, depth, limit, weight=False, pcg=False,weight_type=STD):
        # assume that STD is always baseline and other player makes decisions on that
        board = n.board
        lis = []
        if(pcg):
            lis = [j for j in n.moves]
            if(n.last_move != -1): lis.append(n.last_move)
        if(player == self.player and weight): 
            self.set_weight_type(weight_type)
        elif(weight): 
            self.set_weight_type(STD)
            weight = False
        else:
            self.set_weight_type(NORM)
            weight = False

        #check depth
        if (depth >= limit and limit != -1) or self.game_over(board,player):
            n.score = self.score(board,weight=weight)
            if(pcg): n.finScore = self.score(board,self.player,NORM)
            return n
        #Check Children
        children = [node(self.make_move(board,player,i),i,moves=[j for j in lis]) for i in self.get_valid_moves(board,player,weight)]
        if len(children) == 0:
            d = self.minmax_search(node(''.join([i for i in board]),-1,moves=[j for j in lis]), OTHER[player],depth+1,limit,True^pcg,pcg,weight_type)
            return d
        #Choose Child
        #print(len(children))
        for c in children: 
            d = self.minmax_search(c,OTHER[player],depth+1,limit,True^pcg,pcg,weight_type)
            c.score = d.score
            c.finScore = d.finScore
            c.moves = d.moves
        if(player==BLACK): return max(children, key=lambda c:c.score+random.random())
        else: return min(children, key = lambda c:c.score+random.random())
        pass

    def minmax_strategy(self, board, player, depth=5,weight=False,pcg=False,weight_type=NORM):
        if board==self.get_starting_board(): 
            m = random.choice(self.get_valid_moves(board,player))
            return node(board = None,move = m,score=1,moves=[m])
        return self.minmax_search(n=node(board,-1),player=player,depth=0,limit=depth,weight=weight,pcg=pcg,weight_type=weight_type)
    
    def minmax_weighted_strategy(self,board,player,depth=5,pcg=False,weight_type=STD,weight=True):
        self.set_weight_type(weight_type)
        return self.minmax_strategy(board,player,depth,weight,pcg,weight_type)

    def random_strategy(self, board, player, best_move = None, waste = None):
        if(best_move == None): return random.choice(self.get_valid_moves(board, player))
        else: best_move.value = random.choice(self.get_valid_moves(board,player))

    def best_strategy_dark(self,board,player,best_move,stll_running):
        d = self.dots(board)
        if(d>RD[currTime][1]):
            best_move.value = self.random_strategy(board,player)
            return
        else:
            dt = time.time()
            f = open("PredictWin.txt","a")
            n = self.negamaxTerminal(board,player,-1*math.inf,math.inf,False,NORM,0,-1)
            if(n[0] > 0): winner = player
            elif(n[1] < 0): winner = OTHER[player]
            else: winner = "T"
            #Board Player Move Winner Path
            f.write(str(d)+"\t"+board+"\t"+player+"\t"+str(n[-1])+"\t"+winner+"\t"+str(n[1:])+"\n")
            flip = ''.join([BLACK if i == WHITE else WHITE if i == BLACK else i for i in board])
            f.write(str(d)+"\t"+flip+"\t"+OTHER[player]+"\t"+str(n[-1])+"\t"+OTHER[winner]+"\t"+str(n[1:])+"\n")
            f.close()
            best_move.value = n[-1]

    def best_strategy(self, b, player, best_move, still_running):
        board = ''.join(b)
        self.player = player
        if(enableGhostMode): return self.best_strategy_dark(board,player,best_move,still_running)
        best_move.value = self.random_strategy(board,player)
        if(enableDeception): return True
        #############real code#################
        #assumeMinTime=True
        d = self.dots(board)
        if(d>3 and assumeMinTime): depth = RD[currTime][0]
        else: depth=1
        if(assumeMinTime and d<=RD[currTime][1]):
            n = node(None,self.negamaxTerminal(board,player,-1*math.inf,math.inf,False,NORM,0,-1)[-1])#n = self.minmax_weighted_strategy(b,player,depth,True,NORM,False) 
            best_move.value = n.last_move
            print("assumeMinTime")
        else:
            while(depth <= d):
                if(assumeMinMax): n = self.minmax_weighted_strategy(board,player,depth,False,STD,True)
                else: n = node(None,self.negamaxTerminal(board,player,-1*math.inf,math.inf,True,myWeight,0,depth)[-1])
                best_move.value = n.last_move
                print(depth)
                depth += 1
    def set_player(self,player):
        self.player = player
    standard_strategy = best_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process, Array
import os, signal
silent = False

#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self,display=True):
        self.display = display
        pass

    def play(self,waste=0):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        if(self.display): print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.minmax_weighted_strategy_opt, WHITE: white.minmax_strategy}
        if(self.display): print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            if(self.display): print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            if(self.display): print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))
        return ref.score(board)



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
def convert(board):
    return '?'*10 + ''.join(['?'+board[i] if i%8==0 else board[i]+'?' if i%8==7 else board[i] for i in range(len(board))]) + '?'*10
def convertBack(board):
    return ''.join(["" if i == "?" else "O" if i == "o" else "X" if i == "@" else i for i in board])
def by8(pos):
    return pos%10+8*(pos//10)-9
class NewPlayer():
    def __init__(self,board,player,time_limit):
        self.board = board
        self.player = player 
        self.strat = Strategy()
        self.time_limit = time_limit
        print(convertBack(self.strat.get_pretty_board(self.board)))
        print("Legal Moves: ", [by8(i) for i in self.strat.get_valid_moves(self.board,self.player)])

    def play(self):
        if(self.strat.dots(self.board)>RD[currTime][1]):
            self.strat.set_player(self.player)
            r = self.strat.negamaxTerminal(board,player,-1*math.inf,math.inf,True,myWeight,0,RD[currTime][0])
        else:
            r = self.strat.negamaxTerminal(board,player,-1*math.inf,math.inf,False,NORM,0,-1)
        n = node(None,r[-1])
        n.finScore = r[0]
        n.moves = r[1:]  

        move = by8(n.last_move)
        score = n.finScore
        path = [by8(i) for i in n.moves]
        
        if len(path) == 0: path.append(move)
        print("Heuristic Chooses:", move)
        print("alpabeta", score, path, "and move", move)

class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self,waste=0):
        ref = Strategy()
        if not silent: print("play")
        board = ref.get_starting_board()
        player = BLACK
        if not silent: print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        if not silent: print("Final Score %i." % ref.score(board), end=" ")
        if not silent: print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))
        return ref.score(board)
import sys
if __name__ == "__main__":
    '''print("Options Enabled")
    print("Min Time Enabled:",assumeMinTime)
    print("Reachable Depth:", RD[currTime])
    print("Current Min Time:", currTime)
    print("My Strategy:",myWeight)
    print("Opponent Strategy:",assumeOppStrat)
    print("Opponent Weight Enabled:",assumeOppWeight)
    print("Ghost Mode Enabled:",enableGhostMode)'''
    '''Notation = {"x": BLACK, "o": WHITE}
    board = convert(sys.argv[1].lower().replace("x","@"))
    player = Notation[sys.argv[2].lower()]
    game = NewPlayer(board,player,-1)
    game.play()'''
    while(True):
        game = ParallelPlayer(currTime)
        game.play()
    #for i in range(10):
    '''if(enableGhostMode):
        i = 0
        run = True
        dt = time.time()
        while(run):
            silent = True
            print("Trial",i,end=" ")
            dt2 = time.time()
            try: 
                game =  ParallelPlayer(90)
                game.play()
                print("Passed",time.time()-dt2,time.time()-dt)
            except KeyboardInterrupt:
                print("Stopped",time.time()-dt2,time.time()-dt)
                run = False
            except:
                print("Failed",time.time()-dt2,time.time()-dt)
            i+=1'''
    #print(time.time()-dt)
    game.play()
    #analyze(game,int(input("Trials?")))