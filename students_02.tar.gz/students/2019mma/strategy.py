import sys
import time

INNER = 1
SAFE = 2
CORNER = 3
n = 7
start = time.time()

def printgame(game):
	return '\n'.join([game[i*8 : i*8 + 8] for i in range(8)])

def basicTurn(game):
	return 'o' if game.count('.') % 2 else 'x'
	
def isCorner(i):
	return i in [0, 7, 56, 63]
	
def isSafeEdge(board, i):
	score = 0
	dir = 0
	next = i
	if (not i % 8) or (not (i + 1) % 8):
		dir = 8
	elif i < 8 or i >= 56:
		dir = 1
	else:
		return False
	while board[next] == turn:
		if next in [0, 7, 56, 63]:
			return True
		next += dir
	while board[next] == turn:
		if next in [0, 7, 56, 63]:
			return True
		next -= dir
	return False
	
def isInner(i):
	return i >= 8 and i < 56 and i % 8 and (i + 1) % 8
	
def replaceInd(board, i, v):
	return board[:i] + v + board[i + 1:]

def evalBoard(board, token, enemy):
	return board.count(token) - board.count(enemy) #placeholder heuristic
	
def legalMove(board, token, i):
	if board[i] == '.':
		for n in neighbors[i]:
			if board[n] != '.' and board[n] != token:
				dir = n - i
				next = n + dir
				prev = n
				if abs(dir) == 1:
					while next//8 == i//8 and board[next] != '.':
						if board[next] == token:
							return True
						next += dir
				elif abs(dir) == 8:
					while next >= 0 and next < 64 and board[next] != '.':
						if board[next] == token:
							return True
						next += dir
				else:
					while next >= 0 and next < 64 and abs(next//8 - prev//8) == 1 and board[next] != '.':
						if board[next] == token:
							return True
						prev = next
						next += dir
	return False
	
def makeMove(board, turn, i):
	pos = []
	if board[i] == '.':
		for n in neighbors[i]:
			if board[n] != '.' and board[n] != turn:
				dir = n - i
				next = n + dir
				prev = n
				sub = [prev]
				if abs(dir) == 1:
					while next//8 == i//8 and board[next] != '.':
						if board[next] == turn:
							pos += sub
							break
						sub.append(next)
						next += dir
				elif abs(dir) == 8:
					while next >= 0 and next < 64 and board[next] != '.':
						if board[next] == turn:
							pos += sub
							break
						sub.append(next)
						next += dir
				else:
					while next >= 0 and next < 64 and abs(next//8 - prev//8) == 1 and board[next] != '.':
						if board[next] == turn:
							pos += sub
							break
						sub.append(next)
						prev = next
						next += dir
	if pos:
		for f in [i] + pos:
			board = replaceInd(f, turn)
	return board
	
def legalMoves(board, token):
	return [i for i in range(64) if legalMove(board, token, i)]
	
def negamax(board, token, enemy, levels): #board, token, how many levels to go down.
	if not levels: #done
		return [evalBoard(board, token, enemy)]
	lm = legalMoves(board, token)
	if not lm: #pass
		nm = negamax(board, enemy, token, levels-1) + [-1]
		return [-nm[0]] + nm[1:]
	nmList = sorted([negamax(makeMove(board, token, mv), enemy, token, levels-1) + [mv] for mv in lm])
	best = nmList[0]
	return [-best[0]] + best[1:]

neighbors = {}

for i in range(64):
	neighbors[i] = []
	if i % 8:
		neighbors[i] += [i - 1]
	if (i + 1) % 8:
		neighbors[i] += [i + 1]
	if i > 7:
		neighbors[i] += [i - 8]
		if i - 1 in neighbors[i]:
			neighbors[i] += [i - 9]
		if i + 1 in neighbors[i]:
			neighbors[i] += [i - 7]
	if i < 56:
		neighbors[i] += [i + 8]
		if i - 1 in neighbors[i]:
			neighbors[i] += [i + 7]
		if i + 1 in neighbors[i]:
			neighbors[i] += [i + 9]

class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		brd = ''.join(board).replace('?','').replace('@', 'x')
		token, enemy = ('x', 'o') if player == '@' else ('o', 'x')
		pos = legalMoves(brd, token)
		mv = pos[0]
		mv1 = 11 + (mv//8)*10 + (mv%8)
		best_move.value = mv1
		if brd.count('.') > n: #use heuristic
			bestmove = 0
			xc = []
			for j in [0, 7, 56, 63]:
				xc += [n for n in neighbors[j]]
			for possible in pos:
				brd = replaceInd(brd, possible, '*')
				if isCorner(possible):
					mv = possible
					bestmove = CORNER
				if possible in xc:
					continue
				if not isInner(possible): # is edge
					if isSafeEdge(brd, possible) and bestmove < CORNER:
						mv = possible
						bestmove = SAFE
					elif bestmove == 0:
						mv = possible # non safe edge better than x or c pos
				else: #inner pos
					if bestmove < SAFE:
						mv = possible
						bestmove = INNER
		else: #use negamax
			mv = negamax(brd, token, enemy, n*2)[-1]
		mv1 = 11 + (mv//8)*10 + (mv%8)
		best_move.value = mv1
			
def main():
	board = '.'*27+'OX'+'.'*6+'XO'+'.'*27
	turn = ''

	for arg in sys.argv[1:]:
		if arg.upper() in ('X', 'O'):
			turn = arg
		else:
			board = arg

	if not turn:
		turn = basicTurn(board)

	turn = turn.lower()
	board = board.lower()
	
	enemy = 'x' if turn == 'o' else 'o'
	pos = legalMoves(board, turn)

	print(printgame(board))
	print("Legal Moves: " + ", ".join([str(p) for p in pos]))

	if board.count('.') > n: #use heuristic
		bestmove = 0
		bestpos = pos[0]
		xc = []
		for j in [0, 7, 56, 63]:
			xc += [n for n in neighbors[j]]

		for possible in pos:
			board = replaceInd(board, possible, '*')
			if isCorner(possible):
				bestpos = possible
				bestmove = CORNER
			if possible in xc:
				continue
			if not isInner(possible): # is edge
				if isSafeEdge(possible) and bestmove < CORNER:
					bestpos = possible
					bestmove = SAFE
				elif bestmove == 0:
					bestpos = possible # non safe edge better than x or c pos
			else: #inner pos
				if bestmove < SAFE:
					bestpos = possible
					bestmove = INNER
		print("Heuristic Move: %s" % (bestpos))
	else: #use negamax
		ret = negamax(board, turn, enemy, n*2)
		print("Negamax score: %s and move is: %s" % (ret[0], ret[-1]))

	#print("Total Time Taken: %s" % (time.time() - start))

if __name__ == "__main__":
	main()
