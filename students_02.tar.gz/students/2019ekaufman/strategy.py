#Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
weights = [
0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
0, 120, 0,  20,   5,   5,  20, 0, 120,   0,
0, 0, 0,  -5,  -5,  -5,  -5, 0, 0,   0,
0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
0, 0, 0,  -5,  -5,  -5,  -5, 0, 0,   0,
0, 120, 0,  20,   5,   5,  20, 0, 120,   0,
0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
max_score = 656000
min_score = -656000

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        START_BOARD = "?"*10 + ("?"+"."*8+"?")*6 + "?"*10
        START_BOARD = START_BOARD[:40] + "?...o@...??...@o...?" + START_BOARD[40:]
        return START_BOARD

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pb = ""
        for x in range(10):
            pb += board[x*10:x*10+10] + "\n"
        print(pb)

    def opponent(self, player):
        """Get player's opponent."""
        return BLACK if player == WHITE else WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        current = square + direction # head one tile in direction
        if board[current] != self.opponent(player): # if that tile is not an opponent tile, no match
            return None
        current = square + direction # head one more tile in that direction
        while not(board[current] == OUTER or board[current] == EMPTY): # while current is a black or white tile
            if board[current] == player: # if it is another player tile, return the current square
                return current
            current = current + direction # if it's an opponent tile, keep on going
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] in [BLACK, WHITE, OUTER]:
            return False
        for d in DIRECTIONS:
            if self.find_match(board,player,move, d):
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        tochange = [move]
        if not self.is_move_valid(board, player, move):
            #RAISE AN ERROR MAYBE? IDK REALLY
            pass
        for d in DIRECTIONS:
            current = move + d
            ctochange = []
            while board[current] == self.opponent(player):
                ctochange.append(current)
                current += d
            if board[current] == player:
                tochange = tochange + ctochange
        changed = board
        #newchar = BLACK if player == BLACK else WHITE
        for s in tochange:
            changed = changed[:s] + player + changed[s+1:]
        return changed

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valids = []
        for i in [a for a in range(11,88) if not (a % 10 == 0 or a % 10 == 9)]:
            if self.is_move_valid(board, player, i):
                valids.append(i)
        return valids

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return True if len(self.get_valid_moves(board, player)) > 0 else False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
             return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def finalscore(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        score = 0
        for x in range(11,88):
            if board[x] == player:
                score += 1
            if board[x] == self.opponent(player):
                score -= 1
        return score

    def score(self, board, player=BLACK):
        score = 0
        for x in range(11,88):
            if board[x] == player:
                score += weights[x]
            if board[x] == self.opponent(player):
                score -= weights[x]
        return score

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return not( self.has_any_valid_moves(board,player) or self.has_any_valid_moves(board,self.opponent(player)))

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth, first_move, alpha = min_score, beta = max_score):
        # determine best move for player recursively

        if depth == 0: # if we're as far down the tree as we're willing to go
            return self.score(board) + random.random(), first_move # then return the board's score along with the first move of the subtree from the actual board
        #if self.game_over(board,player): # if there are no more moves down this path
        #    return self.score(board,player)*1000,first_move # designate this path as a winning/losing situation

        valid_moves = self.get_valid_moves(board,player) # list of valid moves

        children = []
        for move in valid_moves:
            #print(alpha, beta)
            child_first_move = move if first_move is None else first_move
            next_board = self.make_move(board,player,move)
            next_player = self.next_player(next_board,player)
            if next_player is None:
                tempscore = 1000*self.finalscore(next_board)
                children.append((tempscore, child_first_move))
            else:
                tempscore, tempmove = self.minmax_search(next_board, next_player, depth - 1, child_first_move, alpha, beta)
                if tempscore is None:
                    break
                if player == BLACK:
                    if tempscore > alpha:
                        alpha = tempscore
                if player == WHITE:
                    if tempscore < beta:
                        beta = tempscore
                if alpha < beta:
                    children.append((tempscore,tempmove))
        #call minmax and determine the scores for each of the children
        #valid_moves_with_scores = [self.minmax_search(self.make_move(board,player,x),self.next_player(self.make_move(board,player,x),player),depth-1, x if first_move is None else first_move) for x in valid_moves]

        if len(children) == 0:
            #print(depth, alpha, beta, )
            return None, None
            #if player == BLACK:
        best = {BLACK:max,WHITE:min }
        return best[player]([c for c in children if c is not None])
        #if player == BLACK: return max(children)
        #if player == WHITE: return min(children)

    def minmax_strategy(self, board, player, depth=7):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        board = "".join(board)
        result = self.minmax_search(board,player,depth,None)
        print(result)
        return result[1]

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an ewxample
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = minmax_strategy #random_strategy
