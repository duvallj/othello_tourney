import random
import math

#### Othello Shell
#### P. White 2016-2018
class Node:
    def __init__(self, board, move, player): #only score and board 
        self.board = board
        self.player = player
        self.move = move
        self.score = -1
        self.stability = False 
    def __lt__(self, other):
        return self.score < other.score

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
best = {BLACK : max, WHITE : min}
CORNERS = [12,19,82,89]

WEIGHTED_SCORE= [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 400, -500,  250,   200,   200,  250, -500, 400,   0,
    0, -500, -600,  -100,  -200,  -200,  -100, -600, -500,   0,
    0,  250,  -100,  60,   30,   30,  60,  -100,  250,   0,
    0,   200,  -100,   30,   30,   30,   30,  -100,   200,   0,
    0,   200,  -100,   30,   30,   30,   30,  -100,   200,   0,
    0,  250,  -100,  60,   30,   30,  60,  -100,  250,   0,
    0, -500, -600,  -100,  -200,  -200,  -100, -600, -500,   0,
    0, 400, -500,  250,   200,   200,  250, -500, 400,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
        
        """Create a new board with the initial black and white positions filled."""
        pass

    def get_pretty_board(self, board):
        #print("board", board)
        for x in range(10):
            temp = "" 
            for y in range(10):
                temp = temp + board[x*10+ y]
            print(temp)
                
        return "%s\n%s\n%s" % ( board[:3],board[3:6],board[6:])
        """Get a string representation of the board."""
        pass

    def opponent(self, player):
        if player is BLACK:
            return WHITE
        return BLACK
        """Get player's opponent."""

     
        

    def find_match(self, board, player, square, direction):
        tempsquare = -1
        x = square + direction
        #test = False
        while x < 90 and board[x] is self.opponent(player):
            tempsquare = x
            x = x+ direction
            #test = True
        if x < 90 and board[x] is EMPTY and tempsquare is not -1:
            return x
        else:
            return None
            
            
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        pass

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def make_move_helper(self, board, player, square, direction):
        tempsquare = -1
        x = square + direction
        if x > 100:
            print(x)
            print(direction)
        #test = False
        while x < 90 and board[x] is self.opponent(player):
            tempsquare = x
            x = x+ direction
            #test = True
        if x < 90 and board[x] is player and tempsquare is not -1:
            return x
        else:
            return None
    


    def make_move(self, board, player, move):
        #print(board)
        #print("MAKE MOVE")
        #board = str(board)
        
        #board_list = list(board)
        #print("move", move)
        #print("substring" ,board[:move])
        #s = "hello"
        #print(s[:2])
        tempboard = board[0:move] + player + board[move+1::]
        #print("Move2," , move)
        #print(tempboard)
        #board_list[move+d] = player
        #print(self.get_pretty_board(''.join(board_list)))
        for d in DIRECTIONS:
            temp = self.make_move_helper(tempboard, player, move, d)
            if temp is not None:
                while move+d is not temp:
                    tempboard = tempboard[0:move+d] + player + tempboard[move+d+1::]
                    #board_list[move+d] = player
                    move = move+d

        #print("tempboard")
        #self.get_pretty_board(tempboard)

        return tempboard
                    
            
            
        """Update the board to reflect the move by the specified player."""
        
        # returns a new board/string
        
    

    def get_valid_moves(self, board, player):
        #print("board",board)
        toReturn = set()
        #tempboard = list(board)
        current_player = [ x for x in range(len(board))if board[x] is player ]
        for p in current_player:
            for d in DIRECTIONS:
                temp = self.find_match(board, player, p, d)
                if temp is not None:
                    #print("hello")
                    toReturn.add(temp)
        #print("list", toReturn)
        return list(toReturn) 
        """Get a list of all legal moves for player."""
        

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        pass

    def is_stable(self, board, move, player):
        filled = True
        
        if move in CORNERS:
            return True
        for d in DIRECTIONS:
            temp = move
            #print(temp + d)
            #print(board[temp+d])
            if board[temp + d] is not "." or "?":
                temp = temp + d
            elif board[temp + d] is "?":
                #print("hello")
                num = 1
                
            else:
                filled = False
        if filled is True:
            return True
        l = []
        for d in DIRECTIONS:
            if move + d is BLACK or WHITE:
                l.append(move + d)
        for num in l:
            if self.is_stable(board, num, player) is True:
                return True

        return False 
            
            
    
    def stable(self, board, move, player):
        #is_stable = True
        
        temp = move
        north = False
        north_move = temp
        if move + N is not "." or "?":
            if board[north_move + N] is self.opponent(player):
                north = True 
            north_move = north_move + N
            
        south = False
        south_move = temp 
        if south_move + S is not "." or "?":
            if board[south_move + S] is self.opponent(player):
                south = True
            south_move = south_move + S

        if north or south is True:
            if north or south is False:
                #print("F")
                return False

        east = False
        east_move = temp
        if east_move + E is not "." or "?":
            if board[east_move + E] is self.opponent(player):
                east = True
            east_move = east_move + E

        west = False
        west_move = temp
        if west_move + W is not "." or "?":
            if board[west_move + W] is self.opponent(player):
                west = True
            west_move = west_move + E

        if east or west is True:
            if east or west is False:
                #print("False")
                return False

        northwest = False
        northwest_move = temp
        if northwest_move + NW is not "." or "?":
            if board[northwest_move + E] is self.opponent(player):
                northwest = True
            northwest_move = northwest_move + E

        southeast = False
        southeast_move = temp
        if southeast_move + SE is not "." or "?":
            if board[southeast_move + SE] is self.opponent(player):
                southeast = True
            southeast_move = southeast_move + SE

        if northwest or southeast is True:
            if northwest or southeast is False:
                #print("F")
                return False

        northeast = False
        northeast_move = temp
        if northeast_move + NE is not "." or "?":
            if board[northeast_move + NE] is self.opponent(player):
                northeast = True
            northeast_move = northeast_move + E

        southwest = False
        southwest_move = temp
        if southwest_move + SW is not "." or "?":
            if board[southwest_move + SW] is self.opponent(player):
                southwest = True
            southwest_move = southwest_move + E

        if northeast or southwest is True:
            if northeast or southwest is False:
                #print("F")
                return False

        

            
                
                
                
            
        #print("True")
        
        
        return True
    
    def weighted_score(self, board, player=BLACK):
        #[x for x in range(len(board))if board[x] is player]
        #print("board")
        #self.get_pretty_board(board)
        
        player_pieces = sum([WEIGHTED_SCORE[x] for x in range(len(board))if board[x] is player])
        
        #print("player", player_pieces)
        opponent_pieces = sum([WEIGHTED_SCORE[x] for x in range(len(board))if board[x] is self.opponent(player)])
        #opponent_pieces = len ( [x for x in range(len(board))if board[x] is self.opponent(player)] )

        return player_pieces - opponent_pieces

    def score_mobility (self, board, player=BLACK):
        can_move = self.get_valid_moves(board, player)
        nullified_spaces = [13, 18, 22, 23, 28, 29, 72, 73, 83, 78, 88, 79]
        for x in nullified_spaces:
            if x in can_move:
                can_move.remove(x)
                
        player_pieces = len(can_move)
        opponent_pieces = len(self.get_valid_moves(board, self.opponent(player)))

        return player_pieces - opponent_pieces

         

        


        
        #return WEIGHTED_SCORE[move]
    #def mobility(self, board, player=BLACK):
        #player_pieces = len([x for x in range(len(board) if board[x] is player)] )
        #opponent_pieces = len( [x for x in range(len(board)if board[x] is self.opponent(player)])
        #mob_value = 100* (player_pieces / (player_pieces + opponent_pieces))
            
        
        
    def next_player(self, board, prev_player):
        if len(self.get_valid_moves(board, self.opponent(prev_player))) is not 0:
            return self.opponent(prev_player)
        elif len(self.get_valid_moves(board, prev_player)) is not 0:
            return prev_player
        else:
            return None 
            

        """Which player should move next?  Returns None if no legal moves exist."""
        pass

    def score(self, board, player=BLACK):
    
        player_pieces = len( [x for x in range(len(board))if board[x] is player] )
        opponent_pieces = len ( [x for x in range(len(board))if board[x] is self.opponent(player)] )
    

        return player_pieces - opponent_pieces
        """Compute player's score (number of player's pieces minus opponent's)."""
        pass

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        pass

    ### Monitoring players


    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def alphabeta (self, node, player, depth, a = -math.inf , b = math.inf):
        #print(node.board)
        board = node.board
        
        if depth is 0:
            stability_score = 0
            if node.stability is True:
                #print(True)
                stability_score = 500
            score = self.weighted_score(board, player) + stability_score + 50*self.score_mobility(board,player) + 10*self.score(board)
            node.score = score
            #print("weighted score", self.weighted_score(board,player))
            #print("stability", stability_score)
            #print("score", score)
            #print("move", node.move)
            return node
            

        #my_moves = get the valid moves for player and board
        my_moves = self.get_valid_moves(board, player)
        #MY_CORNERS = [12,19,82,89]

        my_moves_corners = []

        for x in CORNERS:
            if x in my_moves:
                my_moves_corners.append(x)
                

        #if len(my_moves_corners) is not 0:
            #node.move = random.choice(my_moves_corners)
            #score = self.weighted_score(board, player) + self.score_mobility(board, player) 
            #node.score = score
            #return node
            

        
        #print(my_moves)

        children = []
        for move in my_moves:
            if -1 in my_moves:
                print("True")
            #if node.board[12] or node.board[19] or node.board[82] or node.board is in my_moves:
                
            #print("alphabeta board", board)
            #print("themove", move)
            next_board = self.make_move(board, player, move)
            #print("next_board")
            #self.get_pretty_board(next_board)
            #next_board = make the move for player and board
            next_player = self.next_player(next_board, player)
            if next_player is None: 
                c = Node(next_board, move, player)
                c.score=1000*self.score(next_board)
                #c.score = 1000*score(next_board)
                children.append(c)

            else:
                c = Node(next_board, move, next_player)
                c.stability = self.is_stable(next_board, move, next_player)
                #print("c move", c.move)
                
                c.score = self.alphabeta(c, next_player, depth-1,a, b).score 
                #c.score = self.minmax_search(c, next_player, depth-1, a, b).score
                #print("yes")
                children.append(c)
            if player is BLACK:
                a = max(a, c.score)
            elif player is WHITE:
                b = min(b, c.score)
            if a >= b:
                break

                
        #print(player)
        #print("children:" , children)

        winner = best[player](children)
        node.score = winner.score
        return winner
        

    def minmax_search(self, node, player, depth):
        board = node.board
        
        if depth is 0:
            score = score = self.weighted_score(board, player)
            node.score = score 
            #print("move", node.move)
            return node
            

        #my_moves = get the valid moves for player and board
        my_moves = self.get_valid_moves(board, player)
        #print(my_moves)

        children = []
        for move in my_moves:
            #print("themove", move)
            next_board = self.make_move(player, board, move)
            #next_board = make the move for player and board
            next_player = self.next_player(next_board, player)
            if next_player is None: #
                c = Node(next_board, move, player, score=1000*score(next_board))
                children.append(c)

            else:
                c = Node(next_board, move, next_player)
                #alpha = 
                #print("c move", c.move)
                #if player is MAX:
                    
                #c.score = self.alphabeta(c, next_player,depth-1, a, b).score 
                c.score = self.minmax_search(c, next_player, depth-1).score
                #print("yes")
                children.append(c)

                
        #print(player)
        #print("children:" , children)

        winner = best[player](children)
        node.score = winner.score
        return winner
        
                            
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        

    def alphabeta_strategy(self, board, player, depth=4):
        
        tempnode = Node(board, None, player)
        #print(tempnode.board)
        #print(tempnode.stability)
        #print(tempnode.score)
        return self.alphabeta(tempnode, player, depth).move
        #print("final score," , node.score)
        #return node.move
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move

    def minmax_strategy(self, board, player, depth=4):
        
        tempnode = Node(board, None, player)
        #print(tempnode.board)
        return self.minmax_search(tempnode, player, depth).move
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move

    
        
    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        board = ''.join(board)
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board, player)
            depth += 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.alphabeta_strategy, WHITE: white.minmax_strategy}
        ref.get_pretty_board(board)

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            ref.get_pretty_board(board)
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    #game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()
