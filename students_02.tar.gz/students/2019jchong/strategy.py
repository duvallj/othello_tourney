import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS ={BLACK:"Black", WHITE: "White"}
weights= [0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
0, 200, -40,  20,   5,   5,  20, -40, 200,   0,
0, -40, -40,  -5,  -5,  -5,  -5, -40, -40,   0,
0,  30,  -5,  15,   3,   3,  15,  -5,  30,   0,
0,  10,  -5,   3,   3,   3,   3,  -5,  10,   0,
0,  10,  -5,   3,   3,   3,   3,  -5,  10,   0,
0,  30,  -5,  15,   3,   3,  15,  -5,  20,   0,
0, -40, -40,  -5,  -5,  -5,  -5, -40, -40,   0,
0, 200, -40,  20,   5,   5,  20, -40, 200,   0,
0,   0,   0,   0,   0,   0,   0,   0,   0,   0]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node:
    def __init__(self,board, move, score=0):
        self.board= board
        self.move=move
        self.score=score
    def __lt__(self, other):
        return self.score <other.score
class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""

        edge= '??????????'
        line='?........?'
        middle1='?...o@...?'
        middle2 = '?...@o...?'
        return edge+line+line+line+middle1+middle2+line+line+line+edge

    def get_string(self, board):
        """Get a string representation of the board."""
        return ''.join(board)

    def get_pretty_board(self,board):
        temp= ''.join(board)
        return temp[0:10]+"\n"+ temp[10:20]+"\n"+ temp[20:30]+"\n"+ temp[30:40]+"\n"+ temp[40:50]+"\n"+ temp[50:60]+"\n"+ temp[60:70]+"\n"+ temp[70:80]+"\n"+ temp[80:90]+"\n"+ temp[90:100]

    def opponent(self, player):
        """Get player's opponent."""
        if player== BLACK:
            return WHITE
        return BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        index= square
        while board[index+direction]== self.opponent(player):
            index+= direction
        if board[index+direction]=='?' or board[index+direction]== '.':
            return None
        return index+direction

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        #moves= self.get_valid_moves(board, player) #make this more efficient later
        validmoves= self.get_valid_moves(board, player)

        if move in validmoves:
            return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        a= move
        temp= list(board)
        for dir in DIRECTIONS:
            match=self.find_match(board,  player,move,  dir)
            if match!= None:
                while a!= match:
                    temp[a]= player
                    a+= dir
            a=move
        return self.get_string(temp)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        empty= []
        validmoves=[]
        for a in range(len(board)):
            if board[a]== '.':
                empty.append(a)
        for var in empty:
            for dir in DIRECTIONS:
                if board[var+dir]== self.opponent(player):
                    temp= self.find_match(board,  player,var,  dir)
                    if temp!= None and var not in validmoves:
                        validmoves.append(var)
        temp= self.only_edges(validmoves)
        if len(temp)!=0:
            return temp
        return validmoves
    def only_edges(self, validmoves):
        edited=[]
        for a in validmoves:
            if a%10==1 or a<21 or a%10==8 or a>78:
                edited.append(a)
        return edited

    def has_any_valid_moves(self, board, player):
        validmoves= self.get_valid_moves(board, player)
        """Can player make any moves?"""
        if len(validmoves)==0:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None
    def weightedscore(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count1=0
        count2=0
        for a in range(100):
            if board[a]== WHITE:
                count1=count1+weights[a]
            elif board[a]==BLACK:
                count2=count2+ weights[a]
        return count2-count1

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count1=0
        count2=0
        for a in board:
            if a== WHITE:
                count1+=1
            elif a==BLACK:
                count2+=1
        return count2-count1


    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.has_any_valid_moves(board, self.opponent(player)) or self.has_any_valid_moves(board, player):
            return False
        return True


    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth):
        board = ''.join(board)
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        node= Node(board, None)


        if depth == 0:
            node.score= self.weightedscore(board, player)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c.board, next_player,depth=depth - 1).score
                children.append(c)
        winner = max(children) if player== BLACK else min(children)
        node.score = winner.score
        return winner
    def alphabeta(self, board, player, depth,a,b):
        board = ''.join(board)
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        node= Node(board, None)

        board = node.board
        if depth == 0:
            node.score= self.weightedscore(board, player)
            return node
        my_moves = self.get_valid_moves(board, player)
        if player==BLACK:
            best= -math.inf
            tempnode= Node(board, None, best)
            for move in my_moves:
                tempnode.move= move
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                c = Node(next_board, move, None)
                if self.game_over(next_board, next_player):
                    c.score= self.score(next_board)
                else:
                    c = self.alphabeta(board, next_player, depth-1, a,b)
                best=max(best,c.score)

                a=max(best,a)
                tempnode.score=a
                if a>= b:
                    break
        if player == WHITE:
            best =math.inf

            tempnode = Node(board, None, best)
            for move in my_moves:
                tempnode.move= move
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                c = Node(next_board, move, None)
                if self.game_over(next_board, next_player):
                    c.score = self.score(next_board)

                else:
                    c = self.alphabeta(board, next_player, depth - 1, a, b)
                best = min(best, c.score)

                b = min(best, b)
                tempnode.score=b
                if a >= b:
                    break

        return tempnode

    def ab_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        temp= self.alphabeta(board, player, depth, -math.inf,math.inf)
        return temp.move

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        temp= self.minmax_search(board, player, depth)
        return temp.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def white_best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player,depth)
            depth += 1
    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = ab_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.minmax_strategy}
        print(ref.get_pretty_board(board)) #changed this line

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board)) #changed this line
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.white_best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    game = StandardPlayer()
    #game= ParallelPlayer()
    game.play()
import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS ={BLACK:"Black", WHITE: "White"}
weights= [0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
          0, 200, -40,  20,   5,   5,  20, -40, 200,   0,
          0, -40, -40,  -5,  -5,  -5,  -5, -40, -40,   0,
          0,  30,  -5,  15,   0,   0,  15,  -5,  30,   0,
          0,  10,  -5,   0,   0,   0,   0,  -5,  10,   0,
          0,  10,  -5,   0,   0,   0,   0,  -5,  10,   0,
          0,  30,  -5,  15,   0,   0,  15,  -5,  20,   0,
          0, -40, -40,  -5,  -5,  -5,  -5, -40, -40,   0,
          0, 200, -40,  20,   5,   5,  20, -40, 200,   0,
          0,   0,   0,   0,   0,   0,   0,   0,   0,   0]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node:
    def __init__(self,board, move, score=0):
        self.board= board
        self.move=move
        self.score=score
    def __lt__(self, other):
        return self.score <other.score
class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""

        edge= '??????????'
        line='?........?'
        middle1='?...o@...?'
        middle2 = '?...@o...?'
        return edge+line+line+line+middle1+middle2+line+line+line+edge

    def get_string(self, board):
        """Get a string representation of the board."""
        return ''.join(board)

    def get_pretty_board(self,board):
        temp= ''.join(board)
        return temp[0:10]+"\n"+ temp[10:20]+"\n"+ temp[20:30]+"\n"+ temp[30:40]+"\n"+ temp[40:50]+"\n"+ temp[50:60]+"\n"+ temp[60:70]+"\n"+ temp[70:80]+"\n"+ temp[80:90]+"\n"+ temp[90:100]

    def opponent(self, player):
        """Get player's opponent."""
        if player== BLACK:
            return WHITE
        return BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        index= square
        while board[index+direction]== self.opponent(player):
            index+= direction
        if board[index+direction]=='?' or board[index+direction]== '.':
            return None
        return index+direction

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        #moves= self.get_valid_moves(board, player) #make this more efficient later
        validmoves= self.get_valid_moves(board, player)

        if move in validmoves:
            return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        a= move
        temp= list(board)
        for dir in DIRECTIONS:
            match=self.find_match(board,  player,move,  dir)
            if match!= None:
                while a!= match:
                    temp[a]= player
                    a+= dir
            a=move
        return self.get_string(temp)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        empty= []
        validmoves=[]
        for a in range(len(board)):
            if board[a]== '.':
                empty.append(a)
        for var in empty:
            for dir in DIRECTIONS:
                if board[var+dir]== self.opponent(player):
                    temp= self.find_match(board,  player,var,  dir)
                    if temp!= None and var not in validmoves:
                        validmoves.append(var)
        temp1= self.only_edges(validmoves)

        if len(temp1)!=0:
            return temp1

        return validmoves
    def only_edges(self, validmoves):
        edited=[]
        for a in validmoves:
            if a%10==1 or a<21 or a%10==8 or a>78:
                edited.append(a)
        return edited
    '''def remove_close(self, temp):
        edited= []
        for a in temp:
            if 21<a<28 or 71<a<78 or (a%10==2 and 81>a>21) or (a%10==7 and 21<a<81):
                edited.remove(a)
        return edited'''
    def has_any_valid_moves(self, board, player):
        validmoves= self.get_valid_moves(board, player)
        """Can player make any moves?"""
        if len(validmoves)==0:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None
    def weightedscore(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count1=0
        count2=0
        for a in range(100):
            if board[a]== WHITE:
                count1=count1+weights[a]
            elif board[a]==BLACK:
                count2=count2+ weights[a]
        return count2-count1

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count1=0
        count2=0
        for a in board:
            if a== WHITE:
                count1+=1
            elif a==BLACK:
                count2+=1
        return count2-count1


    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.has_any_valid_moves(board, self.opponent(player)) or self.has_any_valid_moves(board, player):
            return False
        return True


    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth):
        board = ''.join(board)
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        node= Node(board, None)


        if depth == 0:
            node.score= self.weightedscore(board, player)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c.board, next_player,depth=depth - 1).score
                children.append(c)
        winner = max(children) if player== BLACK else min(children)
        node.score = winner.score
        return winner
    def alphabeta(self, board, player, depth,a,b):
        board = ''.join(board)
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        node= Node(board, None)

        board = node.board
        if depth == 0:
            node.score= self.weightedscore(board, player)
            return node
        my_moves = self.get_valid_moves(board, player)
        if player==BLACK:
            best= -math.inf
            tempnode= Node(board, None, best)
            for move in my_moves:
                tempnode.move= move
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                c = Node(next_board, move, None)
                if self.game_over(next_board, next_player):
                    c.score= self.score(next_board)
                else:
                    c = self.alphabeta(board, next_player, depth-1, a,b)
                best=max(best,c.score)

                a=max(best,a)
                tempnode.score=a
                if a>= b:
                    break
        if player == WHITE:
            best =math.inf

            tempnode = Node(board, None, best)
            for move in my_moves:
                tempnode.move= move
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                c = Node(next_board, move, None)
                if self.game_over(next_board, next_player):
                    c.score = self.score(next_board)

                else:
                    c = self.alphabeta(board, next_player, depth - 1, a, b)
                best = min(best, c.score)

                b = min(best, b)
                tempnode.score=b
                if a >= b:
                    break

        return tempnode

    def ab_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        temp= self.alphabeta(board, player, depth, -math.inf,math.inf)
        return temp.move

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        temp= self.minmax_search(board, player, depth)
        return temp.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def white_best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player,depth)
            depth += 1
    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = ab_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.minmax_strategy}
        print(ref.get_pretty_board(board)) #changed this line

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board)) #changed this line
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.white_best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    game = StandardPlayer()
    #game= ParallelPlayer()
    game.play()
