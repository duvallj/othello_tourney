from flips import flip_funcs
black = "X"
white = "O"
empty = '.'
border = '?'
default_board = '...........................o@......@o...........................'


def _on(n):
    n = int(n)
    while n:
        b = n & ~n + 1
        yield b
        n ^= b


def on(n):
    return list(_on(n))


class Reference:
    def __init__(self, obj):
        self.obj = obj

    def __call__(self, obj=None):
        if obj:
            self.obj = obj
        else:
            return self.obj


class Evaluator:
    def __init__(self, players):
        self.players = players
        self.weights = [
            18,  4,  16, 12, 12, 16,  4, 18,
            4,  2,   6,  8,  8,  6,  2,  4,
            16,  6,  14, 10, 10, 14,  6, 16,
            12,  8,  10,  0,  0, 10,  8, 12,
            12,  8,  10,  0,  0, 10,  8, 12,
            16,  6,  14, 10, 10, 14,  6, 16,
            4,  2,   6,  8,  8,  6,  2,  4,
            18,  4,  16, 12, 12, 16,  4, 18
        ]

    def __call__(self, *args, **kwargs):
        val = len(on(player()() | opponent()()))
        if val <= 20:
            return self.opening()
        elif 20 < val <= 55:
            return self.midgame()
        else:
            return self.endgame()

    def opening():
        p = self.player()()
        o = self.opponent()()
        return len(on(o)) - len(on(p))

    def endgame():
        p = self.player()()
        o = self.opponent()()
        return len(on(p)) - len(on(o))

    def midgame():
        return 0


class Move:
    def __init__(self, location):
        self.location = location
        self.score = -1 * float('inf')

    def to_100(self):
        return ((self.location // 8) + 1) * 10 + (self.location % 8) + 1

    def __str__(self):
        return "{} -> {}".format(self.location, self.score)


class Board:
    def __init__(self, board=default_board, current_player=black):
        if isinstance(board, list):
            self.board = ''.join(board).replace(border, '')
        else:
            self.board = board
        b = 0
        w = 0
        for index, char in enumerate(self.board):
            if char == black:
                b |= 1 << index
            elif char == white:
                w |= 1 << index
        self.black = Reference(b)
        self.white = Reference(w)
        self.players = [self.black, self.white] if current_player == black else [self.white, self.black]
        self.evaluator = Evaluator(self.players)

    def player(self):
        return self.players[0]

    def opponent(self):
        return self.players[1]

    def swap_players(self):
        self.players = self.players[::-1]

    def compare(self, other):
        if self.player()() > other.player()():
            return 1
        elif self.player()() < other.player()():
            return -1
        elif self.opponent()() > other.opponent()():
            return 1
        elif self.opponent()() < other.opponent()():
            return -1
        else:
            return 0

    def list_possible_moves(self):
        return [Move(l.bit_length() - 1) for l in on(self.int_possible_moves())]

    def int_possible_moves(self):
        player, opponent = self.player()(), self.opponent()()
        mask = opponent & 0x7E7E7E7E7E7E7E7E
        full = 18446744073709551615
        return (self.partial_moves(player, mask, 1) | self.partial_moves(player, opponent, 8) | self.partial_moves(player, mask, 7) | self.partial_moves(player, mask, 9)) & (full ^ (player | opponent))

    def partial_moves(self, player, mask, d):
        dir2 = d << 1
        dir4 = d << 2
        flip_l = player | (mask & (player << d))
        flip_r = player | (mask & (player >> d))
        mask_l = mask & (mask << d)
        mask_r = mask & (mask >> d)
        flip_l |= mask_l & (flip_l << dir2)
        flip_r |= mask_r & (flip_r >> dir2)
        mask_l &= (mask_l << dir2)
        mask_r &= (mask_r >> dir2)
        flip_l |= mask_l & (flip_l << dir4)
        flip_r |= mask_r & (flip_r >> dir4)
        return ((flip_l & mask) << d) | ((flip_r & mask) >> d)

    def get_flips(player, opponent, m):
        return flip_funcs[m.location()](player, opponent)

    def make_move(self, move):
        index = move.location
        player, opponent = [n() for n in self.players]
        flips = self.get_flips(player, opponent, index)
        if not flips:
            return
        player |= 1 << index
        player |= flips
        opponent ^= opponent & flips
        self.player()(player)
        self.opponent()(opponent)
        self.swap_players()

    def symmetric(self, s):
        if s & 1:
            p, o = map(self.horizontal_mirror, self.players)
        elif s & 2:
            p, o = map(self.vertical_mirror, self.players)
        elif s & 4:
            p, o = map(self.transpose, self.players)
        b = Board(current_player=black if self.black == self.player else white)
        b.player()(p)
        b.opponent()(o)
        b.update()
        return b

    def horizontal_mirror(self, n):
        b = n()
        b = ((b >> 1) & 0x5555555555555555) | ((b << 1) & 0xAAAAAAAAAAAAAAAA)
        b = ((b >> 2) & 0x3333333333333333) | ((b << 2) & 0xCCCCCCCCCCCCCCCC)
        b = ((b >> 4) & 0x0F0F0F0F0F0F0F0F) | ((b << 4) & 0xF0F0F0F0F0F0F0F0)
        return b

    def vertical_mirror(self, n):
        b = n()
        b = ((b >> 8) & 0x00FF00FF00FF00FF) | ((b << 8) & 0xFF00FF00FF00FF00)
        b = ((b >> 16) & 0x0000FFFF0000FFFF) | ((b << 16) & 0xFFFF0000FFFF0000)
        b = ((b >> 32) & 0x00000000FFFFFFFF) | ((b << 32) & 0xFFFFFFFF00000000)
        return b

    def transpose(self, n):
        b = n()
        t = (b ^ (b >> 7)) & 0x00aa00aa00aa00aa
        b = b ^ t ^ (t << 7)
        t = (b ^ (b >> 14)) & 0x0000cccc0000cccc
        b = b ^ t ^ (t << 14)
        t = (b ^ (b >> 28)) & 0x00000000f0f0f0f0
        b = b ^ t ^ (t << 28)
        return b

    def get_all_symmetric(self):
        return {self.symmetric(i) for i in range(1, 8)}

    def update(self):
        self.board = self.string()

    def __eq__(self, other):
        return self.compare(other) == 0

    def __hash__(self):
        return self.black() * 0xdef | self.white() * 0xabc

    def __str__(self):
        return self.string(two=True)

    def string(self, two=False):
        b = self.black()
        w = self.white()
        string = ""
        for i in range(64):
            if b & 1 << i:
                string += "X"
            elif w & 1 << i:
                string += "O"
            else:
                string += "."
            if i % 8 == 7 and two:
                string += "\n"
        return(string)


if __name__ == "__main__":
    from sys import argv
    import random
    board = Board(argv[1], argv[2])
    print(board.list_possible_moves())
