from argparse import ArgumentParser
from random import choice


class Lab3Parser(ArgumentParser):

    def __init__(self, *args, **kwargs):
        self.default_puzzle = '...........................OX......XO...........................'
        super(Lab3Parser, self).__init__(*args, **kwargs)
        self.add_argument("puzzle", nargs='?', default=self.default_puzzle)
        self.add_argument("next_player", nargs='?', default='_')
        self.add_argument("n", type=int, nargs='?', default=8)
        self.add_argument("extra", nargs='*')

    def valid_puzzle(self, puzzle):
        return isinstance(puzzle, str) and len(puzzle) == 64

    def valid_player(self, player):
        return player.lower() in {'x', 'o'}

    def calc_player(self, puzzle):
        return ["X", "O"][puzzle.count('.') % 2 == 1]

    def parse_args(self, args=None, namespace=None):
        args = super(Lab3Parser, self).parse_args(args, namespace)
        set_player = (args.next_player == "_")
        if not self.valid_player(args.next_player) and not set_player:
            args.extra = [args.next_player] + args.extra
            set_player = True
        if not self.valid_puzzle(args.puzzle):
            if not self.valid_player(args.puzzle):
                args.extra = [args.puzzle] + args.extra
            else:
                args.next_player = args.puzzle.upper()
                set_player = False
            args.puzzle = self.default_puzzle
        if set_player:
            args.next_player = self.calc_player(args.puzzle)
        return args


BITS = tuple([1 << x for x in range(64)] + [0, 0])
PASS = 64
COLS = 'ABCDEFGH'
ROWS = '12345678'
LOCATIONS = {COLS[x % 8] + ROWS[x // 8]: x for x in range(64)}
INDEX = {v: k for k, v in LOCATIONS.items()}


def on(n):
    while n:
        b = n & (~n + 1)
        yield b
        n ^= b


def get_flips(player, opponent, move):
    direction = [-9, -8, -7, -1, 1, 7, 8, 9]
    edge = [
        0x01010101010101ff,
        0x00000000000000ff,
        0x80808080808080ff,
        0x0101010101010101,
        0x8080808080808080,
        0xff01010101010101,
        0xff00000000000000,
        0xff80808080808080
    ]
    if move == PASS:
        return 0
    flipped = 0
    for d in range(8):
        if BITS[move] & edge[d] == 0:
            f = 0
            x = move + direction[d]
            while (opponent & BITS[x]) and BITS[x] & edge[d] == 0:
                f |= BITS[x]
                x += direction[d]
            if player & BITS[x]:
                flipped |= f
    return flipped


def play(player, opponent, index):
    index = parse_location(index)
    flips = get_flips(player, opponent, index)
    if not flips:
        return
    player |= (1 << index)
    player |= flips
    opponent ^= opponent & flips
    return player, opponent


def board_to_string(black, white):
    string = ""
    for i in range(64):
        if black & (1 << i):
            string += "X"
        elif white & (1 << i):
            string += "O"
        else:
            string += "."
    return string


def display(black, white, highlight=0):
    string = ""
    for i in range(64):
        if i % 8 == 0:
            string += "+--+--+--+--+--+--+--+--+\n"
        if black & (1 << i):
            string += "|X "
        elif white & (1 << i):
            string += "|O "
        else:
            string += "|{}  {}".format("\033[41m" if highlight & (1 << i) else "", "\033[0m")
        if i % 8 == 7:
            string += "|\n"
    string += "+--+--+--+--+--+--+--+--+\n"
    print(string)


def get_possible_placements(player, opponent):
    mask = opponent & 0x7E7E7E7E7E7E7E7E
    full = (1 << 64) - 1
    return (partial_moves(player, mask, 1) | partial_moves(player, opponent, 8) | partial_moves(player, mask, 7) | partial_moves(player, mask, 9)) & (full ^ (player | opponent))


def partial_moves(player, mask, d):
    dir2 = d << 1
    dir4 = d << 2
    fl = player | (mask & (player << d))
    fr = player | (mask & (player >> d))
    ml = mask & (mask << d)
    mr = mask & (mask >> d)
    fl |= ml & (fl << dir2)
    fr |= mr & (fr >> dir2)
    ml &= (ml << dir2)
    mr &= (mr >> dir2)
    fl |= ml & (fl << dir4)
    fr |= mr & (fr >> dir4)
    return ((fl & mask) << d) | ((fr & mask) >> d)


def parse_location(location):
    if isinstance(location, int):
        return location
    if location.isdigit():
        location = int(location)
    else:
        location = LOCATIONS[location.upper()]
    return location


def evalBoard(player, opponent):
    return len(list(on(player))) - len(list(on(opponent)))


def game_is_over(player, opponent):
    return not get_possible_placements(player, opponent) and not get_possible_placements(opponent, player)


def negamax(player, opponent, alpha, beta, levels):
    if not levels or game_is_over(player, opponent):
        return [evalBoard(player, opponent), -3]
    lm = {i.bit_length() - 1 for i in on(get_possible_placements(player, opponent))}
    if not lm:
        nm = negamax(opponent, player, -beta, -alpha, levels - 1) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    for mv in lm:
        nm = negamax(*[*play(player, opponent, mv)][::-1], -beta, -alpha, levels - 1) + [mv]
        nm = [-nm[0]] + nm[1:]
        best, alpha = max(best, nm), max(alpha, nm[0])
        if alpha >= beta:
            break
    return best


def get_real_placements(player, opponent):
    tl = 1 << 0
    tr = 1 << 7
    bl = 1 << 56
    br = 1 << 63
    top_edge = 0xff
    left_edge = 0x101010101010101
    right_edge = 0x8080808080808080
    bottom_edge = 0xff00000000000000
    edges = top_edge | left_edge | right_edge | bottom_edge
    cs = 0x4281000000008142
    xs = 0x42000000004200
    placements = get_possible_placements(player, opponent)
    if placements & (tl | tr | bl | br):
        placements &= (tl | tr | bl | br)
        return {i.bit_length() - 1 for i in on(placements)}
    indices = set()
    if placements & (top_edge | left_edge | right_edge | bottom_edge):
        for edge, corners in (left_edge, [tl, bl]), (right_edge, [tr, br]), (top_edge, [tl, tr]), (bottom_edge, [bl, br]):
            for c in corners:
                if player & c:
                    for index in {i.bit_length() - 1 for i in on(placements & edge)}:
                        newplayer, newopponent = play(player, opponent, index)
                        myedges = newplayer & edge
                        opedges = newopponent & edge
                        ix = [i.bit_length() - 1 for i in on(myedges)]
                        if all(ix[x] == ix[x - 1] + 1 for x in range(1, len(ix))) or all(ix[x] == ix[x - 1] + 8 for x in range(1, len(ix))):
                            print(index)
                            indices.add(index)
    if placements ^ (placements & (cs | xs)):
        placements ^= (placements & (cs | xs))
    if placements ^ (placements & edges):
        placements ^= (placements & edges)
    if not indices:
        indices |= {i.bit_length() - 1 for i in on(placements)}
    return indices


if __name__ == "__main__":
    parser = Lab3Parser()
    args = parser.parse_args()
    black = 0
    white = 0
    for pos, val in enumerate(args.puzzle):
        if val.upper() == "X":
            black |= (1 << pos)
        elif val.upper() == "O":
            white |= (1 << pos)
    if args.next_player.upper() == "X":
        player, opponent = black, white
    else:
        player, opponent = white, black
    current_player = args.next_player.upper() == "X"
    for move in args.extra:
        location = parse_location(move)
        try:
            player, opponent = play(player, opponent, location)
            print("{} => {}".format('OX'[current_player], INDEX[location]))
            display(*[(opponent, player), (player, opponent)][current_player])
            player, opponent = opponent, player
            current_player = not current_player
        except TypeError:
            current_player = not current_player
            player, opponent = play(opponent, player, location)
            print("{} => {}".format('OX'[current_player], INDEX[location]))
            display(*[(opponent, player), (player, opponent)][current_player])
            player, opponent = opponent, player
            current_player = not current_player
    display(*[(opponent, player), (player, opponent)][current_player])
    print("Possible Moves: {}".format({i.bit_length() - 1 for i in on(get_possible_placements(player, opponent))}))
    if 64 - len(list(on(player | opponent))) > args.n:
        indices = get_real_placements(player, opponent)
        print("Heuristic Chooses:", choice(list(indices)))
    else:
        indices = negamax(player, opponent, -1)
        print(indices[0], indices[1::2])

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'


class Strategy:
    def process_board(self, board, player):
        black, white = 0, 0
        string = ''.join(board).replace(OUTER, "")
        for pos, val in enumerate(string):
            if val == BLACK:
                black |= (1 << pos)
            elif val == WHITE:
                white |= (1 << pos)
        if player == BLACK:
            player, opponent = black, white
        else:
            player, opponent = white, black
        return player, opponent

    def real_location(self, i):
        return ((i // 8) + 1) * 10 + (i % 8) + 1

    def best_strategy(self, board, player, best_move, still_running):
        p, o = self.process_board(board, player)
        best_move.value = self.real_location(self.get_loc(p, o))

    def get_loc(self, player, opponent):
        if len(list(on(player | opponent))) < 48:
            indices = get_real_placements(player, opponent)
            return choice(list(indices))
        else:
            indices = negamax(player, opponent, -65, 65, 8)
            return indices[-1]
