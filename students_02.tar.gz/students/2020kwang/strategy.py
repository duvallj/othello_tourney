import sys
import random
ntable = [{8, 1, 9}, {0, 2, 8, 9, 10}, {1, 3, 9, 10, 11}, {2, 4, 10, 11, 12}, {3, 5, 11, 12, 13}, {4, 6, 12, 13, 14},{5, 7, 13, 14, 15}, {15, 6, 14}, {0, 1, 9, 16, 17}, {0, 1, 2, 8, 10, 16, 17, 18},{1, 2, 3, 9, 11, 17, 18, 19}, {2, 3, 4, 10, 12, 18, 19, 20}, {3, 4, 5, 11, 13, 19, 20, 21},{4, 5, 6, 12, 14, 20, 21, 22}, {5, 6, 7, 13, 15, 21, 22, 23}, {6, 7, 14, 22, 23}, {8, 9, 17, 24, 25},{8, 9, 10, 16, 18, 24, 25, 26}, {9, 10, 11, 17, 19, 25, 26, 27}, {10, 11, 12, 18, 20, 26, 27, 28},{11, 12, 13, 19, 21, 27, 28, 29}, {12, 13, 14, 20, 22, 28, 29, 30}, {13, 14, 15, 21, 23, 29, 30, 31},{14, 15, 22, 30, 31}, {32, 33, 16, 17, 25}, {32, 33, 34, 16, 17, 18, 24, 26},{33, 34, 35, 17, 18, 19, 25, 27}, {34, 35, 36, 18, 19, 20, 26, 28}, {35, 36, 37, 19, 20, 21, 27, 29},{36, 37, 38, 20, 21, 22, 28, 30}, {37, 38, 39, 21, 22, 23, 29, 31}, {38, 39, 22, 23, 30},{33, 40, 41, 24, 25}, {32, 34, 40, 41, 42, 24, 25, 26}, {33, 35, 41, 42, 43, 25, 26, 27},{34, 36, 42, 43, 44, 26, 27, 28}, {35, 37, 43, 44, 45, 27, 28, 29}, {36, 38, 44, 45, 46, 28, 29, 30},{37, 39, 45, 46, 47, 29, 30, 31}, {38, 46, 47, 30, 31}, {32, 33, 41, 48, 49},{32, 33, 34, 40, 42, 48, 49, 50}, {33, 34, 35, 41, 43, 49, 50, 51}, {34, 35, 36, 42, 44, 50, 51, 52},{35, 36, 37, 43, 45, 51, 52, 53}, {36, 37, 38, 44, 46, 52, 53, 54}, {37, 38, 39, 45, 47, 53, 54, 55},{38, 39, 46, 54, 55}, {40, 41, 49, 56, 57}, {40, 41, 42, 48, 50, 56, 57, 58},{41, 42, 43, 49, 51, 57, 58, 59}, {42, 43, 44, 50, 52, 58, 59, 60}, {43, 44, 45, 51, 53, 59, 60, 61},{44, 45, 46, 52, 54, 60, 61, 62}, {45, 46, 47, 53, 55, 61, 62, 63}, {46, 47, 54, 62, 63}, {48, 49, 57},{48, 49, 50, 56, 58}, {49, 50, 51, 57, 59}, {50, 51, 52, 58, 60}, {51, 52, 53, 59, 61}, {52, 53, 54, 60, 62},{53, 54, 55, 61, 63}, {62, 54, 55}]
openingbook = {'...........................OX......XO...........................':{37,44,19,26},'..........................XXX......XO...........................':{18},'...................X.......XX......XO...........................':{18},'...........................OX......XX.......X...................':{45},'...........................OX......XXX..........................':{45},'..................O.......XOX......XO...........................':{19},'....................O.....XXO......XO...........................':{37,45},'...................X.......XX.....OOO...........................':{44,45},'..........................XXX.....OOO...........................':{43},'...........................OOO.....XX.......X...................':{18,19},'...........................OX......XO.......XO..................':{37},'...................XO......XO......XO...........................':{29},'..................OX.......OX......XO...........................':{26},'...........................OOO.....XXX..........................':{20},'...........................OX......XOX.......O..................':{44},'...........................OX......OX......OX...................':{34},'...........................OX......OXX.....O....................':{18,26}}
def replaces(str,pos,symb):
    return str[:pos] + symb + str[pos+1:]
def isValid(board,token,pos):
    if board[pos] != '.':
        return False
    sett = ntable[pos]
    if token not in [board[y] for y in sett]:
        return False
    for n in ntable[pos]:
        if board[n] == token:
            if checkSpot(pos,n-pos,token,board):
                return True
    return False
def flipp(game,move,token,playertoken,direction):
    ret = replaces(game,move,playertoken)
    for d in direction:
        temp = move+d
        while ret[temp] == token:
            ret = ret[:temp] + playertoken + ret[temp+1:]
            temp = temp+d
    return ret
def getMove(game,token,move):
    ret = set()
    if game[move] == '.':
        for y in ntable[move]:
            if game[y] == token:
                if checkSpot(move,y-move,token,game):
                    ret.add(y-move)
    return ret
def display(str):
    ret = ''
    ret += str[:8]
    ret += '\n'
    ret += str[8:16]
    ret += '\n'
    ret += str[16:24]
    ret += '\n'
    ret += str[24:32]
    ret += '\n'
    ret += str[32:40]
    ret += '\n'
    ret += str[40:48]
    ret += '\n'
    ret += str[48:56]
    ret += '\n'
    ret += str[56:64]
    ret += '\n'
    return ret
def checkSpot(spot,direction,token,game):
    playertoken = flip(token)
    temp = spot
    if -1<=direction<= 1:
        temp += direction
        while temp // 8 == spot//8:
            if game[temp] == playertoken:
                return True
            if game[temp] == '.':
                return False
            temp += direction
        return False
    elif abs(direction) is 8:
        temp = temp + direction
        while temp >= 0 and temp <= 63:
            if game[temp] == playertoken:
                return True
            if game[temp] == '.':
                return False
            temp = temp + direction
        return False
    else:
        prev = temp
        while abs((prev%8) - (temp%8)) != 7:
            prev = temp
            temp += direction
            if abs((prev%8) - (temp%8)) is 7:
                break
            if temp >= 0 and temp <= 63:
                if game[temp] == playertoken:
                    return True
                if game[temp] == '.':
                    return False
        return False
def getMoves(board,token):
    ret = set()
    for x in range(64):
        if isValid(board,token,x):
             ret.add(x)
    return ret
def flip(token):
    if token == 'X':
        return 'O'
    return 'X'
def getGoodEdges(corner,etoken):
    temp = corner
    ret = set()
    if corner is 0:
        temp = corner+1
        while temp != etoken and temp < 8:
            if temp == '.':
                ret.add(temp)
                break
            temp += 1
        temp = corner+8
        while temp != etoken and temp <63:
            if temp == '.':
                ret.add(temp)
                break
            temp += 8
        return ret
    if corner is 7:
        temp = corner - 1
        while temp != etoken and temp >= 0:
            if temp == '.':
                ret.add(temp)
                break
            temp -= 1
        temp = corner + 8
        while temp != etoken and temp < 64:
            if temp == '.':
                ret.add(temp)
                break
            temp += 8
        return ret
    if corner is 56:
        temp = corner + 1
        while temp != etoken and temp < 64:
            if temp == '.':
                ret.add(temp)
                break
            temp += 1
        temp = corner - 8
        while temp != etoken and temp >= 0:
            if temp == '.':
                ret.add(temp)
                break
            temp -= 8
        return ret
    if corner is 63:
        temp = corner - 1
        while temp != etoken and temp > 55:
            if temp == '.':
                ret.add(temp)
                break
            temp -= 1
        temp = corner - 8
        while temp != etoken and temp > 5:
            if temp == '.':
                ret.add(temp)
                break
            temp -= 8
        return ret
def evalBoard(board,token):
    gcount = 0
    other = 0
    o = flip(token)
    for x in range(len(board)):
        if board[x] == token:
            gcount += 1
        if board[x] == o:
            other += 1
    return gcount-other
def evalMobility(board,token):
    pmob = len(getMoves(board,flip(token)))
    omob = len(getMoves(board,token))
    corners = {0,7,56,63}
    #bad = {1,6,15,8,9,14,48,49,57,62,54,55}
    for x in corners:
        if board[x] == token:
            pmob += 2000
        elif board[x] == flip(token):
            omob += 5000
    #for x in bad:
     #   if board[x] == token:
      #      pmob -= 20
       # elif board[x] == flip(token):
        #    omob -= 20
    if pmob + omob != 0:
        mobility = 100 * ((pmob-omob)/(pmob+omob))
    else:
        mobility = 0
    return mobility
def evalWeight(board,token):
    table =[]
    gcount = 0
    other = 0
    o = flip(token)
    for x in range(64):
        if board[x] != '.':
            if board[x] == o:
                other += table[x]
            else:
                gcount += table[x]
    return gcount-other
def negamax(board,token,levels): #returns a score together with a move sequence -> score
    if not levels:
	    return [evalMobility(board,token)]
    lm = getMoves(board,flip(token))
    if not lm:
        if not getMoves(board,token):
            return [evalBoard(board,token)]
        best = negamax(board, flip(token), levels - 1) + [-1]
    else:
        best = sorted([negamax(flipp(board,mv,flip(token),token,getMove(board,flip(token),mv)), flip(token), levels - 1) + [mv] for mv in lm])[0]
    return [-best[0]] + best[1:]
def negamax(board,token,levels,improvable,hardbound):
    if not levels:
        return [evalMobility(board, token)]
    lm = getMoves(board,flip(token))
    if not lm:
        lm = getMoves(board,token)
        if not lm:
            return [evalMobility(board,token),-3]
        nm = negamax(board,flip(token),levels-1,-hardbound,-improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newhb = -improvable
    for mv in lm:
        nm = negamax(flipp(board,mv,flip(token),token,getMove(board,flip(token),mv)),flip(token),levels-1,-hardbound,newhb) + [mv]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0]<newhb:
                newhb = nm[0]
                if -newhb > hardbound:
                    return [-best[0]]+best[1:]
    return [-best[0]] + best[1:]
def terminalnegamax(board,token,improvable,hardbound):
    lm = getMoves(board,flip(token))
    if not lm:
        lm = getMoves(board,token)
        if not lm:
            return [evalBoard(board,token),-3]
        nm = terminalnegamax(board,flip(token),-hardbound,-improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newhb = -improvable
    for mv in lm:
        nm = terminalnegamax(flipp(board,mv,flip(token),token,getMove(board,flip(token),mv)),flip(token),-hardbound,newhb) + [mv]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0]<newhb:
                newhb = nm[0]
                if -newhb > hardbound:
                    return [-best[0]]+best[1:]
    return [-best[0]] + best[1:]
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        board = ''.join(board).replace('?','').replace('@','X').upper()
        player = 'X' if player == '@' else 'O'
        move = getTheMove(board,player)
        if move > -1:
            mv1 = 11+((move//8)*10)+(move%8)
        best_move.value = mv1
def getTheMove(board,player):
    game = board
    playertoken = player
    etoken = 'X'
    if playertoken == 'X':
        etoken = 'O'
    count = len([y for y in range(64) if game[y] == '.'])
    n = 11
    if game in openingbook.keys():
        return random.choice(list(openingbook[game]))
    if count > n:
        move = negamax(game,playertoken,5,-64,64)[-1]
        return move
        cornerset = {0, 7, 63, 56}
        edgeset = {1, 2, 3, 4, 5, 6, 15, 23, 31, 39, 47, 55, 62, 61, 60, 59, 58, 57, 8, 16, 24, 32, 40, 48}
        playercorners = set([x for x in cornerset if playertoken == game[x]])
        sett = getMoves(game, etoken)
        imaginaryset = sett
        possiblecorner = cornerset.intersection(sett)
        badcorners = cornerset - playercorners
        connectedset = set()
        for y in playercorners:
            connectedset = connectedset.union(getGoodEdges(y,etoken))
        goodedge = connectedset.intersection(sett)
        for x in badcorners:
            imaginaryset = imaginaryset - ntable[x]
        decentmoves = sett - edgeset
        if len(possiblecorner) > 0:
            move = random.choice(list(possiblecorner))
        elif len(goodedge) > 0:
            move = random.choice(list(goodedge))
        else:
            if len(imaginaryset) > 0:
                move = random.choice(list(imaginaryset))
            elif len(decentmoves) > 0:
                move = random.choice(list(decentmoves))
            else:
                move = random.choice(list(sett))
        #print('{} {}\n My heuristic choice is {}'.format(display(game),sett,move))
        return move
    else:
        move = terminalnegamax(game, playertoken, -64,64)
        #print('nm gave me {}, i choose {}'.format(move, move[-1]))
        return move[-1]
def main():
    game = '.' * 27 + 'OX' + '.' * 6 + 'XO' + '.' * 27
    playertoken = 'X'
    if len(sys.argv) is 2:
        game = sys.argv[1].upper()
        count = 0
        for x in range(64):
            if game[x] == '.':
                count += 1
        if count % 2 is 1:
            playertoken = 'O'
    elif len(sys.argv) is 3:
        game = sys.argv[1].upper()
        playertoken = sys.argv[2].upper()
    etoken = 'X'
    if playertoken == 'X':
        etoken = 'O'
    count = len([y for y in range(64) if game[y] == '.'])
    n = 10
    if count >n:#<= n:
        move = negamax(game,playertoken,4,-64,64)
        print(move)
        cornerset = {0, 7, 63, 56}
        edgeset = {1, 2, 3, 4, 5, 6, 15, 23, 31, 39, 47, 55, 62, 61, 60, 59, 58, 57, 8, 16, 24, 32, 40, 48}
        playercorners = set([x for x in cornerset if playertoken == game[x]])
        sett = getMoves(game, etoken)
        imaginaryset = sett
        possiblecorner = cornerset.intersection(sett)
        badcorners = cornerset - playercorners
        connectedset = set()
        for y in playercorners:
            connectedset = connectedset.union(getGoodEdges(y,etoken))
        goodedge = connectedset.intersection(sett)
        for x in badcorners:
            imaginaryset = imaginaryset - ntable[x]
        decentmoves = sett - edgeset
        if len(possiblecorner) > 0:
            move = random.choice(list(possiblecorner))
        elif len(goodedge) > 0:
            move = random.choice(list(goodedge))
        else:
            if len(imaginaryset) > 0:
                move = random.choice(list(imaginaryset))
            elif len(decentmoves) > 0:
                move = random.choice(list(decentmoves))
            elif len(sett) > 0:
                move = random.choice(list(sett))
            else:
                move = -1
        print('{} \n legal moves: {}\n My heuristic choice is {}'.format(display(game),sett,move))
    else:
        move = terminalnegamax(game, playertoken,-64,64)
        print('negamax gave me {}, i choose {}'.format(move, move[-1]))
if __name__ == '__main__':
    main()
'''...OOOOOOX.XOOOOOXXXXOOOOXOXXXOOOXXXXOOOOXXOXOOOOXXXXXOOOOOOOOOO'''
