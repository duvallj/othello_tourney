import Othello_Core

from multiprocessing import Value
import numpy as np
import Othello_Core as core
import random
import math

#Mina Kim

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

# To refer to neighbor squares we can add a direction to a square.
UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)

class Othello_Strategy(core.OthelloCore):
    def __init__(self):
        Othello_Core.__init__()

    def main(self):
        #get board in string form
        board = self.print_board(self.initial_board())

    def is_valid(self, move):
        """Is move a square on the board?"""
        #move is a string index
        if move in self.squares:
            return True
        return False
    # checks if a certain move is possible given player's turn and coordinates
    def move_is_possible(self, grid_string, turn, x, y):
            a = np.array(list(grid_string))
            board = np.reshape(a, (8, 8))
            if board[x][y] != '.':
                return False
            opponent = 'White' if turn == 'Black' else 'Black'  # set colors
            for r in range(-1, 2):  # -1 to 1 inclusive
                for c in range(-1, 2):
                    xpos = x + r  # advance in chosen direction
                    ypos = y + c
                    if self.out_of_bounds(xpos, ypos):  # if out of bounds, try a different direction
                        continue
                    while not self.out_of_bounds(xpos, ypos) and board[xpos][ypos] == opponent:  # haven't reached own piece yet
                        xpos = xpos + r  # continue in this direction
                        ypos = ypos + c
                        if self.out_of_bounds(xpos, ypos):
                            break
                        if board[xpos][ypos] == turn:  # reached own color, this move is valid
                            return True
                            # while loop brea king means out of bounds --> try a different direction
            return False
    # checks if a pair of coordinates are on the board
    def out_of_bounds(self, x, y):
        if x > -1 and x < 8 and y > -1 and y < 8:  # in bounds
            return False
        return True  # true if it's out of bounds

    def opponent(self, player):
        """Get player's opponent piece."""
        opponent = 'Black' if player == 'White' else 'White'
        return opponent

    def weighted_score(self, player, board):
        """
        Compute the difference between the sum of the weights of player's
        squares and the sum of the weights of opponent's squares.
        """
        opp = self.opponent(player)
        total = 0
        for sq in self.squares():
            if board[sq] == player:
                total += self.SQUARE_WEIGHTS[sq]
            elif board[sq] == opp:
                total -= self.SQUARE_WEIGHTS[sq]
        return total

    def make_move(self, move, player, board):
        """Update the board to reflect the move by the specified player."""
        if not self.is_legal(move, player, board):
            raise self.IllegalMoveError(player, move, board)
        board[move] = player
        for d in core.DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board


    def make_flips(self, move, player, board, direction):
        """Flip pieces in the given direction as a result of the move by player."""
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction

    def legal_moves(self, player, board):
        """Get a list of all legal moves for player, as a list of integers"""
        moves = []
        for x in range(8):
            for y in range(8):
                if self.move_is_possible(board, player, x, y):
                    moves.append((x, y))
        return moves

    def any_legal_move(self, player, board):
        """Can player make any moves? Returns a boolean"""
        legal_moves = self.legal_moves(player, board)
        if len(legal_moves) == 0:
            return False
        return True

    def next_player(self,board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        next_player = 'White' if prev_player == 'Black' else 'Black'
        legal_moves = self.legal_moves(board, next_player)
        if len(legal_moves) == 0:
            return None
        return next_player

    def score(self,player, board): #!!!!MAKE SURE BOARD IS STRING AND PLAYERS ARE REPRESENTED BY O/X
        """Compute player's score (number of player's pieces minus opponent's)."""
        minplayer = 'O' if player == 'X' else 'X'
        mincount, maxcount = 0
        for piece in board:
            if piece == minplayer:
                mincount += 1
            elif piece == player:
                maxcount += 1
        score = maxcount - mincount
        return score

    def is_legal(self, move, player, board):
        """Is this a legal move for the player?"""
        moves = self.legal_moves(player, board)
        if move in moves:
            return True
        return False

    SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    def minimax(self, player, board, depth, evaluate):
        """
        Find the best legal move for player, searching to the specified depth.
        Returns a tuple (move, min_score), where min_score is the guaranteed minimum
        score achievable for player if the move is made.
        """

        # We define the value of a board to be the opposite of its value to our
        # opponent, computed by recursively applying `minimax` for our opponent.
        def value(board):
            return -self.minimax(self.opponent(player), board, depth - 1, evaluate)[0]

        # When depth is zero, don't examine possible moves--just determine the value
        # of this board to the player.
        if depth == 0:
            return evaluate(player, board), None

        # We want to evaluate all the legal moves by considering their implications
        # `depth` turns in advance.  First, find all the legal moves.
        moves = self.legal_moves(player, board)

        # If player has no legal moves, then either:
        if not moves:
            # either the game is over, so the best achievable score is victory or defeat;
            if not self.any_legal_move(self.opponent(player), board):
                return self.final_value(player, board), None
            # or we have to pass this turn, so just find the value of this board.
            return value(board), None

        # When there are multiple legal moves available, choose the best one by
        # maximizing the value of the resulting boards.
        return max((value(self.make_move(m, player, list(board))), m) for m in moves)

    # Values for endgame boards are big constants.
    MAX_VALUE = sum(map(abs, SQUARE_WEIGHTS))
    MIN_VALUE = -MAX_VALUE

    def minimax_searcher(self, depth, evaluate):
        """
        Construct a strategy that uses `minimax` with the specified leaf board
        evaluation function.
        """

        def strategy(player, board):
            return self.minimax(player, board, depth, evaluate)[1]

        return strategy

    def random_strategy(self, board, player):
        return random.choice(self.legal_moves(player, board))

    def best_strategy(self, board, player, best_move, still_running):
        """
        :param board: a length 100 list representing the board state
        :param player: WHITE or BLACK
        :param best_move: shared multiprocessing.Value containing an int of
                the current best move
        :param still_running: shared multiprocessing.Value containing an int
                that is 0 if the parent process intends to kill this process
        :return: best move as an int in [11,88] or possibly 0 for 'unknown'
        """
        # depth = 4
        # while True:
        #     value = self.minimax(player, board, depth, self.score(player, board))
        #     depth += 1

        # legal = self.legal_moves(player, board)
        # max_score = self.score(player, board)
        depth = 4
        evaluate = self.weighted_score
        while still_running != 0:
            best_move.value = self.minimax(player, board, depth, evaluate)

