import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
best = {BLACK: max, WHITE: min}
alpha, beta = 0, 0
ab = {BLACK: alpha, WHITE: beta}

scoring_matrix = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,1200, -20,  40,  15,   15,  40, -20, 1200, 0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  40,   0,
    0,  15,  -5,   3,   3,   3,   3,  -5,   15,   0,
    0,  15,  -5,   3,   3,   3,   3,  -5,   15,   0,
    0,  40,  -5,  15,   3,   3,  15,  -5,  40,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,1200, -20,  40,  15,   15,  40, -20, 1200, 0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
early_scoring_matrix = [
    0,    0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,-1200,  20, -20,  -5,  -5, -20,  20,-1200,   0,
    0,   20,  40,   5,   5,   5,   5,  40,  20,   0,
    0,   20,   5, -15, -30, -30, -15,   5,  20,   0,
    0,    5,   5  -30, -30, -30, -30,   5,   5,   0,
    0,    5,   5, -30, -30, -30, -30,   5,   5,   0,
    0,   20,   5, -15, -30, -30, -15,   5,  20,   0,
    0,   20,  40,   5,   5,   5,   5,  40,  20,   0,
    0,-1200,  20, -20,  -5,  -5, -20,  20,-1200,   0,
    0,    0,   0,   0,   0,   0,   0,   0,   0,   0,
]

#############################################################
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, b, p, s=None, m=None):
        self.board = b
        self.player = p
        self.move = m
        self.score = s

    def __lt__(self, other):
        return self.score < other.score

class Strategy():
    def __init__(self):
        pass


    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        s = "?" * 10
        s += "?........?" * 8
        s += "?" * 10
        return (s[0:44] + WHITE + BLACK + s[46:54] + BLACK + WHITE + s[56::])

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        string = ""
        for x in range(10, 90, 10):
            string += board[x+1:x+9] + "\n"
        return string

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK: return WHITE
        else: return BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        m = square + direction
        between = False
        while(board[m] is self.opponent(player)):
            m += direction
            between = True
        if (board[m] is EMPTY) and (between is True):
            return m
        return None

    def make_move_helper(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        m = square + direction
        between = False
        while(board[m] is self.opponent(player)):
            m += direction
            between = True
        if (board[m] is player) and (between is True):
            return m
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        new_board = board[0:move] + player + board[move + 1::]
        for d in DIRECTIONS:
            match = self.make_move_helper(new_board, player, move, d)
            if match is not None:
                while move+d is not match:
                    new_board = new_board[0:move+d] + player + new_board[move+d+1::]
                    move += d
        return new_board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        #valid = set()
        player_i = [x for x in range(11,89) if board[x] is player]
        #for d in DIRECTIONS:
            #for position in player_i:
                #if self.find_match(board, player, position, d) is not None:
                    #valid.add(self.find_match(board, player, position, d))
        valid = [self.find_match(board, player, position, d) for d in DIRECTIONS for position in player_i if self.find_match(board, player, position, d) is not None]
        return list(set(valid))


    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if len(self.get_valid_moves(board, player)) == 0:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        else:
            return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count = 0
        for i in board:
            if i is player:
                count = count + 1
            elif i is self.opponent(player):
                count = count - 1
        return count

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.next_player(board, player) is None:
            return True

    def weighted_score(self, board, player):
        black = 0
        white = 0
        for pos in range(11,89):
            if board[pos] == BLACK:
                black += scoring_matrix[pos]
            if board[pos] == WHITE:
                white += scoring_matrix[pos]
        return black - white

    def early_weighted_score(self, board, player):
        black = 0
        white = 0
        for pos in range(len(board)):
            if board[pos] == BLACK:
                black += early_scoring_matrix[pos]
            if board[pos] == WHITE:
                white += early_scoring_matrix[pos]
        return black - white

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board = node.board
        if depth == 0:  #if depth bound is reached
            node.score = self.early_weighted_score(board, player)
            return node  # return node

        my_moves = self.get_valid_moves(board, player)  #get valid moves for player & board

        children = []
        for move in my_moves:   #for each valid move
            next_board = self.make_move(board, player, move)    #make the move
            next_player = self.next_player(next_board, player)  #determine next player
            if next_player is None:     #if no one can play: game over
                c = Node(next_board, player, 1000*self.score(next_board), move)
                children.append(c)  #add the new node to the children list
            else:   #game still going
                c = Node(next_board, next_player, None, move)  #new node
                c.score = self.minmax_search(c, next_player, depth=depth - 1).score     #do minmax on new node
                children.append(c)  #add the new node to the children list
        #################################################################
        winner = best[self.opponent(player)](children)  #look for the highest score
        #################################################################
        node.score = winner.score   #propogate score up
        return winner   #return the best node


    def minmax_strategy(self, board, player, depth=4):
        # calls min max search
        # feel free to adjust the parameters
        # returns an integer move
        node = Node(board, player, self.score(board, player))
        m = self.minmax_search(node, player, depth)
        return m

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def alpha_beta_search(self, node, player, alpha, beta, depth):
        board = node.board
        if depth == 0:  # if depth bound is reached
            if player == BLACK:
                node.score = self.weighted_score(board, player)  # score node
            if player == WHITE:
                node.score = -1 * self.weighted_score(board, player)  # score node
            return node  # return node
        my_moves = self.get_valid_moves(board, player)  # get valid moves for player & board
        children = []
        for move in my_moves:  # for each valid move
            next_board = self.make_move(board, player, move)  # make the move
            next_player = self.next_player(next_board, player)  # determine next player
            if next_player is None:  # if no one can play: game over
                c = Node(next_board, player, 1000 * self.score(next_board), move)
                children.append(c)  # add the new node to the children list
            else:  # game still going
                c = Node(next_board, next_player, None, move)  # new node
                c.score = self.alpha_beta_search(c, next_player, alpha, beta, depth=depth - 1).score  # do minmax on new node
                children.append(c)  # add the new node to the children list
            if player == BLACK:
                alpha = max(alpha, c.score)
            if player == WHITE:
                beta = min(beta, c.score)
            #ab[player] = best[player](ab[player], c.score)
            if alpha >= beta: break
        winner = best[player](children)
        #if player == BLACK:
            #winner = max(children)  # look for the highest score
        #if player == WHITE:
            #winner = min(children)  # look for the highest score

        node.score = winner.score  # propagate score up
        return winner  # return the best node


    def alpha_beta_strategy(self, board, player, depth=4):
        #node = Node(board, player)
        global piece_counter
        winning_node = Node(board, player)
        while piece_counter <= 30:
            #piece_counter = piece_counter + 1
            winning_node = self.minmax_strategy(board, player, depth)
            piece_counter += 1
            return winning_node.move
        return self.alpha_beta_search(winning_node, player, alpha= -math.inf, beta= math.inf, depth=depth).move


    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        global piece_counter
        piece_counter = 4
        depth = 1
        board = "".join(board)
        piece_counter = 4
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alpha_beta_strategy(board, player, depth)
            depth += 1

    standard_strategy = best_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.best_strategy, WHITE: white.best_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()

