from functools import reduce

N = 8
INF = 999999999
MAX_DEPTH = 5
r_dir = [-1, 0, 1, -1, 1, -1, 0, 1]
c_dir = [-1, -1, -1, 0, 0, 1, 1, 1]
p_dis = 'X'
o_dis = 'O'
dp = {}


def display(p_board, o_board):
    pstr = str(format(int(p_board), '064b'))
    ostr = str(format(int(o_board), '064b'))
    output = ['' for i in range(N*N)]
    for i in range(N*N):
        if pstr[i]=='1':
            output[i]=p_dis
        elif ostr[i]=='1':
            output[i]=o_dis
        else:
            output[i]='.'
    for i in range(N):
        print()
        for j in range(N):
            print (output[N * i + j], end='')
    print()


def make_move(board1, board2, r_start, c_start):
    flip = []
    for i in range(N):
        r = r_start+r_dir[i]
        c = c_start+c_dir[i]
        if r < 0 or r > N-1 or c < 0 or c > N-1:
            continue
        cnt = 0
        while board2 & 1 << 63-(N*r+c):
            r += r_dir[i]
            c += c_dir[i]
            cnt += 1
            if r < 0 or r > N - 1 or c < 0 or c > N - 1:
                cnt = 0
                break
        if cnt == 0 or not board1 & 1 << 63-(N*r+c):
            continue
        while True:
            r -= r_dir[i]
            c -= c_dir[i]
            if r == r_start and c == c_start:
                break
            flip.append(1<<63-(N*r+c))
    return flip


def eval(p_board, o_board):
    pv, cv, lv, dv = 0, 0, 0, 0
    # parity
    my_tiles = bin(p_board).count('1')
    opp_tiles = bin(o_board).count('1')
    k = 0 if my_tiles == opp_tiles else -1 if my_tiles < opp_tiles else 1
    pv = k * (max(my_tiles, opp_tiles)) / (my_tiles + opp_tiles)
    #stability
    corner_to_dir = {0: [4, 6], 7: [0, 4], 56: [3, 6], 63: [0, 3]}
    for corner in (0, 7, 56, 63):
        mask = 1 << 63-corner
        if p_board & mask:
            cv += 1
            for dir in corner_to_dir[corner]:
                r = corner // 8 + r_dir[dir]
                c = corner % 8 + c_dir[dir]
                while r >= 0 and r < N and c >= 0 and c < N and p_board & (1 << 63-(N*r+c)):
                    dv += 1
                    r += r_dir[dir]
                    c += c_dir[dir]
        elif o_board & mask:
            cv -= 1
            for dir in corner_to_dir[corner]:
                r = corner // 8 + r_dir[dir]
                c = corner % 8 + c_dir[dir]
                while r >= 0 and r < N and c >= 0 and c < N and o_board & (1 << 63-(N*r+c)):
                    dv -= 1
                    r += r_dir[dir]
                    c += c_dir[dir]
    #bad moves
    corner_to_space = {0: [1, 8, 9], 7: [6, 14, 15], 56: [48, 49, 57], 63: [54, 55, 62]}
    for corner in corner_to_space:
        mask = 1 << 63-corner
        if not p_board & mask and not o_board & mask:
            for space in corner_to_space[corner]:
                mask2 = 1 << 63-space
                if p_board & mask2:
                    lv -= 1
                elif o_board & mask2:
                    lv += 1
    score = 100 * pv + 00 * cv + 400 * lv + 450 * dv
    return score


def mini_max(p_board, o_board, depth, maximize, alpha, beta):
    #global moves
    state = (p_board, o_board)
    if state in dp:
        return dp[state]
    if depth == MAX_DEPTH:
        dp[state] = (eval(p_board, o_board), -1)
        return dp[state]
    if maximize:
        max_value = -1*INF
        move = -1
        for i in range(0, N*N):
            mask = 1 << 63-i
            if not p_board & mask and not o_board & mask:
                flip = make_move(p_board, o_board, i//N, i%N)
                if flip:
                    mask2 = reduce(lambda x, y: x ^ y, flip)
                    p_board ^= mask
                    p_board ^= mask2
                    o_board ^= mask2
                    value = mini_max(p_board, o_board, depth+1, not maximize, alpha, beta)[0]
                    if value > max_value:
                        max_value = value
                        move = i
                    p_board ^= mask
                    p_board ^= mask2
                    o_board ^= mask2
                    alpha = max(alpha, value)
                    if alpha >= beta:
                        break
        if move == -1:
            max_value = mini_max(p_board, o_board, depth+1, not maximize, alpha, beta)[0]
        dp[state] = (max_value, move)
        return max_value, move
    else:
        min_value = INF
        move = -1
        for i in range(0, N*N):
            mask = 1 << 63 - i
            if not p_board & mask and not o_board & mask:
                flip = make_move(o_board, p_board, i//N, i%N)
                if flip:
                    mask2 = reduce(lambda x, y: x ^ y, flip)
                    o_board ^= mask
                    p_board ^= mask2
                    o_board ^= mask2
                    value = mini_max(p_board, o_board, depth+1, not maximize, alpha, beta)[0]
                    if value < min_value:
                        min_value = value
                        move = i
                    o_board ^= mask
                    p_board ^= mask2
                    o_board ^= mask2
                    beta = min(beta, value)
                    if alpha >= beta:
                        break
        if move == -1:
            min_value = mini_max(p_board, o_board, depth+1, not maximize, alpha, beta)[0]
        dp[state] = (min_value, move)
        return min_value, move


def findBestMove(brd, token):
    global p_dis, o_dis, MAX_DEPTH, dp
    board = brd
    player = token
    opponent = 'X' if player == 'O' else 'O'
    p_dis = player
    o_dis = opponent
    p_board = 0x0000000000000000
    o_board = 0x0000000000000000
    for i in range(0, N*N):
        if board[i] == player:
            p_board |= 1 << 63-i
        elif board[i] == opponent:
            o_board |= 1 << 63-i
    total = 64-bin(p_board).count('1')+bin(o_board).count('1')
    mv = -1
    for i in range(min(4, total), total+1):
        MAX_DEPTH = i
        dp = {}
        mv = mini_max(p_board, o_board, 0, True, -1*INF, INF)
    return mv


class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?', '').replace('@', 'X')
        token = 'X' if player == '@' else 'O'
        mv = findBestMove(brd, token)
        mv1 = 11 + (mv//8)*10 + (mv%8)
        best_move.value = mv1