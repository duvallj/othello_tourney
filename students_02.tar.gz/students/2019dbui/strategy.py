#
#2019dbui
import sys
import random
# gameBoard = ''.join(list(gameBoard).remove('?')).replace('@', 'X')

corners = {0, 7, 56, 63}
edges = {*range(0, 8)} | {*range(56, 63)} | {*range(0, 57, 8)} | {*range(7, 64, 8)}

def display(board):
	print(''.join([board[i] + '\n' if i % 8 == 7 else board[i] for i in range(len(board))]))

def legalMoves(board, turn):
	opposing = 'O' if turn == 'X' else 'X'
	legal = set()
	opposingSpaces = {x for x in range(64) if board[x] == opposing}
	for index in opposingSpaces:
		# print(index)
		adjacent = {x for x in stepUp(index) | stepDown(index) | stepLeft(index) | stepRight(index) if board[x] == '.'}
		# print(adjacent)
		legal = legal | {x for x in adjacent if checkLegality(board, x, turn)}
	return legal

def stepUp(index):
	if index // 8 != 0:
		return {index - 8} | stepLeft(index - 8) | stepRight(index - 8)
	else:
		return set()

def stepDown(index):
	if index // 8 != 7:
		return {index + 8} | stepLeft(index + 8) | stepRight(index + 8)
	else:
		return set()

def stepLeft(index):
	if index % 8 != 0:
		return {index - 1}
	else:
		return set()

def stepRight(index):
	if index % 8 != 7:
		return {index + 1}
	else:
		return set()

def checkLegality(board, index, turn):
	return checkUp(board, index, turn) or checkDown(board, index, turn) or checkLeft(board, index, turn) or checkRight(board, index, turn) or checkUpLeft(board, index, turn) or checkUpRight(board, index, turn) or checkDownRight(board, index, turn) or checkDownLeft(board, index, turn)

def checkUp(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	up = False
	place = index
	place -= 8
	if place > -1 and gameBoard[place] == opposing:
		while(place > -1):
			if gameBoard[place] == turn:
				up = True
				place = -1
			elif gameBoard[place] == '.':
				place = -1
			place -= 8
	return up

def checkDown(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	down = False
	place = index
	place += 8
	if place < 64 and gameBoard[place] == opposing:
		while(place < 64):
			if gameBoard[place] == turn:
				down = True
				place = 64
			elif gameBoard[place] == '.':
				place = 64
			place += 8
	return down

def checkLeft(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	left = False
	if index % 8 != 0:
		place = index
		place -= 1
		if place % 8 != 0 and gameBoard[place] == opposing:
			while(place > -1 and place % 8 != 7):
				if gameBoard[place] == turn:
					left = True
					place = -1
				elif gameBoard[place] == '.':
					place = -1
				place -= 1
	return left

def checkRight(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	right = False
	if index % 8 != 7:
		place = index
		place += 1
		if place % 8 != 7 and gameBoard[place] == opposing:
			while(place < 64 and place % 8 != 0):
				if gameBoard[place] == turn:
					right = True
					place = 64
				elif gameBoard[place] == '.':
					place = 64
				place += 1
	return right

def checkUpLeft(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	upleft = False
	if index % 8 != 0 and index // 8 != 0:
		place = index
		place -= 9
		if place > -1 and place % 8 != 0 and gameBoard[place] == opposing:
			while(place > -1 and place % 8 != 7):
				if gameBoard[place] == turn:
					upleft = True
					place = -1
				elif gameBoard[place] == '.':
					place = -1
				place -= 9
	return upleft

def checkUpRight(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	upright = False
	if index % 8 != 7 and index // 8 != 0:
		place = index
		place -= 7
		if place > -1 and place % 8 != 7 and gameBoard[place] == opposing:
			while(place > -1 and place % 8 != 0):
				if gameBoard[place] == turn:
					upright = True
					place = -1
				elif gameBoard[place] == '.':
					place = -1
				place -= 7
	return upright

def checkDownLeft(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	downleft = False
	if index % 8 != 0 and index // 8 != 7:
		place = index
		place += 7
		if place < 64 and place % 8 != 0 and gameBoard[place] == opposing:
			while(place < 64 and place % 8 != 7):
				if gameBoard[place] == turn:
					downleft = True
					place = 65
				elif gameBoard[place] == '.':
					place = 65
				place += 7
	return downleft

def checkDownRight(gameBoard, index, turn):
	opposing = 'O' if turn == 'X' else 'X'
	downright = False
	if index % 8 != 7 and index // 8 != 7:
		place = index
		place += 9
		if place < 64 and place % 8 != 7 and gameBoard[place] == opposing:
			while(place < 64 and place % 8 != 0):
				if gameBoard[place] == turn:
					downright = True
					place = 64
				elif gameBoard[place] == '.':
					place = 64
				place += 9
	return downright

def evalBoard(gameBoard, token):
	opponent = 'X' if token == 'O' else 'O'
	score = .5 * (len([1 for x in gameBoard if x == token]) - len([1 for x in gameBoard if x == opponent]))
	score += 3 * len([1 for x in edges if gameBoard[x] == token])
	score -= 4 * len([1 for x in edges if gameBoard[x] == opponent])
	score += len(legalMoves(gameBoard, token)) - len(legalMoves(gameBoard, opponent))
	score += 4 * (frontierPieces(gameBoard, opponent) - frontierPieces(gameBoard, token))
	#score += 3 * stableMoves(gameBoard, token)
	return score

def frontierPieces(gameBoard, turn):
	total = 0;
	for pos in range(0, 64):
		isFrontier = False
		if gameBoard[pos] == turn:
			adjacent = {x for x in stepUp(pos) | stepDown(pos) | stepLeft(pos) | stepRight(pos) if gameBoard[x] == '.'}
			for move in adjacent:
				if gameBoard[move] == '.':
					isFrontier = True
		if isFrontier:
			total += 1
			isFrontier = False
	return total


# def stableMoves(board, token):
# 	opponent = 'X' if token == 'O' else 'O'
# 	total = 0;
# 	for pos in board:
# 		if board[pos] == token:
# 			if isStable(board, pos, token):
# 				total += 1;
# 	return total

# def isStable(board, pos, token):
# 	if pos not in *range(0, 64):
# 		return True
# 	else:
# 		if place % 8 == 0
# 		return isStable(board, pos - 9, token) and isStable(board, pos - 8, token) and isStable(board, pos - 7, token) and isStable(board, pos - 1, token) \
# 		and isStable(board, pos + 1, token) and isStable(board, pos + 7, token) and isStable(board, pos + 8, token) and isStable(board, pos + 9, token)



def flipTokens(board, token, pos):
	opposing = 'O' if token == 'X' else 'X'
	if pos == -1:
		return board
	board = list(board)
	if checkUp(board, pos, token):
		place = pos - 8
		while place > -1 and board[place] == opposing:
			board[place] = token
			place -= 8
	if checkDown(board, pos, token):
		place = pos + 8
		while place < 64 and board[place] == opposing:
			board[place] = token
			place += 8
	if checkLeft(board, pos, token):
		place = pos - 1
		while place % 8 != 0 and board[place] == opposing:
			board[place] = token
			place -= 1
	if checkRight(board, pos, token):
		place = pos + 1
		while place % 8 != 7 and board[place] == opposing:
			board[place] = token
			place += 1
	if checkUpLeft(board, pos, token):
		place = pos - 9
		while place % 8 != 0 and place // 8 != 0 and board[place] == opposing:
			board[place] = token
			place -= 9
	if checkUpRight(board, pos, token):
		place = pos - 7
		while place % 8 != 7 and place // 8 != 0 and board[place] == opposing:
			board[place] = token
			place -= 7
	if checkDownLeft(board, pos, token):
		place = pos + 7
		while place % 8 != 0 and place // 8 != 7 and board[place] == opposing:
			board[place] = token
			place += 7
	if checkDownRight(board, pos, token):
		place = pos + 9
		while place % 8 != 7 and place // 8 != 7 and board[place] == opposing:
			board[place] = token
			place += 9
	board[pos] = token
	return ''.join(board)

def negaMax(board, token, levels):
	if token == 'X':
		other = 'O'
	else:
		other = 'X'
	if not levels or (not legalMoves(board, token) and not legalMoves(board, other)):
		return [evalBoard(board, token)]
	lm = legalMoves(board, token)
	if not lm:
		nm = negaMax(board, other, levels - 1) + [-1]
		return [-nm[0]] + nm[1:]
	nmList = sorted([negaMax(flipTokens(board, token, mv), other, levels-1) + [mv] for mv in lm])
	best = nmList[0]
	return [-best[0]] + best[1:]

def getMove(brd, turn):
	opposing = 'O' if turn == 'X' else 'X'
	available = legalMoves(brd, turn)
	print(available)
	goodMoves = set()
	for move in corners:
		if move in available:
			goodMoves.add(move)
	if goodMoves:
		bestMove = goodMoves.pop();
		for move in goodMoves:
			if evalBoard(flipTokens(brd, turn, move), opposing) < evalBoard(flipTokens(brd, turn, bestMove), opposing):
				bestMove = move
		return bestMove
	else:
		for move in edges:
			if move in available:
				if move // 8 == 0:
					if brd[0] == turn:
						place = move
						isGood = True
						place -= 1
						while place > -1:
							if brd[place] != turn:
								isGood = False
							place -= 1
						if isGood:
							goodMoves.add(move)
					if brd[7] == turn:
						place = move
						isGood = True
						place += 1
						while place < 8:
							if brd[place] != turn:
								isGood = False
							place += 1
						if isGood:
							goodMoves.add(move)
				if move // 8 == 7:
					if brd[56] == turn:
						place = move
						isGood = True
						place -= 1
						while place > 55:
							if brd[place] != turn:
								isGood = False
							place -= 1
						if isGood:
							goodMoves.add(move)
					if brd[63] == turn:
						place = move
						isGood = True
						place += 1
						while place < 63:
							if brd[place] != turn:
								isGood = False
							place += 1
						if isGood:
							goodMoves.add(move)
				if move % 8 == 0:
					if brd[0] == turn:
						place = move
						isGood = True
						place -= 8
						while place > -1:
							if brd[place] != turn:
								isGood = False
							place -= 8
						if isGood:
							goodMoves.add(move)
					if brd[56] == turn:
						place = move
						isGood = True
						place += 8
						while place < 63:
							if brd[place] != turn:
								isGood = False
							place += 8
						if isGood:
							goodMoves.add(move)
				if move % 8 == 7:
					if brd[7] == turn:
						place = move
						isGood = True
						place -= 8
						while place > 7:
							if brd[place] != turn:
								isGood = False
							place -= 8
						if isGood:
							goodMoves.add(move)
					if brd[63] == turn:
						place = move
						isGood = True
						place += 8
						while place < 63:
							if brd[place] != turn:
								isGood = False
							place += 8
						if isGood:
							goodMoves.add(move)
		if goodMoves:
			bestMove = goodMoves.pop();
			for move in goodMoves:
				if evalBoard(flipTokens(brd, turn, move), opposing) < evalBoard(flipTokens(brd, turn, bestMove), opposing):
					bestMove = move
			return bestMove
		else:
			worstMoves = set()
			badMoves = set()
			goodMoves = available
			if brd[0] != turn:
				if 1 in goodMoves:
					goodMoves.remove(1)
					worstMoves.add(1)
				if 8 in goodMoves:
					goodMoves.remove(8)
					worstMoves.add(8)
				if 9 in goodMoves:
					goodMoves.remove(9)
					worstMoves.add(9)
			if brd[7] != turn:
				if 6 in goodMoves:
					goodMoves.remove(6)
					worstMoves.add(6)
				if 14 in goodMoves:
					goodMoves.remove(14)
					worstMoves.add(14)
				if 15 in goodMoves:
					goodMoves.remove(15)
					worstMoves.add(15)
			if brd[56] != turn:
				if 48 in goodMoves:
					goodMoves.remove(48)
					worstMoves.add(48)
				if 49 in goodMoves:
					goodMoves.remove(49)
					worstMoves.add(49)
				if 57 in goodMoves:
					goodMoves.remove(57)
					worstMoves.add(57)
			if brd[63] != turn:
				if 54 in goodMoves:
					goodMoves.remove(54)
					worstMoves.add(54)
				if 55 in goodMoves:
					goodMoves.remove(55)
					worstMoves.add(55)
				if 62 in goodMoves:
					goodMoves.remove(62)
					worstMoves.add(62)
			for edge in edges:
				if edge in goodMoves:
					goodMoves.remove(edge)
					badMoves.add(edge)
			if goodMoves:
				bestMove = goodMoves.pop();
				for move in goodMoves:
					if evalBoard(flipTokens(brd, turn, move), opposing) < evalBoard(flipTokens(brd, turn, bestMove), opposing):
						bestMove = move
				return bestMove
			if badMoves:
				bestMove = badMoves.pop();
				for move in badMoves:
					if evalBoard(flipTokens(brd, turn, move), opposing) < evalBoard(flipTokens(brd, turn, bestMove), opposing):
						bestMove = move
				return bestMove
			if worstMoves:
				bestMove = worstMoves.pop();
				for move in worstMoves:
					if evalBoard(flipTokens(brd, turn, move), opposing) < evalBoard(flipTokens(brd, turn, bestMove), opposing):
						bestMove = move
				return bestMove
			return random.choice([*legalMoves(brd, turn)])

def main():
	#...........................OX......XO...........................
	if len(sys.argv) == 1:
		gameBoard = '...........................OX......XO...........................'
		turn = 'X'
	elif len(sys.argv) == 2:
		if len(sys.argv[1]) > 1:
			gameBoard = sys.argv[1].upper()
			if len([1 for x in gameBoard if x == '.']) % 2 == 0:
				turn = 'X'
			else:
				turn = 'O'
		else:
			gameBoard = '...........................OX......XO...........................'
			turn = sys.argv[1].upper()
	else:
		if len(sys.argv[1]) > 1:
			gameBoard = sys.argv[1].upper()
			turn = sys.argv[2].upper()
		else:
			gameBoard = sys.argv[2].upper()
			turn = sys.argv[1].upper()
	if turn == 'X':
		opposing = 'O'
	else:
		opposing = 'X'
	display(gameBoard)
	availableMoves = legalMoves(gameBoard, turn)
	guaranteed = availableMoves.pop()
	print('{} is a guaranteed move'.format(guaranteed))
	availableMoves.add(guaranteed)
	if gameBoard.count('.') <= 8:
		choice = negaMax(gameBoard, turn, -1)
		print('Negamax returns {} and I choose move {}'.format(choice, choice[-1]))
	else:
		print("My heuristic choice is {}".format(getMove(gameBoard, turn)))

class Strategy():
	if __name__ == "__main__":
		main()
	def best_strategy(self, board, player, best_move, still_running):
		brd = ''.join(board).replace('?', '').replace('@', 'X').replace('o', 'O').upper()
		if player == '@':
			token = 'X' 
		else:
			token = 'O'
		#depth

		mv = getMove(brd, token)
		mv1 = 11 + (mv // 8) * 10 + (mv % 8)
		best_move.value = mv1

		n = 7
		if brd.count('.') <= n:
			mv = negaMax(brd, token, -1)[-1]
			best_move.value = 11 + (mv // 8) * 10 + (mv % 8)