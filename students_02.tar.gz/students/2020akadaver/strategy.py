import sys
import time
surroundingSquares1 = {}
for i in range(8):
    for j in range(8):
        x = i
        y = j
        surroundingSquares1[8*i+j] = [8*i+j for i in range(max(0, x-1), min(7, x+1)+1) for j in range(max(0, y-1), min(7, y+1)+1)]
class Strategy:
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?', '').replace('@', 'X').replace('o', 'O')
        token = 'X' if player == '@' else 'O'
        if (list(brd).count(".") <= 10):
            mv = findBestMove(list(brd), token)[-1]
        else:
            mv = bestMove(list(brd), legalMoves(list(brd), token), token)
            if (mv == -1):
                mv = legalMoves(list(brd), token).pop()
        mv1 = 11+ (mv//8)*10 + mv%8
        best_move.value = mv1
def btp(othelloBoard, whoseMove, p):
    if othelloBoard[p] != '.':
        return ""
    cb = othelloBoard[:]
    opponentMove = ''
    if whoseMove == 'O':
        opponentMove = 'X'
    else:
        opponentMove = 'O'
    cb[p] = whoseMove
    for j in surroundingSquares1[p]:
        if (cb[j] == opponentMove):
            diffx = j//8 - p//8
            diffy = j%8-p%8
            arraytemp = []
            tempx = j//8
            tempy = j%8
            while(tempx <8 and tempx >= 0 and tempy<8 and tempy >= 0):
                arraytemp.append(8*tempx+tempy)
                tempx+=diffx
                tempy+=diffy
            count = 0
            for k in arraytemp:
                if cb[k] == whoseMove:
                    for asdf in arraytemp[:count]:
                        cb[asdf] = whoseMove
                    break
                if cb[k] == '.':
                    break
                count+=1
    return cb
def bestMove(board, setInput, whoseMove):
    opponentMove = ""
    if (whoseMove == 'X'):
        opponentMove = 'O'
    else:
        opponentMove = 'X'
    for k in setInput:
        if k == 0 or k == 7 or k == 56 or k == 63:
            return k
    for k in setInput:
        if k%8 == 0 or k%8 == 7 or k<8 or k>=56:
            if k%8 == 0:
                if board[0] == whoseMove and len(set(board[8:k]))==1 and board[8] != '.':
                    return k
                if board[0] == whoseMove and len(set(board[k+8:56]))==1 and board[k+8] != '.':
                    return k
            if k%8 == 7:
                if board[7] == whoseMove and len(set(board[15:k]))==1 and board[15] != '.':
                    return k
                if board[0] == whoseMove and len(set(board[k+8:63]))==1 and board[k+8] != '.':
                    return k
            if k<8:
                if board[0] == whoseMove and len(set(board[1:k]))==1 and board[1] != '.':
                    return k
                if board[0] == whoseMove and len(set(board[k+1:7]))==1 and board[k+1] != '.':
                    return k
            if k>=56:
                if board[0] == whoseMove and len(set(board[57:k]))==1 and board[57] != '.':
                    return k
                if board[0] == whoseMove and len(set(board[k+1:63]))==1 and board[k+1] != '.':
                    return k
    answerSetNew = set(setInput)
    for k in setInput:
        if k%8 == 0 or k%8 == 7 or k<8 or k>=56 and len(answerSetNew) != 1:
            answerSetNew.remove(k)
    if (board[0] == opponentMove):
        if (1 in answerSetNew and len(answerSetNew) !=1):
            answerSetNew.remove(1)
        if (8 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(8)
        if (9 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(9)
    if (board[7] == opponentMove):
        if (6 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(6)
        if (15 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(15)
        if (14 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(14)
    if (board[56] == opponentMove):
        if (48 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(48)
        if (49 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(49)
        if (57 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(57)
    if (board[63] == opponentMove):
        if (62 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(62)
        if (55 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(55)
        if (54 in answerSetNew and len(answerSetNew) != 1):
            answerSetNew.remove(54)
    if (len(answerSetNew) == 0):
        return -1
    for ks in setInput:
        if ks != 63 and ks!= 56 and ks!= 7 and ks!= 0:
            return ks
    return answerSetNew.pop()
def printBoard(b):
    for i in range(8):
        tmp = ""
        for j in range(8):
            tmp+= b[8*i+j] + " "
        print(tmp)
    print()
def findBestMove(brd, token):
    opponentMove = ''
    if token == 'O':
        opponentMove = 'X'
    else:
        opponentMove = 'O'
    nm = negamaxTerminal(brd, token, -65, 65)
    return nm
def surroundingSquares(a):
    x = a//8
    y = a%8
    return [8*i+j for i in range(max(0, x-1), min(7, x+1)+1) for j in range(max(0, y-1), min(7, y+1)+1)]
def legalMoves(othelloBoard, whoseMove):
    opponentMove = ''
    if whoseMove == 'O':
        opponentMove = 'X'
    else:
        opponentMove = 'O'
    dictPossibleRightNow = {}
    for i in range(64):
        if (othelloBoard[i] == opponentMove):
            for j in surroundingSquares1[i]:
                if j >= 0 and j<64 and othelloBoard[j] == '.':
                    if j in dictPossibleRightNow:
                        dictPossibleRightNow[j].append(i)
                    else:
                        dictPossibleRightNow[j] = [i]
    setActualAns = set()
    count = 0
    for i in dictPossibleRightNow:
        for j in dictPossibleRightNow[i]:
            diffx = j//8 - i//8
            diffy = j%8-i%8
            arraytemp = []
            tempx = j//8
            tempy = j%8
            while(tempx <8 and tempx >= 0 and tempy<8 and tempy >= 0):
                arraytemp.append(8*tempx+tempy)
                tempx+=diffx
                tempy+=diffy
            count1 = count
            for k in arraytemp:
                if othelloBoard[k] != opponentMove and othelloBoard[k] == whoseMove:
                    setActualAns.add(i)
                    break
                elif othelloBoard[k] != opponentMove and othelloBoard[k] == '.':
                    break
                else:
                    count+=1
            if (count-count1 == 0):
                setActualAns.remove(i)
    return setActualAns
def evalBoard(board, token):
    opponentToken = ""
    if (token == 'O'):
        opponentToken = 'X'
    else:
        opponentToken = 'O'
    return board.count(token) - board.count(opponentToken)
def opponentToken(token):
    if token.upper() == 'O':
        return 'X'
    return 'O'
def makeMove(board, token, move):
    bc = board[:]
    bc[move] = token
    return bc
def negamaxTerminal(brd, token, improvable, hardbound):
    lm = legalMoves(brd, token)
    if not lm:
        lm1 = legalMoves(brd, opponentToken(token))
        if not lm1:
            return [evalBoard(brd, token), -3]
        nm = negamaxTerminal(brd, opponentToken(token), -hardbound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(btp(brd, token, mv), opponentToken(token), -hardbound, newHB) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardbound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
def negamax(board, token, levels):
    if not levels:
        return [evalBoard(board, token)]
    lm = legalMoves(board, token)
    if not lm:
        nm = negamax(board, opponentToken(token), levels-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makeMove(board, token, mv), opponentToken(token), levels-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]
# nm = negamax(board, token, 3)
# print(nm)

def main():
    printBoard(list(sys.argv[1].upper()))
    print("legal moves " + str(legalMoves(list(sys.argv[1].upper()), sys.argv[2].upper())))
    nmm = bestMove(list(sys.argv[1]), legalMoves(list(sys.argv[1]), sys.argv[2]), sys.argv[2])
    if nmm == -1:
        nmm = legalMoves(list(sys.argv[1].upper()), sys.argv[2].upper()).pop()
    print("my heuristic move is " + str(nmm))
    if (list(sys.argv[1].upper()).count('.') <= 14):
        nmm = findBestMove(list(sys.argv[1].upper()), sys.argv[2].upper())
        ans = ''
        for i in nmm:
            ans = ans + str(i) + " "
        print("negamax " + ans)
if (__name__ == "__main__"):
    main()

#reasons for not reaching lab 6 percentage
#if you just put in greedy corners --> 58%
#if you are playing inside inner box (last option) --> 48%
#greedy corners + inner --> 61.2%
#just having C X restriction --> 65.5%
#greedy corners + C X restriction --> 67.3%
#put in all three of those improvements --> 65.5%
#adding last improvement left --> 75%


#DONT NECESSARY CHOOSE THE FIRST ONE or something that the computer knows what to put
