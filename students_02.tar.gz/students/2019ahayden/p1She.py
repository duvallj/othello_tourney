#strategy.py
import sys, random
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
sym1, sym2, symE, symA = "X", "O", ".", "#"
N = 60

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        player = sym1 if player == BLACK else sym2

        brd = ''.join(str(v) for v in board)
        brd = brd.replace(OUTER, '').replace(BLACK, sym1).replace(WHITE, sym2)
        # brd = str((''.join(board)).replace(OUTER, '').replace(BLACK, sym1).replace(WHITE, sym2))
        newb = [[] for i in range(8)]
        for idx, sym in enumerate(brd):
            newb[idx // 8].append(sym)
        board = newb
        mv = imp(board, player)
        best_move.value = 11+(mv//8)*10+(mv%8)
        depth = -1
        #while(True):
        if brd.count(EMPTY) < N:
            mv = negamax(board, player, depth)[-1]
            best_move.value = 11+(mv//8)*10+(mv%8)
            #depth += 2

def posToRC(n):
    return n // 8, n % 8

def printBoard(b):
    for i in range(8):
        for j in range(8):
            print(b[i][j], " ", end="")
        print()
    print("-----------------------")

def d1B(board):
    b = ""
    for i in range(8):
        for j in range(8):
            b += board[i][j]
    return b

def withinBounds(r, c):
    return r < 8 and c < 8 and r >= 0 and c >= 0

def legalMoves(board, turn):
    legal, out = [], set()
    opp = sym1 if turn != sym1 else sym2
    for i in [a for a in range(64) if board[a // 8][a % 8] == opp]:
        moves = [(0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1), (-1, 0), (-1, 1)]
        r, c = posToRC(i)
        for e in moves:
            if withinBounds(r + e[0], c + e[1]) and board[r + e[0]][c + e[1]] == turn:
                mult = 1
                while withinBounds(r - e[0] * mult, c - e[1] * mult) and board[r - e[0] * mult][
                            c - e[1] * mult] != "." and board[r - e[0] * mult][c - e[1] * mult] != turn:
                    mult += 1
                if withinBounds(r - e[0] * mult, c - e[1] * mult) and board[r - e[0] * mult][
                            c - e[1] * mult] == ".":
                    legal.append((r - e[0] * mult, c - e[1] * mult))
    for n in legal:
        out.add(n[0]*8+n[1])
    return out
def negamax(board, token, levels): #returns a score together with a move sequence leading to that score
    enemy = sym1 if token != sym1 else sym2
    #DONE
    if not legalMoves(board, token) and not legalMoves(board, enemy):
        return [evalBoard(board, token)]
    if not levels: return [evalBoard(board, token)]
    # PASS
    lm = legalMoves(board, token)
    if not lm:
        nm = negamax(board, enemy, levels-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makeMove(board, token, mv), enemy, levels-1)+[mv] for mv in lm])
    best = nmList[0]
    return [-best[0]]+best[1:]
def evalBoard(board, token):
    enemy = sym1 if token != sym1 else sym2
    d = d1B(board)
    return d.count(token) - d.count(enemy)
def makeMove(board, token, mv):
    r, c = posToRC(mv)
    board[r][c] = token
    return board
def imp(board, t):
    enemy = sym1 if t == sym2 else sym2
    d1 = d1B(board)
    l = legalMoves(board, t)

    corners, xsq, csq = [0, 7, 56, 63], [9, 14, 49, 54], [1, 8, 6, 15, 48, 57, 55, 62]
    edges = [*range(1, 7)] + [*range(57, 63)] + [*range(8, 56, 8)] + [*range(15, 63, 8)]
    # print(edges)
    ret = set()
    # GREEDY CORNERS
    for a in corners:
        if a in l:
            ret.add(a)
    if ret:
        return random.choice([*ret])
    elif t in [d1[c] for c in corners]:
        if d1[corners[0]] == t:
            ret = set(edges[:6] + edges[-6:])
        elif d1[corners[1]] == t:
            ret = set(edges[:6] + edges[-12:-6])
        elif d1[corners[2]] == t:
            ret = set(edges[6:-6])
        elif d1[corners[3]] == t:
            ret = set(edges[6:12] + edges[-6:])
        ret = ret.intersection(l)
        if ret:
            return random.choice([*ret])
    ret = set().union(l)
    for i in range(4):
        if d1[corners[i]] != enemy:
            ret.discard(xsq[i])
            ret.discard(csq[i * 2])
            ret.discard(csq[i * 2 + 1])
    if ret:
        return ret.pop()
    else:
        return random.choice([*l])
def main():
    b = symE * 27 + sym2 + sym1 + symE * 6 + sym1 + sym2 + symE * 27
    if len(sys.argv) > 1: b = (sys.argv[1]).upper()
    if len(sys.argv) == 3: t = (sys.argv[2]).upper()
    elif b.count(".") % 2 == 0: t = sym1
    else: t = sym2

    nb = [[] for i in range(8)]
    for idx, sym in enumerate(b):
        nb[idx // 8].append(sym)
    b = nb

    printBoard(b)
    print("Legal moves: ", legalMoves(b, t))

    print("Heuristic: ", imp(b, t))
    if d1B(b).count(EMPTY) < N:
        m = negamax(b, t, -1)
        print("Negamax returns: ", m)
if __name__=="__main__":
    main()

