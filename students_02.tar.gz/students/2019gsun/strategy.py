import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,E,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
OTHER = {BLACK: WHITE, WHITE: BLACK}

class Node():
    def __init__(self, board, move = None, score = 0):
        self.board = board
        self.move = move
        self.score = score
class AB():
    def __init__(self, board, node, player, depth, a = -999999 ,b = 999999):
        self.board = board
        self.node = node
        self.player = player
        self.depth = depth
        self.a = a
        self.b = b

    def is_valid(self):
        if self.a >= self.b:
            return False
        return True
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return('???????????........??........??........??...o@...??...@o...??........??........??........???????????')

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        new =  '\n' + board[:10] + '\n' + board[10:20] + '\n' + board[20:30] + '\n' + board[30:40] + '\n' + board[40:50] + '\n' + board[50:60] + '\n' + board[60:70] + '\n' + board[70:80] + '\n' + board[80:90] + '\n' + board[90:] + '\n'
        return new
    def opponent(self, player):
        """Get player's opponent."""
        return OTHER[player]

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        pass

    def move_check(self, board, player, move, direction):
        enemy = OTHER[player]
        t = move + direction
        changes = set()
        if t < len(board) - 1  and t >= 1 and board[t] is enemy:
            while t < len(board) - 1  and t >= 1 and board[t] is enemy:
                changes.add(t)
                t += direction
            if t < len(board) - 1  and t >= 1 and board[t] is player:
                changes.add(move)
                return [True, changes]
        return [False]

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] is BLACK or board[move] is WHITE or board[move] is OUTER:
            return False

        enemy = OTHER[player]

        if self.move_check(board, player, move, N)[0]:
            return True
        if self.move_check(board, player, move, E)[0]:
            return True
        if self.move_check(board, player, move, S)[0]:
            return True
        if self.move_check(board, player, move, W)[0]:
            return True
        if self.move_check(board, player, move, (N+E))[0]:
            return True
        if self.move_check(board, player, move, (N+W))[0]:
            return True
        if self.move_check(board, player, move, (S+E))[0]:
            return True
        if self.move_check(board, player, move, (S+W))[0]:
            return True

        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        if self.is_move_valid(board,player,move) is False:
            return board
        changes = set([move])
        output = str(board)

        t = self.move_check(board, player, move, N)
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, S)
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, E)
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, W)
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, (N+E))
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, (N+W))
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, (S+E))
        if t[0]: changes.update(t[1])

        t = self.move_check(board, player, move, (S+W))
        if t[0]: changes.update(t[1])

        #print(output)
        for x in changes:
            output = output[:x] + player + output[x+1:]
        #print(output)
        return output

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        output = []
        for x in range(0,80,10):
            for y in range(11,19):
                if self.is_move_valid(board, player, x+y):
                    output.append(x+y)
        if len(output) is 0:
            return None
        return output

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if self.get_valid_moves(board, player) is None:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        next = OTHER[prev_player]
        if self.has_any_valid_moves(board, next) is False:
            if self.has_any_valid_moves(board, prev_player) is False:
                return None
            return prev_player
        return next

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        player = BLACK
        enemy = OTHER[player]
        p = 0
        e = 0
        for x in range(len(board)):
            if board[x] is player:
                p += 1
            if board[x] is enemy:
                e += 1
        return p - e
    def weighted_score(selfself, Board, player = BLACK):
        matrix = [
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
                    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                    0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
                    0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
                    0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
                    0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
                    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                    0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    ]
        '''[
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 2000000000, -20, 2000, 50, 50, 2000, -20, 2000000000, 0,
                    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                    0, 2000, -5, 15, 3, 3, 15, -5, 2000, 0,
                    0, 500, -5, 3, 3, 3, 3, -5, 500, 0,
                    0, 500, -5, 3, 3, 3, 3, -5, 500, 0,
                    0, 2000, -5, 15, 3, 3, 15, -5, 2000, 0,
                    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                    0, 2000000000, -20, 2000, 50, 50, 2000, -20, 2000000000, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    ]'''
        player = BLACK
        enemy = OTHER[player]
        p = 0
        e = 0
        #print(board)
        for x in range(0,80,10):
            for y in range(11,19):
                if Board[x+y] is player:
                    p+=matrix[x+y]
                if Board[x+y] is enemy:
                    e+=matrix[x+y]
        return p-e
    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.has_any_valid_moves(board,player) is False and self.has_any_valid_moves(board,OTHER[player]) is False:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, n, player, a, b, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if a is None:
            a = -999999
        if b is None:
            b = 999999
        ab = AB(n.board, n, player, depth, a, b)
        best = {BLACK: max, WHITE: min}
        if depth == 0:
            n.score = self.weighted_score(n.board, player)
            return n

        my_moves = self.get_valid_moves(n.board, player)
        if player is BLACK:
            my_moves.sort(key=lambda x: -1*self.weighted_score(self.make_move(n.board,player,x), player))
        else:
            my_moves.sort(key=lambda x: self.weighted_score(self.make_move(n.board,player,x), player))
        children = []
        for move in my_moves:
            next_board = self.make_move(n.board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move, score=1000 * self.weighted_score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, ab.a, ab.b, depth=depth - 1).score
                children.append(c)
                if not ab.is_valid():
                    break
                if player is BLACK:
                    ab.a = max(ab.a, c.score)
                if player is WHITE:
                    ab.b = min(ab.b, c.score)
                if not ab.is_valid():
                    break
        winner = best[player](children, key=lambda x: x.score)
        n.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node(board), player, None, None, depth).move
    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        board = ''.join(board)
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    #game =  ParallelPlayer(5)
    game = StandardPlayer()
    game.play()