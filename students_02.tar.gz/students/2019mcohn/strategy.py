#Jan 12, 0952 version

import random
import math
import copy

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
Dia= [11, 18, 81, 88]
Bad = [12, 17, 21, 22, 27, 28, 71, 72, 77, 78, 82, 87]
Sides = [11, 13, 14, 15,16,18,31,41, 51, 61, 38, 48, 58, 68, 81, 83, 84, 85 ,86, 88]
DIAGS = [1, -1, 10, -10, 9, -9, 11, -11]
PLAYERS = {BLACK: "Black", WHITE: "White"}
score_matrix =[ 0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 0, 10000000000, -2000000000000,  20000,   5000,   5000,  20000, -2000000000000, 10000000000,   0,
    0, -2000000000, -8000000000000,  -5,  -5,  -5,  -5, -80000000000000, -2000000000000,   0,
    0,  20000,  -5,  15,   3,   3,  15,  -5,  20000,   0,
    0,   5000,  -5,   3,   3,   3,   3,  -5,   5000,   0,
    0,   5000,  -5,   3,   3,   3,   3,  -5,   5000,   0,
    0,  20000,  -5,  15,   3,   3,  15,  -5,  20000,   0,
    0, -20000000000000, -800000000000000,  -5,  -5,  -5,  -5, -80000000000000, -200000000000000,   0,
    0, 10000000000, -2000000000000,  20000,   5000,   5000,  20000, -2000000000000000, 10000000000,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,]
score_m = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, move, board, score):
        self.move = move
        self.board = board
        self.score = score
class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        st = ''
        for r in range(10):
            for c in range(10):
                st+=board[r*10+c]+' '
            st+='\n'
        return st

    def opponent(self, player):
        if player == BLACK:
            return WHITE
        else:
            return BLACK

    def find_match(self, board, player, move, dir):
        ind = move
        ind += dir
        if player == WHITE:
            if board[ind] == BLACK:
                while board[ind] == BLACK:
                    ind += dir
                if board[ind] == WHITE:
                    while not ind == move:
                        board = self.change(board, player, ind)
                        ind-=dir
                    return board
            return None
        else:
            while board[ind] == WHITE:
                ind += dir
                if board[ind] == BLACK:
                    while not ind == move:
                        board = self.change(board, player, ind)
                        ind-=dir
                    return board
            return None
    def change(self, board, player, move):
        st = ''
        for i in range(100):
            if i == move:
                st += player
            else:
                st += board[i]
        return st
    def is_move_valid(self, board, player, ind, dir):

        ind +=dir
        if player == WHITE:
            if board[ind]==BLACK:
                while board[ind] == BLACK:
                    ind +=dir
                if board [ind]== WHITE:
                    return True
            return False
        else:
            while board[ind] == WHITE:
                ind +=dir
                if board [ind]== BLACK:
                    return True
            return False
    def make_move(self, board, player, move):
        board = self.change(board, player, move)
        matches = []
        for d in DIRECTIONS:
            m = self.find_match(board, player, move, d)
            if not m == None:
                board = m
        return board
    def get_valid_moves(self, board, player):
        moves = []
        for s in range(11, 89):
            if board[s] == '.':
                for d in DIRECTIONS:
                    if self.is_move_valid(board, player, s, d):
                        moves.append(s)
                        break
        return moves

    def has_any_valid_moves(self, board, player):
        return not len(self.get_valid_moves(board, player))==0

    def next_player(self, board, prev_player):
        if prev_player == BLACK:
            if self.has_any_valid_moves(board, WHITE):
                return WHITE
            elif self.has_any_valid_moves(board, BLACK):
                return BLACK
            else:
                return None
        else:
            if self.has_any_valid_moves(board, BLACK):
                return BLACK
            elif self.has_any_valid_moves(board, WHITE):
                return WHITE
            else:
                return None


    def score(self, board, player=BLACK):
        score = 0
        for i in board:
            if i == '@':
                score+=1
            if i == 'o':
                score-=1
        return score

    def game_over(self, board, player):
        return self.next_player(board, player)==None

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if self.game_over(board, player):
            return self.score(board)*1000000
        if not self.has_any_valid_moves(board,player):
            if player == BLACK:
                return random.random()+self.weighted_score(board)+self.score(board)
            else:
                return random.random()+self.weighted_score(board)+self.score(board)
        if depth == 0:
            return self.weighted_score(board)+random.random()+self.score(board)
        moves = self.get_valid_moves(board, player)
        if player==BLACK:
            return max(moves, key=lambda m:self.minmax_search(self.make_move(board, player, m), WHITE, depth-1))
        else:
            return min(moves, key=lambda m: self.minmax_search(self.make_move(board, player, m), BLACK, depth-1))

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(board, player, depth)

    def alphabeta_search(self, node, player, depth, alpha=-999999999999999999999999999999999, beta=99999999999999999999999999999):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if self.game_over(node.board, player):
            return Node(node.move, node.board, self.score(node.board) * 100000000000000000000000)
        if not self.has_any_valid_moves(node.board, player):
            score = 0
            if player==BLACK:
                player = WHITE
            elif player==WHITE:
                player=BLACK
        moves = self.get_valid_moves(node.board, player)
        extra = []
        for b in Bad:
           if b in moves:
                moves.remove(b)
                extra.append(b)
        if len(moves) == 0:
            for e in extra:
                moves.append(e)
        extra = []
        for m in moves:
            if not m in Sides:
                moves.remove(m)
                extra.append(m)
        if len(moves) == 0:
            for e in extra:
                moves.append(e)
        if player==BLACK:
            if 11 in moves:
                return Node(11, self.make_move(node.board, player, 11), 999999999999999999999)
            if 18 in moves:
                return Node(18, self.make_move(node.board, player, 18), 999999999999999999999)
            if 81 in moves:
                return Node(81, self.make_move(node.board, player, 81), 999999999999999999999)
            if 88 in moves:
                return Node(88, self.make_move(node.board, player, 88), 999999999999999999999)
        else:
            if 11 in moves:
                return Node(11, self.make_move(node.board, player, 11), -999999999999999999999)
            if 18 in moves:
                return Node(18, self.make_move(node.board, player, 18), -999999999999999999999)
            if 81 in moves:
                return Node(81, self.make_move(node.board, player, 81), -999999999999999999999)
            if 88 in moves:
                return Node(88, self.make_move(node.board, player, 88), -999999999999999999999)
        if depth == 0:
            if player == BLACK:
                return Node(node.move, node.board, random.random() + self.weighted_score(node.board)+len(moves)*5)
            else:
                return Node(node.move, node.board, random.random() + self.weighted_score(node.board) - len(moves)*5)

        nodes =[]
        for m in moves:
            if player == BLACK:
                node=(self.alphabeta_search(Node(m,self.make_move(node.board, player, m), node.score), WHITE, depth - 1, alpha, beta))

                alpha = max(alpha, node.score)
            else:
                node = (self.alphabeta_search(Node(m,self.make_move(node.board, player, m), node.score), BLACK, depth - 1, alpha, beta))
                beta = min(beta, node.score)
            nodes.append(Node(m,node.board, node.score))
            if alpha >= beta:
                #print('pruned')
                break
        if player==BLACK:
            return max(nodes, key=lambda x:x.score)
        else:
            return min(nodes, key=lambda x:x.score)


    def alphabeta_strategy(self, board, player, depth=6):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        n = Node(None, board, None)
        return self.alphabeta_search(n, player, depth).move
    def weighted_score(self, board):
        score = 0
        for s in range(100):
            if board[s]==BLACK:
                score+=score_m[s]
            elif board[s]==WHITE:
                score-=score_m[s]
        return score
    '''def weighted_score(self, board):
        score = 0
        empty=0
        black = 0
        white = 0
        for s in range(100):
            if board[s]==EMPTY:
                empty+=1
            if board[s]==BLACK:
                black +=1
            if board[s]==WHITE:
                white+=1
        if empty>32:
            score += (white-black)*1000
        for s in range(100):
            if board[s]==BLACK:
                if abs(score_matrix[s])>100000:
                    score+= score_matrix[s]*100000
                else:
                    if s%10<4 and s/10<4:
                        score+=2000
                    elif s%10>6 and s/10>6:
                        score-=1000
                    elif s%10>6 or s/10>6:
                        score-=500
                    score+= score_matrix[s]
                    ''''''if board[s+1]==WHITE and board[s-1]==WHITE and board[s+10]==WHITE and board[s-10]==WHITE and board[s+11]==WHITE and board[s-11]==WHITE and board[s+9]==WHITE and board[s-9]==WHITE:
                        score+=100''''''
                    score+=200
                    b = 0
                    for d in DIAGS:
                        if board [s+d]==EMPTY:
                            score-=500
                        if board[s+d]==BLACK:
                            b+=1
                        if board[s+d]==WHITE:
                            score+=100
                    if b>0 and b<4:
                        score-=1000
                    if s%10 == 1 or s%10==8 or s/10 ==1 or s/10==8:
                        p = s
                        c=1
                        while board[p]==BLACK:
                            if p in Dia:
                                score+=100*c
                            p+=1
                            c += 1
                            if board[p]==WHITE and board[s-1]==EMPTY:
                                score-=1000000*c
                        p = s
                        c = 1
                        while board[p]==BLACK:
                            if p in Dia:
                                score+=100*c
                            p-=1
                            c+=1
                            if board[p]==WHITE and board[s+1]==EMPTY:
                                score-=1000000*c
                        p = s
                        c = 1
                        while board[p]==BLACK:
                            if p in Dia:
                                score+=100*c
                            p+=10
                            c += 1
                            if board[p]==WHITE and board[s-10]==EMPTY:
                                score-=1000000*c
                        p = s
                        c = 1
                        while board[p]==BLACK:
                            if p in Dia:
                                score+=100*c
                            p-=10
                            c += 1
                            if board[p]==WHITE and board[s+10]==EMPTY:
                                score-=1000000*c

            elif board[s]==WHITE:
                if abs(score_matrix[s])>100000:
                    score-=score_matrix[s]*100000
                else:
                    score-=score_matrix[s]*100
                    ''''''if board[s+1]==BLACK and board[s-1]==BLACK and board[s+10]==BLACK and board[s-10]==BLACK and board[s+11]==BLACK and board[s-11]==BLACK and board[s+9]==BLACK and board[s-9]==BLACK:
                        score-=100''''''
                    if s%10<4 and s/10<4:
                        score-=2000
                    elif s%10>6 and s/10>6:
                        score+=1000
                    elif s%10>6 or s/10>6:
                        score+=500
                    score-=200
                    b = 0
                    for d in DIAGS:
                        if board[s + d] == EMPTY:
                            score += 500
                        if board[s + d] == WHITE:
                            b += 1
                        if board[s+d]== BLACK:
                            score-=100
                    if b > 0 and b < 4:
                        score += 1000
                    if s%10 == 1 or s%10==8 or s/10 ==1 or s/10==8:
                        p = s
                        c=1
                        while board[p]==WHITE:
                            if p in Dia:
                                score-=100*c
                            p+=1
                            c += 1
                            if board[p]==BLACK and board[s-1]==EMPTY:
                                score+=1000000*c
                        p=s
                        c=1
                        while board[p]==WHITE:
                            if p in Dia:
                                score-=100*c
                            p-=1
                            c += 1
                            if board[p]==BLACK and board[s+1]==EMPTY:
                                score+=1000000*c
                        p=s
                        c=1
                        while board[p]==WHITE:
                            if p in Dia:
                                score-=100*c
                            p+=10
                            c += 1
                            if board[p]==BLACK and board[s-10]==EMPTY:
                                score+=1000000*c
                        p=s
                        c=1
                        while board[p]==WHITE:
                            if p in Dia:
                                score-=100*c
                            p-=10
                            c += 1
                            if board[p]==BLACK and board[s+10]==EMPTY:
                                score+=1000000*c
        return score
    '''
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board, player)
            depth += 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()
