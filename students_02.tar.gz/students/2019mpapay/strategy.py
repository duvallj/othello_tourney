import sys
import multiprocessing
from functools import lru_cache
positionToCoord = dict()
coordToPosition = dict()
for i in range(64):
  positionToCoord[i] = (i%8, i//8)
  coordToPosition[(i%8, i//8)] = i
def startingplayer(pzl):
  count = 0
  for i in pzl:
    if i == '.':
      count += 1
  if count%2 == 0:
    return 'X'
  else:
    return 'O'
def printBoard(pzl):
  count = 1
  for j in pzl:
    i = ""
    if j == 1:
      i = "X"
    elif j == -1:
      i = "O"
    elif j == 0:
      i = "."
    if count == 8:
      print(i)
      count = 0
    else:
      print(i, end = ' ')
    count += 1
def convert(thingTobeConverted):
  if type(thingTobeConverted) == str:
    board = list()
    for c in thingTobeConverted:
      if c == 'X':
        board.append(1)
      elif c == 'O':
        board.append(-1)
      elif c == '.':
        board.append(0)
    return board
  if type(thingTobeConverted) == list:
    stringg = ''
    for j in thingTobeConverted:
      if j == 1:
        stringg = stringg + 'X'
      if j == -1:
        stringg = stringg + 'O'
      if j == 0:
        stringg = stringg + '.'
    return stringg
@lru_cache(maxsize=None)
def legalMoves(board, player):
  board = convert(board)
  legalset = set()
  for pos, token in enumerate(board):
    if token == 0:
      startingCoords = positionToCoord[pos]
      startx = startingCoords[0]
      starty = startingCoords[1]
      for xmod in [-1, 0, 1]:
        for ymod in [-1, 0, 1]:
          if xmod == 0 and ymod == 0:
            continue
          possiblelegal = pos
          legal = False
          countofsand = 0
          updatingx = startx + xmod
          updatingy = starty + ymod
          if updatingx < 0 or updatingx > 7:
            continue
          if updatingy < 0 or updatingy > 7:
            continue
          while True:
            testingcoord = (updatingx, updatingy)
            testingpos = coordToPosition[testingcoord]
            if board[testingpos] == 0:
                break
            if board[testingpos] == player * -1:
              countofsand += 1
            if board[testingpos] == player and countofsand > 0:
              legal = True
              break
            elif board[testingpos] == player and countofsand == 0:
              break
            updatingx += xmod
            updatingy += ymod
            if updatingx < 0 or updatingx > 7:
              break
            if updatingy < 0 or updatingy > 7:
              break
          if legal:
            legalset.add(possiblelegal)
  return legalset
  '''legalset = set()
  for pos, token in enumerate(board):
    if token != 0:
      startingCoords = positionToCoord[pos]
      startx = startingCoords[0]
      starty = startingCoords[1]
      for xmod in [-1, 0, 1]:
        for ymod in [-1, 0, 1]:
          if xmod == 0 and ymod == 0:
            continue
          if startx + xmod < 0 or startx + xmod > 7:
            continue
          if starty + ymod < 0 or starty + ymod > 7:
            continue
          newpos = coordToPosition[(startx + xmod, starty + ymod)]
          if board[newpos] == 0:
            possiblelegal = newpos
            newxmod = xmod * -1
            newymod = ymod * -1
            legal = False
            countofsand = 0
            updatingx = startx
            updatingy = starty
            while True:
              testingcoord = (updatingx, updatingy)
              testingpos = coordToPosition[testingcoord]
              if board[testingpos] == 0:
                break
              if board[testingpos] == player * -1:
                countofsand += 1
              if board[testingpos] == player and countofsand > 0:
                legal = True
                break
              elif board[testingpos] == player and countofsand == 0:
                break
              updatingx += newxmod
              updatingy += newymod
              if updatingx < 0 or updatingx > 7:
                break
              if updatingy < 0 or updatingy > 7:
                break
            if legal:
              legalset.add(possiblelegal)
  return legalset'''
def makeMove(board, token, movePos):
  copyb = [j for j in board]
  if movePos == -1:
    return copyb
  flippedpositions = set()
  for xmod in [-1, 0, 1]:
    for ymod in [-1, 0, 1]:
      if xmod == 0 and ymod == 0:
        continue
      startingcoordinates = positionToCoord[movePos]
      testingx = startingcoordinates[0]
      testingy = startingcoordinates[1]
      countofsand = 0
      validDirection = False
      possibleFlipped = set()
      while True:
        testingx = testingx + xmod
        testingy = testingy + ymod
        if testingx < 0 or testingx > 7:
          break
        if testingy < 0 or testingy > 7:
          break
        if copyb[coordToPosition[(testingx, testingy)]] == 0:
          break
        if copyb[coordToPosition[(testingx, testingy)]] == token and countofsand == 0:
          break
        if copyb[coordToPosition[(testingx, testingy)]] == token and countofsand != 0:
          validDirection = True
          break
        if copyb[coordToPosition[(testingx, testingy)]] == (token * -1):
          countofsand += 1
          possibleFlipped.add(coordToPosition[(testingx, testingy)])
      if validDirection:
        flippedpositions |= possibleFlipped
  for i in flippedpositions:
    copyb[i] = token
  copyb[movePos] = token
  return copyb
def boardEval(board, token):
  score = 0
  for i in board:
    if i == token:
      score += 1
    elif i == -token:
      score -= 1
  return score
'''def negamax(nboard, token, level): #levels will be odd
  lm = legalMoves(nboard, token)
  lm2 = legalMoves(nboard, -token)
  if not lm and not lm2:
    return [boardEval(nboard, token)]
  if not lm:
    nm = negamax(nboard, -token, level-1) + [-1]
    return [-nm[0]] + nm[1:]
  nmList = []
  copybb = [j for j in nboard]
  for move in lm:
    newBoard = makeMove(nboard, token, move)
    nboard = copybb
    nmList.append(negamax(newBoard, -token, level - 1) + [move])
  nmList = sorted(nmList)
  best = nmList[0]
  return [-best[0]] + best[1:]'''
#negamax return result: [score, lastMove, penultimateMove, ... , firstMove] (want score as high as possible)
def negamaxTerminal(board, token, improvable, hardBound): # (something, something, -65, 65) #alpha = improvable, beta = hardbound, minimax = negamax
  lm = legalMoves(convert(board), token)
  if not lm:
    lm = legalMoves(convert(board), -token)
    if not lm:
      return [boardEval(board, token), -3] # -3 for game over, score is computed
    nm = negamaxTerminal(board, -token, -hardBound, -improvable) + [-1]
    return [-nm[0]] + nm[1:]
  best = [] # what gets returned
  newHB = -improvable
  copybb = [j for j in board]
  '''for mv in lm:
    nm = [negamaxTerminal(makeMove(board, token, mv), -token, -hardBound, newHB) + [mv]]
    '''
  for mv in lm:
    newBoard = makeMove(board, token, mv)
    nm = negamaxTerminal(newBoard, -token, -hardBound, newHB) + [mv]
    board = copybb
    if not best or nm[0] < newHB:
      best = nm
      if nm[0] < newHB:
        newHB = nm[0]
        if -newHB >= hardBound:
          return[-best[0]] + best[1:]
  return[-best[0]] + best[1:]
def heuristicChoice(possibleMoves, useBoard, newPlayingToken):
  bestMove = next(iter(possibleMoves))
  flag1 = False
  flag2 = False
  for c in possibleMoves:
    if c == 0 or c == 7 or c == 56 or c == 63:
      bestMove = c
      flag1 = True
  if not flag1:
    for k in possibleMoves:
      if k // 8 == 0:
        if useBoard[0] == newPlayingToken or useBoard[7] == newPlayingToken:
          bestMove = k
          break
      if k // 8 == 7:
        if useBoard[56] == newPlayingToken or useBoard[63] == newPlayingToken:
          bestMove = k
          break
      if k % 8 == 0:
        if useBoard[0] == newPlayingToken or useBoard[56] == newPlayingToken:
          bestMove = k
          break
      if k % 8 == 7:
        if useBoard[7] == newPlayingToken or useBoard[63] == newPlayingToken:
          bestMove = k
          break
  if not flag1 and not flag2:
    goodMoves = set()
    badMoves = set()
    for d in possibleMoves:
      if d == 9 or d == 14 or d == 54 or d == 49 or d // 8 == 0 or d // 8 == 7 or d % 8 == 0 or d % 8 == 7:
        badMoves.add(d)
    goodMoves = possibleMoves - badMoves
    goodMovesList = list(goodMoves)
    badMovesList = list(badMoves)
    if goodMovesList:
      for counter, mv in enumerate(goodMovesList):
        scoreofmove = legalMoves(convert(makeMove(useBoard, newPlayingToken, mv)), -newPlayingToken)
        goodMovesList[counter] = (scoreofmove, mv)
      goodMovesList = sorted(goodMovesList)
      bestMove = goodMovesList[0][1]
    elif badMovesList:
      for counter, mv in enumerate(badMovesList):
        scoreofmove = legalMoves(convert(makeMove(useBoard, newPlayingToken, mv)), -newPlayingToken)
        badMovesList[counter] = (scoreofmove, mv)
      badMovesList = sorted(badMovesList)
      bestMove = badMovesList[0][1]
  return bestMove
def main():
  initboard = ""
  playingToken = ""
  if len(sys.argv) == 3:
    playingToken = sys.argv[2].upper()
    initboard = sys.argv[1].upper()
  elif len(sys.argv) == 2:
    initboard = sys.argv[1].upper()
    playingToken = startingplayer(initboard)
  else:
    initboard = "...........................ox......xo...........................".upper()
    playingToken = startingplayer(initboard)
  useBoard = list()
  for c in initboard:
    if c == 'X':
      useBoard.append(1)
    elif c == 'O':
      useBoard.append(-1)
    elif c == '.':
      useBoard.append(0)
  newPlayingToken = 0
  if playingToken == 'X':
    newPlayingToken = 1
  elif playingToken == 'O':
    newPlayingToken = -1
  '''positionToCoord = dict()
  coordToPosition = dict()
  for i in range(64):
    positionToCoord[i] = (i%8, i//8)
    coordToPosition[(i%8, i//8)] = i'''
  printBoard(useBoard)
  possibleMoves = legalMoves(convert(useBoard), newPlayingToken)
  print("Possible Moves:", possibleMoves)
  boardCoun = 0
  for i in useBoard:
    if i == 0:
      boardCoun += 1
  n = 10
  if boardCoun <= n:
    print("My Heuristic choice is {}".format(heuristicChoice(possibleMoves, useBoard, newPlayingToken)))
    nmm = negamaxTerminal(useBoard, newPlayingToken, -65, 65)
    print("Negamax returns {} and I choose move {}".format(nmm, nmm[-1]))
  else:
    print("My Heuristic choice is {}".format(heuristicChoice(possibleMoves, useBoard, newPlayingToken)))


class Strategy():
  def best_strategy(self, board, player, best_move, running):
    if running.value:
      myBoard = "".join(board).replace("?", "").replace("@", 'x').upper()
      myPlayer = player.replace("@", "X").upper()
      useBoard = list()
      for c in myBoard:
        if c == 'X':
          useBoard.append(1)
        elif c == 'O':
          useBoard.append(-1)
        elif c == '.':
          useBoard.append(0)
      newPlayingToken = 0
      if myPlayer == 'X':
        newPlayingToken = 1
      elif myPlayer == 'O':
        newPlayingToken = -1
      possibleMoves = legalMoves(convert(useBoard), newPlayingToken)
      boardCoun = 0
      for i in useBoard:
        if i == 0:
          boardCoun += 1
      n = 12
      if boardCoun <= n:
        hrchoice = heuristicChoice(possibleMoves, useBoard, newPlayingToken)
        best_move.value = 11 + (hrchoice//8)*10 + (hrchoice%8)
        nmm = negamaxTerminal(useBoard, newPlayingToken, -65, 65)
        mvvv = nmm[-1]
        best_move.value = 11 + (mvvv//8)*10 + (mvvv%8)
      else:
        hrchoice = heuristicChoice(possibleMoves, useBoard, newPlayingToken)
        best_move.value = 11 + (hrchoice//8)*10 + (hrchoice%8)
if __name__ == "__main__":
  multiprocessing.freeze_support()
  main()