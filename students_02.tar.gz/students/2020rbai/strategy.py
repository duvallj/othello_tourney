#Strategy for Revised Lab A
import sys
import random
class Strategy():
   def best_strategy(self, board, player, best_move, still_running):
      #board = "".join(board).replace("?","").replace("@", "x") #new
      #if(token == "@"):
      #   token = "x" #new
      #mv = findBestMove(board, token)
      #board = sys.argv[1]
      board = "".join(board).replace("?","").replace("@", "x") #new
      token = player
      sym = token
      if(token == "@"):
         token = "x" #new
         sym = token
      newSpaces = legalMoves(board, sym)
      print(newSpaces)
      if(len(newSpaces) > 0):
         #process the best index
         bestIndex = -1
         #1) check if corner is valid
         for a in (0,63,7,56):
            if(a in newSpaces):
               bestIndex = a
               break
         #2) check if edge is valid and backed by corner
         for position in newSpaces:
            #update = board[0: position] + sym + board[position+1:]
            if(isEdge(position) == False):
               continue
            for x in (-1, 0, 1):
               for y in (-1, 0, 1):
                  if(x == y == 0):
                     continue
                  if(y == 1 and position%8 == 7):
                     continue #invalid overlap
                  if(y == -1 and position%8 == 0):
                     continue #invalid overlap
                  tempSet = capture(board, position, x, y, sym)
                  #for boof in tempSet:
                     #update = update[0: boof]+sym+update[boof+1:]
                  for a in(0,63,7,56):
                     if(a in tempSet and bestIndex == -1):
                        bestIndex = position 
         #3) check if spot next to opponent corner and avoid 
         opponent = "x" if sym == "o" else "o"
         betterSpaces = set()
         for position in newSpaces:
            boofer = False
            if(board[0] != sym and position in (1,8,9)):
               boofer = True
            if(board[7] != sym and position in (6,14,15)):
               boofer = True
            if(board[56] != sym and position in (48,49,57)):
               boofer = True
            if(board[63] != sym and position in (55,54,62)):
               boofer = True
            if(boofer == False):    
               betterSpaces.add(position)
         if(len(betterSpaces) > 0):
            newSpaces = betterSpaces #be wary
         #4) prefer centers over edges
         betterSpaces = set()
         for pos in newSpaces:
            if(isEdge(pos) == False):
               betterSpaces.add(pos)
         if(len(betterSpaces) > 0):
            newSpaces = betterSpaces
         #set bestIndex if not already set
         if(bestIndex == -1):
            bestIndex = random.choice([*newSpaces])#newSpaces.poop()
         if(board.count('.') <= 8):
            nm = negamax(board, token, -1)
            bestIndex = nm[-1]
         mv = bestIndex
         mv1 = 11+(mv//8)*10+(mv%8)
         best_move.value = mv1
def negamax(board, token, levels):
   #print(board)
   if(levels == 0):
      return [evalBoard(board, token)]
   if(gameOver(board, token)):
      #print(evalBoard(board, token))
      return [evalBoard(board, token)]
   enemy = "x"
   if(token == "x"):
      enemy = "o"
   lm = legalMoves(board, token)
   if not lm:
      nm = negamax(board, enemy, levels-1)+[-1]
      return [-nm[0]]+nm[1:]
   nmList = sorted([negamax(makeMove(board, token, mv), enemy, levels-1)+[mv] for mv in lm])
   #print(nmList)
   best = nmList[0]
   return [-best[0]]+best[1:]
#negamax methods
def evalBoard(board, token):
   xcount = 0
   ocount = 0
   for c in board:
      if(c == "x"):
         xcount += 1
      elif(c == "o"):
         ocount += 1
   if(token == "x"):
      return xcount-ocount
   return ocount-xcount
def gameOver(board, token):
   enemy = "x"
   if(token == "x"):
      enemy = "o"
   lmA = legalMoves(board, token)
   lmB = legalMoves(board, enemy)
   if(len(lmA)+len(lmB) == 0):
      return 1
   return 0
def legalMoves(board, token):
   ls = [x for x in range(0, len(board)) if board[x] == "."]
   lm = set()
   for i in ls:
      tboard = board[0:i]+token+board[i+1:]
      #if(valid(tboard, i)):
      valboard = makeMove(board, token, i)
      if(tboard != valboard):
         lm.add(i)
   return lm
#makeMove and helper method
def makeMove(board, token, move):
   update = board[0: move] + token + board[move+1:]
   for x in (-1, 0, 1):
      for y in (-1, 0, 1):
         if(x == y == 0):
            continue
         if(y == 1 and move%8 == 7):
            continue #invalid overlap
         if(y == -1 and move%8 == 0):
            continue #invalid overlap
         tempSet = flipTokens(board, move, x, y, token)
         for boof in tempSet:
            update = update[0: boof]+token+update[boof+1:]
   return update
def flipTokens(game, index, x, y, sym): #assume index valid
   trackSet = set()
   newDex = index+x*8+y
   while(newDex >= 0 and newDex <= 63 and game[newDex] != sym):
      trackSet.add(newDex)
      if(game[newDex] == "."):
         return set() #none since space encountered
      if(y == 1 and newDex%8 == 7):
         return set()
      if(y == -1 and newDex%8 == 0):
         return set()
      #update
      newDex = newDex+x*8+y
   if(newDex < 0 or newDex > 63): #out of range
      return set()
   return trackSet
#heuristic methods
def surroundB(game, index, x, y, sym):
   trackSet = set()
   newDex = index+x*8+y
   while(newDex >= 0 and newDex <= 63 and game[newDex] != sym):
      trackSet.add(game[newDex])
      if(y == 1 and newDex%8 == 7):
         return False
      if(y == -1 and newDex%8 == 0):
         return False
      newDex = newDex+x*8+y
   if(newDex < 0 or newDex > 63):
      return False
   if(len(trackSet) == 0 or "." in trackSet):
      return False
   return True
def valid(game, index):
   for x in (-1, 0, 1):
      for y in (-1, 0, 1):
         if(x == y == 0):
            continue
         if(y == 1 and index%8 == 7):
            continue
         if(y == -1 and index%8 == 0):
            continue
         val = surroundB(game, index, x, y, game[index])
         if(val):
            return True
   return False
def capture(game, index, x, y, sym): #assume index valid
   trackSet = set()
   newDex = index+x*8+y
   while(newDex >= 0 and newDex <= 63 and game[newDex] != sym):
      trackSet.add(newDex)
      if(game[newDex] == "."):
         return set() #none since space encountered
      if(y == 1 and newDex%8 == 7):
         return set()
      if(y == -1 and newDex%8 == 0):
         return set()
      #update
      newDex = newDex+x*8+y
   if(newDex in (0,63,7,56)): #check if corner backed
      trackSet.add(newDex)
   if(newDex < 0 or newDex > 63): #out of range
      return set()
   return trackSet
def isEdge(index):
   if(index in (0,63,7,56)):
      return False
   if(index < 8):
      return True
   if(index%8 == 0):
      return True
   if(index%8 == 7):
      return True
   if(index > 56):
      return True
   return False
def main():
   #print("fwer")
   board = sys.argv[1].lower()
   sym = sys.argv[2].lower()
   #for v in range(0,8):
   #   print(board[v*8:v*8+8])
   newSpaces = legalMoves(board, sym)
   #print(newSpaces)
   if(len(newSpaces) > 0):
      bestIndex = -1
      #1) check if corner is valid
      for a in (0,63,7,56):
         if(a in newSpaces):
            bestIndex = a
            break
      #2) check if edge is valid and backed by corner
      for position in newSpaces:
         if(isEdge(position) == False):
            continue
         for x in (-1, 0, 1):
            for y in (-1, 0, 1):
               if(x == y == 0):
                  continue
               if(y == 1 and position%8 == 7):
                  continue #invalid overlap
               if(y == -1 and position%8 == 0):
                  continue #invalid overlap
               tempSet = capture(board, position, x, y, sym)
               for a in(0,63,7,56):
                  if(a in tempSet and bestIndex == -1):
                     bestIndex = position 
      #3) check if spot next to opponent corner and avoid 
      opponent = "x" if sym == "o" else "o"
      betterSpaces = set()
      for position in newSpaces:
         boofer = False
         if(board[0] != sym and position in (1,8,9)):
            boofer = True
         if(board[7] != sym and position in (6,14,15)):
            boofer = True
         if(board[56] != sym and position in (48,49,57)):
            boofer = True
         if(board[63] != sym and position in (55,54,62)):
            boofer = True
         if(boofer == False):    
            betterSpaces.add(position)
      if(len(betterSpaces) > 0):
         newSpaces = betterSpaces #be wary
      #4) prefer centers over edges
      betterSpaces = set()
      for pos in newSpaces:
         if(isEdge(pos) == False):
            betterSpaces.add(pos)
      if(len(betterSpaces) > 0):
         newSpaces = betterSpaces
      #set bestIndex if not already set
      if(bestIndex == -1):
         bestIndex = random.choice([*newSpaces])#newSpaces.pop()
   else:
      print("No moves are possible")
   board = sys.argv[1].lower()  
   token = sys.argv[2].lower()
   #determine negamax move
   if(board.count('.') <= 8):
      nm = negamax(board, token, -1)
      bestIndex = nm[-1]
   print(bestIndex)
if __name__ == "__main__":
   main()