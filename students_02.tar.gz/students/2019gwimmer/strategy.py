import random
import math


#### Othello Shell
#### P. White 2016-2018

#gabe
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

############################################################
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node:
    def __init__(self,b,m,s=None):
        self.board=b
        self.move=m
        self.score=s
    def __lt__(self,other):
        return self.score-other.score
class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pretty = ''
        for x in range(10):
            pretty = pretty + board[x * 10:x * 10 + 10] + '\n'
        return pretty

    def opponent(self, player):
        """Get player's opponent."""
        op = BLACK if player is WHITE else WHITE
        return op

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given `direction`.  Returns None if no such square exists.
        """
        match=[square,board[square+direction]]
        if match[1] is self.opponent(player):
            while match[1] is self.opponent(player):
                match[0]=match[0]+direction
                match[1]=board[match[0]]
            if match[1] is player:
                return match[0]
            return None
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] is not '.' and board[move]is not player:
            return False
        for d in DIRECTIONS:
            if self.find_match(board,player,move,d):
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        tempboard = list(board)
        tempboard[move] = player
        for d in DIRECTIONS:
            match = [move, tempboard[move+d]]
            if self.find_match(board,player,move,d):
                if tempboard[match[0] + d] is self.opponent(player):
                    while match[1] is self.opponent(player):
                        tempboard[match[0]] = player
                        match[0] = match[0] + d
                        match[1] = tempboard[match[0]]
        return ''.join(tempboard)


    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        op=self.opponent(player)
        movelist=[]
        for c in range(len(board)):
            for d in DIRECTIONS:
                if board[c] is '.' and board[c+d] is op :
                    tempmove=self.find_match(board,player,c,d)
                    if tempmove is not None:
                        movelist.append(c)

        return movelist




    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if len(self.get_valid_moves(board,player)) is not 0:
            return True
        return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.get_valid_moves(board,self.opponent(prev_player)):
            return self.opponent(prev_player)
        if self.get_valid_moves(board,prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        if isinstance(board,str):
            return board.count(player)-board.count(self.opponent(player))
        return board.board.count(player) - board.board.count(self.opponent(player))

    matrix=[    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 1.01, 1.001,  1.002,   1.002,   1.002,  1.002, 1.001, 1.01,   0,
    0, 1.001, 1,  1,  1,  1,  1, 1, 1.001,   0,
    0,  1.002,  1,  1.001,   1,   1,  1.001,  1,  1.002,   0,
    0,   1.002,  1,   1,   1,   1,   1,  1,   1.002,   0,
    0,   1.002,  1,   1,   1,   1,   1,  1,   1.002,   0,
    0,  1.002,  1,  1.001,   1,   1,  1.001,  1,  1.002,   0,
    0, 1.001, 1,  1,  1,  1,  1, 1, 1.001,   0,
    0, 1.01, 1.001,  1.002,   1.002,   1.002,  1.003, 1.001, 1.01,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,]
    def weighted_score(self,board,player=BLACK):    #bonus to twice in a row
        score=0

        for x in range(9,93):
            if board.board[x] is player:
                score+=self.matrix[x]
            if board.board[x] is self.opponent(player):
                score-=self.matrix[x]
        '''
        if len(self.get_valid_moves(board.board, self.opponent(player))) is 0:
            score += 300
        else:
            score -= (3 * len(self.get_valid_moves(board.board, self.opponent(player))))
        '''

        return score


    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.get_valid_moves(board,player) or self.get_valid_moves(board,self.opponent(player)):
            return False
        return True
    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    #https://web.stanford.edu/class/cs221/2017/restricted/p-final/man4/final.pdf
    def oldminmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters

        best={WHITE:min , BLACK:max}
        board=node.board
        if depth is 0:
            node.score=self.weighted_score(node)
            return node
        my_moves=self.get_valid_moves(board,player)
        children=[]
        for move in my_moves:
            next_board=self.make_move(board,player,move)
            next_player=self.next_player(next_board,player)
            if next_player is None:
                c= Node(next_board,move,1000*self.score(next_board))
                children.append(c)
            else:
                c= Node(next_board,move)
                c.score=self.oldminmax_search(c,next_player,depth-1).score
                children.append(c)
        winner=best[player](children)
        node.score=winner.score
        return winner
    def randomminmax_strategy(self, board, player, depth=5):                         #change depth here
        n=Node(board,None)
        temp= self.randomminmax(n,player,depth,-99999,99999)  #does this for most of the game then switches to min-max with num of players as score
        return temp.move
    randmatrix = [0,  0, 0, 0, 0, 0, 0, 0,  0, 0,
                  0, 16.16, -3.03, 2.09, 1.13, 1.13, 2.13, -3.03, 16.16, 0,
                  0, -4.12, -1.81, -.08, -.18, -.27, -.08, -1.81, -4.12, 0,
                  0,  2.13, -.04, .51, .07, -.04, .51, -.08, 1.19, 0,
                  0,  1.13, -.18, -.04, -.01, -.01, .07, -.27, 1.13,  0,
                  0,  1.13, -.18, -.04, -.01, -.01, -.04, -.18, 1.13,  0,
                  0,  2.19, -.08, .51, -.04, -.04, .51, -.04, 2.13, 0,
                  0, -4.12, -1.81, -.08, -.27, -.18, -.04, -1.81, -4.12, 0,
                  0, 16.16, -3.03, 2.19, 1.13, 1.1, 2.13, -4.12, 16.16, 0,
                  0,   0, 0, 0, 0, 0, 0, 0, 0,  0, ]
    oldmatrix=[0,  0, 0, 0, 0, 0, 0, 0,  0, 0,
                  0, 16.16, -3.03, .99, .43, .63, 1.33, -3.03, 16.16, 0,
                  0, -4.12, -1.81, -.08, -.18, -.27, -.08, -1.81, -4.12, 0,
                  0,  1.33, -.04, .51, .07, -.04, .51, -.08, .99, 0,
                  0,  .63, -.18, -.04, -.01, -.01, .07, -.27, .43,  0,
                  0,  .63, -.18, -.04, -.01, -.01, -.04, -.18, .63,  0,
                  0,  .99, -.08, .51, -.04, -.04, .51, -.04, 1.33, 0,
                  0, -4.12, -1.81, -.08, -.27, -.18, -.04, -1.81, -4.12, 0,
                  0, 16.16, -3.03, .99, .43, .63, 1.33, -4.12, 16.16, 0,
                  0,   0, 0, 0, 0, 0, 0, 0, 0,  0, ]
    """[0,  0, 0, 0, 0, 0, 0, 0,  0, 0,
                  0, 70, -15, 10, 2, 2, 10, -15, 70, 0,
                  0, -15, -20, 1, 1, 1, 1, -20, -15, 0,
                  0,  10, 1, 1, 8, 1, 8, 1, 10, 0,
                  0,  2, 1, 1, 1, 1, 1, 1, 2,  0,
                  0,  2, 1, 1, 1, 1, 1, 1, 2,  0,
                  0,  10, 1, 8, 1, 1, 8, 1, 10, 0,
                  0, -13, -20, 1, 1, 1, 1, -20, -15, 0,
                  0, 70, -13, 10, 2, 2, 10, -15, 70, 0,
                  0,   0, 0, 0, 0, 0, 0, 0, 0,  0, ]"""
    def randscore(self, board, player=BLACK):#use number of moves and matrix and    as a percent of 100 for score
        score = 0

        for x in range(9, 93):
            if board.board[x] is player:
                score += self.randmatrix[x]
            if board.board[x] is self.opponent(player):
                score -= self.randmatrix[x]
        """
        mymoves=len(self.get_valid_moves(board.board,player))+.00001
        othermoves=len(self.get_valid_moves(board.board,self.opponent(player)))+.00001
        score=(mymoves/othermoves)*score
        """
        return score*10000            #principle varation search
    def randomminmax(self, node, player, depth,alpha, beta):

        board = node.board
        if depth is 0:
            node.score = self.randscore(node)         #not really random
            return node                               #it just focuses corners
        my_moves=self.get_valid_moves(board,player)
        children=[]
        #my_moves.sort(key= lambda x:self.randscore(Node(self.make_move(board,player,x),player)))
        for m in my_moves:
            next_board = self.make_move(board, player, m)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c=Node(next_board,m,1000*self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, m)
                c.score=self.randomminmax(c,next_player,depth-1,alpha,beta).score
                children.append(c)
                if player is WHITE:
                    beta = min(beta, c.score)
                if player is BLACK:
                    alpha = max(alpha, c.score)
            if alpha >= beta:
                break
        winner = Node(None, 0)
        while len(children) > 0 and not self.cornercheck(winner, player, board):
            if player is WHITE:
                winner = min(children)
                children.remove(min(children))
            else:
                winner = max(children)
                children.remove(max(children))

        node.score = winner.score
        return winner
    def minmax_search(self, node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters

        board = node.board
        if depth is 0:
            node.score = self.weighted_score(node)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:

            next_board=self.make_move(board,player,move)
            next_player=self.next_player(next_board,player)
            if next_player is None:
                #c= Node(next_board,move,10000*self.score(next_board))
                c = Node(next_board, move, 1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth - 1,alpha,beta).score
                if player is WHITE:
                    beta = min(beta, c.score)
                if player is BLACK:
                    alpha = max(alpha, c.score)

                children.append(c)

            if alpha >= beta:
                break
        winner=Node(None,0)
        while len(children)>1 and not self.cornercheck(winner,player,board):
            if player is WHITE:
                winner=min(children)
                children.remove(min(children))
            else:
                winner=max(children)
                children.remove(max(children))
        node.score=winner.score
        return winner
    def cornercheck(self,winner,player,board):
        m=winner.move
        if m is 0:

            return False
        if m is 11 or m is 18 or m is 81 or m is 88:
            return True
        if (m is 12 or m is 21 or m is 22) and (board[11] is not player):
            return False
        if (m is 27 or m is 17 or m is 28) and (board[18] is not player):
            return False
        if (m is 71 or m is 72 or m is 82) and (board[81] is not player):
            return False
        if (m is 87 or m is 78 or m is 77) and (board[88] is not player):
            return False

        return True


    def minmax_strategy(self, board, player, depth=5):                         #change depth here
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        #if random.randint(0,15) is 5 and board.count('.')<25:
        #   return self.random_strategy(board,player)
        n=Node(board,None)  #deal with the move var in Node
        return self.minmax_search(n,player,depth,-99999,99999).move
    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        #if board.count('.')>17:
        depth = 1
        while (True):
            best_move.value=self.randomminmax_strategy(board,player,depth)
            depth+=1            #does corners priority strat first
        #depth=3
        #while(True):                                           #then endgame it only cares about count of pieces
        #    best_move.value=self.minmax_strategy(board, player,depth)
        #    depth+=2

    def human_strategy(self,board,players):
        testmove=input("Where to you want to place your piece:")
        while self.is_move_valid(board,players,testmove) is False:
            testmove=input("Move is illegal try again:")
        return testmove




    standard_strategy = randomminmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.randomminmax_strategy, WHITE: white.random_strategy}     # where to change the strats
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()
