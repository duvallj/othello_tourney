#Mahesh Menon
import random, sys, time

scoringMatrix = [500, -15, 10, 5, 5, 10, -10, 500, -15, -50, -5, -3, -3, -5, -50, -15, 10, -5, 8, 3, 3, 8,\
 -5, 10, 5, -3, 3, 0, 0, 3, -2, 5, 5, -3, 3, 0, 0, 3, -2, 5, 10, -5, 8, 3, 3, 8, -5, 10, -15, -50, -5, -3, \
 -3, -5, -50, -15, 500, -15, 10, 5, 5, 10, -10, 500]
xDict = {1:0, 8:0, 9:0, 6:7, 14:7, 15:7, 48:56, 49:56, 57:56, 54:63, 55:63, 62:63}
boardCache = {}      


def main():
   turn=""
   board = "...........................ox......xo..........................."
   
   
   if len(sys.argv)==2:
      if len(sys.argv[1])>1:
         board = sys.argv[1].lower()
      else:
         turn = sys.argv[1].lower()
   elif len(sys.argv)==3:
      board = sys.argv[1].lower()
      turn = sys.argv[2].lower()

   if turn=="":
      if (board.count("x")+board.count("o"))%2==0:
         turn = "x"
      else:
         turn = "o"
   
   for x in range(8):
      print (board[8*x:8*x+8])
      
   #print("Legal moves:", legalMoves(board,turn))
   start = time.time()
   
   #print(time.time()-start)  
   
   n = 13
   if board.count(".")<=n:
      start = time.time()
      negT = negamaxABTerminal(board, turn, -64, 64)      
      print("Minimax:", negT[0], "and my move is", negT[-1], str(time.time()-start))
   else:
      depth = 1
      start = time.time()
      while(time.time()-start<5):
         print(negamaxAB(board, turn, -64, 64, depth)[-1])
         print(time.time()-start, depth)
         depth+=1
   

class Strategy():
   def best_strategy(self, board, player, best_move, still_running):
      board = ''.join(board).lower().replace('?', '').replace('@', 'x')
      turn = "x" if player=="@" else 'o'    
		#depth		     
      
      n = 10
      if board.count(".")<=n:
         move = bestMove(legalMoves(board,turn), board,turn)
         best_move.value = 11+(move//8)*10 + (move%8)
         move = negamaxABTerminal(board, turn, -64, 64)[-1]
         best_move.value = 11+(move//8)*10 + (move%8)
      else:
         depth = 1
         while(True):
            move = negamaxAB(board, turn, -64, 64, depth)[-1]
            best_move.value = 11+(move//8)*10 + (move%8)
            depth+=1

         
def negamaxABTerminal(board,token,improvable, hardBound): #returns score together with a move sequence linking to that score  
   enemy = "x"
   if token=="x":
      enemy = "o"
   
   lm = []
   lm=legalMoves(board,token)
   
   if not lm:
      lm = legalMoves(board, enemy)
      if not lm:
         return [evalBoardTerminal(board, token, enemy)]
      nm = negamaxABTerminal(board, enemy, -hardBound, -improvable) + [-1]
      return [-nm[0]]+nm[1:]
   best = []
   newHB = -improvable
   for mv in lm:
      nm = negamaxABTerminal(makeMoveImproved(board, lm[mv], token, enemy), enemy, -hardBound, newHB)+[mv]
      if not best or nm[0]<newHB:
         best = nm
         if nm[0]<newHB:
            newHB = nm[0]
            if -newHB>=hardBound:
               return[-best[0]]+best[1:]
   return [-best[0]]+best[1:]

def negamaxAB(board,token,improvable, hardBound, levels): #returns score together with a move sequence linking to that score  
   enemy = "x"
   if token=="x":
      enemy = "o"
   
   lm = []
   lm=legalMoves(board,token)
   
   if not levels:
      return [evalBoard(board, token, enemy)]
      
   if not lm:
      nm = negamaxAB(board, enemy, -hardBound, -improvable, levels-1) + [-1]
      return [-nm[0]]+nm[1:]
   best = []
   newHB = -improvable
   for mv in lm:
      nm = negamaxAB(makeMoveImproved(board, lm[mv], token, enemy), enemy, -hardBound, newHB, levels-1)+[mv]
      if not best or nm[0]<newHB:
         best = nm
         if nm[0]<newHB:
            newHB = nm[0]
            if -newHB>=hardBound:
               return[-best[0]]+best[1:]
   return [-best[0]]+best[1:]
   
def evalBoardTerminal(board, turn, enemy):
   return board.count(turn)-board.count(enemy)

def evalBoard(board, turn, enemy):
   score = 0
   for n, char in enumerate(board):
      if char==turn:
         if n in xDict:
            if board[xDict[n]]==turn:
               score+=50
            else:
               score+=scoringMatrix[n]
         elif (n%8==0): 
            set1 = board[0:57:8]                          
            if enemy not in set1:
               if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):            
                  score+=50               
            else:
               score+=scoringMatrix[n]#scoringMatrix[n]
         elif (n%8==7):
            set1 = board[7:64:8]                        
            if enemy not in set1:
               if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):            
                  score+=50
            else:
               score+=scoringMatrix[n]
         elif (n//8==0):
            set1 = board[0:8]                            
            if enemy not in set1:
               if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):            
                  score+=50
            else:
               score+=scoringMatrix[n]
         elif (n//8==7):
            set1 = board[56:64]                            
            if enemy not in set1:
               if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):            
                  score+=50
            else:
               score+=scoringMatrix[n]
         
         else:               
            score+=scoringMatrix[n]
      # elif char == enemy:
#          if n in xDict:
#             if board[xDict[n]]==enemy:
#                score-=50
#             else:
#                score-=scoringMatrix[n]
#          elif (n%8==0): 
#             set1 = board[0:57:8]                          
#             if turn not in set1:
#                if (8-set1[::-1].index(enemy))-set1.index(enemy)==set1.count(enemy):            
#                   score-=50
#             else:
#                score-=scoringMatrix[n]
#          elif (n%8==7):
#             set1 = board[7:64:8]                        
#             if turn not in set1:
#                if (8-set1[::-1].index(enemy))-set1.index(enemy)==set1.count(enemy):            
#                   score-=50
#             else:
#                score-=scoringMatrix[n]
#          elif (n//8==0):
#             set1 = board[0:8]                            
#             if turn not in set1:
#                if (8-set1[::-1].index(enemy))-set1.index(enemy)==set1.count(enemy):            
#                   score-=50
#             else:
#                score-=scoringMatrix[n]
#          elif (n//8==7):
#             set1 = board[56:64]                            
#             if turn not in set1:
#                if (8-set1[::-1].index(enemy))-set1.index(enemy)==set1.count(enemy):            
#                   score-=50
#             else:
#                score-=scoringMatrix[n]
         
         
   
   score-=len(legalMoves(board, enemy))*5
   # if len(legalMoves(board, enemy))==0:
#       score = 100000
   #print(board, turn, score)
   return score

# def lockedTokens(board, turn):
#    lockedMatrix = [1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1]
#    for n, x in enumerate(locked8):
#       if board[x]==turn:
#          if Math.max(lockedMatrix[locked11[n]-9], lockedMatrix[locked11[n]+9])\
#           + Math.max(lockedMatrix[locked11[n]-8], lockedMatrix[locked11[n]+8])\
#           + Math.max(lockedMatrix[locked11[n]-7], lockedMatrix[locked11[n]+7])\
#           + Math.max(lockedMatrix[locked11[n]-1], lockedMatrix[locked11[n]+1])

def legalMoves(board1, token):
   turn=token.lower()
   board = board1.lower() 
   if board in boardCache:
      return boardCache[board]   
   oppTurn = ""
   if turn == "x":
      oppTurn = "o"
   else:
      oppTurn = "x"
   
   symbols = [x for x in range(64) if board[x]==oppTurn]
   possiblePos = {}
   
   for pos in symbols:
      for x in [pos-9,pos-8,pos-7,pos-1,pos+1,pos+7,pos+8,pos+9]:
         if not abs(x%8-pos%8)<=1:
            continue
         if x>=0 and x<64 and board[x]==".":
            setTokens = {x, pos}
            diff = x-pos
            y = pos-diff
            #print(x, y)
            if diff==-7 or diff==9 or diff==1:
               while y>=0 and y<64 and y%8<(pos)%8:
                  if board[y]==".":
                     break
                  elif board[y]==turn:
                     if x in possiblePos:
                        possiblePos[x] = setTokens|possiblePos[x]
                     else:
                        possiblePos[x] = setTokens
                     break
                  else:  
                     setTokens.add(y)                   
                     y-=diff                     
                     setTokens.add(y)
            elif diff==-9 or diff==7 or diff==-1:
               while y>=0 and y<64 and y%8>(pos)%8:
                  if board[y]==".":
                     break
                  elif board[y]==turn:
                     if x in possiblePos:
                        possiblePos[x] = setTokens|possiblePos[x]
                     else:
                        possiblePos[x] = setTokens
                     break
                  else:     
                     setTokens.add(y)                
                     y-=diff
                     setTokens.add(y)
            else:
               while y>=0 and y<64:  
                  #if x==62:
                  #   print(x, y)                   
                  if board[y]==".":
                     break
                  elif board[y]==turn:
                     if x in possiblePos:
                        possiblePos[x] = setTokens|possiblePos[x]
                     else:
                        possiblePos[x] = setTokens
                     break
                  else: 
                     setTokens.add(y)                    
                     y-=diff
                     setTokens.add(y)
   boardCache[board] = possiblePos
   return (possiblePos)

def makeMoveImproved(board, flippedTokens, token, enemy):
   for x in flippedTokens:
      if board[x] in [".", enemy]:
         board = board[:x] + token + board[x+1:]
   return board
         
def bestMove(possiblePos, board, turn):
   enemy = "x"
   if turn =="x":
      enemy = "o"
      
   for x in possiblePos:
      if makeMoveImproved(board, possiblePos[x], turn, enemy).count(enemy)==0 or len(legalMoves(makeMoveImproved(board, possiblePos[x], turn, enemy), enemy))==0:
         return x
   
   removeList = set()  
   for x in possiblePos:
      if (x%8==0):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n%8==0]         
         if set1.count(".")==1 and set1.count(enemy)==0:
            if set1.index(".") not in [0,7]:
               removeList.add(x)
      if (x%8==7):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n%8==7]
         if set1.count(".")==1 and set1.count(enemy)==0:
            if set1.index(".") not in [0,7]:
               removeList.add(x)
      if (x//8==0):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n//8==0]
         if set1.count(".")==1 and set1.count(enemy)==0:
            if set1.index(".") not in [0,7]:
               removeList.add(x)
      if (x//8==7):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n//8==7]
         if set1.count(".")==1 and set1.count(enemy)==0:
            if set1.index(".") not in [0,7]:
               removeList.add(x)
            
   for x in removeList:
      if len(possiblePos)>1:
         del possiblePos[x]

   for x in [0, 7, 63, 56]:
      if x in possiblePos:
         return(x)
         
   #removes moves that let opponent play to corner
   removeList = []
   for x in possiblePos:
      if not {0, 7, 56, 63}.isdisjoint(legalMoves(makeMoveImproved(board, possiblePos[x], turn, enemy), enemy)):
         removeList.append(x)
   
   for x in removeList:
      if len(possiblePos)>1:
         del possiblePos[x]
         
   #safe edge, fix this, use test case 2      
   goodSet = set()
   for x in possiblePos:
      if (x%8==0):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n%8==0]         
         if ("." not in set1[:x//8+1] and enemy not in set1[:x//8+1]) or ("." not in set1[x//8:] and enemy not in set1[x//8:]):
            return(x)
      elif (x%8==7):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n%8==7]
         if ("." not in set1[:x//8+1] and enemy not in set1[:x//8+1]) or ("." not in set1[x//8:] and enemy not in set1[x//8:]):
            return(x)
      elif (x//8==0):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n//8==0]
         if ("." not in set1[:x%8+1] and enemy not in set1[:x%8+1]) or ("." not in set1[x%8:] and enemy not in set1[x%8:]):
            return(x)
      elif (x//8==7):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n//8==7]
         if ("." not in set1[:x%8+1] and enemy not in set1[:x%8+1]) or ("." not in set1[x%8:] and enemy not in set1[x%8:]):
            return(x)

   if len(goodSet)>0:
      return(random.choice([*goodSet]))               

   removeList = []
   for x in possiblePos:
      if x in [1,8,9] and board[0]==".":
         removeList.append(x)
      elif x in [6,14,15] and board[7]==".":
         removeList.append(x)
      elif x in [48,49,57] and board[56]==".":
         removeList.append(x)
      elif x in [62,54,55] and board[63]==".":
         removeList.append(x)
         
   for x in removeList:
      if len(possiblePos)>1:
         del possiblePos[x]
     
   #claim edge      
   for x in possiblePos:
      set1 = []   
      if (x%8==0):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n%8==0]
         if set1.count(turn)==1 and board[x-8]==board[x+8]==".":
            return(x)
         if enemy not in set1:
            if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):            
               return(x)
         if set1[x//8-1]==set1[x//8+1]==enemy:
            return(x)
      elif (x%8==7):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n%8==7]
         if set1.count(turn)==1 and board[x-8]==board[x+8]==".":
            return(x)
         if enemy not in set1:
            if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):                        
               return(x)
         if set1[x//8-1]==set1[x//8+1]==enemy:
            return(x)
      elif (x//8==0):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n//8==0]
         if set1.count(turn)==1 and board[x-1]==board[x+1]==".":
            return(x)
         if enemy not in set1:
            if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):
               return(x) 
         if set1[x%8-1]==set1[x%8+1]==enemy:
            return(x)           
      elif (x//8==7):
         set1 = [char for n, char in enumerate(makeMoveImproved(board, possiblePos[x], turn, enemy)) if n//8==7]
         if set1.count(turn)==1 and board[x-1]==board[x+1]==".":
            return(x)
         if enemy not in set1:
            if (8-set1[::-1].index(turn))-set1.index(turn)==set1.count(turn):
               return(x)
         if set1[x%8-1]==set1[x%8+1]==enemy:
            return(x)

   
   ranking = sorted([(len(legalMoves(makeMoveImproved(board, possiblePos[x], turn, enemy), turn)), evalBoardTerminal(makeMoveImproved(board, possiblePos[x], turn, enemy), turn, enemy), x) for x in possiblePos])   
   i = 0
   while (ranking[i][2]%8==0 or ranking[i][2]%8==7 or ranking[i][2]//8==0 or ranking[i][2]//8==7):
      if i== len(ranking)-1:
         break
      i+=1
      
      
      
   return(ranking[i][2]) 

if __name__ == "__main__":
   main()

#OXOOO...XXOOOO..OXOO.X..OXOXXX..OXXXXX..OX.......XO.............
#1  O X O O O . . .
#2  X X O O O O . .
#3  O X O O . X . .
#4  O X O X X X . .
#5  O X X X X X . .
#6  O X . . . . . .
#7    X O . . . . .
#8  . . . . . . . .


#XXXXXXXXXOOOOXXOXOOOXXOXXOXXXXOXXOXXOOOXXOXOO.OXXX......XXX.....

#OOOOOOOOOOOOOOOOOXOOXOOOOOXXOXOOOOXOXOOOXXOOOOOXX..XX.....X..... O

#...O......X.O.....XOOO....XOO......OX......OXX......X.X.........

#....O.......OO.X..XOOXX....OOXX....XXO....XXXXX.................

#OOO.O.....O.OOX...OOOXO..XXXX.....OXXX....X......X..............

#...................XXX...OXXXX.OOOXXXOOOOOXXOO.O.XXOOOO....XOOOO

#XXXXXX..XOOOXX..XOXOO...XOXOXXXXXOOXOOXXXOXOO.O..OOO....XXXXXX..