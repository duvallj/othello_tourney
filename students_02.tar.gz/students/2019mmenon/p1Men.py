import sys

def main():
   board = "...........................ox......xo..........................."
   pos = 0
   turn = ""
   letters = "abcdefgh"
   
   print("Initial board state:")
   
   if len(sys.argv)==1:
      print(board)
      for x in range(8):
         print (board[8*x:8*x+8])
      sys.exit()
   if len(sys.argv)==2:
      if len(sys.argv[1])>2:
         board = sys.argv[1].lower()
         print(board)
         for x in range(8):
            print (board[8*x:8*x+8])
         sys.exit()
      else:
         pos = sys.argv[1]
   elif len(sys.argv)==3:
      if len(sys.argv[1])>1:
         board = sys.argv[1].lower()
      else:
         turn = sys.argv[1].lower()
      pos =sys.argv[2]
   elif len(sys.argv)==4:
      board = sys.argv[1].lower()
      turn = sys.argv[2].lower()
      pos = sys.argv[3]
   
   if pos[0] in letters:
      pos = (int(pos[1])-1)*8+letters.find(pos[0])
   else:
      pos = int(pos)
   
   for x in range(8):
      print (board[8*x:8*x+8])   
   print(board)
   
   if turn=="":
      if (board.count("x")+board.count("o"))%2==0:
         turn = "x"
      else:
         turn = "o"
  
   oppTurn = ""
   if turn == "x":
      oppTurn = "o"
   else:
      oppTurn = "x"
   
   print("")
   print("Final board state:")
   
   for x in [pos-9,pos-8,pos-7,pos-1,pos+1,pos+7,pos+8,pos+9]:        
      if not abs(x%8-pos%8)<=1:
         continue
      if x<0 or x>63:
         continue
      
      if board[x]==oppTurn:
         turnover = {x, pos}
         diff = pos - x
         y = x
         if diff==-7 or diff==9:
            while y>=0 and y<64 and y%8<(pos)%8:
               if board[y]==".":
                  break
               elif board[y]==turn:
                  for num in turnover:
                     board = board[:num] + turn + board[num+1:]
                  break
               else:
                  turnover.add(y)
                  y-=diff
         elif diff==-9 or diff==7:
            while y>=0 and y<64 and y%8>(pos)%8:
               if board[y]==".":
                  break
               elif board[y]==turn:
                  for num in turnover:
                     board = board[:num] + turn + board[num+1:]                     
                  break
               else:
                  turnover.add(y)
                  y-=diff
         else:
            while y>=0 and y<64:
               if board[y]==".":
                  break
               elif board[y]==turn:
                  for num in turnover:
                     board = board[:num] + turn + board[num+1:]                    
                  break
               else:
                  turnover.add(y)
                  y-=diff
   
   for x in range(8):
      print (board[8*x:8*x+8])
   print(board, str(board.count("x"))+"/"+str(board.count("o")))   
   
main()      
