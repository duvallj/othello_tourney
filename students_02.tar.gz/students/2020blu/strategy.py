#strategy.py
import sys
import random
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
symbols = {"X", "O"}
corners = {0, 56, 63, 7}
badSquares = {0:{1, 8, 9}, 7:{6, 14, 15}, 56:{48, 49, 57}, 63:{62, 55, 54}}
N = 11
openingSets = {"...........................OX......XO...........................":[26, 19, 37, 44],
               "..........................XXX......XO...........................":[18, 20, 34],
               "..................O.......XOX......XO...........................":[19], #diagonal opening
               "..................OX......XXX......XO...........................":[34, 20], #diag. +
               "..................OX......OXX.....OOO...........................":[25, 43], #diag. ++
               "..................OX.....XXXX.....OOO...........................":[11], #heath tobi
               "...........O......OO.....XXOX.....OOO...........................":[12, 43], #heath tobi +
               "..................OOO....XXOO.....OOO...........................":[12], #heath chimney
               "...........OX.....OX.....XXOX.....OOO...........................":[17], #iwasaki var.
               "...........O......OO.....XXOX.....XOO......X....................":[17], #heathbat
               "...........O.....OOO.....XOOX.....XOO......X....................":[20, 44], #heathbat +
               "..........XO......XX.....XXOX.....OOO...........................":[24], #classic heath
               "..................OX......OXX.....OXO......X....................":[20, 29], #cow
               "..................OOO.....OOO.....OXO......X....................":[11, 21, 37, 33], #chimney
               "..................OX......OOOO....OXO......X....................":[37, 21], #cow +
               "..................OX.....XOOOO....XXO......X....................":[41], #cow bat cambridge
               "..................OX......OOXO....OXXX.....X....................":[11], #rose-v-toth
               "...........O......OO......OOXO....OXXX.....X....................":[21], #tanida
               "...........O......OO......OOXO...XXXXX.....X....................":[42, 41], #aircraft/feldborg

               "..........................XXX.....OOO...........................":[43], #parallel opening
               "..........................XXX.....OXO......X....................":[18, 20, 50, 52], #parallel +

               "....................O.....XXO......XO...........................":[37, 45], #perpendicular opening
               "....................O.....XXO......XXX..........................":[25, 44], #perp. op. v1 +
               "....................O....OOOO......XXX..........................":[18, 25], #ganglion/nocat
               "....................OX...OOOX......XXX..........................":[29], #swallow
               "....................O.....XXO......XX........X..................":[44], #perp. op. v2 +
               "....................O....OOOO......XX........X..................":[21] #bent ganglion

}
transforms = [[8*(x%8) + x//8 for x in range(64)], [63-x for x in range(64)], [8*(7-(x%8)) + 7 - x//8 for x in range(64)], [8*(7-(i%8)) + i//8 for i in range(64)]]
weightMatrix = [4, -3, 2, 2, 2, 2, -3, 4,
                -3, -4, -1, -1, -1, -1, -4, -3,
                2, -1, 1, 0, 0, 1, -1, 2,
                2, -1, 0, 1, 1, 0, -1, 2,
                2, -1, 0, 1, 1, 0, -1, 2,
                2, -1, 1, 0, 0, 1, -1, 2,
                -3, -4, -1, -1, -1, -1, -4, -3,
                4, -3, 2, 2, 2, 2, -3, 4]
def getTurn(game):
    return ["X" if sum([1 for i in game if i == "X"]) % 2 == sum([1 for i in game if i == "O"]) % 2 else "O"][0]
    #turn = ["X" if sum([1 for i in game if i == "."]) % 2 == 0 else "O"][0]

def legalMoves(game, turn):
    legalSet = set()
    adjacencies = {-9, -8, -7, -1, 1, 7, 8, 9}
    for i in range(64):
        if game[i] != ".":
            continue
        for j in adjacencies:
            currPos = i+j
            prev = i
            opposingCount = 0
            while (currPos > -1 and currPos < 64) and not (currPos % 8 == 7 and prev % 8 == 0 and (currPos-prev) % 8 == 7) \
                    and not (currPos % 8 == 0 and prev % 8 == 7 and (currPos-prev) % 8 == 1):
                if game[currPos] == ".":
                    break
                elif game[currPos] in symbols and game[currPos] != turn:
                    currPos += j
                    prev += j
                    opposingCount += 1
                elif game[currPos] == turn:
                    if opposingCount != 0:
                        legalSet.add(i)
                    break
    return legalSet

def flipTiles(game, token, pos):
    legals = legalMoves(game, token)
    if pos not in legals:
        return "illegal"
    else:
        newGame = game[0:pos] + token + game[pos+1:]
        adjacencies = {-9, -8, -7, -1, 1, 7, 8, 9}
        updatedSet = []
        for j in adjacencies:
            currPos = pos+j
            prev = pos
            tempSet = []
            while (currPos > -1 and currPos < 64) and not (currPos % 8 == 7 and prev % 8 == 0 and (currPos-prev) % 8 == 7) \
                    and not (currPos % 8 == 0 and prev % 8 == 7 and (currPos-prev) % 8 == 1):
                if game[currPos] == ".":
                    tempSet = []
                    updatedSet += tempSet
                    break
                elif game[currPos] in symbols and game[currPos] != token:
                    tempSet.append(currPos)
                    currPos += j
                    prev += j
                elif game[currPos] == token:
                    updatedSet += tempSet
                    break
        for i in updatedSet:
            newGame = newGame[0:i] + token + newGame[i+1:]
        return newGame

def fasterLegalMoves(game, turn): #issue: flipped set is correct, changing board is not. may implement later?
    legalSet = {}
    adjacencies = {-9, -8, -7, -1, 1, 7, 8, 9}
    for i in range(64):
        flipSet = []
        if game[i] != ".":
            continue
        for j in adjacencies:
            currPos = i+j
            prev = i
            opposingCount = 0
            tempFlip = []
            while (currPos > -1 and currPos < 64) and not (currPos % 8 == 7 and prev % 8 == 0 and (currPos-prev) % 8 == 7) \
                    and not (currPos % 8 == 0 and prev % 8 == 7 and (currPos-prev) % 8 == 1):
                if game[currPos] == ".":
                    break
                elif game[currPos] in symbols and game[currPos] != turn:
                    tempFlip.append(currPos)
                    currPos += j
                    prev += j
                    opposingCount += 1
                elif game[currPos] == turn:
                    if opposingCount != 0:
                        flipSet += tempFlip
                    break
        if flipSet:
            legalSet[i] = flipSet
    return legalSet

def nextPos(game, turn, legalM, move):
    next = game[0:move] + turn + game[move+1:]
    return "".join([turn if i in legalM[move] else next[i] for i in range(64)])

def evaluate(game, turn):
    return sum([1 for i in game if i == turn]) - sum([1 for i in game if i == (symbols-{turn}).pop()])

def Wevaluate(game, turn):
    return sum([weightMatrix[i] for i in range(64) if game[i]==turn])

def negamax(game, turn, level):
    if not level:
        return [evaluate(game, turn)]
    lm = legalMoves(game, turn)
    enemy = ({"X", "O"}-{turn}).pop()
    if not lm and not legalMoves(game, enemy):
        return [evaluate(game, turn)]
    if not lm:
        nm = negamax(game, enemy, level-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(flipTiles(game, turn, move), enemy, level-1) + [move] for move in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]

def alphaBeta(game, turn, alpha, beta):
    lm = fasterLegalMoves(game, turn)
    enemy = ({"X", "O"}-{turn}).pop()
    if not lm:
        enemymoves = fasterLegalMoves(game, enemy)
        if not enemymoves:
            return [evaluate(game, turn)]
        nm = alphaBeta(game, enemy, -beta, -alpha) + [-1]
        return [-nm[0]] + nm[1:]
    returned = []
    newbeta = -alpha
    for move in lm.keys():
        nm = alphaBeta(nextPos(game, turn, lm, move), enemy, -beta, newbeta) + [move]
        if not returned or nm[0] < newbeta:
            returned = nm
            if nm[0] < newbeta:
                newbeta = nm[0]
                if -newbeta >= beta:
                    return [-returned[0]] + returned[1:]
    return [-returned[0]] + returned[1:]

def alphaBetaDepth(game, turn, alpha, beta, depth):
    if not depth:
        return [Wevaluate(game, turn)]
    lm = fasterLegalMoves(game, turn)
    enemy = ({"X", "O"}-{turn}).pop()
    if not lm:
        enemymoves = fasterLegalMoves(game, enemy)
        if not enemymoves:
            return [evaluate(game, turn)]
        nm = alphaBetaDepth(game, enemy, -beta, -alpha, depth-1) + [-1]
        return [-nm[0]] + nm[1:]
    returned = []
    newbeta = -alpha
    for move in lm.keys():
        nm = alphaBetaDepth(nextPos(game, turn, lm, move), enemy, -beta, newbeta, depth-1) + [move]
        if not returned or nm[0] < newbeta:
            returned = nm
            if nm[0] < newbeta:
                newbeta = nm[0]
                if -newbeta >= beta:
                    return [-returned[0]] + returned[1:]
    return [-returned[0]] + returned[1:]

def heuristic(game, turn):
    legalSet = legalMoves(game, turn)
    owned = [j for j in corners if game[j] == turn]
    for i in legalSet:
        if i in corners:
            return i
        for j in owned:
            if i%8 == j%8 or i//8 == j//8:
                return i

    for r in legalSet:
        for i in badSquares.keys():
            if i not in owned and r in badSquares[i]:
                legalSet = legalSet - {r}
        if r % 8 == 0 or r % 8 == 7 or r // 8 == 0 or r // 8 == 7:
            legalSet = legalSet - {r}
    if legalSet:
        return legalSet.pop()
    else:
        return legalMoves(game, turn).pop()

def main():
    board = "...........................OX......XO..........................."
    tile = getTurn(board)

    if len(sys.argv) > 1:
        if len(sys.argv[1]) > 2:
            board = sys.argv[1].upper()
        else:
            tile = sys.argv[1].upper()
        if len(sys.argv) > 2:
            board = sys.argv[1].upper()
            tile = sys.argv[2].upper()

    print("\n".join([board[8*i:8*(i+1)] for i in range(8)]))

    if board in openingSets:
        mv = random.choice(openingSets[board])
        print(mv)
        return

    for transform in transforms:
        transformed = "".join([board[i] for i in transform])
        if transformed in openingSets:
            transformSet = [transform[i] for i in openingSets[transformed]]
            mv = random.choice(transformSet)
            print(mv)
            return

    print(heuristic(board, tile))

    if board.count(".") <= N:
        nm = alphaBeta(board, tile, -64, 64)
        print(nm, nm[-1])

    for i in range(1, 20, 2):
        mv = alphaBetaDepth(board, tile, -64, 64, i)[-1]
        print(mv)

class Strategy():

    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        brd = ''.join(board).replace("?", "").replace("@", "X").upper()
        token = "X" if player == "@" else "O"

        if brd in openingSets:
            mv = random.choice(openingSets[brd])
            mv1 = 11 + (mv // 8)*10 + (mv%8)
            best_move.value = mv1
            return

        for transform in transforms:
            transformed = "".join([brd[i] for i in transform])
            if transformed in openingSets:
                transformSet = [transform[i] for i in openingSets[transformed]]
                mv = random.choice(transformSet)
                mv1 = 11 + (mv // 8)*10 + (mv%8)
                best_move.value = mv1
                return

        if board.count(".") <= N:
            mv = alphaBeta(brd, token, -64, 64)[-1]
            mv1 = 11 + (mv // 8)*10 + (mv%8)
            best_move.value = mv1

        for i in range(1, 20, 2):
            mv = alphaBetaDepth(brd, token, -64, 64, i)[-1]
            mv1 = 11 + (mv // 8)*10 + (mv%8)
            best_move.value = mv1



if __name__ == '__main__':
    main()


#end of python file
