import Othello_Core as core
import math
import random

weights = [[150, -20, 20, 5, 5, 20, -20, 150],
           [-20, -40, -5, -5, -5, -5, -40, -20],
           [20, -5, 15, 3, 3, 15, -5, 20],
           [5, -5, 3, 3, 3, 3, -5, 5],
           [5, -5, 3, 3, 3, 3, -5, 5],
           [20, -5, 15, 3, 3, 15, -5, 20],
           [-20, -40, -5, -5, -5, -5, -40, -20],
           [150, -20, 20, 5, 5, 20, -20, 150]]

other = {core.BLACK: core.WHITE, core.WHITE: core.BLACK}
miniMaxDepth = 5
corners = [(0, 0), (0, 7), (7, 0), (7, 7)]


class Strategy(core.OthelloCore):
	def best_strategy(self, board, player, best_move, still_running):
		global miniMaxDepth

		def gameOver(state):
			if len(findMoves(state)) != 0:
				return False
			state[1] = other[state[1]]
			if len(findMoves(state)) != 0:
				state[1] = other[state[1]]
				return False
			state[1] = other[state[1]]
			return True

		def findMoves(state):
			b, p = state
			if count(state, p) < count(state, "."):
				b, p = state
				moves = set()
				for r in range(8):
					for c in range(8):
						if b[r][c] == p:
							for i in range(-1, 2):
								for j in range(-1, 2):
									if not (i == 0 and j == 0) and 0 <= r + i < 8 and 0 <= c + j < 8 and b[r + i][c + j] == other[p]:
										curR = r + i
										curC = c + j
										while True:
											if 0 <= curR < 8 and 0 <= curC < 8:
												if b[curR][curC] == ".":
													moves.add((curR, curC))
													break
												elif b[curR][curC] == p:
													break
											else:
												break
											curR += i
											curC += j
				return list(moves)
			else:
				b, p = state
				moves = []
				for r in range(8):
					for c in range(8):
						if b[r][c] == ".":
							foundMove = False
							for dr in range(-1, 2):
								for dc in range(-1, 2):
									if not (dr == 0 and dc == 0):
										curR = r + dr
										curC = c + dc
										if 0 <= curR < 8 and 0 <= curC < 8 and b[curR][curC] == other[p]:
											while 0 <= curR < 8 and 0 <= curC < 8 and b[curR][curC] != ".":
												if b[curR][curC] == p:
													moves.append((r, c))
													foundMove = True
													break
												curR += dr
												curC += dc
											if foundMove:
												break
								if foundMove:
									break
				return moves

		def stablePieces(state, p):
			stable = set()
			for cor in corners:
				right = down = False
				if cor == (0, 0):
					right = down = True
				elif cor == (0, 7):
					down = True
				elif cor == (7, 0):
					right = True
				horStart, horStop, horStep = ((7, -1, -1), (0, 8, 1))[right]
				vertStart, vertStop, vertStep = ((7, -1, -1), (0, 8, 1))[down]
				for r in range(horStart, horStop, horStep):
					for c in range(vertStart, vertStop, vertStep):
						if state[0][r][c] == p:
							stable.add((r, c))
						else:
							vertStop = c
							break
			return len(stable)

		def makeMove(state, r, c):
			turn = state[1]
			b = state[0]
			toFlip = []
			for i in range(-1, 2):
				for j in range(-1, 2):
					if not (i == 0 and j == 0) and 0 <= r + i < 8 and 0 <= c + j < 8 and b[r + i][c + j] == other[
						turn]:
						curR = r + i
						curC = c + j
						curFlip = []
						while True:
							if 0 <= curR < 8 and 0 <= curC < 8:
								if b[curR][curC] == core.EMPTY:
									break
								elif b[curR][curC] == turn:
									toFlip += curFlip
									break
								curFlip.append((curR, curC))
								curR += i
								curC += j
							else:
								break
			for row, col in toFlip:
				state[0][row][col] = turn
			state[1] = other[turn]
			state[0][r][c] = turn

		def miniMax(state, level, alpha, beta, maxPlayer):
			if level == 0 or gameOver(state):
				return heuristic(state), None
			if len(findMoves(state)) == 0:
				temp = [[[i for i in j] for j in k] if type(k) is list else other[k] for k in state]
				return miniMax(temp, level, alpha, beta, not miniMaxDepth)
			if maxPlayer:
				best = -math.inf
				bestMove = None
				for m in findMoves(state):
					temp = [[[i for i in j] for j in k] if type(k) is list else k for k in state]
					makeMove(temp, m[0], m[1])
					i = miniMax(temp, level - 1, alpha, beta, False)[0]
					if i >= best:
						best = i
						bestMove = m
					alpha = max(alpha, i)
					if beta <= alpha:
						break
				return best, bestMove
			else:
				best = math.inf
				bestMove = None
				for m in findMoves(state):
					temp = [[[i for i in j] for j in k] if type(k) is list else k for k in state]
					makeMove(temp, m[0], m[1])
					i = miniMax(temp, level - 1, alpha, beta, True)[0]
					if i <= best:
						best = i
						bestMove = m
					beta = min(beta, i)
					if beta <= alpha:
						break
				return best, bestMove

		def heuristic(state):
			if gameOver(state):
				m = count(state, player)
				o = count(state, other[player])
				if m > o:
					return 1000000000 + m - o
				elif m < o:
					return -1000000000 + m - o
				else:
					return 0
			numStable = stablePieces(state, player)
			otherStable = stablePieces(state, other[player])
			weight = 0
			b, p = state
			pieces = 64 - count(state, ".")
			for r in range(8):
				for c in range(8):
					if b[r][c] == player:
						weight += weights[r][c]
					elif b[r][c] == other[player]:
						if (r, c) in corners:
							weight -= 750
						else:
							weight -= weights[r][c]
			moves = findMoves(state)
			numMoves = (-1, 1)[p == player] * len(moves)
			if numMoves == 0:
				potential = (1, -1)[p == player] * 500
			else:
				potential = sum(weights[i[0]][i[1]] for i in moves) / numMoves
			if pieces > 58:
				return weight + potential + numMoves * 2 + (count(state, player) - count(state, other[player])) * 20 + numStable * 25 - otherStable * 27
			elif pieces > 20:
				return weight * 2 + potential * 2 + numMoves * 6 + (count(state, player) - count(state, other[player])) * 4 + numStable * 25 - otherStable * 27
			else:
				return weight * 2 + potential * 3 + numMoves * 10 + (count(state, player) - count(state, other[player])) + numStable * 25 - otherStable * 27

		def count(state, p):
			b = state[0]
			out = 0
			for r in b:
				for c in r:
					if c == p:
						out += 1
			return out

		def convertBoard(b, p):
			newBoard = []
			for r in range(8):
				row = []
				for c in range(8):
					row.append(b[convertMove((r, c))])
				newBoard.append(row)
			return [newBoard] + [p]

		def convertMove(move):
			r, c = move
			return 10 * (r + 1) + c + 1

		state = convertBoard(board, player)
		best_move.value = convertMove(random.choice(findMoves(state)))
		while True:
			best_move.value = convertMove(miniMax(state, miniMaxDepth, -math.inf, math.inf, True)[1])
			miniMaxDepth += 1