import copy
##Shay Le, Period 1

class Strategy:
    WHITE = 'o'
    BLACK = '@'
    BLANK = '.'

    def best_strategy(self, board, player, best_move, still_running):
        bb = self.redo(board)
        a = self.strat(bb, 5, player) ## call this first
        best_move.value = self.realIndex(a)

    def redo(self, board):
        temp = board[0:90]
        for i in range(80, 9, -10):
            temp = temp[:i] + temp[i + 1:i + 9] + temp[i + 10:]
        thing = temp[10:]
        return thing

    def realIndex(self, index):
        tenind = index + 11
        for k in range(0, index // 8):
            tenind += 2
        return tenind

    def checkPossibles(self, board, move):
        other = self.BLACK
        if move == self.BLACK:
            other = self.WHITE

        poss = []
        oth = list(board)
        for i in range(len(oth)):
            if oth[i] == self.BLANK:
                if i % 8 > 0 and oth[i - 1] == other:
                    for l in range(i - 1, (i // 8) * 8, -1):
                        if oth[l] == move:
                            poss.append(i)
                            break
                        if oth[l] == self.BLANK:
                            break
                if i not in poss and i % 8 < 7 and oth[i + 1] == other:
                    for r in range(i + 1, (i // 8 + 1) * 8):
                        if oth[r] == move:
                            poss.append(i)
                            break
                        if oth[r] == self.BLANK:
                            break
                if i not in poss and i > 7 and oth[i - 8] == other:
                    for u in range(i - 8, -1, -8):
                        if oth[u] == move:
                            poss.append(i)
                            break
                        if oth[u] == self.BLANK:
                            break
                if i not in poss and i < 56 and oth[i + 8] == other:
                    for d in range(i + 8, 64, 8):
                        if oth[d] == move:
                            poss.append(i)
                            break
                        if oth[d] == self.BLANK:
                            break
                if i not in poss and i > 17 and i % 8 > 1 and oth[i - 9] == other:
                    for lu in range(i - 18, 0, -9):
                        if oth[lu] == move:
                            poss.append(i)
                            break
                        if lu % 8 == 0 or lu < 8:
                            break
                        if oth[lu] == self.BLANK:
                            break
                if i not in poss and i < 48 and i % 8 > 1 and oth[i + 7] == other:
                    for ld in range(i + 14, 64, 7):
                        if oth[ld] == move:
                            poss.append(i)
                            break
                        if ld % 8 == 0 or ld > 56:
                            break
                        if oth[ld] == self.BLANK:
                            break
                if i not in poss and i > 15 and (i) % 8 < 6 and oth[i - 7] == other:
                    for ru in range(i - 14, 0, -7):
                        if oth[ru] == move:
                            poss.append(i)
                            break
                        if ru % 8 > 6 or ru < 8:
                            break
                        if oth[ru] == self.BLANK:
                            break
                if i not in poss and i < 46 and (i) % 8 < 6 and oth[i + 9] == other:
                    for rd in range(i + 18, 64, 9):
                        if oth[rd] == move:
                            poss.append(i)
                            break
                        if rd % 8 > 6 or rd > 56:
                            break
                        if oth[rd] == self.BLANK:
                            break
        return poss

    def flip(self, move, board, start, direction, end):
        b = copy.deepcopy(board)
        f = list(b)
        for index in range(start, end, direction):
            f[index] = move
        return "".join(f)

    def changeBoard(self, oth, i, move):
        other = self.BLACK
        if move == self.BLACK:
            other = self.WHITE
        b = copy.deepcopy(oth)
        if i % 8 > 0 and oth[i - 1] == other:
            for l in range(i - 1, (i // 8) * 8, -1):
                if oth[l] == move:
                    b = self.flip(move, b, i, -1, l)
                    break
                if oth[l] == self.BLANK:
                    break
        if i % 8 < 7 and oth[i + 1] == other:
            for r in range(i + 1, (i // 8 + 1) * 8):
                if oth[r] == move:
                    b = self.flip(move, b, i, 1, r)
                    break
                if oth[r] == self.BLANK:
                    break
        if i > 7 and oth[i - 8] == other:
            for u in range(i - 8, -1, -8):
                if oth[u] == move:
                    b = self.flip(move, b, i, -8, u)
                    break
                if oth[u] == self.BLANK:
                    break
        if i < 56 and oth[i + 8] == other:
            for d in range(i + 8, 64, 8):
                if oth[d] == move:
                    b = self.flip(move, b, i, 8, d)
                    break
                if oth[d] == self.BLANK:
                    break
        if i > 17 and i % 8 > 1 and oth[i - 9] == other:
            for lu in range(i - 18, 0, -9):
                if oth[lu] == move:
                    b = self.flip(move, b, i, -9, lu)
                    break
                if lu % 8 == 0 or lu < 8:
                    break
                if oth[lu] == self.BLANK:
                    break
        if i < 48 and i % 8 > 1 and oth[i + 7] == other:
            for ld in range(i + 14, 64, 7):
                if oth[ld] == move:
                    b = self.flip(move, b, i, 7, ld)
                    break
                if ld % 8 == 0 or ld > 56:
                    break
                if oth[ld] == self.BLANK:
                    break
        if i > 15 and i % 8 < 6 and oth[i - 7] == other:
            for ru in range(i - 14, 0, -7):
                if oth[ru] == move:
                    b = self.flip(move, b, i, -7, ru)
                    break
                if ru % 8 > 6 or ru < 8:
                    break
                if oth[ru] == self.BLANK:
                    break
        if i < 46 and (i) % 8 < 6 and oth[i + 9] == other:
            for rd in range(i + 18, 64, 9):
                if oth[rd] == move:
                    b = self.flip(move, b, i, 9, rd)
                    break
                if rd % 8 > 6 or rd > 56:
                    break
                if oth[rd] == self.BLANK:
                    break
        return b

    def heuristic(self, board, player):
        opp = self.BLACK
        if player == self.BLACK:
            opp = self.WHITE
        h = [130, -20, 20, 5,  5,  20, -20, 130,
             -20, -40, -5, -5, -5, -5, -40, -20,
             20,  -5,  15, 3,  3,  15, -5,  20,
             5,   -5,  3,  3,  3,  3,  -5,  5,
             5,   -5,  3,  3,  3,  3,  -5,  5,
             20,  -5,  15, 3,  3,  15, -5,  20,
             -20, -40, -5, -5, -5, -5, -40, -20,
             130, -20, 20, 5,  5,  20, -20, 130,
             ]
        p = o = 0
        for i in range (0, len(board)):
            if board[i] == player:
                p += h[i]
            if board[i] == opp:
                o +=h[i]
        return (p-o)

    def strat(self, board, depth, player): ## call this first
        try:
            poss = self.checkPossibles(board, player)
            if len(poss) ==1:
                return poss[0]

            maxval = float("inf")*-1
            minindex = poss[0]

            for i in poss:
                newb = self.changeBoard(board, i, player)
                val = self.minimax(newb, depth-1, True, -1*float("inf"), float("inf"), player)
                if val > maxval:
                    maxval = val
                    minindex = i
            return minindex
        except:
            t = self.checkPossibles(board,player)
            return t[0]

    def minimax(self, board, depth, yesmaxing, a, b, player):
        try:
            opp = self.BLACK
            if player == self.BLACK:
                opp = self.WHITE

            # stop
            if depth == 0 or self.BLANK not in str(board):
                return self.heuristic(board, player)

            poss = self.checkPossibles(board, player)

            # no moves from here
            if not poss:
                return self.minimax(board, depth - 1, False * yesmaxing, a, b, opp)

            if yesmaxing:
                for i in poss:
                    newb = self.changeBoard(board, i, player)
                    vv = self.minimax(newb, depth - 1, False, a, b, opp)
                    if vv>a:
                        a=vv
                    if a >=b:
                        return a
                return a
            else:  # min
                for i in poss:
                    newbe = self.changeBoard(board, i, player)
                    vv = self.minimax(newbe, depth - 1, True, a, b, opp)
                    if vv < b:
                        b = vv
                    if b <= a:
                        return b
                return b
        except:
            return self.heuristic(board, player)
