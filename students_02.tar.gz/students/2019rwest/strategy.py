#Jan 12, 0952 version

import random
import math
import re
import time

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        self.scoreMatrix = [
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
            0, 1020, -200,  220,   5,   5,  220, -200, 1020,   0,
            0, -200, -400,  50,  -5,  -5,  50, -400, -200,   0,
            0,  220,  50,  105,   3,   3,  105,  50,  220,   0,
            0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
            0,   5,  -5,   -50,   3,   3,   3,  -5,   5,   0,
            0,  220,  50,  105,   -50,   3,  105,  50,  220,   0,
            0, -200, -400,  50,  -5,  -5,  55, -400, -200,   0,
            0, 1020, -200,  220,   5,   5,  220, -200, 1020,   0,
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        ]

        self.movesMade = 0
        self.firstMove = True


        pass
        """
        self.board = self.get_starting_board()
        self.get_pretty_board(self.board)
        print(self.find_match(self.board, BLACK, 45, W))
        print(self.get_valid_moves(self.board, BLACK))
        """

    def get_starting_board(self):
        startBoard = "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
        print(len(startBoard))
        return startBoard

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        toReturn = ""
        for x in range(0, 10):
            toReturn += board[10*x:10*x+10] +"\n"
        return toReturn

    def opponent(self, player):
        """Get player's opponent."""
        pass

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        if player == BLACK:
            lookFor = WHITE
        else:
            lookFor = BLACK
        if board[square+direction] != lookFor:
            return None
        square += direction
        while board[square] == lookFor:
            square += direction
        if board[square] == EMPTY:
            return square
        else:
            return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        if player == BLACK:
            lookFor = WHITE
        else:
            lookFor = BLACK
        board = board[:move] + player + board[move + 1:]
        for direc in DIRECTIONS:
            score = move
            if board[score + direc] == lookFor:
                score += direc
                while board[score] == lookFor:
                    score += direc
                if board[score] == player:
                    score -= direc
                    while board[score] != player:
                        board = board[:score] + player + board[score + 1:]
                        score -= direc
        return board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valMoves = []
        pieces = [m.start() for m in re.finditer(player, board)]
        for piece in pieces:
            for direc in DIRECTIONS:
                x = self.find_match(board, player, piece, direc)
                if x:
                    valMoves.append(x)
        return valMoves


    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        pass

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if prev_player == BLACK:
            if len(self.get_valid_moves(board, WHITE)) > 0:
                return WHITE
            elif len(self.get_valid_moves(board, BLACK)) > 0:
                return BLACK
            else:
                return None
        else:
            if len(self.get_valid_moves(board, BLACK)) > 0:
                return BLACK
            elif len(self.get_valid_moves(board, WHITE)) > 0:
                return WHITE
            else:
                return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        if player == BLACK:
            return len([m.start() for m in re.finditer(player, board)]) - len([m.start() for m in re.finditer(WHITE, board)])
        else:
            return len([m.start() for m in re.finditer(WHITE, board)]) - len(
                [m.start() for m in re.finditer(BLACK, board)])

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        pass

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ classes #################

    class Node:
        def __init__(self, board, move, score=None):
            self.board = board
            self.move = move
            self.score = score

        def __lt__(self, other):
            return self.score - other.score

    ################ strategies #################

    def simple_score(self, board):
        return len([m.start() for m in re.finditer(BLACK, board)]) - len(
            [m.start() for m in re.finditer(WHITE, board)])

    def simple_matrix_score(self, board):
        blackSum = 0
        whiteSum = 0
        for x in range(0, len(board)):
            if board[x] == BLACK:
                blackSum += self.scoreMatrix[x]
            elif board[x] == WHITE:
                whiteSum += self.scoreMatrix[x]
        return blackSum - whiteSum

    def regex_matrix_score(self, board):
        return sum([self.scoreMatrix[x] for x in [m.start() for m in re.finditer(BLACK, board)]]) - sum(
            [self.scoreMatrix[x] for x in [m.start() for m in re.finditer(WHITE, board)]]
        )

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK:max, WHITE:min}
        board = node.board
        if depth == 0:
            node.score = self.regex_matrix_score(board)
            return node
        my_moves = set(self.get_valid_moves(board, player))
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = self.Node(next_board, move, score=1000 * self.simple_score(next_board))
                children.append(c)
            else:
                c = self.Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth=depth - 1).score
                children.append(c)
        winner = best[player](children)
        node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(self.Node(board, None), player, depth).move

    def alphabeta_search(self, node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK:max, WHITE:min}
        board = node.board
        if depth == 0:
            node.score = self.regex_matrix_score(board)
            return node
        my_moves = set(self.get_valid_moves(board, player))
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = self.Node(next_board, move, score=1000 * self.simple_score(next_board))
                children.append(c)
            else:
                c = self.Node(next_board, move)
                c.score = self.alphabeta_search(c, next_player, depth - 1, alpha, beta).score
                children.append(c)
                if player == BLACK:
                    alpha = max(alpha, c.score)
                else:
                    beta = min(beta, c.score)
                if alpha >= beta:
                    break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def alphabeta_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.alphabeta_search(self.Node(board, None), player, depth, -2000000, 2000000).move
    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def quick_move_strategy(self, board, player):
        self.update_matrix(board, player)
        my_moves = set(self.get_valid_moves(board, player))
        scores = {x:self.scoreMatrix[x] for x in my_moves}
        score = max(scores, key=lambda x: scores[x]+random.random())
        return score

    def get_fewer_moves(self, board, player):
        self.update_matrix(board, player)
        my_moves = set(self.get_valid_moves(board, player))
        scores = {x:self.scoreMatrix[x] for x in my_moves}
        score = sorted(scores, key=lambda x: scores[x]+random.random())
        if len(score) > 3:
            score = score[:3]
        return score

    def alphabeta2_search(self, node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK:max, WHITE:min}
        board = node.board
        if depth == 0:
            node.score = self.regex_matrix_score(board)
            return node
        if player == BLACK and self.firstMove:
            my_moves = self.get_fewer_moves(board, player)
        else:
            my_moves = set(self.get_valid_moves(board, player))
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = self.Node(next_board, move, score=1000 * self.simple_score(next_board))
                children.append(c)
            else:
                c = self.Node(next_board, move)
                c.score = self.alphabeta2_search(c, next_player, depth - 1, alpha, beta).score
                children.append(c)
                if player == BLACK:
                    alpha = max(alpha, c.score)
                else:
                    beta = min(beta, c.score)
                if alpha >= beta:
                    break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def alphabeta2_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.alphabeta2_search(self.Node(board, None), player, depth, -2000000, 2000000).move

    def update_matrix(self, board, player):
        if self.firstMove:
            self.firstMove = False
        else:
            return
        if board[11] == player:
            self.scoreMatrix[12] = self.scoreMatrix[21] = self.scoreMatrix[22] = 25
        if board[18] == player:
            self.scoreMatrix[27] = self.scoreMatrix[28] = self.scoreMatrix[17] = 25
        if board[88] == player:
            self.scoreMatrix[87] = self.scoreMatrix[78] = self.scoreMatrix[77] = 25
        if board[81] == player:
            self.scoreMatrix[71] = self.scoreMatrix[82] = self.scoreMatrix[72] = 25


    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = ''.join(board)
        """
        self.movesMade += 1
        if self.movesMade <= 15:
            best_move.value = self.quick_move_strategy(board, player)
            time.sleep(random.random()*.5)
        else:
            depth = 1
            while (still_running):
                best_move.value = self.alphabeta_strategy(board, player, depth)
                depth += 1
        """
        depth = 1
        self.movesMade += 1


        while(still_running):
            ## doing random in a loop is pointless but it's just an example
            #  best_move.value = self.random_strategy(board, player)
            self.firstMove = True
            if self.movesMade < 16:
                best_move.value = self.alphabeta2_strategy(board, player, depth)
            else:
                best_move.value = self.alphabeta_strategy(board, player, depth)
            depth += 1



    def score_strategy(self, board, player):
        pass

    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.quick_move_strategy}
        #  strategy = {BLACK: black.standard_strategy, WHITE: white.random_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            self.testStrats(board)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))

    def testStrats(self, board):
        strat = Strategy()
        tic = time.time()
        for x in range(0, 10000):
            strat.regex_matrix_score(
                board)
        toc = time.time()
        tic2 = time.time()
        for x in range(0, 10000):
            strat.simple_matrix_score(
                board)
        toc2 = time.time()
        print("Regex", str(toc - tic))
        print("Simple", str(toc2 - tic2))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    #  game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()

