import sys
import time
import random
class Strategy():
 def best_strategy(self, board, player, best_move, still_running):
    board2 = ''.join(board).replace('?', '').replace('@','X')
    print(board2)
    token = 'X' if player == '@' else 'O'
    pds = {0 for thing in board2 if thing == '.'}
    
    if len(pds)< 8:
        nm = negamax(board2, token, 1)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(1, nm, nm[-1]))
        nm = negamax(board2, token, 3)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(3, nm, nm[-1]))
        nm = negamax(board2, token, 5)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(5, nm, nm[-1]))
        nm = negamax(board2, token, 7)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(7, nm, nm[-1]))
    else:
        mv = findBestMove(board2, token)
    mv1 = 11+ (mv//8)*10+(mv%8)
    best_move.value= mv1
startTime = time.clock()
rowlookup = [[i for i in range(8*j, 8*j + 8)] for j in range(8)]
collookup = [[i for i in range(j, 64 , 8)] for j in range(8)]
diaglookup = []
l1 = [0,1,2,3,4,5,6,7,15,23,31,39,47]
l2 = [0,1,2,3,4,5,6,7,8,16,24,32,40,48,56]
for j in l1:
    newset = []
    for i in range(j, 63, 7):
        if i%8!= 7:
            newset.append(i)
        elif j %8 == 7:
            newset.append(i)
        else:
            break
    if len(newset) > 2:
        diaglookup.append(newset)
for j in l2:
    newset = []
    for i in range(j, 64, 9):
        if i %8 != 0:
            newset.append(i)
        elif j%8 == 0:
            newset.append(i)
        else:
            break
    if len(newset) > 2:
       diaglookup.append(newset)

setList = []
for nbrlist in rowlookup:
    setList.append(nbrlist)
for nbrList in collookup:
    setList.append(nbrList)
for nbrList in diaglookup:
    setList.append(nbrList)

idxnbr = {idx: [nbrList for nbrList in setList if idx in nbrList] for idx in range(64)}

def findPosMoves(board, player): 
    possMoves = []
    boolcheck= 0 #0 means looking for first playerpos, 1 = check for stuff between, 2 = found stuff between looking for next empty
    if player == 'X':
        opp = 'O'
    else:
        opp = 'X'
    for nbrList in setList:
        boolcheck = 0
        for idx in nbrList:
            if board[idx] == player and boolcheck == 0:
                boolcheck = 1
            elif boolcheck == 1 and board[idx] == '.':
                boolcheck = 0
            elif boolcheck == 1 and board[idx] == opp:
                boolcheck = 2
            elif boolcheck == 2 and board[idx] == '.':
                if idx not in possMoves:
                    possMoves.append(idx)
                boolcheck = 0
            elif boolcheck == 2 and board[idx] == player:
                boolcheck = 1
    for nbrList in setList:
        boolcheck = 0
        nbrList = nbrList[::-1]
        for idx in nbrList:
            if board[idx] == player and boolcheck == 0:
                boolcheck = 1
            elif boolcheck == 1 and board[idx] == '.':
                boolcheck = 0
            elif boolcheck == 1 and board[idx] == opp:
                boolcheck = 2
            elif boolcheck == 2 and board[idx] == '.':
                if idx not in possMoves:
                    possMoves.append(idx)
                boolcheck = 0
            elif boolcheck == 2 and board[idx] == player:
                boolcheck = 1
    return possMoves
def findMove(pzl):
    xlist = {i for i in range(len(pzl)) if pzl[i] == '.'}
    if len(xlist) %2 == 0:
        return 'X'
    else:
        return 'O'
def showBoard(pzl):
    count = 1
    for num in range(8):
        line = str(count ) + ' '
        for j in range(8*num, 8*num +8):
            line += pzl[j] + ' '
        print( line)
        count += 1
    print( '  a b c d e f g h')
def replacepuz(pzl, newnum, index):
    return pzl[:index] + newnum + pzl[index +1:]
def fliptokens(board, player,pos):
    if player == 'X':
        opp = 'O'
    else:
        opp = 'X'
    board2 = replacepuz(board, player, pos)
    for nbrList in idxnbr[pos]:
        check = 0
        indecestoChange = []
        for idx in nbrList:
            if idx == pos:
                check= 1
            elif check == 1 and board2[idx] == player:
                for mv in indecestoChange:
                    board2 = replacepuz(board2, player, mv)
                break
            elif check == 1 and board2[idx] == '.':
                break
            elif check == 1 and board2[idx] ==opp:
                indecestoChange.append(idx)
    
    for nbrList in idxnbr[pos]:
        nbrList = nbrList[::-1]
        check = 0
        indecestoChange = []
        for idx in nbrList:
            if idx == pos:
                check= 1
            elif check == 1 and board2[idx] == player:
                for mv in indecestoChange:
                    board2 = replacepuz(board2, player, mv)
                break
            elif check == 1 and board2[idx] == '.':
                break
            elif check == 1 and board2[idx] ==opp:
                indecestoChange.append(idx)
    return board2
def xvso(pzl,token):
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    xlist = {i for i in range(len(pzl)) if pzl[i] == token}
    ylist = {i for i in range(len(pzl)) if pzl[i] == enemy}
    return len(xlist) - len(ylist)
def modboard(board,token,pos):
    idxlist = findPosMoves(board, token)
    board2 = board
    for idx in idxlist:
        if idx == pos:
            board2 = replacepuz(board2, '+', idx)
        else:
            board2 = replacepuz(board2, '*', idx)
    return board2
def edgeCovered(board, token, pos):
    if token== 'X':
        opp = 'O'
    else:
        opp = 'X'
    edges = [[0,1,2,3,4,5,6,7],\
             [0,8,16,24,32,40,48,56],\
             [56,57,58,59,60,61,62,63],\
             [63,55,47,39,31,23,15,7]]
    board = fliptokens(board, token, pos)
    for arr in edges:
        if pos in arr:
            for move in arr:
                if board[move] != token:
                    break
                if board[move] == '.' or board[move] == opp:
                    break
                if move == pos:
                    return True
            for move in arr[::-1]:
                if board[move] != token:
                    break
                if board[move] == '.' or board[move] == opp:
                    break
                if move == pos:
                    return True
    return False
def findBestMove(board, token):
    corners = [0,7,63, 56]
    dictborder =  {1:0, 8:0, 9:0, 6:7, 14:7, 15:7, 55:63, 54:63, 62:63, 48:56, 49: 56, 57:56}
    edgeList = []
    nonEdge = []
    edges = {0,1,2,3,4,5,6,7,8,16,24,32,40,48,56, 57,58,59,60,61,62,63,55,47,39,31,23,15}
    posMoves = findPosMoves(board, token)
    for corn in corners:
        if corn in posMoves:
            return corn
    for move in posMoves:
        if move in edges:
            edgeList.append(move)
            if edgeCovered(board,token,move):
                return move
        elif move in dictborder.values():
            if board[dictborder[move]] != token:
                break
        else:
            nonEdge.append(move)
    if len(nonEdge) != 0:
        return random.choice([*nonEdge])
    else:
        return random.choice([*posMoves])

def negamax(board, token,levels): #returns a score together with a move sequence leading to that score
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    if not levels:
        return [xvso(board, token)] #first element is score, remaining elements are moves used to get to that score
    lm = findPosMoves(board, token)
    if not lm: 
        nm = negamax(board, enemy, levels-1) + [-1]
        return [-nm[0]] +nm[1:]
    nmList = sorted( [negamax(replacepuz(board, token, mv), enemy, levels-1) + [mv] for mv in lm])

    best = nmList[0]

    return [-best[0]] + best[1:]
def main():
    emptyboard = '...........................OX......XO...........................'
    if len(sys.argv) > 1:
        if len(sys.argv[1]) == 1:
            token = sys.argv[1].upper()
            board2 = emptyboard
        else:
            board2 = sys.argv[1].upper()
            if len(sys.argv)>2:
                token = sys.argv[2].upper()
            else:
                token = findMove(board)

    else:
        board2 = emptyboard
        token = findMove(board2)
    posMoves = {0 for thing in board2 if thing == '.'}
    if len(posMoves) < 8:
        nm = negamax(board2, token, 1)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(1, nm, nm[-1]))
        nm = negamax(board2, token, 3)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(3, nm, nm[-1]))
        nm = negamax(board2, token, 5)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(5, nm, nm[-1]))
        nm = negamax(board2, token, 7)
        mv = nm[-1]
        print ("At level{} nm gives {} and I pick move {}".format(7, nm, nm[-1]))
    else:
        mv = findBestMove(board2, token)
        print(mv)
    mv1 = 11+ (mv//8)*10+(mv%8)
    print(mv1)
if __name__ == "__main__":
    main()
    





    
