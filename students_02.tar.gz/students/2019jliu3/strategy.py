import sys
import random
import time

def whoseMove(game):
    if game.count('.')%2==0: return 'x'
    else: return 'o'

def legalMoves(game,token):
    legalMoves = set()
    for x in range(len(game)):
        if (game[x]=='.' and isLegal(game,x,token)): legalMoves.add(x)
    return legalMoves

def isLegal(game,pos,token):
    if token=='x': next='o'
    else: next='x'
    neighbors=set() #returns a set of tuples containing: (neighbor position,direction) - directions:1=right,2=left,3=down,4=up,5=down-left,6=up-right,7=down-right,8=up-left
    table = {0:(1,'right','left'),6:(7,'down-left','up-right'),7:(8,'down','up'),8:(9,'down-right','up-left')} #table : (increment,plus,minus)
    for k, v in table.items():
        if pos<63-k and game[pos+v[0]]==next: neighbors.add((pos+v[0],v[1]))
        if pos>k and game[pos-v[0]]==next: neighbors.add((pos-v[0],v[2]))
    evaluation = {'right':1,'left':-1,'down':8,'up':-8,'down-left':7,'up-right':-7,'down-right':9,'up-left':-9}
    oldpos=pos
    for neighbor in neighbors:
        i = evaluation[neighbor[1]]
        while(pos+i>=0 and pos+i<64 and game[pos+i]==next and (not ((pos%8==7 and (pos+i)%8==0) or (pos%8==0 and (pos+i)%8==7)))):#very important line (prevents crossing bug)
            pos=pos+i
        if pos+i>=0 and pos+i<64 and game[pos+i]==token and (not ((pos%8==7 and (pos+i)%8==0) or (pos%8==0 and (pos+i)%8==7))) : return True
        pos=oldpos
    return False


def evalBoard(game,token):# o is negative, x is positive
    if token == 'x': return game.count('x') - game.count('o')
    else: return game.count('o')-game.count('x')

def heuristic(game,moves,token):
    solidEdge = []
    CXwithCorner = []
    innerMoves = []
    edgeMovesNotCX = []
    CXmoves = []
    for move in moves:
        if move==0 or move==7 or move==56 or move==63: return move #greedy corner

        if game[0]==token and (move//8==0 or move%8==0):
             if move//8==0:
                 oldmove=move
                 while((move//8 == (move-1)//8) and (game[move]==token or oldmove==move)):
                    move=move-1
                 if move==0:
                     solidEdge.append(oldmove)
                 move=oldmove
             else:
                  oldmove=move
                  while(move-8>=0 and (game[move]==token or oldmove==move)):
                     move=move-8
                  if move==0:
                      solidEdge.append(oldmove)
                  move=oldmove
        if game[7]==token and (move//8==0 or move%8==7):
             if move//8==0:
                 oldmove=move
                 while((move//8 == (move+1)//8) and (game[move]==token or oldmove==move)):
                    move=move+1
                 if move==7:
                     solidEdge.append(oldmove)
                 move = oldmove
             else:
                  oldmove=move
                  while(move-8>=0 and (game[move]==token or oldmove==move)):
                     move=move-8
                  if move==7:
                      solidEdge.append(oldmove)
                  move = oldmove
        if game[56]==token and (move//8==7 or move%8==0):
             if move//8==7:
                 oldmove=move
                 while((move//8 == (move-1)//8) and (game[move]==token or oldmove==move)):
                    move=move-1
                 if move==56:
                     solidEdge.append(oldmove)
                 move = oldmove
             else:
                  oldmove=move
                  while(move+8<=63 and (game[move]==token or oldmove==move)):
                     move=move+8
                  if move==56:
                      solidEdge.append(oldmove)
                  move = oldmove
        if game[63]==token and (move//8==7 or move%8==7):
             if move//8==7:
                 oldmove=move
                 while((move//8 == (move+1)//8) and (game[move]==token or oldmove==move)):
                    move=move+1
                 if move==63:
                     solidEdge.append(oldmove)
                 move = oldmove
             else:
                  oldmove=move
                  while(move+8<=63 and (game[move]==token or oldmove==move)):
                     move=move+8
                  if move==63:
                      solidEdge.append(oldmove)
                  move = oldmove
        if ((game[0]==token) and (move==1 or move==8 or move==9)) or ((game[7]==token) and (move==6 or move==14 or move==15)) or ((game[56]==token) and (move==48 or move==49 or move==57)) or ((game[63]==token) and (move==62 or move==55 or move==54)): CXwithCorner.append(move)
        if (move//8!=0 and move//8!=7 and move%8!=7 and move%8!=0 and move!=9 and move!=14 and move!=49 and move!=54): innerMoves.append(move)
        if (move//8==0 or move//8==7 or move%8==7 or move%8==0) and (move!=1 and move!=8 and move!=9 and move!=6 and move!=14 and move!=15 and move!=48 and move!=49 and move!=57 and move!=62 and move!=55 and move!=54): edgeMovesNotCX.append(move)
        if (move==1 or move==8 or move==9 or move==6 or move==14 or move==15 or move==48 or move==49 or move==57 or move==62 or move==55 or move==54): CXmoves.append(move)

    if len(solidEdge)!=0: return solidEdge.pop(random.randrange(len(solidEdge)))
    if len(CXwithCorner)!=0: return CXwithCorner.pop(random.randrange(len(CXwithCorner)))
    if len(innerMoves)!=0: return innerMoves.pop(random.randrange(len(innerMoves)))
    if len(edgeMovesNotCX)!=0: return edgeMovesNotCX.pop(random.randrange(len(edgeMovesNotCX)))

    moves = list(moves)
    return moves.pop(random.randrange(len(moves)))

def makeMove(game,token,pos):
    oldpos = pos
    if token=='x': next='o'
    else: next='x'
    if isLegal(game,pos,token):
        neighbors=set() #returns a set of tuples containing: (neighbor position,direction) - directions:1=right,2=left,3=down,4=up,5=down-left,6=up-right,7=down-right,8=up-left
        table = {0:(1,'right','left'),6:(7,'down-left','up-right'),7:(8,'down','up'),8:(9,'down-right','up-left')} #table : (increment,plus,minus)
        for k, v in table.items():
            if pos<63-k and game[pos+v[0]]==next: neighbors.add((pos+v[0],v[1]))
            if pos>k and game[pos-v[0]]==next: neighbors.add((pos-v[0],v[2]))
        evaluation = {'right':1,'left':-1,'down':8,'up':-8,'down-left':7,'up-right':-7,'down-right':9,'up-left':-9}
        oldpos=pos
        for neighbor in neighbors:
            i = evaluation[neighbor[1]]
            while(pos+i>=0 and pos+i<64 and game[pos+i]==next and (not ((pos%8==7 and (pos+i)%8==0) or (pos%8==0 and (pos+i)%8==7)))):
                pos=pos+i
            if pos+i>=0 and pos+i<64 and game[pos+i]==token and (not ((pos%8==7 and (pos+i)%8==0) or (pos%8==0 and (pos+i)%8==7))):
                game = game[:pos]+token+game[pos+1:]
                while(game[pos-i]==next):
                    pos=pos-i
                    game = game[:pos]+token+game[pos+1:]
            pos=oldpos
        game = game[:pos]+token+game[pos+1:]
        pos = oldpos
        return game

def negamaxTerminal(game,token,improvable,hardBound,start_time,original_game,original_token):
    if time.clock()-start_time>60: return [heuristic(original_game,legalMoves(original_game,original_token),original_token)]
    if token == 'x': enemy = 'o'
    else: enemy = 'x'
    lm = legalMoves(game,token)
    if not lm:
        lm = legalMoves(game,enemy)
        if not lm: return[evalBoard(game,token),-3]
        nm = negamaxTerminal(game,enemy,-hardBound,-improvable,start_time,original_game,original_token) + [-1]
        return [-nm[0]] + nm[1:]
    best = [] #toReturn
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(game,token,mv),enemy,-hardBound,newHB,start_time,original_game,original_token) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardBound: return [-best[0]] + best[1:] # Alpha - Beta Pruning
    return [-best[0]] + best[1:]

def findBestMove(game,token,n):
    if game.count('.')>n:
        move = heuristic(game,legalMoves(game,token),token)
    else:
        levels=100000
        start_time = time.clock()
        nm = negamaxTerminal(game,token,-65,65,start_time,game,token)
        move = nm[-1]
    return move

def display(game):
    for x in range(8):
        print((' ').join(game[8*x:8*x+8]))

def main():
    game = '...........................ox......xo...........................' #default values
    token = whoseMove(game)
    for x in sys.argv: #cmd line values
        if len(x)==64:
            game = x.lower()
            token = whoseMove(game)
        elif len(x)==1: token = x.lower()
    moves = legalMoves(game,token)
    if len(moves) == 0: print('pass')
    else:
        nextMove=0
        if len(moves)==1: nextMove = moves.pop()
        else:
            nextMove = findBestMove(game,token)
        print(nextMove)

if __name__ == "__main__":
    main()
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = ''.join(board).replace('?','').replace('@','x')
        token = 'x' if player == '@' else 'o'

        #algorithm part
        mv = findBestMove(brd,token,10)
        mv1 = 11 + (mv//8) * 10 + (mv % 8)
        best_move.value = mv1
