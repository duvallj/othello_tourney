import sys
import time
import random
moveCache = dict()
def main():
  depth = 14
  startTime = time.clock()
  rawgame = ''
  turn = 2
  for data in sys.argv[1:]:
    if len(data) == 64:
      rawgame = data.upper()
    if data.upper() == 'X' or data.upper() == 'O':
      turn = 1 if data.upper() == 'X' else 0
    if data in '1234567890':
      depth = int(data)
  if not rawgame:
    rawgame = '...........................OX......XO...........................'
  if turn == 2:
    turn = (rawgame.count('.') & 1)^1

#  rawgame = 'OOXXXXOOOOOXXXXXOOXOXXX.OOXXOXXXOOOOXOXXOXOOOOOOOXXXOXOOOOOOOOOO'
 # turn = 0
  game = {(i//8, i%8):1 if rawgame[i] == 'X' else 0 if rawgame[i] == 'O' else -1 for i in range(64)}
  strgame = "".join(["".join([str(game[(i, j)]) for j in range(8)]) for i in range(8)])
  firstmoves, secondmoves, thirdmoves, lastmoves = allmoves(game, turn, strgame, False)
  print("Legal moves: " + str({x[0]*8+x[1] for x in set().union(firstmoves, secondmoves, thirdmoves, lastmoves)}))
  secondmoves = secondmoves - lastmoves
  thirdmoves = thirdmoves - lastmoves
  if firstmoves:
    myMove = random.choice([*firstmoves])
  elif secondmoves:
    myMove = random.choice([*secondmoves])
  elif thirdmoves:
    myMove = random.choice([*thirdmoves])
  elif lastmoves:
    myMove = random.choice([*lastmoves])
  print("\n".join(["".join([str(game[(i, j)]).replace('-1', '.').replace('1', 'X').replace('0', 'O') for j in range(8)]) for i in range(8)]))
  print("My heuristic choice is {}".format(myMove[0]*8+myMove[1]))
  if rawgame.count('.') <= depth:
    myMove = negamax(game, turn, -65, 65, strgame)
    print("Negamax returns "+str(myMove)+" and I choose move "+str(myMove[-1]))
  print("Time elapsed (seconds): "+str(time.clock()-startTime))

def placeMove(game, turn, r, c):
  newgame = {k:v for k, v in game.items()}
  opps = set()
  flips = set()
  for a in range(r+1, 8):
    if game[a, c] == turn:
      for x in opps:
        newgame[x] = turn
        flips.add(a*8+c)
      break
    if game[a, c] == turn^1:
      opps.add((a,c))
    if game[a, c] == -1:
      break

  opps = set()
  for b in range(r-1, -1, -1):
    if game[b, c] == turn:
      for x in opps:
        newgame[x] = turn
        flips.add(b*8+c)
      break
    if game[b, c] == turn ^ 1:
      opps.add((b, c))
    if game[b, c] == -1:
      break

  opps = set()
  for x in range(c + 1, 8):
    if game[r, x] == turn:
      for q in opps:
        newgame[q] = turn
        flips.add(r*8+x)
      break
    if game[r, x] == turn ^ 1:
      opps.add((r, x))
    if game[r, x] == -1:
      break

  opps = set()
  for y in range(c-1, -1, -1):
    if game[r, y] == turn:
      for q in opps:
        newgame[q] = turn
        flips.add(r*8+y)
      break
    if game[r, y] == turn ^ 1:
      opps.add((r, y))
    if game[r, y] == -1:
      break

  opps = set()
  for i in range(1, 8-max(r, c)):
    if game[r+i, c+i] == turn:
      for x in opps:
        newgame[x] = turn
        flips.add((r+i)*8+(c+i))
      break
    if game[r+i, c+i] == turn ^ 1:
      opps.add((r+i, c+i))
    if game[r+i, c+i] == -1:
      break

  opps = set()
  for j in range(1, min(r, c)+1):
    if game[r - j, c - j] == turn:
      for x in opps:
        newgame[x] = turn
        flips.add((r-j)*8+(c-j))
      break
    if game[r - j, c - j] == turn ^ 1:
      opps.add((r - j, c - j))
    if game[r - j, c - j] == -1:
      break

  opps = set()
  for k in range(1, min(8 - r, c+1)):
    if game[r + k, c - k] == turn:
      for x in opps:
        newgame[x] = turn
        flips.add((r+k)*8+(c-k))
      break
    if game[r + k, c - k] == turn ^ 1:
      opps.add((r + k, c - k))
    if game[r + k, c - k] == -1:
      break

  opps = set()
  for l in range(1, min(r+1, 8-c)):
    if game[r - l, c + l] == turn:
      for x in opps:
        newgame[x] = turn
        flips.add((r-l)*8+(c+l))
      break
    if game[r - l, c + l] == turn ^ 1:
      opps.add((r - l, c + l))
    if game[r - l, c + l] == -1:
      break

  newgame[(r, c)] = turn
  return newgame, flips

def allmoves(game, turn, rawgame, endGame):
#  global moveCache
#  mcKey = rawgame + str(turn)
#  if mcKey in moveCache: return moveCache[mcKey]
#  if (rawgame, turn) in moveCache:
#    return moveCache[(rawgame, turn)]
  legalmoves = set()
  cornermoves = set()
  goodmoves = set()
  badmoves = set()
  for key in game:
    if game[key] == turn:
      tempcorner, tempgood, templegal, tempbad = getmoves(*key, turn, game)
      cornermoves = cornermoves|tempcorner
      goodmoves = goodmoves|tempgood
      legalmoves = legalmoves|templegal
      badmoves = badmoves|tempbad
#  moveCache[(rawgame, turn)] = {*cornermoves, *goodmoves, *legalmoves, *badmoves}
  if endGame:
#    moveCache[mcKey] = {*cornermoves, *goodmoves, *legalmoves, *badmoves}
    return {*cornermoves, *goodmoves, *legalmoves, *badmoves}
#  moveCache[mcKey] = cornermoves, goodmoves, legalmoves, badmoves
  return cornermoves, goodmoves, legalmoves, badmoves

def getmoves(r, c, turn, game):
  corners = set()
  goods = set()
  legals = set()
  bads = set()
  oneOpp = False
  for a in range(r+1, 8):
    if game[a, c] == turn:
      break
    if game[a, c] == turn^1:
      oneOpp = True
    if game[a, c] == -1:
      if oneOpp:
        if a in (0, 7) and c in (0, 7):
          corners.add((a, c))
        elif a in (0, 1, 6, 7) or c in (0, 1, 6, 7):
          safeEdges(a, c, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((a, c))
      break

  oneOpp = False
  for b in range(r-1, -1, -1):
    if game[b, c] == turn:
      break
    if game[b, c] == turn ^ 1:
      oneOpp = True
    if game[b, c] == -1:
      if oneOpp:
        if (b == 0 or b == 7) and (c == 0 or c == 7):
          corners.add((b, c))
        elif b in (0, 1, 6, 7) or c in (0, 1, 6, 7):
          safeEdges(b, c, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((b, c))
      break

  oneOpp = False
  for x in range(c + 1, 8):
    if game[r, x] == turn:
      break
    if game[r, x] == turn ^ 1:
      oneOpp = True
    if game[r, x] == -1:
      if oneOpp:
        if (r == 0 or r == 7) and (x == 0 or x == 7):
          corners.add((r, x))
        elif r in (0, 1, 6, 7) or x in (0, 1, 6, 7):
          safeEdges(r, x, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((r, x))
      break

  oneOpp = False
  for y in range(c-1, -1, -1):
    if game[r, y] == turn:
      break
    if game[r, y] == turn ^ 1:
      oneOpp = True
    if game[r, y] == -1:
      if oneOpp:
        if (r == 0 or r == 7) and (y == 0 or y == 7):
          corners.add((r, y))
        elif r in (0, 1, 6, 7) or y in (0, 1, 6, 7):
          safeEdges(r, y, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((r, y))
      break

  oneOpp = False
  for i in range(1, 8-max(r, c)):
    if game[r+i, c+i] == turn:
      break
    if game[r+i, c+i] == turn ^ 1:
      oneOpp = True
    if game[r+i, c+i] == -1:
      if oneOpp:
        if (r+i == 0 or r+i == 7) and (c+i == 0 or c+i == 7):
          corners.add((r+i, c+i))
        elif r+i in (0, 1, 6, 7) or c+i in (0, 1, 6, 7):
          safeEdges(r+i, c+i, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((r+i, c+i))
      break

  oneOpp = False
  for j in range(1, min(r, c)+1):
    if game[r - j, c - j] == turn:
      break
    if game[r - j, c - j] == turn ^ 1:
      oneOpp = True
    if game[r - j, c - j] == -1:
      if oneOpp:
        if (r-j == 0 or r-j == 7) and (c-j == 0 or c-j == 7):
          corners.add((r-j, c-j))
        elif r-j in (0, 1, 6, 7) or c-j in (0, 1, 6, 7):
          safeEdges(r-j, c-j, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((r-j, c-j))
      break

  oneOpp = False
  for k in range(1, min(8 - r, c+1)):
    if game[r + k, c - k] == turn:
      break
    if game[r + k, c - k] == turn ^ 1:
      oneOpp = True
    if game[r + k, c - k] == -1:
      if oneOpp:
        if (r+k == 0 or r+k == 7) and (c-k == 0 or c-k == 7):
          corners.add((r+k, c-k))
        elif r+k in (0, 1, 6, 7) or c-k in (0, 1, 6, 7):
          safeEdges(r+k, c-k, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((r+k, c-k))
      break

  oneOpp = False
  for l in range(1, min(r+1, 8-c)):
    if game[r - l, c + l] == turn:
      break
    if game[r - l, c + l] == turn ^ 1:
      oneOpp = True
    if game[r - l, c + l] == -1:
      if oneOpp:
        if (r-l == 0 or r-l == 7) and (c+l == 0 or c+l == 7):
          corners.add((r-l, c+l))
        elif r-l in (0, 1, 6, 7) or c+l in (0, 1, 6, 7):
          safeEdges(r-l, c+l, r, c, goods, bads, legals, game, turn)
        else:
          legals.add((r-l, c+l))
      break
  return corners, goods, legals, bads

def safeEdges(x, y, r, c, goods, bads, legals, game, turn):
  if (r == 0 or r == 7) and (c == 0 or c == 7) and x not in (1, 6) and y not in (1, 6):
    goods.add((x, y))
    return
  if x in (0, 1, 6, 7) and y in (0, 1, 6, 7) and not hasNearestCorner(x, y, game, turn):
    bads.add((x, y))
  if x in (1, 6) or y in (1, 6):
    legals.add((x, y))
    return
  if x == 0 or x == 7:
    isgood = True
    for q in range(0, x):
      if game[x, q] != turn:
        bads.add((x, y))
        isgood = False
        break
    if isgood:
      goods.add((x, y))
    isgood = True
    for z in range(x + 1, 8):
      if game[x, z] != turn:
        bads.add((x, y))
        isgood = False
        break
    if isgood:
      goods.add((x, y))
  else:
    isgood = True
    for q in range(0, max(y, 4)):
      if game[q, y] != turn:
        bads.add((x, y))
        isgood = False
        break
    if isgood:
      goods.add((x, y))
    isgood = True
    for z in range(min(y + 1, 4), 8):
      if game[z, y] != turn:
        bads.add((x, y))
        isgood = False
        break
    if isgood:
      goods.add((x, y))

def hasNearestCorner(x, y, game, turn):
  if x in (0, 1) and y in (0, 1):
    return game[0, 0] == turn
  elif x in (0, 1) and y in (6, 7):
    return game[0, 7] == turn
  elif x in (6, 7) and y in (0, 1):
    return game[7, 0] == turn
  else:
    return game[7, 7] == turn

def boardEval(game, turn):
  friendly = 0
  enemy = 0
  for k,v in game.items():
    if v == turn:
      friendly += 1
    elif v == turn^1:
      enemy += 1
  return friendly-enemy

def negamax(game, turn, improvable, hardbound, rawboard):
  lm = allmoves(game, turn, rawboard, True)
  if not lm:
    lm = allmoves(game, turn^1, rawboard, True)
    if not lm: return [boardEval(game, turn), -3]
    nm = negamax(game, turn^1, -hardbound, -improvable, rawboard)+[-1]
    return [-nm[0]]+nm[1:]
  best = []
  for mv in lm:
    newgame, stradjust = placeMove(game, turn, *mv)
    rawboard = "".join([str(int(q)^1) if q in stradjust else q for q in rawboard])
    nm = negamax(newgame, turn^1, -hardbound, -improvable, rawboard)+[mv[0]*8+mv[1]]
    if not best or nm[0] < -improvable:
      best = nm
      if nm[0] < -improvable:
        improvable = -nm[0]
        if improvable >= hardbound: return [-best[0]]+best[1:]
  return [-best[0]]+best[1:]

def boardEvalmid(game, turn, lm):
  return len(lm) - len(allmoves(game, turn^1, '', True))

def maximin(game, turn, improvable, hardbound, depth):
  lm = allmoves(game, turn, '', True)
  if not depth:
    return [boardEvalmid(game, turn, lm)]
  if not lm:
    nm = maximin(game, turn ^ 1, -hardbound, -improvable, depth) + [-1]
    return [-nm[0]] + nm[1:]
  best = []
  for mv in lm:
    newgame, stradjust = placeMove(game, turn, *mv)
    nm = maximin(newgame, turn ^ 1, -hardbound, -improvable, depth-1) + [mv[0] * 8 + mv[1]]
    if not best or nm[0] < -improvable:
      best = nm
      if nm[0] < -improvable:
        improvable = -nm[0]
        if improvable >= hardbound: return [-best[0]] + best[1:]
  return [-best[0]] + best[1:]
if __name__ == '__main__':
  main()

class Strategy():
  def best_strategy(self, board, player, best_move, still_running):
    board = "".join(board)
    board = board.replace("?", "")
    rawboard = board
    board = {(i // 8, i % 8): 1 if board[i] == '@' else 0 if board[i].upper() == 'O' else -1 for i in range(64)}
    strboard = "".join(["".join([str(board[(i, j)]) for j in range(8)]) for i in range(8)])
    player = 1 if player == '@' else 0
    depth = 8
    if rawboard.count('.') <= depth:
      firstmoves, secondmoves, thirdmoves, lastmoves = allmoves(board, player, strboard, False)
      secondmoves = secondmoves - lastmoves
      thirdmoves = thirdmoves - lastmoves
      if firstmoves:
        myMove = random.choice([*firstmoves])
      elif secondmoves:
        myMove = random.choice([*secondmoves])
      elif thirdmoves:
        myMove = random.choice([*thirdmoves])
      else:
        myMove = random.choice([*lastmoves])
      best_move.value = myMove[0] * 10 + myMove[1] + 11
      myMove = negamax(board, player, -65, 65, strboard)[-1]
      best_move.value = 11+(myMove//8)*10+(myMove%8)
    else:
      depth = 1
      while(True):
        myMove = maximin(board, player, -65, 65, depth)[-1]
        best_move.value = 11+(myMove//8)*10+(myMove%8)
        depth += 1
