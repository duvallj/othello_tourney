import random
import numpy as np
#### Othello Shell
#### P. White 2016-2018
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
CORNERS = [11, 18, 81, 88]
WEIGHT_MATRIX = [0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 0, 120, -20,  20,   5,   5,  20, -20, 120,   0, 0, -20, -40,  -5,  -5,  -5,  -5, -40, -20, 0, 0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0, 0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0, 0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0, 0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0, 0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0, 0, 120, -20,  20,   5,   5,  20, -20, 120,   0, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0] # [1]*100
MAX = sum(map(abs, WEIGHT_MATRIX))
MIN = -MAX
class Node():
    def __init__(self, board, prev_move, score = 0):
        self.board = board
        self.prev_move = prev_move
        self.score = score

class Strategy():
    def __init__(self):
        pass
    #to call any of these following methods within themselves must do self.method(), not just method()!!!!!
    def get_starting_board(self):
        e = "?" * 10
        m = "?" + "." * 8 + "?"
        b = e + m * 8 + e
        b = b[:44] + "o" + "@" + b[46:54] + "@" + "o" + b[56:]
        return b
    def get_pretty_board(self, board):
        s = ""
        i = 10
        while (i <= 100):
            s += board[i-10:i]
            s += "\n"
            i += 10
        return s
    def opponent(self, player):
        opp = BLACK
        if player == BLACK:
            opp = WHITE
        return opp
    def get_next_player(self, board, player):
        n = self.opponent(player)
        if not self.has_any_valid_moves(board, n):
            n = player
            if not self.has_any_valid_moves(board, n):
                return None
        return n
    def find_match(self, board, player, square, direction):
        opp_piece = self.opponent(player)
        pos = square+direction
        while(board[pos] == opp_piece):
            pos += direction
        if pos == square + direction:
            return False
        elif board[pos] == player:
            return (square, pos)
        else:
            return False
    def is_move_valid(self, board, player, move):
        if board[move] != ".":
            return False
        ret = False
        for dir in DIRECTIONS:
            if self.find_match(board, player, move, dir) != False:
                ret =  True
                break
        return ret
    def make_move(self, b, player, move):
        board = "".join(b)
        if board[move] != ".":
            error = self.IllegalMoveError(player, move, board)
            print(error)
            return False
        endpoints = []
        for dir in DIRECTIONS:
            m = self.find_match(board, player, move, dir)
            if m is not False:
                dot, end = m
                endpoints.append((end, dir))
        if len(endpoints) < 1:
            error = self.IllegalMoveError(player, move, board)
            print(error)
            return False
        for tuplE in endpoints:
            end, dir = tuplE
            pos = move
            while (pos!=end):
                board = board[0:pos] + player + board[pos+1:]
                pos = pos+dir
        return board
    def get_valid_moves(self, board, player):
        moves = set()
        starts = [i+11 for i in range(78) if board[i+11] == "."]
        for start in starts:
            for dir in DIRECTIONS:
                match = self.find_match(board, player, start, dir)
                if match != False:
                    moves.add(match[0])
                    break
        return moves
    def has_any_valid_moves(self, board, player):
        m = self.get_valid_moves(board, player)
        return len(m) > 0
    def next_player(self, board, prev_player):
        opp = self.opponent(prev_player)
        if self.has_any_valid_moves(board, opp):
            return opp
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        else:
            return None

    def stable_disks(self, board, player):
        inds = [num for num in range(11, 89) if board[num] == player]
        stable = [n for n in inds if self.stable_test(board, n, player)]
        return stable
    def stable_test(self, board, index, player):
        half_dirs = list()
        half_dirs += [N] + [E] + [NE] + [NW]
        for dir in half_dirs:
            p = index+dir
            n = index - dir
            while board[p] == player:
                p = p + dir
            while board[n] == player:
                n = n - dir
            o = self.opponent(player)
            if board[p] == OUTER and board[n] == OUTER:
                continue
            ns = ""
            while board[n] is not OUTER:
                ns += board[n]
                n = n - dir
            ps = ""
            while board[p] is not OUTER:
                ps += board[p]
                p = p + dir
            if "." in ns and "." in ps:
                return False
        return True

    def diff_stable_score(self, board, player):
        # score = 0
        stable = len(self.stable_disks(board, player)) - len(self.stable_disks(board, self.opponent(player)))
        return stable
    def stable_score(self, board, player):
        return len(self.stable_disks(board, player))
    def weighted_score(self, board, player = BLACK):
        weights = WEIGHT_MATRIX
        board_list = list(board)
        board_list = [0 if x == "." else 0 if x == "?" else 1 if x == BLACK else -1 if x == WHITE else x for x in
                      board_list]
        a = np.array(weights)
        b = np.array(board_list)
        score = np.dot(a, b)
        return score
    def score(self, board, player=BLACK):
        blacks = [i for i in range(78) if board[i+11] == BLACK]
        whites = [i for i in range(78) if board[i+11] == WHITE]
        return len(blacks) - len(whites)
    def h_score(self, board, player = BLACK):
        x = self.stable_score(board, player)
        if x > 32:
            if player == BLACK:
                return 1000*x
            return -1000*x
        #if x == 0:
            #return self.weighted_score(board, player)
        ws = self.weighted_score(board, player)
        ms = 10*len(self.get_valid_moves(board, player)) - 10*len(self.get_valid_moves(board, self.opponent(player))) + x*10
        if player == WHITE:
            ms = -1*ms
        return ws+ms

    def get_rid_of_cornergives(self, board, player, valid_moves):
        """opencs = []
        l = []
        half_dirs = list()
        half_dirs += [N] + [E] + [NE] + [NW]
        for corner in CORNERS:
            if board[corner] == ".":
                opencs.append(corner)
        for move in valid_moves:
            add = True
            for dir in half_dirs:
                x = move + dir
                y = move - dir
                "xs = ""
                ys = ""
                while board[x] not OUTER:
                    xs += board[x]
                while board[y] not OUTER:
                    ys += board[y]
                if "
                if x in opencs or y in opencs:
                    add = False
            if add:
                l.append(move)
        return l"""
        opencorner_adjs = []
        for corner in CORNERS:
            if board[corner] == ".":
                for dir in DIRECTIONS:
                    opencorner_adjs.append(corner + dir)
        ret = [x for x in valid_moves if x not in opencorner_adjs]
        return ret

    def game_over(self, board, player):
        return self.next_player(board, player) is None
    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)
    def minmax_search(self, node, player, depth):
        board = "".join(node.board)
        if depth == 0:
            node.score = self.h_score(board)
            return node
        else:
            children = []
            valid_dot_moves = self.get_valid_moves(board, player)
            for move in valid_dot_moves:
                next_board = self.make_move(board, player, move)
                c = Node(next_board, move)
                next_player = self.get_next_player(next_board, player)
                if next_player is None:
                    score = self.h_score(next_board)
                    score = score*1000
                else:
                    n = self.minmax_search(c, next_player, depth-1)
                    score = n.score
                c.score = score
                children.append(c)
            if player == BLACK:
                winner = max(children, key = lambda c: c.score)
            else:
                winner = min(children, key = lambda child: child.score)
            """else:
                return -1#node.prev_move"""
            return winner
    def minmax_strategy(self, board, player, depth = 4):
        node = Node(board, 0)
        corner = set(CORNERS).intersection(set(self.get_valid_moves(board, player)))
        c = list(corner)
        if len(corner) == 1:
            return c[0]
        if len(c) > 1:
            return random.choice(c)
        best_child = self.minmax_alphabeta(node, player, depth, MIN, MAX)#self.minmax_search(node, player, depth)##
        return best_child.prev_move
    def minmax_alphabeta(self, node, player, depth, a, b):
        board = node.board
        if depth == 0:
            node.score = self.h_score(board, player)
            return node
        else:
            children = []
            valid_dot_moves = self.get_valid_moves(board, player)
            non_cornergive_valid = self.get_rid_of_cornergives(board, player, valid_dot_moves)
            moves = valid_dot_moves
            if len(non_cornergive_valid) > 0:
                moves = non_cornergive_valid
            for move in moves:
                next_board = self.make_move(board, player, move)
                c = Node(list(next_board), move)
                next_player = self.get_next_player(next_board, player)
                if next_player is None:
                    score = self.score(next_board)
                    score = score * 1000
                else:
                    n = self.minmax_alphabeta(c, next_player, depth - 1, a, b)
                    score = n.score
                c.score = score
                children.append(c)
                if player == BLACK:
                    a = max(a, c.score)
                else:
                    b = min(b, c.score)
                if a >= b:
                    break
            if player == BLACK:
                winner = max(children, key=lambda c: c.score)
            else:
                winner = min(children, key=lambda child: child.score)
            return winner

    def random_strategy(self, board, player):
        s = self.get_valid_moves(board, player)
        l = list(s)
        return random.choice(l)

    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        while (True):
            best_move.value = self.minmax_strategy(board, player)
            depth += 1

    standard_strategy = minmax_strategy


import time
from multiprocessing import Value, Process
import os, signal

silent = False


class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.random_strategy}
        print(ref.get_pretty_board(board))
        while player is not None:
            move = strategy[player](board, player)
            # if playing a HUMAN and dont trust what move was returned, here is where to check is_move_valid!!!!!!!!!! IF PLAYING HUMAN
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            t1 = time.time()
            p.start()
            p.join(self.time_limit)
            running.value = 0
            time.sleep(0.01)
            p.terminate()
            time.sleep(0.01)
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    game = StandardPlayer()
    game.play()
