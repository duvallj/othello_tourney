import sys
corners = {0,7,63,56}
center = {18,19,20,21,26,27,28,29,34,35,36,37,42,43,44,45}
class Strategy:
    def best_strategy(self,board,player,best_move,still_running):
        playerToToken = {'@': 'x', 'o': 'o'}
        board = ''.join(board)
        board = "".join([board[i:i+8] for i in range(11,91,10)])
        board = board.replace('@','x')
        token = playerToToken[player]
        depth = 13
        asd = findMoves(board, token)
        # print(board)
        # print(token)
        # print(asd)
        mv = goodMove(board, asd, token)
        # print(mv)
        myMove = 11 + (int(mv) // 8) * 10 + (int(mv) % 8)
        best_move.value = myMove
        while(True):
        # if board.count('.') < depth:
            mv = negamaxTerminal(board,token,-65,65)[-1]
            myMove = 11+(mv//8)*10+(mv%8)
            best_move.value = myMove


    # def main():
#     board = "...........................ox......xo..........................."
#     try:
#         board = sys.argv[1].lower()
#         turn = curTurn(board)
#         if len(sys.argv) > 2:
#             turn = sys.argv[2].lower()
#         # a = findMoves(board, turn)
#         # print(a)
#         print(negamax(board,turn,5)[-1])
#     except IndexError:
#         # findMoves(board,'x')
#         turn = 'x'
#         print(negamax(board,turn,2)[-1])
#
#         # board = changeBoard(board, possmoves)
#         # printb(board)
import sys
import time

# corners = {0, 7, 63, 56}
turns = {'x':'o','o':'x'}

def main():
    asdf = 13
    board = "...........................ox......xo..........................."
    try:
        board = sys.argv[1].lower()
        turn = curTurn(board)
        if len(sys.argv) > 2:
            turn = sys.argv[2].lower()
        # if board.count('.') <=asdf:
        # while '.' in board:
        printb(board)
        # print('Possible Moves: ' + ''.join(str(findMoves(board, turn))))
        # print("My heuristic move is: ", end="")
        asd = findMoves(board, turn)
        print(goodMove(board, asd, turn))
        if board.count('.') <= asdf:
            a = negamaxTerminal(board, turn, -65,65)
        # print("Negamax: " + ''.join(str(a)) + " and my move is: " + str(a[-1]))
            print(str(a[-1]))
    except IndexError:
        a = findMoves(board, 'x')
        goodMove(board, a, 'x')
        # board = changeBoard(board, possmoves)
        # printb(board)


def curTurn(board):
    return ['x', 'o'][len([1 for x in range(64) if board[x] == '.']) % 2]


def printb(board):
    print('\n'.join([''.join(board[n * 8:n * 8 + 8]) for n in range(8)]))


def checkEdge(board, count, ind, turn):
    # board = boardcheck(board, ind, turn)
    safe = True
    while True:
        ind += count
        if ind // 8 < 0 or ind // 8 > 7 or ind < 0 or ind > 63:
            break
        elif board[ind] != turn:
            safe = False
            break
    if safe:
        return True
    return False


def goodMove(board, possMoves, turn):
    goodmoves = set()
    ogmoves = set()
    worstmoves = set()
    okmoves = set()
    badmoves = set()
    for x in possMoves:
        if x in corners:
            return x
        if x // 8 == 0 or x // 8 == 7:
            nb = boardcheck(board, x, turn)
            if checkEdge(nb, -1, x, turn) or checkEdge(nb, 1, x, turn):
                goodmoves.add(x)
                continue
                # return x
            elif x in {1, 6, 57, 62}:
                worstmoves.add(x)
                continue
            else:
                badmoves.add(x)
                continue
        elif x % 8 == 0 or x % 8 == 7:
            nb = boardcheck(board, x, turn)
            if checkEdge(nb, 8, x, turn) or checkEdge(nb, -8, x, turn):
                goodmoves.add(x)
                continue
                # return x
            elif x in {8, 48, 15, 55}:
                worstmoves.add(x)
                continue
            else:
                badmoves.add(x)
                continue
        if goodmoves:
            bestgoodmove = []
            for x in list(goodmoves):
                a = len(findMoves(boardcheck(board, x, turn), turns[turn]))
                bestgoodmove.append((a, x))
            bestgoodmove = sorted(bestgoodmove)
            return bestgoodmove[0][1]
            # return goodmoves.pop()
        else:
            if board[0] == turn and x == 9:
                # return x
                okmoves.add(x)
                continue
            elif board[7] == turn and x == 14:
                okmoves.add(x)
                continue
                # return x
            elif board[56] == turn and x == 49:
                okmoves.add(x)
                continue
                # return x
            elif board[63] == turn and x == 54:
                # return x
                okmoves.add(x)
                continue
            elif x in (9, 14, 49, 54):
                worstmoves.add(x)
                continue
            else:
                # return x
                if x in center:
                    ogmoves.add(x)
                    continue
                else:
                    okmoves.add(x)
                    continue
    if ogmoves:
        bestogmove = []
        for x in list(ogmoves):
            a = len(findMoves(boardcheck(board, x, turn), turns[turn]))
            bestogmove.append((a, x))
        bestogmove = sorted(bestogmove)
        return bestogmove[0][1]
    if okmoves:
        bestokmove = []
        for x in list(okmoves):
            a = len(findMoves(boardcheck(board,x,turn),turns[turn]))
            bestokmove.append((a,x))
        bestokmove = sorted(bestokmove)
        return bestokmove[0][1]
    if badmoves:
        bestbadmove = []
        for x in list(badmoves):
            a = len(findMoves(boardcheck(board, x, turn), turns[turn]))
            bestbadmove.append((a, x))
        bestbadmove = sorted(bestbadmove)
        return bestbadmove[0][1]
        # return badmoves.pop()
    if worstmoves:
        bestwmove = []
        for x in list(worstmoves):
            a = len(findMoves(boardcheck(board, x, turn), turns[turn]))
            bestwmove.append((a, x))
        bestwmove = sorted(bestwmove)
        return bestwmove[0][1]
        # return worstmoves.pop()


def findMoves(board, turn):
    neigh = set()
    for x in range(len(board)):
        if board[x] == '.':
            # test = board[0:x] + turn + board[x+1:]
            # bb = boardc(board,x,turn)
            # if test != bb:
            if boardc(board,x,turn):
                neigh.add(x)
    return list(neigh)
def boardc(board,ina,turn):
    lis = [-7, -8, -9, -1, 1, 7, 8, 9]
    ind = int(ina)
    changemove = []
    if ind // 8 == 0 or ind // 8 == 1:
        lis = [i for i in lis if i > 0 or i == -1]
    if ind % 8 == 7 or ind % 8 == 6:
        lis = [i for i in lis if i not in {-7, 1, 9}]
    if ind % 8 == 0 or ind % 8 == 1:
        lis = [i for i in lis if i not in {-9, -1, 7}]
    if ind // 8 == 7 or ind // 8 == 6:
        lis = [i for i in lis if i < 0 or i == 1]
    for i in lis:
        # temp = set()
        if board[ind + i] in {turn, '.', '*'}:
            continue
        else:
            line = ind // 8
            count = 1
            aa = True
            asdf = True
            while asdf and aa:
                place = ind + i * count
                if (place < 0) or (place > 63) or (line != ((place) // 8) and i in {-1, 1}):
                    aa = False
                    continue
                aas = board[place]
                if ((place % 8 == 0 and i in {-9, 7}) and aas != turn) or (
                    (place % 8 == 7 and i in {9, -7}) and aas != turn):
                    aa = False
                    continue
                elif aas in {'.', '*'}:
                    aa = False
                    continue
                elif aas == turn:
                    return True
                    # asdf = False
                    # for x in list(temp):
                    #     board = board[:x] + turn + board[x + 1:]
                    # continue
                else:
                    # temp.add(place)
                    count += 1
    return False
def boardcheck(board, ina, turn):
    lis = [-7, -8, -9, -1, 1, 7, 8, 9]
    ind = int(ina)
    changemove = []
    if ind // 8 == 0 or ind // 8 == 1:
        lis = [i for i in lis if i > 0 or i == -1]
    if ind % 8 == 7 or ind % 8 == 6:
        lis = [i for i in lis if i not in {-7, 1, 9}]
    if ind % 8 == 0 or ind % 8 == 1:
        lis = [i for i in lis if i not in {-9, -1, 7}]
    if ind // 8 == 7 or ind // 8 == 6:
        lis = [i for i in lis if i < 0 or i == 1]
    for i in lis:
        temp = set()
        line = ind // 8
        if board[ind + i] in {turn, '.', '*'}:
            continue
        else:
            count = 1
            aa = True
            asdf = True
            while asdf and aa:
                place = ind + i * count
                if (place < 0) or (place > 63) or (line != ((place) // 8) and i in {-1, 1}):
                    aa = False
                    continue
                aas = board[place]
                if ((place % 8 == 0 and i in {-9, 7}) and aas != turn) or ((place % 8 == 7 and i in {9, -7})and aas != turn):
                    aa = False
                    continue
                elif aas in {'.', '*'}:
                    aa = False
                    continue
                elif aas == turn:
                    asdf = False
                    for x in list(temp):
                        board = board[:x] + turn + board[x + 1:]
                    continue
                else:
                    temp.add(place)
                    count += 1
    board = board[:ind] + turn + board[ind + 1:]
    return board

def findscore(board, turn):
    player = board.count(turn)
    opp = board.count(turns[turn])
    return player - opp


def count(board):
    a = 0
    for i in board:
        if i == 'o':
            a += 1
    return a

def negamaxTerminal(board, token, improvable, hardBound):
    lm = findMoves(board,token)
    if(not lm):
        lm = findMoves(board, turns[token])
        if(not lm):
            return [findscore(board,token), -3]
        nm = negamaxTerminal(board, turns[token], -hardBound, -improvable)+[-1]
        return [-nm[0]]+nm[1:]
    best = [] #what gets returned
    newHB = -improvable
    for mv in lm:
        # print(lm)
        nm = negamaxTerminal(boardcheck(board,mv, token), turns[token], -hardBound, newHB)+[mv]
        # print(nm)
        if not best or nm[0] < newHB: #less than b/c negative
            best = nm
            if(nm[0] < newHB):
                newHB = nm[0]
                if(-newHB > hardBound):
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]

if __name__ == "__main__":
    main()