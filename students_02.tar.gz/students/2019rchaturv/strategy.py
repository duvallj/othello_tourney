import sys,random
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = "".join(board).replace("?","").replace("@","X").upper()
        token ="X" if player == "@" else "O"
        Otoken = "X" if token == "O" else "O"
        lm = legalMoves(brd, token, Otoken)
        if brd.count(".")<10:
             mv2 = findBestMove(brd,token)
             best_move.value = (11 + (mv2[-1]//8)*10+ (mv2[-1]%8))
        else:
            mv = nextMove(list(brd), list(lm), token, Otoken)
            if mv==-1:
                t=[]
                for x in lm:
                    t.append(x)
                best_move.value = random.choice(t)
                mv3 = mobility(brd,lm,token,Otoken)
                best_move.value= (11 + (mv3//8)*10+ (mv3%8))
            mv1= 11 + (mv//8)*10+ (mv%8)
            best_move.value = mv1
            mv2 = findBestMove(brd,token)
            best_move.value = (11 + (mv2[-1]//8)*10+ (mv2[-1]%8))
def mobility(board,moves,token,Otoken ):
    mini, mov =64, ""
    for x in moves:
        bd = str(board)
        tp = legalMoves(makeMove(bd,token, x, moves),token,Otoken)
        if len(tp)<mini:
            mini=len(tp)
            mov = x
    return mov
def nextMove(boards,lists, tokens, Otokens):
    corners = [0,7,56,63]
    edges = [[0,1,2,3,4,5,6,7],[0,8,16,24,32,40,48,56],[7,15,23,31,39,47,55,63],[56,57,58,59,60,61,62,63]]
    dicts = {0: [0,1], 7:[0,2], 56:[1,3], 63 : [2,3]}
    ret = list(set(lists).intersection(corners))
    if ret: return random.choice(ret)
    boolen =[]
    for x in corners:
        if boards[x] == tokens: boolen.append(x)
    if boolen:
        for x in range(len(boolen)):
            for y in dicts[boolen[x]]:
                for z in edges[y]:
                    boolin = True
                    if z in lists:
                        maxi = maxer(z, boolen[x])
                        #print(maxi[0], maxi[1])
                        for a in range(maxi[0], maxi[1]):
                            if not(boards[a] == tokens or boards[a] == Otokens):
                                boolin = False
                                #print(z, "Y")
                                break
                        if boolin: return z
    diction = {0: [1,8,9], 7:[6,14,15], 56 : [48,49,57], 63 :[54,55,62]}
    bad, good = [1,8,9,6,14,15,48,49,57,54,55,62], []
    for x in boolen:
        for y in diction[0]:
            good.append(y)
    temp = []
    for x in lists:
        if x in good:
            temp.append(x)
        if not x in bad:
            temp.append(x)
    fret = []
    for x in temp:
        dec = True
        for y in range(4):
            if x in edges[y]:
                dec = False
                #break
        if dec: fret.append(x)
    if fret: return random.choice(fret)
    if temp: return random.choice(temp)
    fret =[]
    for x in lists:
        dec = True
        for y in range(4):
            if x in edges[y]:
                dec = False
                #break
        if dec: fret.append(x)
    if fret: return random.choice(fret)
    return -1
def findBestMove(board,token):
    l = negaMaxTerminal(board,token,-65,65)
    return l
def printB(pzl):
    [print(pzl[x],"\n") if x % 8  == 7 else print(pzl[x]," ", end = "")for x in range(64)]
def evaluateBoard(board,token):
    if token == "X": Otoken = "O"
    else: Otoken = "X"
    countO,countT =board.count(Otoken), board.count(token)
    return countT-countO
def legalMoves(brd, token, Otoken):
        if (brd + token) in dicty:
            return dicty[brd + token]
        nums ={}
        possible = {0:[9,1,-7,8,-8], 1: [-1,1,-7,7,-8,8,-9,9], 2:[-1,1,-7,7,-8,8,-9,9], 3:[-1,1,-7,7,-8,8,-9,9],
        4:[-1,1,-7,7,-8,8,-9,9], 5:[-1,1,-7,7,-8,8,-9,9], 6:[-1,1,-7,7,-8,8,-9,9], 7:[-9,-1,7,8,-8]}
        for y in range(64):
            if brd[y] == token:
                for x in possible[y%8]:
                    net = set()
                    temp = recur(y,x, brd, Otoken, net)
                    if temp>-1:
                        if not temp in nums:
                            nums[temp]= net
                        else :
                            for w in net:
                                nums[temp].add(w)
        dicty[brd + token] = nums
        return nums
def makeMove(board, token,poss, dic):
    #brd = list(board)
    nb = board
    for x in dic[poss]:
        nb = nb[:x] + token + nb[x+1:]
        #brd[x] = token
    return nb
def recur(pos, scal, board, Otoken,setT):
    possible = {0:[9,1,-7,8,-8], 1: [-1,1,-7,7,-8,8,-9,9], 2:[-1,1,-7,7,-8,8,-9,9], 3:[-1,1,-7,7,-8,8,-9,9],
    4:[-1,1,-7,7,-8,8,-9,9], 5:[-1,1,-7,7,-8,8,-9,9], 6:[-1,1,-7,7,-8,8,-9,9], 7:[-9,-1,7,8,-8]}
    if pos <0 or pos > 63 or pos+scal < 0 or pos+scal> 63 or not (scal in possible[pos%8]):
        return -1
    if board[pos] == Otoken and board[pos+scal] == ".":
        #print(pos + scal, "W")
        setT.add(pos+scal)
        return pos+scal
    if board[pos + scal] == Otoken:
        #print(pos+scal, "Y")
        setT.add(pos+scal)
        return recur(pos + scal, scal, board, Otoken, setT)
    else:
        return -1
def maxer(i1,i2):
    if i1> i2: return [i2,i1]
    else: return [i1+1,i2]
def negaMaxTerminal(brd, token, improvable, hardbound):
    enemy = "X" if token == "O" else "O"
    lm = legalMoves(brd,token, enemy)
    if not lm:
        lm1 = legalMoves(brd,enemy, token)
        if not lm1: return [evaluateBoard(brd,token),-3]
        nm = negaMaxTerminal(brd,enemy,-hardbound,-improvable) +[-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in lm:
        nm = negaMaxTerminal(makeMove(brd,token,mv,lm), enemy, -hardbound, newHB) +[mv]
        if not best or nm[0]< newHB:
            best = nm
            if nm[0]< newHB:
                newHB = nm[0]
                if -newHB> hardbound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
dicty={}
def main():
    brd, token = sys.argv[1].upper(), sys.argv[2].upper()
    Otoken = "X" if token == "O" else "O"
    p,t = legalMoves(brd, token, Otoken), []
    for x in p:
        t.append(x)
    print(random.choice(t))
    if brd.count(".")<9:
         mv2 = findBestMove(brd,token)
         print(mv2)
    else:
        mv = nextMove(list(brd), t, token, Otoken)
        if mv==-1:
            c=[]
            for x in p:
                c.append(x)
            print(random.choice(t))
            mv3 = mobility(brd,p,token,Otoken)
            print(mv3)
        print(mv)
        #mv2 = findBestMove(brd,token)
        #best_move.value = (11 + (mv2[-1]//8)*10+ (mv2[-1]%8))
# def main():
#     board, token = sys.argv[1].upper(), sys.argv[2].upper()
#     #print(board + token)
#     printB(board)
#     Otoken = "O" if token == "X" else "X"
#     p,t = legalMoves(board,token,Otoken), []
#     for x in p:
#         t.append(x)
#     print("Legal Possible Moves ", t)
#     if p:
#         print("My Heuristic Move is: " , nextMove(list(board), p, token, Otoken))
#     if board.count(".")<9:
#         m = findBestMove(board,token)
#         if m:
#             print("MiniMax ", m[0]," and my score is ", m[1:])

if __name__ == "__main__":
    main()
