import sys,random
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = list("".join().replace("?","").replace("@","X"))
        token ="X" if player == "@" else "O"
        mv = findBestMove(brd,token)
        mv1= 11 + (mv//8)*10+ (mv%8)
        best_move.value = mv1
def maxer(i1,i2):
    if i1> i2: return [i2,i1]
    else: return [i1+1,i2]

def nextMove(boards,lists, tokens, Otokens):
    corners = [0,7,56,63]
    edges = [[0,1,2,3,4,5,6,7],[0,8,16,24,32,40,48,56],[7,15,23,31,39,47,55,63],[56,57,58,59,60,61,62,63]]
    dicts = {0: [0,1], 7:[0,2], 56:[1,3], 63 : [2,3]}
    ret = list(set(lists).intersection(corners))
    if ret: return random.choice(ret)
    boolen =[]
    for x in corners:
        if boards[x] == tokens: boolen.append(x)
    if boolen:
        for x in range(len(boolen)):
            for y in dicts[boolen[x]]:
                for z in edges[y]:
                    boolin = True
                    if z in lists:
                        maxi = maxer(z, boolen[x])
                        #print(maxi[0], maxi[1])
                        for a in range(maxi[0], maxi[1]):
                            if not(boards[a] == tokens or boards[a] == Otokens):
                                boolin = False
                                #print(z, "Y")
                                break
                        if boolin: return z
    diction = {0: [1,8,9], 7:[6,14,15], 56 : [48,49,57], 63 :[54,55,62]}
    bad, good = [1,8,9,6,14,15,48,49,57,54,55,62], []
    for x in boolen:
        for y in diction[x]:
            good.append(y)
    temp = []
    for x in lists:
        if x in good:
            temp.append(x)
        if not x in bad:
            temp.append(x)
    fret = []
    for x in temp:
        dec = True
        for y in range(4):
            if x in edges[y]:
                dec = False
                #break
        if dec: fret.append(x)
    if fret: return random.choice(fret)
    if temp: return random.choice(temp)
    for x in lists:
        for y in diction[x]:
            fret.append(y)
    if fret: return random.choice(fret)
    fret =[]
    for x in lists:
        dec = True
        for y in range(4):
            if x in edges[y]:
                dec = False
                #break
        if dec: fret.append(x)
    if fret: return random.choice(fret)
    return random.choice(lists)
def printB(pzl):
    [print(pzl[x],"\n") if x % 8  == 7 else print(pzl[x]," ", end = "")for x in range(64)]
def evaluateBoard(board, token):
    Otoken = "O" if token == "X" else "X"
    return board.count(token) - board.count(Otoken)
def recur(board,pos, scal, Otoken):
    possible = {0:[9,1,-7,8,-8], 1: [-1,1,-7,7,-8,8,-9,9], 2:[-1,1,-7,7,-8,8,-9,9], 3:[-1,1,-7,7,-8,8,-9,9],
    4:[-1,1,-7,7,-8,8,-9,9], 5:[-1,1,-7,7,-8,8,-9,9], 6:[-1,1,-7,7,-8,8,-9,9], 7:[-9,-1,7,8,-8]}
    #print(board[18])
    if pos <0 or pos > 63 or pos+scal < 0 or pos+scal> 63 or not (scal in possible[pos%8]):
        return -1
    if board[pos] == Otoken and board[pos+scal] == ".":
        #print(pos+scal, "X")
        return pos+scal
    if board[pos + scal] == Otoken:
        #print(pos+scal, "y")
        return recur(board,pos + scal, scal, Otoken)
    else:
        #print(pos+scal, "L")
        return -1
def legalMoves(board, token, Otoken):
    possible = {0:[9,1,-7,8,-8], 1: [-1,1,-7,7,-8,8,-9,9], 2:[-1,1,-7,7,-8,8,-9,9], 3:[-1,1,-7,7,-8,8,-9,9],
    4:[-1,1,-7,7,-8,8,-9,9], 5:[-1,1,-7,7,-8,8,-9,9], 6:[-1,1,-7,7,-8,8,-9,9], 7:[-9,-1,7,8,-8]}
    nums=set()
    for y in range(64):
        if board[y] == token:
            for x in possible[y%8]:
                temp = recur(board,y,x, Otoken)
                if temp>-1:
                    nums.add(temp)
    return nums
def recurP(board,pos, scal,token, Otoken):
    possible = {0:[9,1,-7,8,-8], 1: [-1,1,-7,7,-8,8,-9,9], 2:[-1,1,-7,7,-8,8,-9,9], 3:[-1,1,-7,7,-8,8,-9,9],
    4:[-1,1,-7,7,-8,8,-9,9], 5:[-1,1,-7,7,-8,8,-9,9], 6:[-1,1,-7,7,-8,8,-9,9], 7:[-9,-1,7,8,-8]}
    if pos <0 or pos > 63 or pos+scal < 0 or pos+scal> 63 or not (scal in possible[pos%8]):
        return -1
    if board[pos] == Otoken and board[pos+scal] == token:
        #print(pos+scal, "X")
        return pos+scal
    if board[pos + scal] == Otoken:
        #print(pos+scal, "y")
        return recurP(board,pos + scal, scal, token, Otoken)
    else:
        #print(pos+scal, "L")
        return -1
def makeMove(board, token, Otoken,poss):
    board1 = list(board)
    board1[poss] = token
    possible = {0:[9,1,-7,8,-8], 1: [-1,1,-7,7,-8,8,-9,9], 2:[-1,1,-7,7,-8,8,-9,9], 3:[-1,1,-7,7,-8,8,-9,9],
    4:[-1,1,-7,7,-8,8,-9,9], 5:[-1,1,-7,7,-8,8,-9,9], 6:[-1,1,-7,7,-8,8,-9,9], 7:[-9,-1,7,8,-8]}
    for x in possible[poss%8]:
        temp = recurP(board1,poss,x, token, Otoken)
        if temp>-1:
            if poss> temp:
                maxi,mini = poss+x, temp
            else:
                maxi,mini = temp, poss+x
            for x in range(mini,maxi+1,abs(x)):
                board1[x] = token

    return board1
def negMax(board, token, Otoken,levels):
    if not levels:
        return [evaluateBoard(board,token)]
    lm, lm1 = legalMoves(board, token, Otoken), legalMoves(board,Otoken, token)
    if not lm and not lm1:
        return [evaluateBoard(board, token)]
    if not lm:
        nm = negMax(board, Otoken, token, levels) +[-1]
        return [-nm[0]] + nm[1:]
    best = sorted([negMax(makeMove(board, token, Otoken, mv), Otoken, token, levels-1) + [mv] for mv in lm])[0]
    return [-best[0]] + best[1:]
def findBestMove(board,token):
    count = board.count(".")
    Otoken = "O" if token == "X" else "X"
    p = legalMoves(board,token,Otoken)
    print(nextMove(board,p, token, Otoken))
    l = negMax(board,token,Otoken,-1)
    print(l[-1])



def main():
    board, token = list(sys.argv[1].upper()), sys.argv[2].upper()
    printB(board)
    Otoken = "O" if token == "X" else "X"
    p = legalMoves(board,token,Otoken)
    print("Legal Possible Moves ", p)
    if p:
        print("My Heuristic Move is: ", nextMove(board, p, token, Otoken))
    l = negMax(board,token,Otoken,-1)
    print("MiniMax ", l[0]," and my score is ", l[1:])

if __name__ == "__main__":
    main()
