import random,time,sys
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):

        brd = "".join(board).replace('?',"").replace('@','x')
        if player=='@': token = 'x'
        else: token = 'o'

        mv = findBestMove(brd, player)
        print("beforeswitch" + str(mv))
        mv1 = 11 + (mv // 8) * 10 + (mv % 8)
        print("final" + str(mv1))
        best_move.value=mv1

    def best_strategytwo(self, board, player):
        brd = "".join(board).replace('?', "").replace('@', 'x')
        if player == '@':
            token = 'x'
        else:
            token = 'o'

        mv = findBestMove(brd, player)
        print("beforeswitch" + str(mv))
        mv1 = 11 + (mv // 8) * 10 + (mv % 8)
        print("final" + str(mv1))
        return mv1

def findBestMove(table,token):
    if len([i for i, letter in enumerate(table) if letter == "."]) > 8:
        moves = possibleMoves(token, table)

        if len(moves)>0:
            for x in [0, 7, 56, 63]:
                if x in moves:
                    return x


            for corner in [(0,[1,8]),(7,[-1,8]),(56,[-8,1]),(63,[-8,-1])]:
                if table[corner[0]]==token:
                    for direction in corner[1]:
                        endSafe = corner[0]+direction
                        while 0<=endSafe+direction<=63 and table[endSafe]==token:
                            endSafe+=direction
                        endOppo =endSafe
                        while 0<=endOppo+direction<=63 and table[endOppo] ==oppToken(token):
                            endOppo+=direction
                        if endOppo in moves:
                            return endOppo
            tempMoves = moves[:]
            outSideMid = moves[:]
            for move in moves:
                if move%8==0 or move%8==7:
                    for direction in [-8,8]:
                        pointer = move+direction
                        while 0<=pointer+direction<=63 and table[pointer]==token:
                            if pointer in [0,7,56,63]:
                                return move
                            else:pointer+=direction
                    if table[move+8]==oppToken(token) and table[move-8]==oppToken(token):
                        return move
                elif int(move/8)==0 or int(move/8)==7:
                    for direction in [-1,1]:
                        pointer = move+direction
                        while 0<=pointer+direction<63 and table[pointer]==token:
                            if pointer in [0,7,56,63]:
                                return move
                            else:pointer+=direction
                    if table[move + 1] == oppToken(token) and table[move - 1] == oppToken(token):
                        return move

                if (move in [1,9,8] and table[0]!=token) or (move in [6,14,15] and table[7]!=token) or (move in [48,49,57] and table[56]!=token) or (move in [55,54,62] and table[63]!=token):
                    tempMoves.remove(move)
                if 2>move%8>5 or 2>int(move/8)>5:
                    outSideMid.remove(move)
                    # elif temp%8==0 or temp%8==7 or int(temp/8)==0 or int(temp/8)==7:
                    #    tempMoves.remove(temp)
            if len(outSideMid) >0: return random.choice(outSideMid)
            if len(tempMoves) > 0: return random.choice(tempMoves)
            else:
                rand = random.choice(moves)
                if rand in moves:
                    return rand
    else:
        currentLevel = 9
        mv = negamax(table, token, currentLevel)
        return mv[-1]


def move(index, token, board):
    if index in possibleMoves(token, board):
        if token == 'x':
            opptoken = 'o'
        else:
            opptoken = 'x'
        copyBoard = list(board)
        # left,right,up,down,diagupleft,diagupright,diagdownleft,diagdownright = index-1,index+1,index-8,index+8,index-9,index-7,index+7,index+9
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]
        switchedPositions = [index]
        for x in directions:
            tempObj = index + x
            positionsPassed = []
            while 63 >= (tempObj + x) >= 0 and board[tempObj] == opptoken:
                if x == 1 or x == -1:
                    if int((tempObj + x) / 8) != int(index / 8):
                        break
                if x == 7 or x == -9:
                    if tempObj % 8 == 0 or index % 8 == 0:
                        break
                if x == 9 or x == -7:
                    if tempObj % 8 == 7 or index % 8 == 7:
                        break
                positionsPassed.append(tempObj)
                tempObj += x
            if len(positionsPassed) > 0 and board[tempObj] == token:

                for z in positionsPassed:
                    switchedPositions.append(z)
        # print(switchedPositions)
        for pos in switchedPositions:
            copyBoard[pos] = token
        finalBoard = "".join(copyBoard)
        # printBoardShort(finalBoard)
        return finalBoard
    return board
def evalBoard(board, token):
    if token=='x': opptoken = 'o'
    else: opptoken='x'
    num = len([i for i, letter in enumerate(board) if letter == token])-len([a for a, letter in enumerate(board) if letter == opptoken])
    return num
def oppToken(token):
    if token=='x':return 'o'
    return 'x'
def negamax(board, token, levels):

        if not levels: return [evalBoard(board, token)]
        lm = possibleMoves(token,board)
        if not lm:
            mm = negamax(board, oppToken(token), levels - 1) + [1]
            return [-mm[0]] + mm[1:]
        else:
            nmList = sorted([negamax(move(mv,token,board), oppToken(token), levels - 1) + [mv] for mv in lm])
            best = nmList[0]
            return [-best[0]] + best[1:]

    # preferred  # of levels: 3
# Test with only 1 level




def possibleMoves(token,board):
    if token == 'x':
        opptoken = 'o'
    else:
        opptoken = 'x'
    poss = set()
    for index in [i for i, letter in enumerate(board) if letter == "."]:


        # left,right,up,down,diagupleft,diagupright,diagdownleft,diagdownright = index-1,index+1,index-8,index+8,index-9,index-7,index+7,index+9
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]

        for x in directions:
            tempObj = index + x

            while 63 >= (tempObj + x) >= 0:
                if board[tempObj] == opptoken:
                    if x == 1 or x == -1:
                        if int((tempObj + x) / 8) != int(index / 8):
                            break
                    if x == 7 or x == -9:
                        if tempObj % 8 == 0 or index % 8 == 0:
                            break
                    if x == 9 or x == -7:
                        if tempObj % 8 == 7 or index % 8 == 7:
                            break
                    tempObj += x
                else: break
            if 63 >= (tempObj) >= 0 and board[tempObj] == token and tempObj!=index+x:
                poss.add(index)
                print(index)
        # print(switchedPositions)


    return list(poss)
def main():

    if len(sys.argv) == 1:
        board = "...........................ox......xo..........................."
        if len([i for i, letter in enumerate(board) if letter == "."]) % 2 == 0:
            token = 'x'
        else:
            token = 'o'

    elif len(sys.argv) == 2:
        board = sys.argv[1].lower()
        if len([i for i, letter in enumerate(board) if letter == "."]) % 2 == 0:
            token = 'x'
        else:
            token = 'o'
    else:
        token,board = sys.argv[1].lower(), sys.argv[2].lower()
    if token == '@':
        player = 'x'
    else:
        player = 'o'
    brd = "".join(board).replace('?', "").replace('@', 'x')

    print(brd)
    print(possibleMoves(player,brd))
    s= Strategy()
    print("retfromstrategy"+str(s.best_strategytwo(brd,player)))

    mv = findBestMove(brd, player)
    print("beforeswitch"+str(mv))
    mv1 = 11 + (mv // 8) * 10 + (mv % 8)
    print("final"+str(mv1))
    return mv1



if __name__=='__main__':
    main()

