# Arya Kumar, Gabor Pd. 3
# This contains all of the code required for bitwise
# manipulations of the board. Utilizes Vectorized Move Ordering,
# BitBoards, NegaScout for search, memoization, pattern based eval,
# and kindergarden bitboard manipulations.

# The links I used for reference:
#     https://chessprogramming.wikispaces.com/Flipping+Mirroring+and+Rotating
#     https://chessprogramming.wikispaces.com/Kindergarten+Bitboards
#     http://drpetric.blogspot.sg/2013/09/bit-gathering-via-multiplication.html

import sys # Used in main strategy class
from functools import reduce
from lookups import * # Large lookups
from patterns import * # Evaluation patterns
from obook import openingBook # Used in main strategy class

## LOOKUPS ##
revBits8 = [int(bin((256)|x)[-1:2:-1], 2) for x in range(256)] # Reversed 8 bits
stages = [0]*13 + [1]*4 + [2]*4 + [3]*4 + [4]*4 + [5]*4 + [6]*4 + [7]*4 + [8]*4 + [9]*4 + [10]*4 + [11]*4 + [12]*3 # move number -> pattern stage

## GENERATORS + DECORATORS ##
# chunkify([1, 2, 3, 4, 5, 6], 2) -> genexp([1, 2], [3, 4], [5, 6])
def chunkify(iterable, chunksize):
    for i in range(0, len(iterable), chunksize):
        yield iterable[i:i+chunksize]

# Decorator to memoize edge stability
def memoize(func):
    class memoizeDict(dict):
        def __missing__(self, key):
            toRet = self[key] = func(key)
            return toRet
    return memoizeDict().__getitem__

## Utility Functions ##
# Converts 8x8 stringboard to bitboard
def makeBitBoard(board, playerColor):
    opponentColor = {"X":"O","O":"X","@":"o","o":"@"}[playerColor]
    return reduce(lambda m,n:m*2+(n==playerColor),board,0), reduce(lambda m,n:m*2+(n==opponentColor),board,0)

## SYMMETRY FUNCTIONS ##
# This is all the code used for the opening book.
# Not so worried about performance because this only gets run once
# The board is formatted as <64 bit player> + <64 off bits> + <64 bits opponent>
# Numbers were found from the kindergartden bitboards link

def horiMirror(b):
    b =    ((b >> 1) & 0x555555555555555500000000000000005555555555555555) | ((b << 1) & 0xAAAAAAAAAAAAAAAA0000000000000000AAAAAAAAAAAAAAAA)
    b =    ((b >> 2) & 0x333333333333333300000000000000003333333333333333) | ((b << 2) & 0xCCCCCCCCCCCCCCCC0000000000000000CCCCCCCCCCCCCCCC)
    return ((b >> 4) & 0x0F0F0F0F0F0F0F0F00000000000000000F0F0F0F0F0F0F0F) | ((b << 4) & 0xF0F0F0F0F0F0F0F00000000000000000F0F0F0F0F0F0F0F0)

def vertMirror(b):
    b =    ((b >>  8) & 0x00FF00FF00FF00FF000000000000000000FF00FF00FF00FF) | ((b <<  8) & 0xFF00FF00FF00FF000000000000000000FF00FF00FF00FF00)
    b =    ((b >> 16) & 0x0000FFFF0000FFFF00000000000000000000FFFF0000FFFF) | ((b << 16) & 0xFFFF0000FFFF00000000000000000000FFFF0000FFFF0000)
    return ((b >> 32) & 0x00000000FFFFFFFF000000000000000000000000FFFFFFFF) | ((b << 32) & 0xFFFFFFFF000000000000000000000000FFFFFFFF00000000)

def diagMirror(b):
    t = (b ^ (b >> 7))  & 0x00aa00aa00aa00aa000000000000000000aa00aa00aa00aa
    b = b ^ t ^ (t << 7)
    t = (b ^ (b >> 14)) & 0x0000cccc0000cccc00000000000000000000cccc0000cccc
    b = b ^ t ^ (t << 14)
    t = (b ^ (b >> 28)) & 0x00000000f0f0f0f0000000000000000000000000f0f0f0f0
    return (b ^ t ^ (t << 28)) & 0xFFFFFFFFFFFFFFFF0000000000000000FFFFFFFFFFFFFFFF

def antiDiagMirror(b):
    t  = b ^ (b << 36)
    b ^= 0xf0f0f0f00f0f0f0f0000000000000000f0f0f0f00f0f0f0f & (t ^ (b >> 36))
    t  = 0xcccc0000cccc00000000000000000000cccc0000cccc0000 & (b ^ (b << 18))
    b ^= t ^ (t >> 18)
    t  = 0xaa00aa00aa00aa000000000000000000aa00aa00aa00aa00 & (b ^ (b <<  9))
    return (b ^ t ^ (t >>  9)) & 0xFFFFFFFFFFFFFFFF0000000000000000FFFFFFFFFFFFFFFF

# These next functions are for a single board only. They unreflect a move.
def horiMirrorSingle(b):
    b =    ((b >> 1) & 0x5555555555555555) | ((b << 1) & 0xAAAAAAAAAAAAAAAA)
    b =    ((b >> 2) & 0x3333333333333333) | ((b << 2) & 0xCCCCCCCCCCCCCCCC)
    return ((b >> 4) & 0x0F0F0F0F0F0F0F0F) | ((b << 4) & 0xF0F0F0F0F0F0F0F0)

def vertMirrorSingle(b):
    b =    ((b >>  8) & 0x00FF00FF00FF00FF) | ((b <<  8) & 0xFF00FF00FF00FF00)
    b =    ((b >> 16) & 0x0000FFFF0000FFFF) | ((b << 16) & 0xFFFF0000FFFF0000)
    return ((b >> 32) & 0x00000000FFFFFFFF) | ((b << 32) & 0xFFFFFFFF00000000)

def diagMirrorSingle(b):
    t = (b ^ (b >> 7)) & 0x00aa00aa00aa00aa
    b = b ^ t ^ (t << 7)
    t = (b ^ (b >> 14)) & 0x0000cccc0000cccc
    b = b ^ t ^ (t << 14)
    t = (b ^ (b >> 28)) & 0x00000000f0f0f0f0
    return b ^ t ^ (t << 28)

def antiDiagMirrorSingle(b):
    t  = b ^ (b << 36)
    b ^= 0xf0f0f0f00f0f0f0f & (t ^ (b >> 36))
    t  = 0xcccc0000cccc0000 & (b ^ (b << 18))
    b ^= t ^ (t >> 18)
    t  = 0xaa00aa00aa00aa00 & (b ^ (b <<  9))
    return b ^ t ^ (t >>  9)

# unreflects a board using a given symmetryIndex
def reverseSymMove(discs, symIndex):
    if symIndex == 0:
        return discs
    if symIndex == 1:
        return horiMirrorSingle(discs)
    if symIndex == 2:
        return vertMirrorSingle(discs)
    if symIndex == 3:
        return vertMirrorSingle(horiMirrorSingle(discs))
    if symIndex == 4:
        return diagMirrorSingle(discs)
    if symIndex == 5:
        return antiDiagMirrorSingle(discs)
    if symIndex == 6:
        return antiDiagMirrorSingle(vertMirrorSingle(discs))
    if symIndex == 7:
        return diagMirrorSingle(vertMirrorSingle(discs))
    return discs

# Given (player << 128) | opponent, returns the unique board.
# Unique board is the board with the smallest integer val. This
# is what is stored in the opening book.
def getUniqueBoard(combined):
    unique = combined
    symIndex = 0
    sym1 = horiMirror(combined) # Horizontal
    sym2 = vertMirror(combined) # Vertical
    sym3 = horiMirror(sym2) # Rotate 180
    sym4 = diagMirror(combined) # Flip Diag
    sym5 = antiDiagMirror(combined) # Flip Anti Diag
    sym6 = vertMirror(sym5) # 90 CW
    sym7 = vertMirror(sym4) # 90 ACW
    # Minimize:
    if sym1 < unique:
        unique, symIndex = sym1, 1
    if sym2 < unique:
        unique, symIndex = sym2, 2
    if sym3 < unique:
        unique, symIndex = sym3, 3
    if sym4 < unique:
        unique, symIndex = sym4, 4
    if sym5 < unique:
        unique, symIndex = sym5, 5
    if sym6 < unique:
        unique, symIndex = sym6, 6
    if sym7 < unique:
        unique, symIndex = sym7, 7
    return unique, symIndex

## BOARD MANUPULATIONS ##
# Returns [(move1, delta1), ...] for each board. Heavily Optimized
def validMoves(player, opponent):
    blank = ~ (player | opponent)
    # Get Possible Moves Left
    w = opponent & 0x7e7e7e7e7e7e7e7e
    t = w & (player >> 1)
    t |= w & (t >> 1)
    v = w & (w >> 1)
    t |= v & (t >> 2)
    t |= v & (t >> 2)
    rLeft = blank & (t >> 1)
    # Get Possible Moves Right
    t = w & (player << 1)
    t |= w & (t << 1)
    v = w & (w << 1)
    t |= v & (t << 2)
    t |= v & (t << 2)
    rRight = blank & (t << 1)
    # Get Possible Moves Top
    w = opponent & 0x00ffffffffffff00
    t = w & (player >> 8)
    t |= w & (t >> 8)
    v = w & (w >> 8)
    t |= v & (t >> 16)
    t |= v & (t >> 16)
    rTop = blank & (t >> 8)
    # Get Possible Moves Bottom
    t = w & (player << 8)
    t |= w & (t << 8)
    v = w & (w << 8)
    t |= v & (t << 16)
    t |= v & (t << 16)
    rBottom = blank & (t << 8)
    # Get Possible Moves Left Top
    w = opponent & 0x007e7e7e7e7e7e00
    t = w & (player >> 9)
    t |= w & (t >> 9)
    v = w & (w >> 9)
    t |= v & (t >> 18)
    t |= v & (t >> 18)
    rLeftTop = blank & (t >> 9)
    # Get Possible Moves Left Bottom
    t = w & (player << 7)
    t |= w & (t << 7)
    v = w & (w << 7)
    t |= v & (t << 14)
    t |= v & (t << 14)
    rLeftBottom = blank & (t << 7)
    # Get Possible Moves Right Top
    t = w & (player >> 7)
    t |= w & (t >> 7)
    v = w & (w >> 7)
    t |= v & (t >> 14)
    t |= v & (t >> 14)
    rRightTop = blank & (t >> 7)
    # Get Possible Moves Right Bottom
    t = w & (player << 9)
    t |= w & (t << 9)
    v = w & (w << 9)
    t |= v & (t << 18)
    t |= v & (t << 18)
    rRightBottom = blank & (t << 9)
    # Combine all the possible moves
    r = rLeft | rRight | rTop | rBottom | rLeftTop | rLeftBottom | rRightTop | rRightBottom
    # Now, we have to extract the possible moves and get deltas for each
    moves = []
    while r: # Once there are no moves left, this will be all zeroes
        m = r & -r # Get the least significant bit
        delta = 0
        # Left
        if rLeft & m: # If this was a left mobility
            mask = (m << 1) & 0xfefefefefefefefe # Mask the bits that have no left
            if mask: # If there are still things to be done
                _delta = 0 # Create a temporary delta
                while mask & opponent: # While the tile is the opponent's
                    _delta |= mask # Add the opponent tile to the temporary delta
                    mask = (mask << 1) & 0xfefefefefefefefe # Shift board to the left
                if mask & player: # If the tile is the player's
                    delta |= _delta # Then it is a valid flip - add _delta
        # Right
        if rRight & m:
            mask = (m >> 1) & 0x7f7f7f7f7f7f7f7f
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask >> 1) & 0x7f7f7f7f7f7f7f7f
                if mask & player:
                    delta |= _delta
        # Top
        if rTop & m:
            mask = (m << 8) & 0xffffffffffffff00
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask << 8) & 0xffffffffffffff00
                if mask & player:
                    delta |= _delta
        # Bottom
        if rBottom & m:
            mask = (m >> 8) & 0x00ffffffffffffff
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask >> 8) & 0x00ffffffffffffff
                if mask & player:
                    delta |= _delta
        # Left Top
        if rLeftTop & m:
            mask = (m << 9) & 0xfefefefefefefe00
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask << 9) & 0xfefefefefefefe00
                if mask & player:
                    delta |= _delta
        # Left Bottom
        if rLeftBottom & m:
            mask = (m >> 7) & 0x00fefefefefefefe
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask >> 7) & 0x00fefefefefefefe
                if mask & player:
                    delta |= _delta
        # Right Top
        if rRightTop & m:
            mask = (m << 7) & 0x7f7f7f7f7f7f7f00
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask << 7) & 0x7f7f7f7f7f7f7f00
                if mask & player:
                    delta |= _delta
        # Right Bottom
        if rRightBottom & m:
            mask = (m >> 9) & 0x007f7f7f7f7f7f7f
            if mask:
                _delta = 0
                while mask & opponent:
                    _delta |= mask
                    mask = (mask >> 9) & 0x007f7f7f7f7f7f7f
                if mask & player:
                    delta |= _delta

        moves.append((m, delta)) #  Add move, delta
        r &= r - 1 # Remove smallest bit

    return moves # No genExp because we sort this several times

# Based on logistello's delta implementation
def makeMove(player, opponent, move, delta):
    return player ^ (move | delta), opponent ^ delta

# Returns win: (1<<50) or loss: -(1<<50)
def evalFinalBoard(player, opponent):
    playerCount = bin(player).count("1") # Count player tokens
    opponentCount = bin(opponent).count("1") # Count opponent tokens
    if playerCount > opponentCount: # Win
        return 1 << 50
    return -(1<<50) # Loss

# Patterns based eval for search leafs
def evalBoard(player, opponent):
    combined = player | opponent
    if combined == 0xFFFFFFFFFFFFFFFF: # Quick way to check if the game is over
        return evalFinalBoard(player, opponent) # Use final evaluation
    s = stages[bin(combined).count("1") - 4] # Get gamestage (0-12)

    # Faster to apply each operation once on both of these ints at once
    combinedPO = (player << 128) | opponent

    # Collect each feature individually. From Kindergarden Bitboards
    # Diagonals:
    diagA4D1MaskMul = (combinedPO & 0x102040800000000000000000000000001020408000000000) * 16843009
    diagA5D8MaskMul = (combinedPO & 0x8040201000000000000000000000000080402010) * 72340172821233664
    diagH4E1MaskMul = (combinedPO & 0x80402010000000000000000000000000804020100000000) * 2149582850
    diagH5E8MaskMul = (combinedPO & 0x102040800000000000000000000000001020408) * 2130440
    diagA5E1MaskMul = (combinedPO & 0x81020408000000000000000000000000810204080000000) * 4311810305
    diagA4E8MaskMul = (combinedPO & 0x804020100800000000000000000000008040201008) * 72340172838010880
    diagH5D1MaskMul = (combinedPO >> 21 & 0x804020100800000000000000000000008040201008) * 2201172838402
    diagH4D8MaskMul = (combinedPO & 0x10204081000000000000000000000000102040810) * 36600682651844608
    diagA6F1MaskMul = (combinedPO & 0x40810204080000000000000000000000408102040800000) * 1103823438081
    diagA3F8MaskMul = (combinedPO & 0x80402010080400000000000000000000804020100804) * 72340172838076416
    diagH3C8MaskMul = (combinedPO & 0x1020408102000000000000000000000010204081020) * 9150170671349760
    diagH6C1MaskMul = (combinedPO >> 16 & 0x20100804020100000000000000000000201008040201) * 9016003946094600
    diagA7G1MaskMul = (combinedPO & 0x20408102040800000000000000000000204081020408000) * 282578800148737
    diagA2G8MaskMul = (combinedPO & 0x8040201008040200000000000000000080402010080402) * 72340172838076672
    diagH2B8MaskMul = (combinedPO & 0x102040810204000000000000000000001020408102040) * 2287542667870208
    diagH7B1MaskMul = (combinedPO >> 6 & 0x10080402010080400000000000000000100804020100804) * 1154048505100108801
    diag8MaskMulA = (combinedPO & 0x804020100804020100000000000000008040201008040201) * 72340172838076673
    diag8MaskMulB = (combinedPO & 0x10204081020408000000000000000000102040810204080) * 72340172838076673
    # Columns
    colAMaskMul = (combinedPO & 0x808080808080808000000000000000008080808080808080) * 567382630219905
    colBMaskMul = (combinedPO & 0x404040404040404000000000000000004040404040404040) * 1134765260439810
    colCMaskMul = (combinedPO & 0x202020202020202000000000000000002020202020202020) * 2269530520879620
    colDMaskMul = (combinedPO & 0x101010101010101000000000000000001010101010101010) * 4539061041759240
    colEMaskMul = (combinedPO & 0x80808080808080800000000000000000808080808080808) * 9078122083518480
    colFMaskMul = (combinedPO & 0x40404040404040400000000000000000404040404040404) * 18156244167036960
    colGMaskMul = (combinedPO & 0x20202020202020200000000000000000202020202020202) * 36312488334073920
    colHMaskMul = (combinedPO & 0x10101010101010100000000000000000101010101010101) * 72624976668147840
    # 4x2 Corners
    cornA1B4MaskMulA = (combinedPO & 0x808080800000000000000000000000008080808000000000) * 270549121
    cornA1B4MaskMulB = (combinedPO & 0x404040400000000000000000000000004040404000000000) * 270549121
    cornA8B5MaskMulA = (combinedPO & 0x8080808000000000000000000000000080808080) * 270549121
    cornA8B5MaskMulB = (combinedPO & 0x4040404000000000000000000000000040404040) * 270549121
    cornA8D7MaskMul = (combinedPO & 0xf0f00000000000000000000000000000f0f0) * 4097
    cornH8E7MaskMul = (combinedPO & 0xf0f00000000000000000000000000000f0f) * 17
    cornH8G5MaskMulA = (combinedPO & 0x101010100000000000000000000000001010101) * 270549121
    cornH8G5MaskMulB = (combinedPO & 0x202020200000000000000000000000002020202) * 270549121
    cornH1G4MaskMulA = (combinedPO & 0x20202020000000000000000000000000202020200000000) * 270549121
    cornH1G4MaskMulB = (combinedPO & 0x10101010000000000000000000000000101010100000000) * 270549121
    cornA1D2MaskMul = (combinedPO & 0xf0f00000000000000000000000000000f0f0000000000000) * 17
    cornH1E2MaskMul = (combinedPO & 0xf0f00000000000000000000000000000f0f000000000000) * 4097

    # Lookup values for each feature and return the sum
    return (
        # Length 4 diagonals
        diag4[s][base2To3[diagA4D1MaskMul >> 188 & 0xF] - base2To3[diagA4D1MaskMul >> 60 & 0xF] ] +
        diag4[s][base2To3[diagA5D8MaskMul >> 188 & 15] - base2To3[diagA5D8MaskMul >> 60 & 15] ] +
        diag4[s][base2To3[diagH4E1MaskMul >> 188 & 0xF] - base2To3[diagH4E1MaskMul >> 60 & 0Xf] ] +
        diag4[s][base2To3[diagH5E8MaskMul >> 152 & 0xF] - base2To3[diagH5E8MaskMul >> 24 & 0xF] ] +
        # Length 5 diagonals
        diag5[s][base2To3[diagA5E1MaskMul >> 187 & 0x1F] - base2To3[diagA5E1MaskMul >> 59 & 0x1F] ] +
        diag5[s][base2To3[diagA4E8MaskMul >> 187 & 31] - base2To3[diagA4E8MaskMul >> 59 & 31] ] +
        diag5[s][base2To3[diagH5D1MaskMul >> 168 & 0x1F] - base2To3[diagH5D1MaskMul  >> 40 & 0x1F] ] +
        diag5[s][base2To3[diagH4D8MaskMul >> 187 & 31] - base2To3[diagH4D8MaskMul >> 59 & 31] ] +
        # Length 6 diagonals
        diag6[s][base2To3[diagA6F1MaskMul >> 186 & 0x3F] - base2To3[diagA6F1MaskMul >> 58 & 0x3F] ] +
        diag6[s][base2To3[diagA3F8MaskMul >> 186 & 63] - base2To3[diagA3F8MaskMul >> 58 & 63] ] +
        diag6[s][base2To3[diagH3C8MaskMul >> 186 & 63] - base2To3[diagH3C8MaskMul >> 58 & 63] ] +
        diag6[s][base2To3[diagH6C1MaskMul >> 176 & 0x3F] - base2To3[diagH6C1MaskMul  >> 48 & 0x3F] ] +
        # Length 7 diagonals
        diag7[s][base2To3[diagA7G1MaskMul >> 185 & 127] - base2To3[diagA7G1MaskMul >> 57 & 127] ] +
        diag7[s][base2To3[diagA2G8MaskMul >> 185 & 127] - base2To3[diagA2G8MaskMul >> 57 & 127] ] +
        diag7[s][base2To3[diagH2B8MaskMul >> 185 & 127] - base2To3[diagH2B8MaskMul >> 57 & 127] ] +
        diag7[s][base2To3[diagH7B1MaskMul >> 184 & 127] - base2To3[diagH7B1MaskMul  >> 56 & 127] ] +
        # Length 8 diagonals
        diag8[s][base2To3[diag8MaskMulA >> 184 & 0xff] - base2To3[diag8MaskMulA >> 56 & 0xff] ] +
        diag8[s][base2To3[diag8MaskMulB >> 184 & 0xFF] - base2To3[diag8MaskMulB >> 56 & 0xFF] ] +
        # Rows
        lc1[s][base2To3[(player >> 56) & 0xFF] - base2To3[(opponent >> 56) & 0xFF] ] +
        lc2[s][base2To3[(player >> 48) & 0xFF] - base2To3[(opponent >> 48) & 0xFF] ] +
        lc3[s][base2To3[(player >> 40) & 0xFF] - base2To3[(opponent >> 40) & 0xFF] ] +
        lc4[s][base2To3[(player >> 32) & 0xFF] - base2To3[(opponent >> 32) & 0xFF] ] +
        lc4[s][base2To3[(player >> 24) & 0xFF] - base2To3[(opponent >> 24) & 0xFF] ] +
        lc3[s][base2To3[(player >> 16) & 0xFF] - base2To3[(opponent >> 16) & 0xFF] ] +
        lc2[s][base2To3[(player >> 8)  & 0xFF] - base2To3[(opponent >> 8)  & 0xFF] ] +
        lc1[s][base2To3[player & 0xFF] - base2To3[opponent & 0xFF] ] +
        # Columns
        lc1[s][base2To3[colAMaskMul >> 184 & 0xff] - base2To3[colAMaskMul >> 56 & 0xff] ] +
        lc2[s][base2To3[colBMaskMul >> 184 & 0xff] - base2To3[colBMaskMul >> 56 & 0xff] ] +
        lc3[s][base2To3[colCMaskMul >> 184 & 0xff] - base2To3[colCMaskMul >> 56 & 0xff] ] +
        lc4[s][base2To3[colDMaskMul >> 184 & 0xff] - base2To3[colDMaskMul >> 56 & 0xff] ] +
        lc4[s][base2To3[colEMaskMul >> 184 & 0xff] - base2To3[colEMaskMul >> 56 & 0xff] ] +
        lc3[s][base2To3[colFMaskMul >> 184 & 0xff] - base2To3[colFMaskMul >> 56 & 0xff] ] +
        lc2[s][base2To3[colGMaskMul >> 184 & 0xff] - base2To3[colGMaskMul >> 56 & 0xff] ] +
        lc1[s][base2To3[colHMaskMul >> 184 & 0xff] - base2To3[colHMaskMul >> 56 & 0xff] ] +
        # 4x2 corners
        corn[s][base2To3[((cornA1B4MaskMulA >> 184 & 240) |(cornA1B4MaskMulB >> 187 & 15) )] - base2To3[((cornA1B4MaskMulA >> 56 & 240) |(cornA1B4MaskMulB >> 59 & 15) )] ] +
        corn[s][base2To3[(revBits8[cornA8B5MaskMulA >> 156 & 15] | revBits8[cornA8B5MaskMulB >> 151 & 240] )] - base2To3[(revBits8[cornA8B5MaskMulA >> 28 & 15] | revBits8[cornA8B5MaskMulB >> 23 & 240]  )] ] +
        corn[s][base2To3[cornA8D7MaskMul >> 140 & 255] - base2To3[cornA8D7MaskMul >> 12 & 255] ] +
        corn[s][base2To3[revBits8[cornH8E7MaskMul >> 132 & 255]] - base2To3[revBits8[cornH8E7MaskMul >> 4 & 255]] ] +
        corn[s][base2To3[(revBits8[cornH8G5MaskMulA >> 149 & 15] | revBits8[cornH8G5MaskMulB >> 146 & 240] )] - base2To3[(revBits8[cornH8G5MaskMulA >> 21 & 15] | revBits8[cornH8G5MaskMulB >> 18 & 240] )] ] +
        corn[s][base2To3[((cornH1G4MaskMulA >> 182 & 15) | (cornH1G4MaskMulB >> 177 & 240) )] - base2To3[((cornH1G4MaskMulA >> 54 & 15) |(cornH1G4MaskMulB >> 49 & 240) )] ] +
        corn[s][base2To3[cornA1D2MaskMul >> 184 & 255] - base2To3[cornA1D2MaskMul >> 56 & 255] ] +
        corn[s][base2To3[revBits8[cornH1E2MaskMul >> 184 & 255]] - base2To3[revBits8[cornH1E2MaskMul >> 56 & 255]] ] +
        # Parity
        parity[s][(60-s)&1]
    )


@memoize # Returns edge stability (precalced vals). Uses (player << 64) | opponent as combinedPO
def getEdgeStability(combinedPO):
    player = combinedPO >> 64 # We only have them collected because that's how vectorized ordering gives them to us
    opponent = combinedPO & 0xFFFFFFFFFFFFFFFF

    # Again, all the masks use kindergarden bitboards
    playerB2L = (player & 0x40000000000000) >> 45
    opponentB2L = (opponent & 0x40000000000000) >> 45

    playerG7R = (player & 0x200) >> 9
    opponentG7R = (opponent & 0x200) >> 9

    playerG2 = (player & 0x2000000000000)
    opponentG2 = (opponent & 0x2000000000000)
    playerG2L = playerG2 >> 40
    playerG2R = playerG2 >> 49
    opponentG2L = opponentG2 >> 40
    opponentG2R = opponentG2 >> 49

    playerB7 = (player & 0x4000)
    opponentB7 = (opponent & 0x4000)
    playerB7L = playerB7 >> 5
    playerB7R = playerB7 >> 14
    opponentB7L = opponentB7 >> 5
    opponentB7R = opponentB7 >> 14

    # left
    playerLeft = playerB2L | ((((player & 0x8080808080808080) * 567382630219905) >> 55) & 510) | playerB7R
    opponentLeft = opponentB2L | ((((opponent & 0x8080808080808080) * 567382630219905) >> 55) & 510) | opponentB7R
    leftIndex = base2To3[playerLeft] + 2 * base2To3[opponentLeft]

    #right
    playerRight = playerG2L | ((((player & 0x101010101010101) * 72624976668147840) >> 55) & 510) | playerG7R
    opponentRight = opponentG2L | ((((opponent & 0x101010101010101) * 72624976668147840) >> 55) & 510) | opponentG7R
    rightIndex = base2To3[playerRight] + 2 * base2To3[opponentRight]

    # top
    playerTop = playerB2L | ((player & 0xff00000000000000) >> 55) | playerG2R
    opponentTop = opponentB2L | ((opponent & 0xff00000000000000) >> 55) | opponentG2R
    topIndex = base2To3[playerTop] + 2 * base2To3[opponentTop]

    # bottom
    playerBottom = playerB7L | ((player & 0xff) << 1) | playerG7R
    opponentBottom = opponentB7L | ((opponent & 0xff) << 1) | opponentG7R
    bottomIndex = base2To3[playerBottom] + 2 * base2To3[opponentBottom]

    return edgeTable[topIndex] + edgeTable[bottomIndex] + edgeTable[leftIndex] + edgeTable[rightIndex] # Precomputed stabilities

# vectorized masks (max move count is 60)
mobMasks0      = [0, 0x7e7e7e7e7e7e7e7e7e7e7e7e7e7e7e7e]
mobMasks1      = [0, 0x00ffffffffffff0000ffffffffffff00]
mobMasks2      = [0, 0x007e7e7e7e7e7e00007e7e7e7e7e7e00]
potMobMaskL1   = [0, 0xfefefefefefefefefefefefefefefefe]
potMobMaskR1   = [0, 0x7f7f7f7f7f7f7f7f7f7f7f7f7f7f7f7f]
potMobMaskL8   = [0, 0xffffffffffffff00ffffffffffffff00]
potMobMaskR8   = [0, 0x00ffffffffffffff00ffffffffffffff]
potMobMaskL9   = [0, 0xfefefefefefefe00fefefefefefefe00]
potMobMaskR7   = [0, 0x00fefefefefefefe00fefefefefefefe]
potMobMaskL7   = [0, 0x7f7f7f7f7f7f7f007f7f7f7f7f7f7f00]
potMobMaskR9   = [0, 0x007f7f7f7f7f7f7f007f7f7f7f7f7f7f]
popCountFrames = [0, 1<<128]
for x in range(60): # No more than 60 possible moves
    mobMasks0.append((mobMasks0[-1] << 129) | mobMasks0[1])
    mobMasks1.append((mobMasks1[-1] << 129) | mobMasks1[1])
    mobMasks2.append((mobMasks2[-1] << 129) | mobMasks2[1])
    potMobMaskL1.append((potMobMaskL1[-1] << 129) | potMobMaskL1[1])
    potMobMaskR1.append((potMobMaskR1[-1] << 129) | potMobMaskR1[1])
    potMobMaskL8.append((potMobMaskL8[-1] << 129) | potMobMaskL8[1])
    potMobMaskR8.append((potMobMaskR8[-1] << 129) | potMobMaskR8[1])
    potMobMaskL9.append((potMobMaskL9[-1] << 129) | potMobMaskL9[1])
    potMobMaskR7.append((potMobMaskR7[-1] << 129) | potMobMaskR7[1])
    potMobMaskL7.append((potMobMaskL7[-1] << 129) | potMobMaskL7[1])
    potMobMaskR9.append((potMobMaskR9[-1] << 129) | potMobMaskR9[1])
    popCountFrames.append((popCountFrames[-1] << 129) | popCountFrames[1])


# Evaluates a whole list of boards at once for PVS move ordering
# Simply uses mobility, potential mobility and edge stability
def moveOrder(boards):
    vectorizedOP = 0
    vectorizedPO = 0
    vectorizedBlank = 0
    moveNumber = bin(boards[0][0] | boards[0][1]).count("1") - 3

    cEdg = 312000 + 6240 * moveNumber  # Edge weight
    cCur = 50000 + 2000 * moveNumber if moveNumber < 25 else 75000 + 1000 * moveNumber # Mobility Weight
    cPot = 20000 # Potential mobility weight

    numBoards = len(boards)
    values = [0] * numBoards # These values will be returned eventually

    i = 0 # Add all the boards to the vectorized boards
    for player, opponent in boards:
        vectorizedBlank = (vectorizedBlank << 129) | (~(player | opponent) & 0xFFFFFFFFFFFFFFFF) # The blanks
        combinedPO = ((player << 64) | opponent) # Used twice
        vectorizedOP = (vectorizedOP << 129) | ((opponent << 64) | player)
        vectorizedPO = (vectorizedPO << 129) | combinedPO
        # Add edge stability
        values[i] = (cEdg * getEdgeStability(combinedPO & 0xffc381818181c3ffffc381818181c3ff)) / 32000 # Max is 75000
        i += 1 # Incrementing because the combined for loop was slower

    vectorizedBlank *= 0x10000000000000001 # Thank you Kindergarden Bitboards :)

    # this is just validMoves with larger boards :)
    # Get mobility Left
    w = vectorizedOP & mobMasks0[numBoards]
    sR1 = vectorizedPO >> 1
    t = w & sR1
    t |= w & (t >> 1)
    v = w & (w >> 1)
    t |= v & (t >> 2)
    t |= v & (t >> 2)
    r = t >> 1
    # Get mobility Right
    sL1 = vectorizedPO << 1
    t = w & sL1
    t |= w & (t << 1)
    v = w & (w << 1)
    t |= v & (t << 2)
    t |= v & (t << 2)
    r |= t << 1
    # Get mobility Top
    w = vectorizedOP & mobMasks1[numBoards]
    sR8 = vectorizedPO >> 8
    t = w & sR8
    t |= w & (t >> 8)
    v = w & (w >> 8)
    t |= v & (t >> 16)
    t |= v & (t >> 16)
    r |= t >> 8
    # Get mobility Bottom
    sL8 = vectorizedPO << 8
    t = w & sL8
    t |= w & (t << 8)
    v = w & (w << 8)
    t |= v & (t << 16)
    t |= v & (t << 16)
    r |= t << 8
    # Get mobility Left Top
    w = vectorizedOP & mobMasks2[numBoards]
    sR9 = vectorizedPO >> 9
    t = w & sR9
    t |= w & (t >> 9)
    v = w & (w >> 9)
    t |= v & (t >> 18)
    t |= v & (t >> 18)
    r |= t >> 9
    # Get mobility Left Bottom
    sL7 = vectorizedPO << 7
    t = w & sL7
    t |= w & (t << 7)
    v = w & (w << 7)
    t |= v & (t << 14)
    t |= v & (t << 14)
    r |= t << 7
    # Get mobility Right Top
    sR7 = vectorizedPO >> 7
    t = w & sR7
    t |= w & (t >> 7)
    v = w & (w >> 7)
    t |= v & (t >> 14)
    t |= v & (t >> 14)
    r |= t >> 7
    # Get mobility Right Bottom
    sL9 = vectorizedPO << 9
    t = w & sL9
    t |= w & (t << 9)
    v = w & (w << 9)
    t |= v & (t << 18)
    t |= v & (t << 18)
    r |= t << 9

    # Get potential mobility
    vectorizedPotentialMobility = (
        (sL1 & potMobMaskL1[numBoards]) |
        (sR1 & potMobMaskR1[numBoards]) |
        (sL8 & potMobMaskL8[numBoards]) |
        (sR8 & potMobMaskR8[numBoards]) |
        (sL9 & potMobMaskL9[numBoards]) |
        (sR7 & potMobMaskR7[numBoards]) |
        (sL7 & potMobMaskL7[numBoards]) |
        (sR9 & potMobMaskR9[numBoards]))

    frame = popCountFrames[numBoards] # Turn the most significant bit on
    binR = bin((r & vectorizedBlank) | frame) # minimum of 1
    binPotentialMobility = bin((vectorizedPotentialMobility & vectorizedBlank) | frame)
    leftStartIndex = 3
    midIndex = 67
    rightEndIndex = 131

    i = 0
    # Count the bits to know the mobilities and potential mobilities
    for player, opponent in boards:
        pMobCur = binR.count("1", leftStartIndex, midIndex)
        pMobPot = binPotentialMobility.count("1", midIndex, rightEndIndex)
        oMobCur = binR.count("1", midIndex, rightEndIndex)
        oMobPot = binPotentialMobility.count("1", leftStartIndex, midIndex)
        leftStartIndex += 129
        midIndex += 129
        rightEndIndex += 129

        values[i] += ( # Mobility percentage
            (cCur * (pMobCur - oMobCur)) / (pMobCur + oMobCur + 2) +
            # Potential mobility percentage
            (cPot * (pMobPot - oMobPot)) / (pMobPot + oMobPot + 2))

        i += 1

    return values # The completed weights

# Simple negascout, using move ordering and ttable. Depth is 0 at leafs.
# Complex number tuples are used in the ttable as they take less space, and seem cool :)
def negaScout(player, opponent, depth, alpha=-(1<<48), beta=1<<48, isRoot=True, ttable=None):
    if depth == 0: # Leaf:
        return evalBoard(player, opponent)
    if isRoot: # We have to create the ttable
        ttable = {} # Create a transposition table
    else: # Try a ttable lookup
        try: # Catches KeyError, empty dict, etc.
            lookup = ttable[(player << 64) | opponent]
            # Real: previous stored depth, Imag: previous stored flag
            if lookup[1].real <= depth:
                lookupValue = lookup[0]
                flag = lookup[1].imag
                if flag == 1: # Exact
                    return lookupValue
                elif flag == 2: # Lower bound
                    alpha = max(alpha, lookupValue)
                elif flag == 3: # Upper bound
                    beta = min(beta, lookupValue)
                if alpha >= beta: # Cutoff
                    return lookupValue
        except: pass # Too hard to catch all the exceptions lol

    moves = validMoves(player, opponent) # Get all validMoves
    isOpponent = False
    if not moves: # If no moves available
        moves = validMoves(opponent, player)
        if moves: # Don't recur again, just do it here
            if depth == 1: # This would be the leaf node
                value = evalBoard(player, opponent)
                # Store in ttable:
                ttable[(player << 64) | opponent] = (value, depth + (3j if (value <= alpha) else (2j if value >= beta else 1j)) )
                return value
            isOpponent = True # Not a leaf node - drop a ply
            player, opponent = opponent, player # Swap
            alpha = -beta
            beta = -alpha
            depth -= 1
        else: # No validMoves - game is over
            value = evalFinalBoard(player, opponent) # Return win / loss
            # Store in ttable:
            ttable[(player << 64) | opponent] = (value, depth + (3j if (value <= alpha) else (2j if value >= beta else 1j)) )
            return value

    nextBoards = [(opponent ^ rev, player ^ (move | rev)) for move, rev in moves] # Get the next boards
    nextBoardEvalValues = moveOrder(nextBoards) # Score each board
    sortedMoves = sorted(list(zip(nextBoardEvalValues, moves, nextBoards))) # Sort by score

    b, a = beta, alpha
    bestMove = isRoot and sortedMoves[0][1][0] # Faster to and than if statement

    i = 0 # First iteration
    for nextMove in sortedMoves:
        nextPlayer, nextOpponent = nextMove[2]
        # Null window after iteration 1
        t = -negaScout(nextPlayer, nextOpponent, depth-1, -b, -alpha, False, ttable)
        if i and a < t < beta: # PV refuted (not bext move), retry with full window
            t = -negaScout(nextPlayer, nextOpponent, depth-1, -beta, -alpha, False, ttable)
        if t > alpha:
            bestMove = isRoot and nextMove[1][0] # Bestmove as before
            alpha = t # New alpha
        if alpha >= beta:
            break # Cutoff
        i = 1 # Not the first iteration anymore
        b = alpha + 1 # Null window searches from now on

    # Store in ttable:
    ttable[(player << 64) | opponent] = (alpha, depth + (3j if (alpha <= a) else (2j if alpha >= beta else 1j)) )
    if isOpponent: # Undo enemy ply drop
        alpha = -alpha
    return (bestMove, alpha) if isRoot else alpha
