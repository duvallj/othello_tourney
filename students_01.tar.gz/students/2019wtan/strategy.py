#Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

MATRIX = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   20,   20,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   20,  -5,   3,   3,   3,   3,  -5,   20,   0,
    0,   20,  -5,   3,   3,   3,   3,  -5,   20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   20,   20,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
];

# MATRIX = [
#     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
#     0, 120, -20,  20,   0,   0,  20, -20, 120,   0,
#     0, -20, -40,  0,  0,  0,  0, -40, -20,   0,
#     0,  20,  0,  0,   0,   0,  0,  0,  20,   0,
#     0,   5,  0,   0,   0,   0,   0,  0,   0,   0,
#     0,   5,  0,   0,   0,   0,   0,  0,   0,   0,
#     0,  20,  0,  0,   0,   0,  0,  0,  20,   0,
#     0, -20, -40,  0,  0,  0,  0, -40, -20,   0,
#     0, 120, -20,  20,   0,   0,  20, -20, 120,   0,
#     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
# ];

startplayer = BLACK;

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

   def __init__(self):
      pass

   def get_starting_board(self):
      return "???????????........??........??........??...@o...??...o@...??........??........??........???????????"; 
      pass

   def get_pretty_board(self, board):
      """Get a string representation of the board."""
      stringy = ' ';
      spaces = ['\n'];
      j = 0;
      for i in range(0, len(board)):
         spaces.append(board[i]);
         j = j + 1;
         if (j == 10):
            spaces.append('\n');
            j = 0;
      return stringy.join(spaces);
      pass

   def opponent(self, player):
      if(player == BLACK):
         return WHITE;
      return BLACK;
      pass

   def find_match(self, board, player, square, direction):
      """
      Find a square that forms a match with `square` for `player` in the given
      `direction`.  Returns None if no such square exists.
      """
      if(direction == N):
         iterator = -10;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator - 10;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
            
      if(direction == S):
         iterator = 10;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator + 10;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      if(direction == E):
         iterator = 1;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator + 1;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      if(direction == W):
         iterator = -1;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator - 1;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      if(direction == NE):
         #print("Checking Northeast");
         iterator = -9;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator - 9;
            if(board[square + iterator] == player):
              # print("Found.");
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      if(direction == SE):
         iterator = 11;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator + 11;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      if(direction == SW):
         iterator = 9;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator + 9;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      if(direction == NW):
         iterator = -11;
         while((square + iterator) >= 0 and (square + iterator) <= 99 and board[square + iterator] != '?'):
            iterator = iterator - 11;
            if(board[square + iterator] == player):
               return square + iterator;
            if(board[square + iterator] == '.'):
               break;
      return None;

   def is_move_valid(self, board, player, move):
      """Is this a legal move for the player?"""
      legality = [];
      for d in DIRECTIONS:
         f = self.find_match(board, player, move, d);
         if (f != None):
            if(d == N):
              # print("Candidacy North");
               n = -10;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n - 10;
               if(move + n == f):
                  legality.append(d);
            elif(d == NE):
              # print("Candidacy Northeast");
               n = -9;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n - 9;
               if(move + n == f):
                  legality.append(d);
            elif(d == E):
             #  print("Candidacy East");
               n = 1;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n + 1;
               if(move + n == f):
                  legality.append(d);
            elif(d == SE):
             #  print("Candidacy Southeast");
               n = 11;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n + 11;
               if(move + n == f):
                  legality.append(d);
            elif(d == S):
             #  print("Candidacy South");
               n = 10;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n + 10;
               if(move + n == f):
                  legality.append(d);
            elif(d == SW):
             #  print("Candidacy Southwest");
               n = 9;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n + 9;
               if(move + n == f):
                  legality.append(d);
            elif(d == W):
             #  print("Candidacy West");
               n = -1;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n - 1;
               if(move + n == f):
                  legality.append(d);
            elif(d == NW):
             #  print("Candidacy Northwest");
               n = -11;
               while(move + n != f):
                  if(board[move + n] != self.opponent(player)):
                     break;
                  n = n - 11;
               if(move + n == f):
                  legality.append(d);
      return (len(legality) > 0);
      pass

   def make_move(self, board, player, move):
      """Update the board to reflect the move by the specified player."""
      edit = [];
      for x in board:
         edit.append(x);
      for d in DIRECTIONS:
         f = self.find_match(board, player, move, d);
         #print(f);
         if (f != None):
            if(d == N):
               
               n = -10;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n - 10;
            elif(d == NE):
               n = -9;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n - 9;
            elif(d == E):
               n = 1;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n + 1;
            elif(d == SE):
               n = 11;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n + 11;
            elif(d == S):
               n = 10;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n + 10;
            elif(d == SW):
               n = 9;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n + 9;
            elif(d == W):
               n = -1;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n - 1;
            elif(d == NW):
               n = -11;
               while(move + n != f):
                  if(board[move + n] == self.opponent(player)):
                     edit[move + n] = player;
                  n = n - 11;
      edit[move] = player;
      #print(edit);
      return ''.join(edit);
         
      # returns a new board/string
      pass

   def get_valid_moves(self, board, player):
      """Get a list of all legal moves for player."""
      good = [];
      for i in range(len(board)):
         if(board[i] == '.' and (board[i + 1] == self.opponent(player) or board[i - 1] == self.opponent(player) or board[i - 10] == self.opponent(player) or board[i + 10] == self.opponent(player) or board[i + 9] == self.opponent(player) or board[i + 11] == self.opponent(player) or board[i - 9] == self.opponent(player) or board[i - 11] == self.opponent(player))):
            #print(i,', ',board[i],', ', self.is_move_valid(board, player, i));
            if (self.is_move_valid(board, player, i)):
               good.append(i);
               #print(board[i]);
      #print(self.opponent(player));
      #print(good);
      
      return good;

   def has_any_valid_moves(self, board, player):
      """Can player make any moves?"""
      if (len(self.get_valid_moves(board, player)) > 0):
         return True;
      return False;

   def next_player(self, board, prev_player):
      """Which player should move next?  Returns None if no legal moves exist."""
      if(self.has_any_valid_moves(board, self.opponent(prev_player))):
         return self.opponent(prev_player);
      return None;

   def grand_score(self, board, historic, player=BLACK):
      """Compute player's score (number of player's pieces minus opponent's)."""
      # rewrite score function to take advantage of mobility at start, switching to large delta and large piece-count at the end-stage.
      maxcount = 0;
      mincount = 0;
      hcount = 0;
      
      maxmobile = self.get_valid_moves(board, startplayer);
      minmobile = self.get_valid_moves(board, self.opponent(startplayer));
      
      maxcorners = 0;
      mincorners = 0;
      
      matscore = 0;
      
      maxstab = 0;
      minstab = 0;
      
      for i in range(0, len(board)):
         if(board[i] == startplayer):
            if((i == 11 or i == 18 or i == 81 or i == 88)):
               maxcorners += 1;
               maxstab += 20;
            maxcount = maxcount + 1;
            matscore += MATRIX[i];
            
            maxstab += 1;
            
            if(i - 1 in minmobile):
               c = 1;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i + 1 in minmobile):
               c = -1;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i - 11 in minmobile):
               c = 11;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i - 10 in minmobile):
               c = 10;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i - 9 in minmobile): 
               c = 9;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i + 11 in minmobile):
               c = -11;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i + 10 in minmobile):
               c = -10;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            if(i + 9 in minmobile): 
               c = -9;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  maxstab -= 1;
                  c = c * 2;
            
         if(board[i] == self.opponent(startplayer)):
            if(i == 11 or i == 18 or i == 81 or i == 88):
               minstab += 20;
               mincorners += 1;
            mincount = mincount + 1;
            matscore -= MATRIX[i];
            
            minstab += 1;
            
            if(i - 1 in maxmobile):
               c = 1;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i + 1 in maxmobile):
               c = -1;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i - 11 in maxmobile):
               c = 11;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i - 10 in maxmobile):
               c = 10;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i - 9 in maxmobile): 
               c = 9;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i + 11 in maxmobile):
               c = -11;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i + 10 in maxmobile):
               c = -10;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            if(i + 9 in maxmobile): 
               c = -9;
               while(not(i + c > 99 or i + c < 0) and board[i + c] == self.opponent(startplayer)):
                  minstab -= 1;
                  c = c * 2;
            
      for i in historic:
         if(i == startplayer):
            hcount = hcount + 1;
      
      delta = maxcount - hcount;
      
      if(maxcorners + mincorners == 0):
         corners = 0;
      else:
         corners = 100 * (maxcorners - mincorners) / (maxcorners + mincorners);
      
      if(len(maxmobile) + len(minmobile) == 0):
         mobility = 0;
      else:
         mobility = 100 * (len(maxmobile) - len(minmobile)) / (len(maxmobile) + len(minmobile));
      
      parity = 100 * (maxcount - mincount) / (maxcount + mincount);
      
      if(maxstab + minstab == 0):
         stability = 0;
      else:
         stability = (maxstab - minstab) / (maxstab + minstab);
       
      
      if(maxcount + mincount < 45):
         return 100000 * maxcorners - 140000 * mincorners + 50 * stability + 5 * matscore + 100 * mobility + 5 * parity;
      else:
         return 100000 * maxcorners - 140000 * mincorners + 200 * stability + 200 * delta + 50 * mobility + 100 * parity;
         #return 1000 * maxcorners - 100000 * mincorners + 200 * stability + 200 * delta + 50 * mobility + 100 * parity;
   
   def count(self, board):
      count = 0;
      for i in board:
         if(i != '.'):
            count = count + 1;
      return count;
      
   def fscore(self, board, player=BLACK):
      """Compute player's score (number of player's pieces minus opponent's)."""
      count = 0;
      for x in range(0, len(board)):
         if(board[x] == startplayer):
            count += 1;
         elif(board[x] == self.opponent(startplayer)):
            count -= 1;
            
      return count;
   
   def matrix_score(self, board, player=BLACK):
      """Compute player's score (number of player's pieces minus opponent's)."""
      count = 0;
      for x in range(0, len(board)):
         if(board[x] == startplayer):
            count += MATRIX[x];
         elif(board[x] == self.opponent(startplayer)):
            count -= MATRIX[x];
            
      return count;
   
   def game_over(self, board, player):
      if(not(self.has_any_valid_moves(board, player)) and not(self.has_any_valid_moves(board, self.opponent(player)))):
         return True;
      return False; 
      

   ### Monitoring players

   class IllegalMoveError(Exception):
      def __init__(self, player, move, board):
         self.player = player
         self.move = move
         self.board = board
   
      def __str__(self):
         return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

   ################ strategies #################

   def minimax_search(self, board, player, target, depth=0, parent="@0@0", a = math.inf, b = -1 * math.inf):
      if(depth == target or self.game_over(board, player) or not(self.has_any_valid_moves(board, player))):
            return (-1, self.grand_score(board, player));

      moves = [];
      scores = [];
      for x in self.get_valid_moves(board, player):
         result = self.minimax_search(self.make_move(board, player, x), self.opponent(player), target, depth + 1,board, a, b);
         
         score = .2 * MATRIX[x] + 2 * result[1];
         scores.append(score); #add score-matrix reference to here.
         moves.append(x);
         
         if player == startplayer:
            if score > a:
               a = score;
               if a > b:
                  break;
         else:
            if score < b:
               b = score;
               if b < a:
                  break;
                  
      if player == startplayer:
         maxindex = scores.index(max(scores));
         return (moves[maxindex], scores[maxindex]);
      else:
         minindex = scores.index(min(scores));
         return (moves[minindex], scores[minindex]);

   def minimax_strategy(self, board, player, depth=3):
#       # calls minmax_search
#       # feel free to adjust the parameters
#       # returns an integer move
      startplayer = player;
      result = self.minimax_search(board, player, depth);
      return result[0];
   
   def random_strategy(self, board, player):
      return random.choice(self.get_valid_moves(board, player))

   def best_strategy(self, board, player, best_move, still_running):
      ## THIS IS the public function you must implement
      ## Run your best search in a loop and update best_move.value
      depth = 3
      startplayer = player;
      nboard = "".join(board);
      while(still_running):
         best_move.value = self.minimax_strategy(nboard, player, depth)
         depth += 1;


   standard_strategy = minimax_strategy;


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
   def __init__(self):
      pass

   def play(self):
      ### create 2 opponent objects and one referee to play the game
      ### these could all be from separate files
      ref = Strategy()
      black = Strategy()
      white = Strategy()
   
      print("Playing Standard Game")
      board = ref.get_starting_board()
      player = BLACK
      strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
      print(ref.get_pretty_board(board))
   
      while player is not None:
         move = strategy[player](board, player)
         print("Player %s chooses %i" % (player, move))
         board = ref.make_move(board, player, move)
         print(ref.get_pretty_board(board))
         player = ref.next_player(board, player)
   
      print("Final Score %i." % ref.fscore(board), end=" ")
      print("%s wins" % ("Black" if ref.fscore(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

   def __init__(self, time_limit = 5):
      self.black = Strategy()
      self.white = Strategy()
      self.time_limit = time_limit

   def play(self):
      ref = Strategy()
      print("play")
      board = ref.get_starting_board()
      player = BLACK
   
      print("Playing Parallel Game")
      strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
      while player is not None:
         best_shared = Value("i", -99)
         best_shared.value = -99
         running = Value("i", 1)
      
         p = Process(target=strategy(player), args=(board, player, best_shared, running))
         # start the subprocess
         t1 = time.time()
         p.start()
         # run the subprocess for time_limit
         p.join(self.time_limit)
         # warn that we're about to stop and wait
         running.value = 0
         time.sleep(0.01)
         # kill the process
         p.terminate()
         time.sleep(0.01)
         # really REALLY kill the process
         if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
         # see the best move it found
         move = best_shared.value
         if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
         if not silent:print(board, ref.get_valid_moves(board, player))
         # make the move
         board = ref.make_move(board, player, move)
         if not silent: print(ref.get_pretty_board(board))
         player = ref.next_player(board, player)
   
      print("Final Score %i." % ref.score(board), end=" ")
      print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
   # game =  ParallelPlayer(0.1)
   game = StandardPlayer()
   game.play()
