#Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018
# Bejoy Sen P6

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
WEIGHTS = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
           0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
           0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
           0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
           0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
           0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
           0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
           0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
BEST = {BLACK: max, WHITE: min}
class Node:
    def __init__(self, board, move=None, score=None):
        self.board = board
        self.move = move
        self.score = score
    def __lt__(self,other):
        return self.score < other.score
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pretty = ""
        for x in range(10):
            pretty+="\n"+"|---"*10+"|\n|"
            for y in range(10):
                if board[10*x+y]==OUTER:
                    if x%9==0:
                        token = str(y%9)
                    else:
                        token = str(x%9)
                else:
                    token = board[10*x+y]
                pretty+=" "+token+" |"
        pretty+="\n"+"|---"*10+"|"
        return pretty
        # return "".join(["".join([board[10*r+c]+" " for c in range(10)])+"\n" for r in range(10)])

    def opponent(self, player):
        """Get player's opponent."""
        return BLACK if player==WHITE else WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        nbr = square+direction
        if board[nbr]!=self.opponent(player):
            return None
        p = nbr
        while board[p]!=OUTER:
            p+=direction
            if board[p]!=self.opponent(player):
                break
        if board[p]==player:
            return p
        return None


    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        for direction in DIRECTIONS:
            if self.find_match(board, player, move, direction) is not None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        new_board = list(board)
        for direction in DIRECTIONS:
            match = self.find_match(board, player, move, direction)
            if match is not None:
                for x in range(move,match,direction):
                    new_board[x] = player
        return "".join(new_board)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        return [move for move in range(len(board)) if board[move]==EMPTY and self.is_move_valid(board, player, move)]

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player))!=0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        return board.count(player)-board.count(self.opponent(player))

    def weightedscore(self, board, player=BLACK):
        opponent = self.opponent(player)
        count = 0
        for sq in range(len(board)):
            if board[sq]==player:
                count += WEIGHTS[sq]
            elif board[sq]==opponent:
                count -= WEIGHTS[sq]
        return count

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return next_player(board, player) is None

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth, method=None):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if method is None:
            method = self.weightedscore
        board = node.board
        if depth==0:
            node.score = method(board)
            return node
        my_moves = self.get_valid_moves(board,player)

        children = [] # change for alpha-beta pruning
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move, 10000*self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth = depth-1).score
                children.append(c)
        winner = BEST[player](children)
        node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node(board, player), player, depth).move

    def minimax_strategy(self, board, player, depth=3): # this is different
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node(board, player), player, depth, self.score).move

    def random_strategy(self, board, player, depth=None): # depth for compatibility
        return random.choice(self.get_valid_moves(board, player))

    def player_strategy(self, board, player):
        return int(input("Move # = "))
    def parallel_strategy(self, board, player, best_move, still_running, strategy):
        depth = 1
        while(True):
            best_move.value = strategy(board, player, depth)
            print("DEPTH >>> "+str(depth)) # CHANGE
            depth+=1

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        self.parallel_strategy(board, player, best_move, still_running, self.minmax_strategy)

    def worst_strategy(self, board, player, best_move, still_running):
        best_move.value = self.random_strategy(board, player)

    def alt_strategy(self, board, player, best_move, still_running):
        self.parallel_strategy(board, player, best_move, still_running, self.minimax_strategy)
    standard_strategy = minmax_strategy
