#!
#Zane Givans Period 3
import sys

tempDict = {}
conversion = {"a": 0, "b": 1, "c":2, "d":3, "e":4, "f":5, "g":6, "h":7}
corners = [0, 7, 56, 63]
edges = [1, 2, 3, 4, 5, 6, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 57, 58, 59, 60, 61, 62]
inCorners = {1:0, 6:7, 8:0, 9:0, 14:7, 15:7, 48:56, 49:56, 54:63, 55:63, 57:56, 62:63}
def prnt(pzl):
	if pzl == "":
		print(pzl)
	else:
		for y in range(8):
			print(pzl[0+(8*y):8+(8*y)])
def prntPos(pzl, places):
	for x in places:
		pzl = pzl[:x] + "*" + pzl[x+1:]
	for y in range(8):
		print(pzl[0+(8*y):8+(8*y)])
def score(pzl):
	ocount = 0
	xcount = 0
	for x in pzl:
		if x.lower() == "x":
			xcount+=1
		if x.lower() =="o":
			ocount+=1
	return str(xcount) + "/" + str(ocount)
def swap(trn):
	if trn=="x":
		return "o"
	return "x"
def moves(pzl, trn):
	overall = []
	if pzl+trn in tempDict:
		return tempDict[pzl+trn]
	for x in range(64):
		if pzl[x].lower() == trn:
			directions = [x-9, x-8, x-7, x-1, x+1, x+7, x+8, x+9]
			for y in directions:
				if y>=0 and y<64:
					if (trn == "x" and pzl[y].lower() =="o") or (trn == "o" and pzl[y].lower() =="x"):
						temp = possible(pzl, y, x, trn)
						if temp!=-1 and temp not in overall:
							overall.append(temp)
	tempDict[pzl+trn] = overall
	return overall
def possible(pzl, index, prev, trn):
	if index<0 or index>63 or pzl[index].lower() == trn:
		return -1
	if (index%8==0 and (prev+1)%8==0) or (prev%8==0 and (index+1)%8==0):
		return -1
	if pzl[index] == ".":
		return index
	else:
		newind = index + (index-prev)
		return possible(pzl, newind, index, trn)
def move(pzl, index, trn):
	"""if index not in moves(pzl, trn):
		return ""
	"""
	pzl = pzl[:index] + trn + pzl[index+1:]
	directions = [index-9, index-8, index-7, index-1, index+1, index+7, index+8, index+9]
	maybe = [x for x in directions if x>=0 and x<63 and (pzl[x]!= trn and pzl[x]!= ".")]
	for y in maybe:
		temp = possible2(pzl, y, index, trn)
		if temp!= -1:
			num = y
			while num!= temp:
				pzl = pzl[:num] + trn + pzl[num+1:]
				num+=(y-index)
	return pzl
def possible2(pzl, index, prev, trn):
	if index<0 or index>63 or pzl[index] == ".":
		return -1
	if (index%8==0 and (prev+1)%8==0) or (prev%8==0 and (index+1)%8==0):
		return -1
	if pzl[index] == trn:
		return index
	else:
		newind = index + (index-prev)
		return possible2(pzl, newind, index, trn)
def smartMove(pzl, trn):
	test = moves(pzl, trn)
	if len(test) == 1:
		return test[0]
	if test:
		for x in test:
			if x in corners:
				return x
		for x in test:
			if x in edges:
				directions = [x-9, x-8, x-7, x-1, x+1, x+7, x+8, x+9]
				maybe = [y for y in directions if y>=0 and y<63 and (pzl[y]!= trn and pzl[y]!= ".")]
				for numb in maybe:
					temp = possible2(pzl, numb, x, trn)
					if temp!= -1 and temp in corners:
						return x
		for x in test:
			if x not in edges:
				if (x not in inCorners) or (x in inCorners and pzl[inCorners[x]] ==trn):
					return x
		for x in test:
			if x in edges and x not in inCorners:
					return x
		return test[0]
	else:
		return -1
def evalBoard(pzl, trn):
	ocount = 0
	xcount = 0
	for x in pzl:
		if x.lower() == "x":
			xcount+=1
		if x.lower() =="o":
			ocount+=1
	if trn.lower() == "x":
		return (xcount-ocount)
	else:
		return (ocount-xcount)
def negamax(board, token):
	token = token.lower()
	
	lm = moves(board, token.lower())
	if token.lower() == "o":
		enemy = "x"
	else:
		enemy = "o"
	om = moves(board, enemy)
	if not om and not lm:
		return [evalBoard(board, token)]
	elif not lm:
		nm = negamax(board, enemy) + [-1]
		return [-nm[0]] + nm[1:]
	nmList = sorted([negamax(move(board, mv, token.lower()), enemy)+[mv] for mv in lm])
	best = nmList[0]
	return [-best[0]] + best[1:]

def negamaxTerminal(brd, token, improvable, hardBound):
	if token == "x":
		enemy = "o"
	else:
		enemy = "x"
	lm = moves(brd, token)
	if not lm:
		lm1 = moves(brd, enemy)
		if not lm1:
			return [evalBoard(brd, token), -3]
		nm = negamaxTerminal(brd, enemy, -hardBound, -improvable) + [-1]
		return [-nm[0]] + nm[1:]
	best = []
	newHB = -improvable
	for mv in lm:
		nm = negamaxTerminal(move(brd, mv, token), enemy, -hardBound, newHB) + [mv]
		if not best or nm[0]<newHB:
			best = nm
			if nm[0]<newHB:
				newHB = nm[0]
				if -newHB>hardBound:
					return [-best[0]] + best[1:]
	return [-best[0]] + best[1:]
def main():
	arg, turn = sys.argv[1].lower(), sys.argv[2].lower()
	prnt(arg)
	print("Possible moves ", end="", flush= True)
	print(moves(arg, turn))
	dotCount = 0
	for x in arg:
		if x==".":
			dotCount+=1
	print("My Heuristic move is ", end="", flush=True)
	print(smartMove(arg, turn))
	print("Negamax ", end="", flush=True)
	mv = negamaxTerminal(arg, turn, -65, 65)
	print(mv)

class Strategy():
	def best_strategy(self, board, player, best_move, stilLrunning):
		brd = ''.join(board).replace('?', '').replace('@', 'x')
		token = "x" if player == '@' else 'o'
		dotCount = 0
		for x in brd:
			if x==".":
				dotCount+=1
		mv = smartMove(brd, token)
		mv1 = 11 + (mv//8)*10 + (mv%8)
		best_move.value = mv1
		mv = negamaxTerminal(brd, token, -65, 65)[-1]
		mv1 = 11 + (mv//8)*10 + (mv%8)
		best_move.value = mv1
		
if __name__ == "__main__":
	main()



"""
movesList = []
if len(sys.argv)<2:
	arg = "."*27 + "ox" + "."*6 + "xo" + "."*27
	turn = "x"
elif len(sys.argv[1]) == 64:
	arg = sys.argv[1]
	if len(sys.argv)>2:
		if sys.argv[2].lower() == "x" or sys.argv[2].lower() == "o":
			turn = sys.argv[2].lower()
			for x in sys.argv[3:]:
				movesList.append(x)
		else:
			temp = len([x for x in arg if x=="."])
			if temp%2==0:
				turn = "x"
			else:
				turn = "o"
			for x in sys.argv[2:]:
				movesList.append(x)
	else:
		temp = len([x for x in arg if x=="."])
		if temp%2==0:
			turn = "x"
		else:
			turn = "o"
elif sys.argv[1].lower() == "x" or sys.argv[1].lower() == "o":
	arg = "."*27 + "ox" + "."*6 + "xo" + "."*27
	turn = sys.argv[1].lower()
	for x in sys.argv[2:]:
		movesList.append(x)
else:
	arg = "."*27 + "ox" + "."*6 + "xo" + "."*27
	turn = "x"
	temp = len([x for x in arg if x=="."])
	if temp%2==0:
		turn = "x"
	else:
		turn = "o"
	for x in sys.argv[1:]:
		movesList.append(x)
prnt(arg)
print(arg + " " + score(arg))
print("")
compilation = []
for x in movesList:
	if x[0].lower() in conversion:
		x = conversion[x[0].lower()] + (int(x[1])-1)*8
	compilation.append(x)
	check = move(arg, int(x), turn)
	if check:
		arg = check
		print(turn + "-->" + str(x))
		prnt(arg)
		print(arg + " " + score(arg))
		print("")
	else:
		turn = swap(turn)
		check = move(arg, int(x), turn)
		if check:
			arg = check
			print(turn + "-->" + str(x))
			prnt(arg)
			print(arg + " " + score(arg))
			print("")
	turn = swap(turn)"""
