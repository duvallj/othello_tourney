import sys, random

dN={0: {8, 1, 9}, 1: {0, 9, 2, 10}, 2: {1, 3, 9, 10, 11}, 3: {2, 4, 10, 11, 12}, 4: {3, 5, 11, 12, 13}, 
5: {4, 6, 12, 13, 14}, 6: {5, 7, 13, 14, 15}, 7: {14, 6, 15}, 8: {16, 0, 9, 17}, 9: {0, 1, 2, 8, 10, 17, 18}, 
10: {1, 2, 3, 9, 11, 17, 18, 19}, 11: {2, 3, 4, 10, 12, 18, 19, 20}, 12: {3, 4, 5, 11, 13, 19, 20, 21}, 13: {4, 5, 6, 12, 14, 20, 21, 22}, 
14: {5, 6, 7, 13, 15, 21, 22, 23}, 15: {22, 7, 6, 14, 23}, 16: {24, 8, 25, 17, 9}, 17: {8, 9, 10, 16, 18, 25, 26}, 18: {9, 10, 11, 17, 19, 25, 26, 27}, 
19: {10, 11, 12, 18, 20, 26, 27, 28}, 20: {11, 12, 13, 19, 21, 27, 28, 29}, 21: {12, 13, 14, 20, 22, 28, 29, 30}, 22: {13, 14, 15, 21, 23, 29, 30, 31}, 
23: {30, 15, 14, 22, 31}, 24: {32, 16, 33, 25, 17}, 25: {33, 34, 16, 17, 18, 24, 26}, 26: {33, 34, 35, 17, 18, 19, 25, 27}, 
27: {34, 35, 36, 18, 19, 20, 26, 28}, 28: {35, 36, 37, 19, 20, 21, 27, 29}, 29: {36, 37, 38, 20, 21, 22, 28, 30}, 30: {37, 38, 39, 21, 22, 23, 29, 31}, 
31: {38, 23, 22, 30, 39}, 32: {40, 24, 41, 25, 33}, 33: {32, 34, 41, 42, 24, 25, 26}, 34: {33, 35, 41, 42, 43, 25, 26, 27}, 
35: {34, 36, 42, 43, 44, 26, 27, 28}, 36: {35, 37, 43, 44, 45, 27, 28, 29}, 37: {36, 38, 44, 45, 46, 28, 29, 30}, 38: {37, 39, 45, 46, 47, 29, 30, 31}, 
39: {46, 31, 30, 38, 47}, 40: {48, 41, 32, 49, 33}, 41: {32, 33, 34, 40, 42, 49, 50}, 42: {33, 34, 35, 41, 43, 49, 50, 51}, 
43: {34, 35, 36, 42, 44, 50, 51, 52}, 44: {35, 36, 37, 43, 45, 51, 52, 53}, 45: {36, 37, 38, 44, 46, 52, 53, 54}, 
46: {37, 38, 39, 45, 47, 53, 54, 55}, 47: {38, 54, 39, 46, 55}, 48: {56, 49, 40, 57, 41}, 49: {40, 41, 42, 48, 50, 57, 58}, 
50: {41, 42, 43, 49, 51, 57, 58, 59}, 51: {42, 43, 44, 50, 52, 58, 59, 60}, 52: {43, 44, 45, 51, 53, 59, 60, 61}, 
53: {44, 45, 46, 52, 54, 60, 61, 62}, 54: {45, 46, 47, 53, 55, 61, 62, 63}, 55: {46, 62, 47, 54, 63}, 56: {48, 57, 49}, 
57: {56, 49, 48, 58, 50}, 58: {57, 50, 59, 51, 49}, 59: {58, 51, 50, 60, 52}, 60: {53, 51, 59, 52, 61}, 61: {62, 54, 60, 53, 52}, 
62: {55, 53, 61, 54, 63}, 63: {54, 62, 55}}
def jump(g, t, o):
   jumps = dict()
   for i in range(64):
      right=i+1
      left=i-1
      up=i-8
      down=i+8
      diagUR=i-7
      diagUL=i-9
      diagBL=i+7
      diagBR=i+9
      shoot = {}
      s, e = down, i + 16
      if i < 48:
         if g[s] == o:
            while e < 64:
               if g[e] == t:
                  break
               if g[e] == '.':
                  shoot[s] = e
                  break
               e = e + 8
   
      s, e = up, up - 8
      if i > 15:
         if g[s] == o:
            while e > -1:
               if g[e] == t:
                  break
               if g[e] == '.':
                  shoot[s] = e
                  break
               e = e - 8
   
      s, e = right, right + 1
      if s < 63:
         if s % 8 < 7:
            if g[s] == o:
               while e % 8 != 0:
                  if g[e] == t:
                     break
                  if g[e] == '.':
                     shoot[s] = e
                     break
                  e = e + 1
   
      s, e = left, left - 1
      if s % 8 > 0:
         if g[s] == o:
            while e % 8 != 7:
               if g[e] == t:
                  break
               if g[e] == '.':
                  shoot[s] = e
                  break
               e = e - 1
   
      s, e = diagUL, diagUL-9
      if i % 8 > 1:
         if i / 8 > 1:
            if g[s] == o:
               while e % 8 != 7:
                  if g[e] == t:
                     break
                  if g[e] == '.':
                     shoot[s] = e
                     break
                  e = e - 9
   
      j = diagUR - 7
      if i % 8 < 6:
         if i / 8 > 1:
            while j % 8 > i % 8 and j / 8 < i / 8:
               if g[j] == t:
                  break
               if g[j] == '.':
                  shoot[diagUR] = j
                  break
               j = j - 7
   
      j = i + 14
      if i % 8 > 1:
         if i / 8 < 6:
            while j % 8 < i % 8 and j / 8 > i / 8:
               if j > 63:
                  break
               if g[j] == t:
                  break
               if g[j] == '.':
                  shoot[diagBL] = j
                  break
               j += 7
   
      j = i + 18
      if i % 8 < 6:
         if i / 8 < 6:
            while j % 8 > i % 8 and j / 8 > i / 8:
               if j > 63:
                  break
               if g[j] == t:
                  break
               if g[j] == '.':
                  shoot[diagBR] = j
                  break
               j = j + 9
   
      jumps[i] = shoot
   return jumps
def mve(gameboard, index, turn, other, jumps):
   mvs = set()
   for i in dN[index]:
      if gameboard[i] == other:
         try:
            if gameboard[jumps.get(index)[i]] == '.':
               mvs.add(jumps.get(index)[i])
         except:
            continue
   return mvs
def allLegalMoves(board, t, o):
   total = set()
   for i in range(64):
      curr = board[i]
      if curr == t:
         currSet=mve(board, i, t, o, jump(board, t, o))
         total = total.union(currSet)
      #try
      #  total.remove(-1)
      #except:
      #  continue
   return total



switch = {"X":"O","O":"X","@":"o","o":"@"}
movement = {(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, -1), (-1, 1)}
d2rc = {8:(1, 0), -8:(-1, 0), 1:(0, 1), -1:(0, -1), 9:(1, 1), 7:(1, -1), -9:(-1, -1), -7:(-1, 1)}
rightSide = {7,15,23,31,39,47,55,63}
leftSide = {0,8,16,24,32,40,48,56}

def twoD(board): #good
   i=0
   while i<64:
      print(board[i] + " " + board[i + 1] + " " + board[i + 2] + " " + board[i + 3] + " " + board[i + 4] + " " + board[
         i + 5] + " " + board[i + 6] + " " + board[i + 7])
      i=i+8


def compMove(board, t, o): #update w/ val mve
   first = validMoves(board, t, o)
   second = set(first)

   cornerSquares = [0, 7, 56, 63]
   isCornerMove=False #check if any of the squares are corners, default is False
   for i in cornerSquares:
      if i in first:
         isCornerMove=True #switch to true if any of the possibleMoves are corners
   if isCornerMove==True: ################handle corners first
      soc = list()
      for i in cornerSquares:
         if i in first:
            soc.append(i) #append any of the corners to the list of corners "soc"
         else:
            if board[i] != t:
               xSquares = {0: {1, 8, 9}, 7: {6, 14, 15}, 56: {48, 49, 57}, 63:{54, 55, 62}}
               second = set(second) - set(xSquares[i]) #remove any of the adjacent squares because we don't want to give away a corner
      endIndex=len(soc) - 1
      randomInt=random.randint(0, endIndex) #return a random corner if there are multiple (no bias)
      randomCorner=list(soc)[randomInt]
      return randomCorner
   first = second

   for move in first: #all other remaning moves, "Safe edges"
      storage = makeMove(board, t, move) #play the move to see if it will connect to another corner
      store=move
      if move < 8: 
         store = move
         while store > 0 and storage[store - 1] == t:
            store = store - 1
         if store == 0:
            return move
         store = move
         while store < 7 and storage[store + 1] == t:
            store = store + 1
         if store == 7:
            return move
      elif move > 55:
         store = move
         while store > 56 and storage[store - 1] == t:
            store = store- 1
         if store == 56:
            return move
         store = move
         while store < 63 and storage[store + 1] == t:
            store = store + 1
         if store == 63:
            return move
      elif move % 8 == 0:
         store = move
         while store > 0 and storage[store - 8] == t:
            store = store- 8
         if store == 0:
            return move
         store = move
         while store < 56 and storage[store + 8] == t:
            store =store+ 8
         if store == 56:
            return move
      elif move % 8 == 7:
         store = move
         while store > 7 and storage[store - 8] == t:
            store = store- 8
         if store == 7:
            return move
         store = move
         while store < 63 and storage[store + 8] == t:
            store = store + 8
         if store == 63:
            return move
   for i in first:
      if i > 7:
         if i < 56:
            if i % 8 != 0 :
               if i % 8 != 7: 
                  return i

   randInt=random.randint(0, len(first) - 1) ##last case option
   randMove=list(first)[randInt]
   return randMove


def negamax(board, token, enemy): #good
    myMoves = validMoves(board, token, switch[token])
    numOfMyMoves= len(myMoves)
    oppMoves = validMoves(board, switch[token], token)
    haveMovesLeft=board.count('.') >= 1
    passingPlayers=(len(myMoves) + len(oppMoves))
    baseCase=not haveMovesLeft or passingPlayers==0
    if baseCase:
        return [evalBoard(board, token, 'o')]
    myPass=numOfMyMoves==0
    if myPass:
        temp = negamax(board, switch[token], token)
        temp1=[-temp[0]]
        temp2=temp[1:]
        return temp1+temp2
    best = sorted(negamax(makeMove(board[:], token, mve), enemy, token) + [mve] for mve in myMoves)[0]
    #best=sorted(best)
    temp1= [-best[0]]
    temp2= best[1:]
    combined=temp1+temp2
    return combined 

def evalBoard(board, token, enemy): #good
    myTokens=board.count(token)
    enemyTokens=board.count(switch[token])
    count=myTokens-enemyTokens 
    return count

def makeMove(board, token, move): #one line
    tempSet= {move}
    try:
      for i in movement:
        crow,ccol=i[0],i[1]
        toFlip=tempSet.union(alternate(board, token, move, crow, ccol))
      toFlip=tempSetf
    except:
      toFlip = tempSet.union(*[alternate(board, token, move, crow, ccol) for crow, ccol in movement])
      for i in toFlip:
          first=board[0:i]
          end=board[i+1:]
          toRet=first+token+end
          board = toRet
    return board

def validMoves(board, token, enemy): 
    try:
      set2=set()
      for k in range (len(board)):
        row, col = int(k/8), int(k%8) 
        for crow, ccol in movement:
          if board[94] == '.':
            if newJumps(board, row, col, crow, ccol, token): 
              set2.add(col + (8*row))
      if -1 in set2:
        set2.remove(-1)
      return set2

    except:
      set2= {(col + (8*row)) for crow, ccol in movement for row, col in (divmod(i, 8) for i in range(64) if board[i] == ".") if newJumps(board, row, col, crow, ccol, token)}
      return set2


def alternate(board, token, index, crow, ccol):
    toFlip = set() 
    startR, startC = int(index/8), int(index%8) 
    moveR= startR + crow 
    moveC= startC + ccol 
    inR=0 <= moveR < 8
    inC=0 <= moveC < 8
    enemyToken=switch[token]
    while inR and inC and board[moveC + (8*moveR)] == enemyToken:
        toFlip.add(moveC + (8*moveR))
        moveR = moveR + crow
        moveC = moveC + ccol
        inR=0 <= moveR < 8
        inC=0 <= moveC < 8
    validR= 0 <= moveR < 8
    validC= 0 <= moveC < 8
    isDiff=(abs(startR-moveR) > 1 or abs(startC-moveC) > 1)
    if validR and validC and board[moveC + (8*moveR)] == token and isDiff:
        return toFlip
    else:
        return {}

def newJumps(board, row, col, crow, ccol, token):
    moveR, moveC = row + crow, col + ccol
    inR= 0 <= moveR < 8
    inC= 0 <= moveC < 8
    while inR and inC and board[moveC + (8*moveR)] == switch[token]:
        moveR += crow
        moveC += ccol
        inR= 0 <= moveR < 8
        inC= 0 <= moveC < 8
    validR= 0 <= moveR < 8
    validC= 0 <= moveC < 8
    isDiff=(abs(row-moveR) > 1 or abs(col-moveC) > 1)
    torf=validR and validC and board[moveC + (8*moveR)] == token and isDiff
    return torf


def main(): #good
   try:
      board=sys.argv[1]
      board=board.upper()
   except:
      board='...........................OX......XO...........................'
   try:
      t=sys.argv[2]
      t=t.upper()
   except:
      if board.count('.') % 2 == 0:
         t = 'X'
      else:
         t = 'O'
   if t == 'X':
      o = 'O'
   else:
      o = 'X'

   twoD(board)
   print("Possible Moves: " + str(validMoves(board,t,o)))
   if board.count('.') <= 8:
      toRet = negamax(board, t, o)
      print("Heuristic : " + str(toRet[len(toRet)-1]))
      score = makeMove(board, t, toRet[-1]).count(t)
      print("NegaMax: " + str(toRet[0]) + " " + str(toRet[1:]))
   else:
      toRet=compMove(board, t, o)
      print("Hueristic: " + str(toRet))

officialFormat = [11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 31, 32, 33, 34, 35, 36, 37, 38, 
41, 42, 43, 44, 45, 46, 47, 48, 51, 52, 53, 54, 55, 56, 57, 58, 61, 62, 63, 64, 65, 66, 67, 68, 71, 72, 73, 74, 75, 
76, 77, 78, 81, 82, 83, 84, 85, 86, 87, 88]

class Strategy():
    def best_strategy(self, board, token, best_move, running):
        newBoard = ''.join(board).replace("?","")
        lm = validMoves(newBoard, token, switch[token])
        spot = officialFormat[compMove(newBoard, token, 'O')] 
        rand = list(lm)[0]
        none= spot==-1
        none2= rand==-1
        if none == -1:
            if not none2:
                best_move.value = rand
        else:
            best_move.value = spot
        depth = 1
        while(True):
            best_move.value = officialFormat[negamaxDepth(newBoard, token, depth)[-1]]
            depth=depth+1

def negamaxDepth(board, token, depth):
    turnMoves = validMoves(board, token, switch[token])
    numOfMyMoves=len(turnMoves)
    oppoMoves = validMoves(board, switch[token], token)

    noDepth=depth <= 0
    noEmptySpots=board.count('.') == 0
    bothPass=(len(turnMoves) + len(oppoMoves)) == 0
    if noDepth or noEmptySpots or bothPass: #base case, if there are no moves then return evalB
        return [evalBoard(board, token, switch[token])]

    noMoves=numOfMyMoves==0
    if noMoves:
        nm = negamax(board, switch[token], token)
        trump
        return [-nm[0]] + nm[1:]
    
    best = sorted(negamax(makeMove(board[:], token, mv), switch[token], token) + [mv] for mv in turnMoves)[0]
    p1=[-best[0]]
    p2=best[1:]
    combined=p1+p2
    return combined

def moveid(board, token, index, direction): 
    plusOrMinus=direction == -1 or direction == 1
    L=index in rightSide and (index+d) in leftSide
    R=index in leftSide and (index+d) in rightSide
    if plusOrMinus and L or R:
        return {-1}
    r = int(index/8)
    c = int(index%8) 
    changeR, changeC = d2rc[d][0], d2rc[d][1]
    delr, delC = r + changeR, c + changeC
    start = index + direction
    enemy=switch[token]

    inR= 0 <= delr < 8
    inC= 0 <= delc < 8
    while inR and inC and board[start] == enemy:
        start = start + direction
        delr = delr + changeR
        delc = delc + changeC
        inR= 0 <= delr < 8
        inC= 0 <= delc < 8
    dR = r - delr 
    dC = c - delc 

    inR= 0 <= delr < 8
    inC= 0 <= delc < 8
    available=board[start] == "."
    changed=(abs(dR) > 1 or abs(dC) > 1)
    if inR and inC and available and changed:
        return {start}
    else:
      return {-1}
    return{-1}


#class Strategy():
#  def best_strategy(self, board, player, best_move, still_running):
#    brd = ''.join(board).replace('?', '').replace('@', 'X')
#    token = "X" if player == '@' else 'O'
#    enemy = "O" if token == "X" else "X"
#    if brd.count('.') <= 64:
#      mv = negamax(brd, token, enemy)[-1]
    #else:
    #  mv = compMove(brd, token, enemy)
#    mv1 = 11 + (mv // 8) * 10 + (mv % 8)
#    best_move.value = mv1

main()





##submit code in courrier font 

'''
//Neil Kothari, Period 3

states=['Washington', 'Oregon', 'California', 'Idaho', 'Nevada', 'Montana', 'Wyoming', 'Utah', 'Arizona', 'Colorado', 'New mexico',
'North dakota', 'South dakota', 'Nebraska', 'Kansas', 'Oklahoma', 'Texas', 'Minnesota','Iowa','Missouri','Arkansas','Louisiana',
'Wisconsin','Illinois', 'Kentucky', 'Tennessee', 'Mississippi', 'Michigan', 'Indiana', 'Ohio', 'West virginia', 'Virginia', 
'North carolina', 'South carolina', 'Georgia', 'Alabama', 'Florida', 'Pennsylvania', 'Maryland', 'Delaware', 'New jersey',
'New york', 'Connecticut', 'Rhode island', 'Massachusetts', 'Vermont', 'New hampshire', 'Maine', 'Alaska', 'Hawaii']

abbreviations=['Wa', 'Or', 'Ca', 'Id', 'Nv', 'Mt', 'Wy', 'Ut', 'Az', 'Co', 'Nm', 'Nd', 'Sd', 'Ne','Ks','Ok','Tx','Mn','Ia','Mo',
'Ar','La','Wi','Il','Ky','Tn', 'Ms', 'Mi', 'In', 'Oh', 'Wv', 'Va', 'Nc', 'Sc', 'Ga', 'Al', 'Fl', 'Pa', 'Md', 'De', 'Nj', 'Ny', 
'Ct', 'Ri', 'Ma', 'Vt', 'Nh', 'Me', 'Al', 'Ak', 'Hi']

var adjacencyMatrix={
0:[1,3],
1:[0,2,3,4],
2:[1,4,8],
3:[0,1,4,5,6,7],
4:[1,3,2,7,8],
5:[3,6,11,12],
6:[5,3,7,9,13,12],
7:[3,4,8,9,6],
8:[2,4,7,10],
9:[6,7,10,15,14,13],
10:[7,9,8,15,16],
11:[5,12,17],
12:[11,5,6,13,18,17],
13:[12,18,19,14,9,6],
14:[9,13,15,19],
15:[9,14,19,20,16,10],
16:[10,15,20,21],
17:[11,12,18,22],
18:[17,12,13,19,23,22],
19:[18,13,14,15,20,25,24,23],
20:[19,15,16,21,26,25],
21:[16,20,26],
22:[17,18,23,27],
23:[22,18,19,24,28],
24:[19,23,28,29,30,31,25],
25:[19,24,20,26,35,34,32,31],
26:[20,21,25,35],
27:[22,28,29],
28:[23,27,29,24],
29:[27,28,24,37,30],
30:[31,38,24,29,37],
31:[30,38,24,25,32],
32:[31,25,34,33],
33:[32,34],
34:[32,25,35,33,36],
35:[25,26,34,36],
36:[34,35],
37:[29,30,38,39,40,41],
38:[30,37,39,31],
39:[38,40,37],
40:[41,37,39],
41:[45,44,42,40,37],
42:[44,43,41],
43:[44,42],
44:[45,46,41,42,43],
45:[41,46,44],
46:[44,45,47],
47:[46],
48:[],
49:[]
}


function getBorders(input)
{
    input=cleanInput(input)
    if (input.length==2)
    {
        if (abbreviations.indexOf(input)==-1)
            return 'None'
        return stateNums = adjacencyMatrix[abbreviations.indexOf(input)];
    }
    else
    {
        if (states.indexOf(input)==-1)
            return 'None'
        return stateNums = adjacencyMatrix[states.indexOf(input)];
    }
}

function getStateBorders(input)
{
    input=cleanInput(input)
    stateNums=getBorders(input, states, abbreviations, adjacencyMatrix)
    var toRet=[];
    for (i = 0; i < stateNums.length; i++) { 
        toRet[i]=states[stateNums[i]];
    }
    return toRet;
}
    


function doStatesBorder(state1, state2)
{
    state1=cleanInput(state1)
    state2=cleanInput(state2)
    if (state1.length==2)
        state1Num= abbreviations.indexOf(state1)
    else
        state1Num= states.indexOf(state1)
    if (state2.length==2)
        state2Num=abbreviations.indexOf(state2)
    else
        state2Num= states.indexOf(state2)
    
    if(adjacencyMatrix[state1Num].includes(state2Num))
    {
        return true
    }
    return false;
}

function cleanInput(input)
{
    //Fix capitalization
    cleanedInput=input.toLowerCase()
    cleanedInput=cleanedInput.charAt(0).toUpperCase()+cleanedInput.substring(1)
    
    //return statement
    return cleanedInput;
}



////////////////RUN AND INPUT STUFF HERE
console.log(
getStateBorders('ViRginia', states, abbreviations, adjacencyMatrix)
//doStatesBorder('Pennsylvania', 'OH', states, abbreviations, adjacencyMatrix)
)
'''