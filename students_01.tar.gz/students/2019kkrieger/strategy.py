#
#Kayla Krieger, Period 3
import sys
from random import choice
board = "...........................OX......XO..........................."
turn = "X"
if len(sys.argv) < 4:
    n = 14
else:
    n = sys.argv[3]

def addToDict(function):
    myDict = {}
    def newFunction(*args):
        if args in myDict:
            return myDict[args]
        else:
            val = function(*args)
            myDict[args] = val
            return val
    return newFunction

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?', '')
        mv = bestMove(brd, player, possibleMoves(brd, player))
        mv1 = 11 + (mv // 8)*10 + (mv % 8)
        best_move.value = mv1
        if brd.count(".") <= 8:
            mv = negamaxTerminal(brd, player, -65, 65)[-1]
            mv1 = 11 + (mv // 8)*10 + (mv % 8)
            best_move.value = mv1

def printBoard(board):
    for i in range(0, 64, 8):
        print(''.join(board[c] if c not in possibleMoves(board, turn) else "*" for c in range(i, i+8)))

def asteriskPrint(board):
    newBoard = board
    for i in possibleMoves(board, turn):
        newBoard = newBoard[:i] + "*" + newBoard[i+1:]
    printBoard(newBoard)

def whoseTurn(board):
    return "O" if board.count(".")%2 else "X"

def freePositions(board):
    return {i for i in range(len(board)) if board[i] == "."}

def opposite(ch):
    return {"X":"O", "O":"X", "o":"@", "@":"o"}[ch]

@addToDict
def possibleMoves(board, turn):
    validPositions = set()
    for index,value in enumerate(board):
        if value == turn:
            R,C = divmod(index, 8)
            #up
            r,c = R-1, C
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                r-=1
            if isValidPos(r, c) and board[r*8+c] == "." and R-r > 1:
                validPositions.add(r*8+c)

            #down
            r,c = R+1, C
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                r+=1
            if isValidPos(r, c) and board[r*8+c] == "." and r-R > 1:
                validPositions.add(r*8+c)

            #left
            r,c = R, C-1
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                c-=1
            if isValidPos(r, c) and board[r*8+c] == "." and C-c > 1:
                validPositions.add(r*8+c)

            #right
            r,c = R, C+1
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                c+=1
            if isValidPos(r, c) and board[r*8+c] == "." and c-C > 1:
                validPositions.add(r*8+c)

            #top left
            r,c = R-1, C-1
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                r-=1
                c-=1
            if isValidPos(r, c) and board[r*8+c] == "." and R-r > 1:
                validPositions.add(r*8+c)

            #top right
            r,c = R-1, C+1
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                r-=1
                c+=1
            if isValidPos(r, c) and board[r*8+c] == "." and R-r > 1:
                validPositions.add(r*8+c)

            #bottom left
            r, c = R+1, C-1
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                r+=1
                c-=1
            if isValidPos(r, c) and board[r*8+c] == "." and r-R > 1:
                validPositions.add(r*8+c)

            #bottom right
            r, c = R+1, C+1
            while isValidPos(r, c) and board[r*8+c] == opposite(turn):
                r+=1
                c+=1
            if isValidPos(r, c) and board[r*8+c] == "." and r-R > 1:
                validPositions.add(r*8+c)
    return validPositions

@addToDict
def makeMove(board, turn, pos):
    flips = set()
    finalBoard = ""
    if pos not in possibleMoves(board, turn):
        print("Invalid move")
        exit()
    else:
        board = board[:pos] + turn + board[pos+1:]
        R, C = divmod(pos, 8)
        tempFlips = set()

        #up
        r,c = R-1, C
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            r-=1
        if isValidPos(r, c) and board[r*8+c] == turn and R-r > 1:
            flips |= tempFlips
        tempFlips = set()

        #down
        r,c = R+1, C
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            r+=1
        if isValidPos(r, c) and board[r*8+c] == turn and r-R > 1:
            flips |= tempFlips
        tempFlips = set()

        #left
        r,c = R, C-1
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            c-=1
        if isValidPos(r, c) and board[r*8+c] == turn and C-c > 1:
            flips |= tempFlips
        tempFlips = set()

        #right
        r,c = R, C+1
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            c+=1
        if isValidPos(r, c) and board[r*8+c] == turn and c-C > 1:
            flips |= tempFlips
        tempFlips = set()

        #top left
        r,c = R-1, C-1
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            r-=1
            c-=1
        if isValidPos(r, c) and board[r*8+c] == turn and R-r > 1:
            flips |= tempFlips
        tempFlips = set()

        #top right
        r,c = R-1, C+1
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            r-=1
            c+=1
        if isValidPos(r, c) and board[r*8+c] == turn and R-r > 1:
            flips |= tempFlips
        tempFlips = set()

        #bottom left
        r, c = R+1, C-1
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            r+=1
            c-=1
        if isValidPos(r, c) and board[r*8+c] == turn and r-R > 1:
            flips |= tempFlips
        tempFlips = set()

        #bottom right
        r, c = R+1, C+1
        while isValidPos(r, c) and board[r*8+c] == opposite(turn):
            tempFlips.add(r*8+c)
            r+=1
            c+=1
        if isValidPos(r, c) and board[r*8+c] == turn and r-R > 1:
            flips |= tempFlips
        tempFlips = set()
        finalBoard = ''.join(i if j not in flips else turn for j, i in enumerate(board))
    return finalBoard

def isValidPos(row, col):
    return -1 < row < 8 and -1 < col < 8

inp = [i.upper() for i in sys.argv[1:]]
if len(inp) == 2:
    board = inp[0]
    turn = inp[1]
elif len(inp) == 1:
    if len(inp[0]) > 1:
        board = inp[0]
        turn = whoseTurn(board)
    else:
        turn = inp[0]

print(board.lower())
print(turn)

xorc = {1,8,9,6,14,15,48,49,57,54,55,62}
edges = {1, 2, 3, 4, 5, 6, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 57, 58, 59, 60, 61, 62}
moves = possibleMoves(board, turn)
badMoves = moves & xorc

def safeEdge(board, turn, pos):
    R, C = divmod(pos, 8)
    newBoard = makeMove(board, turn, pos)

    def safe(dr, dc):
        r, c = R + dr, C + dc
        while isValidPos(r, c) and newBoard[r*8+c] == turn:
            r, c = r + dr, c + dc
        return not isValidPos(r, c)

    if pos in {1, 2, 3, 4, 5, 6, 57, 58, 59, 60, 61, 62}:
        if safe(0, -1) or safe(0, 1):
            return pos

    if pos in {8, 16, 24, 32, 40, 48, 15, 23, 31, 39, 47, 55}:
        if safe(1, 0) or safe(-1, 0):
            return pos

def bestMove(board, turn, moves):
    for i in moves:
        if i in {0, 7, 56, 63}:
            return i
    for i in moves:
        if i in edges and safeEdge(board, turn, i):
            return i
    if moves - badMoves - edges:
        return (moves - badMoves - edges).pop()
    elif moves - badMoves:
        return (moves-badMoves).pop()
    else: return moves.pop()

def negamaxTerminal(board, turn, improvable, hardBound):
    if not possibleMoves(board, turn):
        pm = possibleMoves(board, opposite(turn))
        if not pm: return [evalBoard(board, turn),  -3] #<-- game is over
        nm = negamaxTerminal(board, opposite(turn), -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = [] #what gets returned
    newHB = -improvable
    for pos in possibleMoves(board, turn):
        nm = negamaxTerminal(makeMove(board, turn, pos), opposite(turn), -hardBound, newHB) + [pos]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound: return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]

def evalBoard(board, turn):
    return board.count(turn) - board.count(opposite(turn))

def main():
    print("Output:")
    possMoves = possibleMoves(board, turn)
    asteriskPrint(board)
    print("Possible moves: {}".format(possMoves))
    print("My Heuristic move is: " + str(bestMove(board, turn, possMoves)))
    if board.count(".") <= n:
        nm = negamaxTerminal(board, turn, -65, 65)
        print("Negamax: {} and my move is {}".format(nm, nm[-1]))

if __name__ == "__main__":
    main()
