import random
import math
import numpy as np

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
OPPONENT = {BLACK: WHITE, WHITE: BLACK}
best = {BLACK: max, WHITE: min}
PLAYERS_WEIGHT = {BLACK: 1, WHITE: -1, EMPTY: 0, OUTER: 0}
corners = {11, 18, 81, 88}
weighted_matrix = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 20, -3,  11,   8,   8,  11, -3, 20,   0,
    0, -3, -10,  -4,  1,  1,  -4, -10, -3,   0,
    0,  11,  -4,  2,   2,   2,  2,  -4,  11,   0,
    0,   8,  1,   2,   -3,   -3,   2,  1,   8,   0,
    0,   8,  1,   2,   -3,   -3,   2,  1,   8,   0,
    0, 11, -4, 2, 2, 2, 2, -4, 11, 0,
    0, -3, -10, -4, 1, 1, -4, -10, -3, 0,
    0, 20, -3, 11, 8, 8, 11, -3, 20, 0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

class Node:
    def __init__(self, board, move, score=0.0):
        self.board = board
        self.move = move
        self.score = score
    def __lt__(self, other):
        return self.score<other.score

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = ""
        for r in range(0,10):
            for c in range(0,10):
                if r==0 or r==9 or c==0 or c==9:
                    board+="?"
                elif (r==4 and c==4) or (r==5 and c==5):
                    board+="o"
                elif (r==4 and c==5) or (r==5 and c==4):
                    board+="@"
                else:
                    board+="."
        return board

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        n = 10
        board = [board[i:i+n] for i in range(0, len(board), n)]
        return "\n".join(board)

    def opponent(self, player):
        """Get player's opponent."""
        if player==BLACK:
            return WHITE
        return BLACK

    def find_match(self, board, player, square, direction, make_move=False):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        count = 0
        square+=direction
        while(board[square]==self.opponent(player)):
            count+=1
            square+=direction

        if not make_move:
            if count>0 and board[square]==".":
                return square
        else:
            if count>0 and board[square]==player:
                return square
        return None

    def is_move_valid(self, board, player, move): # for ref?
        """Is this a legal move for the player?"""
        pass

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board = list(board)
        board[move] = player
        index = move
        for dir in DIRECTIONS:
            match = self.find_match("".join(board), player, move, dir, True)
            if match != None:
                index+=dir
                while(index!=match):
                    board[index] = player
                    index += dir
            index = move
        return "".join(board)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves = set()
        for r in range(1, 9):
            for c in range(1, 9):
                index = r * 10 + c
                if board[index]==player: # calls find match in every direction if there is a piece at given index
                    for dir in DIRECTIONS:
                        res = self.find_match(board, player, index, dir)
                        if res!=None:
                            moves.add(res)
        return list(moves)

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        for r in range(1, 9):
            for c in range(1, 9):
                index = r * 10 + c
                if board[index]==player: # calls find match in every direction if there is a piece at given index
                    for dir in DIRECTIONS:
                        res = self.find_match(board, player, index, dir)
                        if res!=None:
                            return True
        return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def convert(self, board):
        board = list(board)
        for x in range(len(board)):
            board[x] = PLAYERS_WEIGHT.get(board[x])
        return board

    def score(self, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        return board.count(BLACK) - board.count(WHITE)

    def weighted_score(self, board, player):
        board = self.convert(board)
        #if player==BLACK:
        return np.dot(board, weighted_matrix).sum() + random.random()
        #else:
            #return -1*np.dot(board, weighted_matrix).sum() + random.random()

    def corners(self, board, player):
        player_count = opp_count = 0
        if board[11] == player:
            player_count += 1
        elif board[11] == OPPONENT[player]:
            opp_count += 1
        if board[18] == player:
            player_count += 1
        elif board[18] == OPPONENT[player]:
            opp_count += 1
        if board[81] == player:
            player_count += 1
        elif board[81] == OPPONENT[player]:
            opp_count += 1
        if board[88] == player:
            player_count += 1
        elif board[88] == OPPONENT[player]:
            opp_count += 1
        return (player_count - opp_count)

    def stability(self, board, player, next_player):
        moves = self.get_valid_moves(board, next_player)
        count = 0
        for index in range(1,89):
            if board[index]==BLACK or board[index]==WHITE: #piece at index
                br = False
                for dir in DIRECTIONS:
                    new_index = index+dir
                    if board[new_index]==EMPTY and new_index in moves:
                        count-=1 # unstable piece
                        br = True
                        break
                    if not br:
                        count+=1
        return count

    def eval(self, board, player):
        piece_diff = num_corners = corner_poten = mobility = frontier = weight = 0
        weight = self.weighted_score(board, player)
        piece_diff = self.score(board)

        #calc frontier disks
        black = white = 0
        for r in range(1,9):
            for c in range(1,9):
                index = r*10+c
                if board[index]!=EMPTY:
                    for dir in DIRECTIONS:
                        new_index=index+dir
                        if new_index/10>0 and new_index/10<9 and new_index%10<9 and new_index%10>0 and board[new_index]==EMPTY:
                            if board[index]==BLACK:
                                black+=1
                            else:
                                white+=1
                            break
        frontier = -1*(black-white)

        #calc corners
        black=white=0
        if board[11]==BLACK: black+=1
        elif board[11]==WHITE: white+=1
        if board[18]==BLACK: black+=1
        elif board[18]==WHITE: white+=1
        if board[81]==BLACK: black+=1
        elif board[81]==WHITE: white+=1
        if board[88]==BLACK: black+=1
        elif board[88]==WHITE: white+=1
        corners = 25*(black-white)

        #calculate corner potential
        black=white=0
        if board[11]==EMPTY:
            if board[12]==BLACK: black+=1
            elif board[12]==WHITE: white+=1
            if board[21]==BLACK: black+=1
            elif board[21]==WHITE: white+=1
            if board[22]==BLACK: black+=1
            elif board[22]==WHITE: white+=1
        if board[18]==EMPTY:
            if board[17]==BLACK: black+=1
            elif board[17]==WHITE: white+=1
            if board[28]==BLACK: black+=1
            elif board[28]==WHITE: white+=1
            if board[27]==BLACK: black+=1
            elif board[27]==WHITE: white+=1
        if board[81]==EMPTY:
            if board[71]==BLACK: black+=1
            elif board[71]==WHITE: white+=1
            if board[82]==BLACK: black+=1
            elif board[82]==WHITE: white+=1
            if board[72]==BLACK: black+=1
            elif board[72]==WHITE: white+=1
        if board[88]==EMPTY:
            if board[78]==BLACK: black+=1
            elif board[78]==WHITE: white+=1
            if board[87]==BLACK: black+=1
            elif board[87]==WHITE: white+=1
            if board[77]==BLACK: black+=1
            elif board[77]==WHITE: white+=1
        corner_poten = -12.5*(black-white)

        #calc mobility
        black = len(self.get_valid_moves(board, BLACK))
        white = len(self.get_valid_moves(board, WHITE))
        mobility = black-white

        return (10*piece_diff)+(801.724*corners)+(382.026*corner_poten)+(78.922*mobility)+(74.396*frontier)+(10*weight)

    def eval2(self, board, player):
        moves = self.get_valid_moves(board, player)
        max_score = 0
        best_move = moves[0]
        for move in moves:
            score = 0
            new_board = self.make_move(board, player, move)
            mobility = len(self.get_valid_moves(new_board, player)) - len(self.get_valid_moves(new_board, OPPONENT[player]))
            score = score + self.weighted_score(new_board, player) + 30*self.corners(new_board, player) + 5*mobility + 25*self.stability(new_board, player, OPPONENT[player])
            if score > max_score:
                max_score = score
                best_move = move
        return best_move

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return (not self.has_any_valid_moves(board, player) and not self.has_any_valid_moves(board, self.opponent(player)))

    def moves_left(self, board):
        return board.count(".")

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board = node.board
        if depth == 0:
            return Node(board, node.move, self.weighted_score(board, player))

        # score all the children
        children = []
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player==None:
                c = Node(next_board, move, score = 1000*self.score(next_board, next_player))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth=depth-1).score
                children.append(c)

        winner = best[player](children)
        node.score = winner.score
        return winner

    def end_search(self, node, player, alpha, beta):
        board = node.board

        # score all the children
        children = []
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, move, score=self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.end_search(c, next_player, alpha, beta).score
                children.append(c)
            if player == BLACK:
                alpha = max(alpha, c.score)
            if player == WHITE:
                beta = min(beta, c.score)
            if alpha >= beta:
                break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def minmax_alpha_beta(self, node, player, depth, alpha, beta): #need to return node/move instead of score
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board = node.board
        if depth == 0:
            return Node(board, node.move, self.eval(board, player))

        # score all the children
        children = []
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_alpha_beta(c, next_player, depth - 1, alpha, beta).score
                children.append(c)
            if player==BLACK:
                alpha = max(alpha, c.score)
            if player==WHITE:
                beta = min(beta, c.score)
            if alpha >= beta:
                break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def minmax_strategy_ab(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_alpha_beta(Node(board, None), player, depth, -math.inf, math.inf).move

    def minmax_strategy(self, board, player, depth=3):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node(board, None), player, depth).move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def combo_strategy(self, board, player):
        if(self.moves_left(board)<=18): # 18 moves left, full search
            return self.best_strategy_2(board, player)
        else: # prioritize most moves
            moves = self.get_valid_moves(board, player) # gets all valid moves
            for index in corners: # if corner is available, take corner no matter what
                if index in moves:
                    return index
            max = 0
            toRet = 0
            for move in moves:
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                if next_player == None: # game ends, you win
                    return move
                num = len(self.get_valid_moves(next_board, player)) # maximize num moves
                if num>max:
                    max = num
                    toRet = move
            if toRet == 0:
                return self.random_strategy(board, player)
            return toRet

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 3
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy_ab(board, player, depth)
            depth += 1

    def best_strategy_2(self, board, player):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        moves_left = self.moves_left(board)
        best_move = None
        depth = 5
        if moves_left>16:
            best_move = self.eval2(board, player)
        else:
            best_move = self.end_search(Node(board, None), player, -math.inf, math.inf).move
        return best_move

    standard_strategy = best_strategy_2

###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        #strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        strategy = {BLACK: black.minmax_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    #game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()


