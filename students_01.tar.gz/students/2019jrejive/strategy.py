import sys, time, random
directions = [1, -1, 8, -8, 9, -9, 7, -7]
indexing_bits = [2**i for i in range(64)]
topLeft = 0b1000000000000000000000000000000000000000000000000000000000000000
topRight = 0b0000000100000000000000000000000000000000000000000000000000000000
bottomLeft = 0b0000000000000000000000000000000000000000000000000000000010000000
bottomRight = 0b0000000000000000000000000000000000000000000000000000000000000001
wrap_bits = {1:0b1111111011111110111111101111111011111110111111101111111011111110, -1:0b0111111101111111011111110111111101111111011111110111111101111111,
8:0b1111111111111111111111111111111111111111111111111111111111111111, -8:0b1111111111111111111111111111111111111111111111111111111111111111,
9:0b1111111011111110111111101111111011111110111111101111111011111110, -9:0b0111111101111111011111110111111101111111011111110111111101111111,
7:0b0111111101111111011111110111111101111111011111110111111101111111, -7:0b1111111011111110111111101111111011111110111111101111111011111110}
corners = 0b1000000100000000000000000000000000000000000000000000000010000001
bad = 0b0100001011000011000000000000000000000000000000001100001101000010
filled = 0b1111111111111111111111111111111111111111111111111111111111111111
center = 0b0000000000000000000000000001100000011000000000000000000000000000
edges = 0b1011110100000000100000011000000110000001100000010000000010111101
top = 0b1111111100000000000000000000000000000000000000000000000000000000
bottom = 0b0000000000000000000000000000000000000000000000000000000011111111
left = 0b1000000010000000100000001000000010000000100000001000000010000000
right = 0b0000000100000001000000010000000100000001000000010000000100000001
cache = {}

def legal_moves(x, o, token):
    x_bits, o_bits = int(x), int(o)
    moves = 0
    moved_dirs = set()
    if token == 'x':
        for d in directions:
            if d < 0:
                d = -d
                candidates = o_bits&((x_bits&wrap_bits[-d])<<d)
                while candidates != 0:
                    possible_move = ((x_bits|o_bits)^filled)&((candidates&wrap_bits[-d])<<d)
                    if possible_move: moved_dirs.add(d)
                    moves |= possible_move
                    candidates = o_bits&((candidates&wrap_bits[-d])<<d)
            else:
                candidates = o_bits&((x_bits&wrap_bits[d])>>d)
                while candidates != 0:
                    possible_move = ((x_bits|o_bits)^filled)&((candidates&wrap_bits[d])>>d)
                    if possible_move: moved_dirs.add(-d)
                    moves |= possible_move
                    candidates = o_bits&((candidates&wrap_bits[d])>>d)
    else:
        for d in directions:
            if d < 0:
                d = -d
                candidates = x_bits&((o_bits&wrap_bits[-d])<<d)
                while candidates != 0:
                    possible_move = ((o_bits|x_bits)^filled)&((candidates&wrap_bits[-d])<<d)
                    if possible_move: moved_dirs.add(d)
                    moves |= possible_move
                    candidates = x_bits&((candidates&wrap_bits[-d])<<d)
            else:
                candidates = x_bits&((o_bits&wrap_bits[d])>>d)
                while candidates != 0:
                    possible_move = ((o_bits|x_bits)^filled)&((candidates&wrap_bits[d])>>d)
                    if possible_move: moved_dirs.add(-d)
                    moves |= possible_move
                    candidates = x_bits&((candidates&wrap_bits[d])>>d)
    indeces = set()
    index = 0
    while moves:
        if moves & 1:
            indeces.add(1<<index)
        index+=1
        moves = moves >> 1
    return indeces, moved_dirs
def s2b(board): #string to bits
    x = "".join(['1' if i == 'x' else '0' for i in board])
    o = "".join(['1' if i == 'o' else '0' for i in board])
    x_bits = 0
    o_bits = 0
    power = 0
    for index in range(len(x)-1, -1, -1):
        x_bits += int(x[index])*2**power
        o_bits += int(o[index])*2**power
        power+=1
    return x_bits, o_bits
def change_board(x, o, move, token, dirs):
    # display(b2s(x_bits, o_bits))
    # print("Move:",format(move, '064b').index('1'))
    # print()
    x_bits, o_bits = int(x), int(o)
    if token == 'x':
        for d in dirs:
            changes = 0
            if d < 0:
                d = -d
                candidates = o_bits&((move&wrap_bits[-d])<<d)
                while candidates != 0:
                    changes |= candidates
                    if ((candidates&wrap_bits[-d])<<d) & x_bits:
                        o_bits -= changes
                        x_bits |= changes
                        break
                    candidates = o_bits&((candidates&wrap_bits[-d])<<d)
            else:
                candidates = o_bits&((move&wrap_bits[d])>>d)
                while candidates != 0:
                    changes |= candidates
                    if ((candidates&wrap_bits[d])>>d)&x_bits:
                        o_bits -= changes
                        x_bits |= changes
                        break
                    candidates = o_bits&((candidates&wrap_bits[d])>>d)
        x_bits |= move
    else:
        for d in dirs:
            changes = 0
            if d < 0:
                d = -d
                candidates = x_bits&((move&wrap_bits[-d])<<d)
                while candidates != 0:
                    changes |= candidates
                    if ((candidates&wrap_bits[-d])<<d)&o_bits:
                        x_bits -= changes
                        o_bits |= changes
                        break
                    candidates = x_bits&((candidates&wrap_bits[-d])<<d)
            else:
                candidates = x_bits&((move&wrap_bits[d])>>d)
                while candidates != 0:
                    changes |= candidates
                    if ((candidates&wrap_bits[d])>>d)&o_bits:
                        x_bits -= changes
                        o_bits |= changes
                        break
                    candidates = x_bits&((candidates&wrap_bits[d])>>d)
        o_bits |= move
    # display(b2s(x_bits, o_bits))
    return x_bits, o_bits
def b2s(x_bits, o_bits):
    x = "".join(['x' if i == '1' else '.' for i in format(x_bits, '064b')])
    o = "".join(['o'  if i == '1' else '.' for i in format(o_bits, '064b')])
    board = "".join(['x' if x[i] == 'x' else 'o' if o[i] == 'o' else '.' for i in range(len(x))])
    return board
def display(game):
    print("\n".join([game[i:i+8] for i in range(0, len(game),8)])+"\n")
def count(b):
    bits = int(b)
    score = 0
    while bits:
        score += 1
        bits = bits & (bits-1)
    return score
def potential_mobility(x_bits, o_bits, token):
    moves = 0
    if token == 'x':
        for d in directions:
            if d < 0:
                d = -d
                moves |= ((o_bits&wrap_bits[-d])<<d)&((x_bits|o_bits)^filled)
            else:
                moves |= ((o_bits&wrap_bits[d])>>d)&((x_bits|o_bits)^filled)
    else:
        for d in directions:
            if d < 0:
                d = -d
                moves |= ((x_bits&wrap_bits[-d])<<d)&((x_bits|o_bits)^filled)
            else:
                moves |= ((x_bits&wrap_bits[d])>>d)&((x_bits|o_bits)^filled)
    return count(moves)
def stability(x_bits, o_bits, token):
    stable, semi_stable, unstable = 0,0,0
    bits = x_bits if token == 'x' else o_bits
    enemy = o_bits if token == 'x' else x_bits
    for corner_bit in [indexing_bits[0], indexing_bits[7], indexing_bits[-1], indexing_bits[56]]:
        if not corner_bit&bits:
            continue
        for d in [1,-1,8,-8]:
            if d < 0:
                d = -d
                candidates = ((corner_bit&wrap_bits[-d])<<d)&bits
                while candidates:
                    # stable += 1
                    stable |= candidates
                    candidates = ((candidates&wrap_bits[-d])<<d)&bits
            else:
                candidates = ((corner_bit&wrap_bits[d])>>d)&bits
                while candidates:
                    # stable += 1
                    stable |= candidates
                    candidates = ((candidates&wrap_bits[d])>>d)&bits
    for start in indexing_bits:
        if not start&enemy: continue
        for d in directions:
            temp_unstable = 0
            if d < 0:
                d = -d
                candidates = ((start&wrap_bits[-d])<<d)&bits
                while candidates:
                    temp_unstable |= candidates
                    if ((candidates&wrap_bits[-d])<<d)&((x_bits|o_bits)^filled):
                        unstable |= temp_unstable
                        break
                    candidates = ((candidates&wrap_bits[-d])<<d)&bits
            else:
                candidates = ((start&wrap_bits[d])>>d)&bits
                while candidates:
                    temp_unstable |= candidates
                    if ((candidates&wrap_bits[d])>>d)&((x_bits|o_bits)^filled):
                        unstable |= temp_unstable
                        break
                    candidates = ((candidates&wrap_bits[d])>>d)&bits

    return stable, unstable, bits^(stable|unstable)
def frontiers(x_bits, o_bits, token):
    bits = x_bits if token == 'x' else o_bits
    periods = ((x_bits|o_bits)^filled)
    frontiers = 0
    for d in directions:
        if d < 0:
            d = -d
            frontiers |= ((bits&wrap_bits[-d])<<d)&bits
        else:
            frontiers |= ((periods&wrap_bits[d])>>d)&bits
    return frontiers
def wedges(x_bits, o_bits, semi_stable, token):
    wedges = 0
    enemy_token = [{'x','o'}-{token}][0].pop()
    bits = x_bits if token == 'x' else o_bits
    enemy = o_bits if token == 'x' else x_bits
    if topLeft&enemy:
        wedges |= ((top&bits)&semi_stable)
        wedges |= ((left&bits)&semi_stable)
    if topRight&enemy:
        wedges |= ((top&bits)&semi_stable)
        wedges |= ((right&bits)&semi_stable)
    if bottomLeft&enemy:
        wedges |= ((bottom&bits)&semi_stable)
        wedges |= ((left&bits)&semi_stable)
    if bottomRight&enemy:
        wedges |= ((bottom&bits)&semi_stable)
        wedges |= ((right&bits)&semi_stable)
    return wedges
def evaluation(x_bits, o_bits, token):
    score = 0
    num_periods = 64-count(x_bits|o_bits)
    if token == 'x':
        if count(x_bits) == 0:
            return float('-inf')
        if count(o_bits) == 0:
            return float('inf')
        if num_periods > 12:
            stable, unstable, semi_stable = stability(x_bits, o_bits, token)
            score += count(stable)*3
            score += count(semi_stable)
            score -= count(unstable)*5
            f = frontiers(x_bits, o_bits, token)
            score -= count(f)
            score += count(x_bits & corners)*10
            score -= count(o_bits&corners)*1000000000000000000
            score += count(potential_mobility(x_bits, o_bits, token))*5
            score += count(x_bits&center)*3
            score += count(wedges(x_bits, o_bits, semi_stable, token))*100
        else:
            score = (count(x_bits)-count(o_bits))
            return score
    else:
        if count(o_bits) == 0:
            return float('-inf')
        if count(x_bits) == 0:
            return float('inf')
        if num_periods > 12:
            stable, unstable, semi_stable = stability(x_bits, o_bits, token)
            score += count(stable)*3
            score += count(semi_stable)
            score -= count(unstable)*5
            f = frontiers(x_bits, o_bits, token)
            score -= count(f)
            score += count(o_bits & corners)*10
            score -= count(x_bits&corners)*1000000000
            score += count(potential_mobility(x_bits, o_bits, token))*5
            score += count(o_bits&center)*3
            score += count(wedges(x_bits, o_bits, semi_stable, token))*100
        else:
            score = (count(o_bits)-count(x_bits))
            return score
    return score
def negamax(bits, lm_tuple, token, depth): #returns [score, last_move, penultimate_move, move before that…. First move]
    x_bits, o_bits = int(bits[0]), int(bits[1])
    if depth == 0:
        return [evaluation(x_bits, o_bits, token)]
    lm, dirs = lm_tuple[0], lm_tuple[1]
    enemy_token = [{'x','o'}-{token}].pop().pop()
    if not lm and not legal_moves(x_bits, o_bits, enemy_token)[0]:
        return [evaluation(x_bits, o_bits, token)]
    if not lm:
        nm = negamax([x_bits, o_bits], legal_moves(x_bits, o_bits, enemy_token), enemy_token, depth-1)+[-1] #-1 indicates a pass
        return [-1*nm[0]]+nm[1:]
    nm = []
    for move in lm:
        changed_x, changed_o = change_board(x_bits, o_bits, move, token, dirs)
        nm.append(negamax([changed_x, changed_o], legal_moves(changed_x, changed_o, enemy_token), enemy_token, depth-1)+[move])
    best = min(nm)
    return [-best[0]]+best[1:]
def orderMoves(bits, lm, dirs, token):
    x_bits, o_bits = bits[0], bits[1]
    best = []
    while lm:
        nm = negamax([x_bits, o_bits], [lm, dirs], token, 2)
        lm = lm-{nm[-1]}
        best.append(nm[-1])
    return best
def negamaxTerminal(bits, token, lowerBound, upperBound, depth):
    x_bits, o_bits = bits[0], bits[1]
    if depth == 0:
        return [evaluation(x_bits, o_bits, token)]
    if (x_bits,o_bits,token) in cache:
        lm, dirs = cache[(x_bits,o_bits,token)]
    else:
        lm, dirs = legal_moves(x_bits, o_bits, token)
        cache[(x_bits,o_bits,token)] = (lm, dirs)
    enemy_token = [{'x','o'}-{token}].pop().pop()
    if not lm:
        if (x_bits,o_bits,enemy_token) in cache:
            lm, dirs = cache[(x_bits,o_bits,enemy_token)]
        else:
            lm, dirs = legal_moves(x_bits, o_bits, enemy_token)
        if not lm: return [evaluation(x_bits, o_bits, token), -3] #-3 to say game over
        nm = negamaxTerminal((x_bits, o_bits), enemy_token, -upperBound, -lowerBound, depth-1)+[-1]
        return [-nm[0]]+nm[1:]
    best = []
    newUB = -lowerBound
    for mv in lm:
        nm = negamaxTerminal(change_board(x_bits, o_bits, mv, token, dirs), enemy_token, -upperBound, newUB, depth-1)+[mv]
        if not best or nm[0]<newUB:
            best  = nm
            if nm[0] < newUB:
                newUB = nm[0]
                if -newUB > upperBound:
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]
class Strategy():
    # def __init__(self):
    #     start = time.time()
    #     while time.time() - start <= 10:
    #         pass
    def best_strategy(self, board, player, best_move, still_running):
        playerToToken = {"@":'x', "o":'o'}
        board = ((''.join(board)).replace('?','')).replace('@', 'x').lower()
        token = playerToToken[player.lower()].lower()
        x_bits, o_bits = s2b(board)
        if 64 - count(x_bits|o_bits) <= 11:
            mv = format(negamaxTerminal([x_bits, o_bits], token, float('-inf'), float('inf'), -1)[-1], '064b').index('1')
            best_move.value = 11+(mv//8)*10+(mv%8)
        else:
            depth = 4
            while True:
                mv = format(negamaxTerminal([x_bits, o_bits], token, float('-inf'), float('inf'), depth)[-1],'064b').index('1')
                move = 11+(mv//8)*10+(mv%8)
                best_move.value = move
                depth+=1
# board = sys.argv[1].lower()
# token = sys.argv[2].lower()
# x_bits, o_bits = s2b(board)
# if 64 - count(x_bits|o_bits) > 11:
#     mv = negamaxTerminal([x_bits, o_bits], token, float('-inf'), float('inf'), 4)
# else:
#     mv = negamaxTerminal([x_bits, o_bits], token, float('-inf'), float('inf'), -1)
# print(format(mv[-1], '064b').index('1'))
