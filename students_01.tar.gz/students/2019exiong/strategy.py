import sys
import random
import time

player = 'x'
pzl = "...........................ox......xo..........................."
playPos = -1
direction = [-9, -8, -7, -1, 1, 7, 8, 9]
noGo = {-9: [0, 1, 2, 3, 4, 5, 6 ,7 ,8 , 16, 24 ,32, 40, 48, 56], 
        -8: [0, 1, 2, 3, 4, 5, 6, 7],
        -7: [0, 1, 2, 3, 4, 5, 6 , 7, 15, 23, 31, 39, 47, 55, 63],
        -1: [0,8 , 16, 24 ,32, 40, 48, 56],
        1: [7, 15, 23, 31, 39, 47, 55, 63],
        7: [0,8 , 16, 24 ,32, 40, 48, 56, 57, 58, 59, 60, 61, 62, 63],
        8: [56, 57, 58, 59, 60,61, 62, 63],
        9: [7, 15, 23, 31, 39, 47, 55, 56, 57, 58, 59, 60, 61, 62, 63]}
conners = {0:{1,8,9}, 7:{6,14,15}, 56:{48,49,57}, 63:{54,55,62}}
conner_dir = {0:{-1, -8, -9}, 7:{1, -7, -8}, 56:{8, 7, -1}, 63:{9, 8, 1}}
conner_pos = {0,7,56,63}
edges_h = [1,2,3,4,5,6,57,58,59,60,61,62]
edges_v = [8,16,24,32,40,48,15,23,31,39,47,55]
playertable = {'o': 'x', 'x':'o'}


def showBoard(pzl):
    for r in range(0,64,8):
        row = ''
        #row = str(r//8 + 1) + ' '
        for ch in pzl[r:r+8]:
            row += ch + " "
        print(row)
    #print("  a b c d e f g h")

def legalMoves(pzl, player):
    lmoves = set()
    corners = set()    
    badNeighbors = set()
    #handle conner first
    for pos in conner_pos:
        if pzl[pos] == '.':
            for di in conner_dir[pos]:
                newpos = pos-di
                if  0<=newpos<=63 and pzl[newpos]== playertable[player]:
                    newpos = pos
                    if isLegalMove(pzl, player, newpos, di):
                        corners.add(newpos)
        if pzl[pos] != player:
            badNeighbors.update(conners[pos])
    if corners:
        return corners

    if  pzl.count('.')< pzl.count(playertable[player]):
        olist = set([i for i in range(64) if pzl[i] =='.'])
        olist = olist - conner_pos
        for opp in olist:
            for di in direction:
                newpos = opp-di
                if  0<=newpos<=63 and pzl[newpos]== playertable[player]:
                    newpos = opp
                    if isLegalMove(pzl, player, newpos, di):
                        lmoves.add(newpos)
    else:
        olist = set([i for i in range(64) if pzl[i] == playertable[player] ] )
        olist = olist - conner_pos
        corners = set()
        for opp in olist:
            for di in direction:
                newpos = di + opp
                if  0<=newpos<=63 and pzl[newpos]== ".":
                    if isLegalMove(pzl, player, newpos, di):
                        lmoves.add(newpos)
    if badNeighbors:
        betterMoves = lmoves - badNeighbors
        if betterMoves:
            return betterMoves
    return lmoves
          
def allLegalMoves(pzl, player):
    olist = [i for i in range(64) if pzl[i] == playertable[player] ]
    lmoves = set()
    for opp in olist:
        for di in direction:
            newpos = di + opp
            if 0<=newpos<=63 and pzl[newpos]== ".":
                if isLegalMove(pzl, player, newpos, di):
                    lmoves.add(newpos)
    return lmoves  
            
def isLegalMove(pzl, player, pos, di):
    cdir = 0 - di
    newpos = pos + cdir
    while 0<=newpos<=63:
        if newpos in noGo[di]:
            return False
        if pzl[newpos] == ".":
            return False
        if pzl[newpos] == player:
            return True
        newpos += cdir

def makeMove(pzl, player, pos):
    newPzl = pzl
    for dire in direction:
        if isLegalMove(pzl, player, pos, dire):
            flipPos = pos - dire
            while pzl[flipPos] != player:
                newPzl = newPzl[:flipPos] + player + newPzl[flipPos+1:]
                flipPos = flipPos - dire
    return  newPzl[:pos] + player + newPzl[pos+1:]


def isGoodEdge(pzl, player, pos, di):
    newpos = pos + di
#     if pzl[pos+di] == pzl[pos-di] == playertable[player]:
#         return True
    if pzl[newpos] == player:
        while 0<=newpos<=63:
            if newpos in noGo[di]:
                return pzl[newpos] == player
            if pzl[newpos] == '.':
                return True
            if pzl[newpos] != player:
                return False
            newpos += di
    else:
        oppoToken = playertable[player]
        canflip = True
        while 0<=newpos<=63:
            if newpos in noGo[di]:
                return pzl[newpos] == player
            if pzl[newpos] == '.':
                return False
            if pzl[newpos] == oppoToken and not canflip:
                return False
            elif pzl[newpos] == player and canflip:
                canflip = False
            else:
                newpos += di
                
def bestMove(pzl, player, moves):
    finalDiskCount = 0
    finalEnemyMobility = 1000
    finalPos = -1
    for pos in moves:
        
        tmpPzl = pzl
        newPzl = makeMove(tmpPzl, player, pos)
        enemyMobility =  len(allLegalMoves(newPzl, playertable[player]))
        diskCount = newPzl.count(player)
        if enemyMobility < finalEnemyMobility:
                finalDiskCount = diskCount
                finalEnemyMobility = enemyMobility
                finalPos = pos
        elif enemyMobility == finalEnemyMobility:
            if diskCount > finalDiskCount:
                finalDiskCount = diskCount
                inalPos = pos

    return finalPos

def bestMoves(pzl, player):
    corners = set()
    safeEdges = set()
    badEdges = set()
    moves = legalMoves(pzl, player)
    savedMoves = moves
     
    for pos in moves:
        isSafeEdge = False
        if pos in edges_h:
            for d in [-1, 1]:
                isSafeEdge = isGoodEdge(pzl, player, pos, d)
                if isSafeEdge: break
        elif pos in edges_v:
            for d in [-8, 8]:
                isSafeEdge = isGoodEdge(pzl, player, pos, d)
                if isSafeEdge: break
        if isSafeEdge:
            safeEdges.add(pos)
        if (pos in edges_h or pos in edges_v) and (not isSafeEdge):
            badEdges.add(pos)
    for pos in conners:
        if pzl[pos] == player:
            for nbr in conners[pos]:
                if nbr in moves:
                    safeEdges.add(nbr)
#     if safeEdges: 
#         return bestMove(pzl, player, safeEdges)
    moves = moves - badEdges
              
    if moves:
#         return bestMove(pzl, player, moves)
        return moves
#     if badEdges:
#         return bestMove(pzl, player, badEdges)

    return savedMoves

def evalBoard(pzl, token):
    return pzl.count(token) - (pzl.count(playertable[token]))

def negamax(board, token, levels):  
    lm = bestMoves(board, token)
    if levels == 0 or (len(lm)== 0 and len(bestMoves(board, playertable[token])) == 0): 
        return [len(allLegalMoves(board, token))]
    #lm = legalMoves(board, token)
    if not lm:
        nm = negamax(board, playertable[token], levels-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makeMove(board, token, move), playertable[token], levels-1) + [move] for move in lm])    
    best = nmList[0]
    return [-best[0]] + best[1:]

def negamaxTerminal(brd, token, improvable, hardBound):
    enemy = playertable[token]
    lm = legalMoves(brd, token)
    if not lm:
        lm = legalMoves(brd, enemy)
        if not lm: return [evalBoard(brd, token), -3]
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = [] #what gets returned
    newHB= -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(brd, token, mv), enemy, -hardBound, newHB) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                #pruning 
                if -newHB > hardBound: return [-best[0]]+best[1:]
    return [-best[0]] + best[1:]

if len(sys.argv) == 3:
    pzl = sys.argv[1].lower()
    player = sys.argv[2].lower()
elif len(sys.argv) == 2:
    if len(sys.argv[1]) == 64:
        pzl = sys.argv[1].lower()
        if pzl.count('.')%2:
            player = 'o'
        else:
            player = 'x'
    else:
        player = sys.argv[1].lower()

# else:
#     showBoard(pzl) 
#     print(legalMoves(pzl, player))
#     sys.exit()
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?','').replace('@','x')
        token = 'x' if player == '@' else 'o'
        if board.count('.') <=14:
            mv = negamaxTerminal(brd, token, -64, 64)
            best_move.value = 11 + (mv[-1]//8)*10 + (mv[-1]%8)
        else:
            mv = negamax(brd, token, 5)
            best_move.value = 11 + (mv[-1]//8)*10 + (mv[-1]%8)


def main():
    if pzl.count('.')<= 15:    
        nm = negamaxTerminal(pzl, player, -64, 64)#1, 3, 5, 7, 9   
        print('At level {} negamax gives {} and I pick move {}'.format(-1, nm, nm[-1]))
    else:
        nm = negamax(pzl, player, 5)
        print('At level {} negamax gives {} and I pick move {}'.format(-1, nm, nm[-1]))
#         print("Heuristic: ", bestMoves(pzl,player))

if __name__ == "__main__":
    main()
