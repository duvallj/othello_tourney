import random
import copy

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
VECTOR = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

VECTOR1 = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   20,   20,  20, -20, 120,   0,
    0, -20, -40, -30,  -30,  -30,  -30, -30, -20,   0,
    0,  20, -30,  50,  15,   15,  50, -30,  20,   0,
    0,   20, -30,  15,  0,   0,  15, -30,   20,   0,
    0,   20, -30,  15,  0,   0,  15, -30,   20,   0,
    0,  20, -30,  50,  15,   15,  50, -30,  20,   0,
    0, -20, -40, -30,  -30,  -30,  -30, -40, -20,   0,
    0, 120, -20,  20,   20,   20,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
SECONDMATRIX = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -50,  20,   20,   20,  20, -50, 120,   0,
    0, -50, -120,  -5,  -5,  -5,  -5, -120, -50,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   20,  -5,   3,   3,   3,   3,  -5,   20,   0,
    0,   20,  -5,   3,   3,   3,   3,  -5,   20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -50, -120,  -5,  -5,  -5,  -5, -120, -50,   0,
    0, 120, -50,  20,   20,   20,  20, -50, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
CORNERS = {11, 18, 81, 88}
EDGES = [12,13,14,15,16,17,21,31,41,51,61,71,82,83,84,85,86,87,28,38,48,58,68,78]
nonosquares = [12, 21, 22, 17, 27, 28, 71, 72, 82, 87, 78, 77]
FOURMIDDLE = [44,45,54,55]
OUTSIDEFOUR = [44 + N, 44 + W, 44 + NW, 45 + N, 45 + E, 45 + NE, 54 + W, 54 + S, 54 + SW, 55 + E, 55 + S, 55 + SE]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Node():
    def __init__(self, board, move, score = 0):
        self.board = board
        self.move = move
        self.score = score
    def __lt__(self, other):
        self.score < other.score

class Mobility():
    def __init__(self, board, move, mobility = 0):
        self.board = board
        self.move = move
        self.mobility = mobility
    def __lt__(self, other):
        self.mobility < other.mobility

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        outside = list(OUTER * 10)
        middle = list(OUTER + (8 * EMPTY) + OUTER)
        start = outside + (8 * middle) + outside
        start[44] = start[55] = WHITE
        start[45] = start[54] = BLACK
        startingboard = "".join(start)
        return startingboard

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        string = ""
        for x in range(0,100,10):
            string += board[x:x+10] + "\n"
        return string

    def opponent(self, player):
        """Get player's opponent."""
        if player == WHITE:
            return BLACK
        elif player == BLACK:
            return WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        pos = square + direction
        if board[pos] == self.opponent(player):
            while board[pos] != OUTER and board[pos] == self.opponent(player):
                pos += direction
                if board[pos] == player:
                    return square
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        legal = False
        for dir in DIRECTIONS:
            if self.find_match(board, player, move, dir) != None:
                legal = True
        return legal

    def update_string(self, board, var, player):
        newboard = copy.deepcopy(board)
        newboard = newboard[0:var] + player + newboard[var + 1::]
        return newboard

    def make_move(self, board, player, move): #make board into a list
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        if self.is_move_valid(board, player, move):
            board = list(board)
            for dir in DIRECTIONS:
                if self.find_match(board, player, move, dir) != None:
                    current = copy.deepcopy(move)
                    current = current + dir
                    while board[current] != player:
                        #board = self.update_string(board, current, player)
                        board[current] = player
                        current = current + dir
            board[move] = player
            #board = self.update_string(board, move, player)
            return "".join(board)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves = []
        squares = [x for x in range(10, 89) if board[x] == EMPTY]
        for squ in squares:
            for dir in DIRECTIONS:
                match = self.find_match(board, player, squ, dir)
                if match != None and match not in moves:
                    moves.append(match)
        return moves

    def countcoins(self, board, player):
        return [x for x in range(10 ,89) if board[x] == player]

    def protectcorners(self, board, player):
        moves = self.get_valid_moves(board, player)
        yesmoves = [x for x in moves if x not in nonosquares]
        if len(yesmoves) == 0:
            return moves
        else:
            return yesmoves

    def cornermoves(self, board, player):
        moves = self.get_valid_moves(board, player)
        corners = [x for x in moves if x in CORNERS or x in EDGES]
        outsidefour = [x for x in moves if x in OUTSIDEFOUR]
        if len(corners) != 0:
            return corners
        elif len(outsidefour) != 0:
            return outsidefour
        else:
            return moves

    def protectmiddle(self, board, player):
        pass

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        emptylist = []
        if self.get_valid_moves(board, player) == emptylist:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        else:
            return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        black = [x for x in range(10, 89) if board[x] == player]
        white = [x for x in range(10, 89) if board[x] == self.opponent(player)]
        return len(black) - len(white) + random.random()

    def weighted_score(self, board, player=BLACK):
        places = [x for x in range(10, 89) if board[x] == player]
        score = 0
        for x in places:
            score += VECTOR[x]
        return score + random.random()

    def otherweighted_score(self, board, player = BLACK):
        places = [x for x in range(10, 89) if board[x] == player]
        score = 0
        for x in places:
            score += SECONDMATRIX[x]
        return score + random.random()

    def numberofcoins(self, board):
        coins = [x for x in range(10, 89) if board[x] == BLACK or WHITE]
        return len(coins)

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.next_player(board, player) == None:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        nodeboard = Node(board, None)
        if depth == 0:
            return Node(board, None, self.weighted_score(board) + random.random() + self.mobilityheuristic(board) + self.cornerheuristic(board))
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                #c = Node(next_board, move, score = 1000*self.score(next_board))
                c = Node(next_board, move, score = 1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c.board, next_player, depth = depth-1).score
                children.append(c)

        winner = best[player](children)
        nodeboard.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth = 4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        winner = self.minmax_search(board, player, depth)
        return winner.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def alphabeta(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
                return Node(board, None, self.weighted_score(board) + random.random() + self.mobilityheuristic(board) + self.cornerheuristic(board))
        my_moves = self.get_valid_moves(board, player)
        other_moves = self.get_valid_moves(board, self.opponent(player))
        if best[player] == max:
            v = -float("inf")
            dummy = Node(board, None, v)
            for move in my_moves:
                #move = nodes.move
                dummy.move = move
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                c = Node(next_board, move)
                if next_player == None:
                    c.score = 1000 * self.score(next_board) + random.random()
                else:
                    c = self.alphabeta(c, next_player, depth-1, a, b)
                dummy = max(dummy, c)
                a = max(a, dummy.score)
                if b <= a:
                    break
            return dummy
        else:
            v = float("inf")
            dummy = Node(board, None, v)
            for move in my_moves:
                #move = nodes.move
                dummy.move = move
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                c = Node(next_board, move)
                if next_player == None:
                    c.score = 1000 * self.score(next_board) + random.random()
                else:
                    c = self.alphabeta(c, next_player, depth - 1, a, b)
                dummy = min(dummy, c)
                b = min(b, dummy.score)
                if b <= a:
                    break
            return dummy

    def alphabeta_strategy(self, board, player, depth = 4):
        winner = self.alphabeta(Node(board, None), player, depth, -float("inf"), float("inf"))
        return winner.move

    def mobilityheuristic(self, board):
        blackmoves = len(self.get_valid_moves(board, BLACK))
        whitemoves = len(self.get_valid_moves(board, WHITE))
        if blackmoves + whitemoves !=0:
            h = 100 * ((blackmoves - whitemoves) / (blackmoves + whitemoves))
        else:
            h = 0
        return h

    def cornerheuristic(self, board):
        blackcorners = len([x for x in CORNERS if board[x] == BLACK])
        whitecorners = len([x for x in CORNERS if board[x] == WHITE])
        if whitecorners + blackcorners !=0:
            h = 100 * ((blackcorners - whitecorners) / (blackcorners + whitecorners))
        else:
            h = 0
        return h

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = "".join(board)
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board, player, depth)
            #best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    def white_best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = "".join(board)
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.minmax_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.white_best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            # is move valid if not -- then forfeit
            #if ref.is_move_valid(board, player, move):
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        print(winner, black_score)
        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    #game = StandardPlayer()
    game = ParallelPlayer()
    game.play()

