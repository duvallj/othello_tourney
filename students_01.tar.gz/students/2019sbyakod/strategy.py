import sys
import random

sys.setrecursionlimit(1500)

class Strategy():
	def best_strategy(self, brd, p1, best_move, still_running):
		brd = ''.join(brd).replace('?', '').replace('@', 'x')
		tkn = "x" if p1 == '@' else "o"
		if(tkn == "x"):
			oppTkn = "o"
		else:
			oppTkn = "x"
		posMoves = posMoves2(brd, tkn, oppTkn)
		mv = mvPlayed(brd, tkn, posMoves)
		mv1 = 11 + (mv//8) * 10 + (mv%8)
		best_move.value = mv1

edges = {1, 2, 3, 4, 5, 6, 8, 16, 24, 32, 40, 48, 15, 23, 31, 39, 47, 55, 57, 58, 59, 60, 61, 62}
def displayBoard(brd):
 print(("\n"+brd[0:8] + "\n" + brd[8:16] + "\n" + brd[16:24] + "\n" + brd[24:32] + "\n" + brd[32:40]+ "\n" + brd[40:48] + "\n" + brd[48:56]+ "\n" + brd[56:64]))

def showBoard(brd, posMoves):
 
 lbrd = list(brd)
 for i in posMoves:
  lbrd[i] = "*"
 brd = ''.join(lbrd)
 print(brd)
 print("\n"+brd[0:8] + "\n" + brd[8:16] + "\n" + brd[16:24] + "\n" + brd[24:32] + "\n" + brd[32:40]+ "\n" + brd[40:48] + "\n" + brd[48:56]+ "\n" + brd[56:64])
def posMoves(brd):
	pmList = set()
	indT = [pos for pos,  char in enumerate(brd) if char == nxtTkn]
	for y in {1, -1, -7, 7, 9, -9, 8, -8}:
		for x in indT:
			col = int(x % 8)
			row = x // 8
			cInd = x+y 
			if y in{-7, 1, 9}:
				col += 1
			elif y in{-9, -1, 7}:
				col -= 1
			while cInd < 64 and cInd > -1 and brd[cInd] == oppTkn and col > -1 and col < 8:
				cInd=cInd+y
				if y in{-7, 1, 9}:
					col += 1
				elif y in{-9, -1, 7}:
					col -= 1
				if cInd > 63 or cInd < 0 or col < 0 or col > 7:
					break
				if brd[cInd] == ".":
					pmList.add(cInd) 
					break

	return pmList

def posMoves2(brd, nxtTkn, oppTkn):
	pmList = set()

	indT = [pos for pos,  char in enumerate(brd) if char == nxtTkn]

	for y in {1, -1, -7, 7, 9, -9, 8, -8}:
		for x in indT:
			col = int(x % 8)
			row = x // 8
			cInd = x+y 
			if y in{-7, 1, 9}:
				col += 1
			elif y in{-9, -1, 7}:
				col -= 1
			while cInd < 64 and cInd > -1 and brd[cInd] == oppTkn and col > -1 and col < 8:
				cInd=cInd+y
				if y in{-7, 1, 9}:
					col += 1
				elif y in{-9, -1, 7}:
					col -= 1
				if cInd > 63 or cInd < 0 or col < 0 or col > 7:
					break
				if brd[cInd] == ".":
					pmList.add(cInd) 
					break

	return pmList
def needToBeFlipped(brd, ind):	
	fp = []
	col = int(ind % 8)
	for r in [1, -1, -7, 7, 9, -9, 8, -8]:
		cInd = ind
		cInd = cInd + r
		col = int(ind % 8)
		if r in[-7, 1, 9]:
			col += 1
		elif r in[-9, -1, 7]:
			col -= 1
		if cInd < 64 and cInd > -1 and col > -1 and col < 8 and brd[cInd] == oppTkn: 
			cInd = cInd + r
			if r in[-7, 1, 9]:
				col += 1
			elif r in[-9, -1, 7]:
				col -= 1
			while cInd < 64 and cInd > -1 and col > -1 and col < 8 and brd[cInd] == oppTkn:
				if r in[-7, 1, 9]:
					col += 1
				elif r in[-9, -1, 7]:
					col -= 1
				cInd = cInd + r
				if cInd > 63 or cInd < 0 or col < 0 or col > 7:
					break
			if cInd > 63 or cInd < 0 or col < 0 or col > 7:
				continue
			elif brd[cInd] == nxtTkn:
				while cInd != ind:
						cInd = cInd - r
						fp.append(cInd)
	while ind in fp:				
		fp.remove(ind)
	return fp

def needToBeFlipped2(brd, ind, nxtTkn, oppTkn):	
	fp = []
	col = int(ind % 8)
	for r in [1, -1, -7, 7, 9, -9, 8, -8]:
		cInd = ind
		cInd = cInd + r
		col = int(ind % 8)
		if r in[-7, 1, 9]:
			col += 1
		elif r in[-9, -1, 7]:
			col -= 1
		if cInd < 64 and cInd > -1 and col > -1 and col < 8 and brd[cInd] == oppTkn: 
			cInd = cInd + r
			if r in[-7, 1, 9]:
				col += 1
			elif r in[-9, -1, 7]:
				col -= 1
			while cInd < 64 and cInd > -1 and col > -1 and col < 8 and brd[cInd] == oppTkn:
				if r in[-7, 1, 9]:
					col += 1
				elif r in[-9, -1, 7]:
					col -= 1
				cInd = cInd + r
				if cInd > 63 or cInd < 0 or col < 0 or col > 7:
					break
			if cInd > 63 or cInd < 0 or col < 0 or col > 7:
				continue
			elif brd[cInd] == nxtTkn:
				while cInd != ind:
						cInd = cInd - r
						fp.append(cInd)
	while ind in fp:				
		fp.remove(ind)
	return fp

def flpr(brd, fp, nT, i):
	brd = brd[:i]+nT+brd[i+1:]
	for f in fp:
		brd = brd[:f]+nT+brd[f+1:]
	return brd

def evalBoard(brd,  p1,  otherp1): 
	return brd.count(p1)-brd.count(otherp1);

def evalBoard2(brd,  p1,  otherp1): 
	return len(posMoves2(brd, otherp1, p1));

def makeMove(brd,  p1,  i, otherp1):
	brd = flpr(brd, needToBeFlipped2(brd, i, p1, otherp1), p1, i)
	return brd;

def negaMax(brd,  p1,  otherp1,  lvls, legal, periods):
	legal = posMoves2(brd, p1, otherp1)
	legal2 = posMoves2(brd, otherp1, p1)

	lM  = set(legal)
	lM2 = set(legal2)
	sumL = len(lM) + len(lM2)
	if periods == 0 or sumL == 0: 
		return [evalBoard(brd,  p1,  otherp1)]
	
	if not lM: 
		nm = negaMax(brd,  otherp1,  p1,  lvls-1, legal, periods) + [-1]
		return [-nm[0]] + nm[1:]
	nmList = sorted([negaMax(makeMove(brd,  p1,  mv, otherp1),  otherp1, p1,  lvls-1 , lM, periods-1) + [mv] for mv in lM])
	bst = nmList[0]
	return [-bst[0]] + bst[1:]

def negaMax2(brd,  p1,  otherp1,  lvls, legal):
	legal = posMoves2(brd, p1, otherp1)
	legal2 = posMoves2(brd, otherp1, p1)

	lM  = set(removeCX(brd, legal, p1))
	lM2 = set(removeCX(brd, legal2, otherp1))
	sumL = len(lM) + len(lM2)
	if lvls == 0 or sumL == 0: 
		return [evalBoard(brd,  p1,  otherp1)]
	
	if not lM: 
		nm = negaMax2(brd,  otherp1,  p1,  lvls-1, legal) + [-1]
		return [-nm[0]] + nm[1:]
	nmList = sorted([negaMax2(makeMove(brd,  p1,  mv, otherp1),  otherp1, p1,  lvls-1 , lM) + [mv] for mv in lM])
	bst = nmList[0]
	return [-bst[0]] + bst[1:]

def removeCX(brd, posMoves, nxtTkn):
	lm = list(posMoves.intersection(set([1, 8, 9, 6, 14, 15, 48, 49, 57, 54, 55, 62])))
	lmk = posMoves.copy()
	lst = posMoves.copy()
	for l in lm:
		lmk.remove(l)

	if(len(lmk) != 0):
		if(1 in posMoves and brd[0] != nxtTkn):
			lst.remove(1)
		if(8 in posMoves and brd[0] != nxtTkn):
			lst.remove(8)
		if(9 in posMoves and brd[0] != nxtTkn):
			lst.remove(9)
		if(6 in posMoves and brd[7] != nxtTkn):
			lst.remove(6)
		if(14 in posMoves and brd[7] != nxtTkn):
			lst.remove(14)
		if(15 in posMoves and brd[7] != nxtTkn):
			lst.remove(15)
		if(48 in posMoves and brd[56] != nxtTkn):
			lst.remove(48)
		if(49 in posMoves and brd[56] != nxtTkn):
			lst.remove(49)
		if(57 in posMoves and brd[56] != nxtTkn):
			lst.remove(57)
		if(54 in posMoves and brd[63] != nxtTkn):
			lst.remove(54)
		if(55 in posMoves and brd[63] != nxtTkn):
			lst.remove(55)
		if(62 in posMoves and brd[63] != nxtTkn):
			lst.remove(62)
		return lst
	else:
		return posMoves

def mvPlayed(brd, nxtTkn, posMoves):
	if(nxtTkn == "x"):
		oppTkn = "o"
	else:
		oppTkn = "x"

	lst = removeCX(brd, posMoves, nxtTkn)
	l01 = list(posMoves.intersection(set([1, 2, 3, 4, 5, 6])))
	l02 = list(posMoves.intersection(set([8, 16, 24, 32, 40, 48])))
	l71 = l01[::-1]
	l72 = list(posMoves.intersection(set([15, 23, 31, 39, 47, 55])))
	l561 = l02[::-1]
	l562 = list(posMoves.intersection(set([57, 58, 59, 60, 61, 62])))
	l631 = l72[::-1]
	l632 = l562[::-1]

	str = "not found"
	dep = 8

	if(brd.count(".") > 8):
		if(0 in lst): 
			return(0)
			str = "found"
		elif(7 in lst):
			return(7)
			str = "found"
		elif(56 in lst):
			return(56)
			str = "found"
		elif(63 in lst):
			return(63)
			str = "found"
		elif(16 in lst and brd[8] == oppTkn and brd[24] == oppTkn):
			print("WEDGE")
			return(16)
			str = "found"
		elif(2 in lst and brd[1] == oppTkn and brd[3] == oppTkn):
			return(2)
			str = "found"
		elif(23 in lst and brd[15] == oppTkn and brd[31] == oppTkn):
			return(23)
			str = "found"
		elif(5 in lst and brd[4] == oppTkn and brd[6] == oppTkn):
			return(5)
			str = "found"
		elif(40 in lst and brd[32] == oppTkn and brd[48] == oppTkn):
			return(40)
			str = "found"
		elif(58 in lst and brd[57] == oppTkn and brd[59] == oppTkn):
			return(58)
			str = "found"
		elif(47 in lst and brd[55] == oppTkn and brd[39] == oppTkn):
			return(47)
			str = "found"
		elif(61 in lst and brd[60] == oppTkn and brd[62] == oppTkn):
			return(61)
			str = "found"
		else:
			if(brd[0] == nxtTkn):
				arg = 0
				for l in l01:
					for i in range(1, l):
						if brd[i] != oppTkn:
							arg = 1
							break
					if(arg == 1):
						break
					if(arg == 0):
						return(l)
						str = "found"
						strD = "done"
						break
			if(str == "not found"):
				if(brd[0] == nxtTkn):
					arg = 0
					for l in l02:
						for i in range(8, l, 8):
							if brd[i] != oppTkn:
								arg = 1
								break

						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(brd[7] == nxtTkn):
					arg = 0
					for l in l71:
						for i in range(l+1, 7):
							if brd[i] != oppTkn:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(brd[7] == nxtTkn):
					arg = 0
					for l in l72:
						for i in range(15, l, 8):
							if brd[i] != oppTkn:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(brd[56] == nxtTkn):
					arg = 0
					for l in l561:
						for i in range(l+8, 56, 8):
							if brd[i] != oppTkn:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(brd[56] == nxtTkn):
					arg = 0
					for l in l562:
						for i in range(57, l):
							if brd[i] != oppTkn:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(brd[63] == nxtTkn):
					arg = 0
					for l in l631:
						for i in range(l+8, 63, 8):
							if brd[i] != oppTkn:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				if(brd[63] == nxtTkn):
					arg = 0
					for l in l632:
						for i in range(l+1, 63):
							if brd[i] != oppTkn:
								arg = 1
								break
						if(arg == 1):
							break
						if(arg == 0):
							return(l)
							str = "found"
							strD = "done"
							break
			if(str == "not found"):
				lk = lst.copy()
				for s in edges:
					if(s in lk):
						lk.remove(s)
				lt = list(lk)
				if(len(lt) != 0):
					mv = negaMax2(brd,  nxtTkn,  oppTkn,  3, posMoves)
					return mv[len(mv)-1]
				else:
					la = lst.copy()
					ll = list(la)
					mv = negaMax2(brd,  nxtTkn,  oppTkn,  3, posMoves)
					return mv[len(mv)-1]

	else:
		mv = negaMax(brd,  nxtTkn,  oppTkn,  -1, posMoves, brd.count("."))
		return mv[len(mv)-1]


if len(sys.argv) == 3:
	brd = sys.argv[1].lower()
	nxtTkn = sys.argv[2].lower()

if len(sys.argv) == 2:
	brd = sys.argv[1].lower()
	if brd.count(".") % 2 == 0:
	 nxtTkn = "x"
	else:
	 nxtTkn = "o"
if len(sys.argv) == 1:
  brd = "...........................ox......xo...........................".lower()
  nxtTkn = "x"

if nxtTkn == "x":
		oppTkn = "o"
else:
		oppTkn = "x"

print(mvPlayed(brd, nxtTkn, posMoves2(brd, nxtTkn, oppTkn)))