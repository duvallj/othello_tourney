EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
#Sanjay Ramakrishnan
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
from Othello_Core import OthelloCore
import random
import math
class Strategy(OthelloCore):
    depthg = None
    bestpos = None
    def best_strategy(self, board, player, best_move, still_running):
        numempty = 0
        board1 = ''
        self.origplayer = player
        for x in board:
            board1 += x
            if x == EMPTY:
                numempty += 1
        if player == BLACK:
            opp = WHITE
        else:
            opp = BLACK
        lm = self.legalMoves(board1, player)
        # if numempty >= 5:
        if True:
            forbidden = set()
            for c in lm:
                if c in {11, 18, 81, 88}:   #if corner, pick it instantly
                    best_move.value = c
                    return
                if board[11] == EMPTY:
                    if c in {12, 21, 22}:
                        forbidden.add(c)
                if board[18] == EMPTY:
                    if c in {17, 27, 28}:
                        forbidden.add(c)
                if board[81] == EMPTY:
                    if c in {71, 72, 82}:
                        forbidden.add(c)
                if board[88] == EMPTY:
                    if c in {77, 78, 87}:
                        forbidden.add(c)
                boardasdf = board[:]
                nextboard = self.make_move(c, player, boardasdf)
                nextboard1 = ''
                for x in nextboard:
                    nextboard1 += x
                opplm = self.legalMoves(nextboard1, opp)
                for d in opplm:
                    if len(opplm) == 0:
                        best_move.value = c
                        return
                    if d in {11, 18, 81, 88}:   #if opponent has corner, avoid
                        forbidden.add(c)
            if len(lm - forbidden) == 0:
                best_move.value = random.choice(list(lm))
                return
            if self.bestpos == None:
                self.depthg = 4
                self.bestpos = 0
                while True:
                    self.ab(board, player, self.depthg, -pow(2, 150), pow(2, 150), True, forbidden)
                    best_move.value = self.bestpos
                    self.bestpos = None
                    self.depthg += 1
        # else:
        #     self.ab(board, player, 7, -pow(2, 150), pow(2, 150), True, set())
        #     best_move.value = self.bestpos
    def ab(self, board, player, depth, alpha, beta, maxing, forbidden):
        boardasdf = board[:]
        board1 = ''
        for x in board:
            board1 += x
        lm = self.legalMoves(board1, player)
        if player == BLACK:
            np = WHITE
        else:
            np = BLACK
        if depth == 0 or len(lm) == 0:
            return self.heuristic(board, self.origplayer)
        lm = lm - forbidden
        if maxing:
            v = -pow(2, 50)
            for c in lm:
                asdf = max(v, self.ab(self.make_move(c, player, boardasdf), np, depth - 1, alpha, beta, False, set()))
                if depth == self.depthg and asdf > v:
                    self.bestpos = c    #this keeps track of the best position
                v = asdf
                alpha = max(alpha, v)
                if beta <= alpha:
                    break
        else:
            v = pow(2, 50)
            for c in lm:
                v = min(v, self.ab(self.make_move(c, player, boardasdf), np, depth - 1, alpha, beta, True, set()))
                beta = min(beta, v)
                if beta <= alpha:
                    break
        return v

    def legalMoves(self, board, player):    #find legal moves -- returns list of ints (indices in string)
        puz = board.split(OUTER)
        puzzle = ''
        for p in puz:
            if p != '':
                puzzle += p
        myturn = player
        bpuzzle = [[],[],[],[],[],[],[],[]]
        legalmoves = set()
        for r in range(8):
            for c in range(8):
                bpuzzle[r].append(puzzle[8*r+c])
        for r in range(8):
            for c in range(8):
                if bpuzzle[r][c] == '.':
                    if myturn == '@':
                        b = []
                        for i in range(3):
                            for j in range(3):
                                if r-1+i >= 0 and c-1+j >= 0 and r-1+i < 8 and c-1+j < 8:
                                    if bpuzzle[r-1+i][c-1+j] == 'o':
                                        b.append((r-1+i, c-1+j))
                        if not len(b) == 0:
                            for p in b:
                                if p == (r-1, c-1):
                                    for x in range(25):
                                        if r-x > 0 and c-x > 0:
                                            if bpuzzle[r-1-x][c-1-x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c-1-x] == '.':
                                                break
                                elif p == (r-1, c):
                                    for x in range(25):
                                        if r-x > 0:
                                            if bpuzzle[r-1-x][c] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c] == '.':
                                                break
                                elif p == (r-1, c+1):
                                    for x in range(25):
                                        if r-x > 0 and c+x < 7:
                                            if bpuzzle[r-1-x][c+1+x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c+1+x] == '.':
                                                break
                                elif p == (r, c-1):
                                    for x in range(25):
                                        if c-x > 0:
                                            if bpuzzle[r][c-1-x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c-1-x] == '.':
                                                break
                                elif p == (r, c+1):
                                    for x in range(25):
                                        if c+x < 7:
                                            if bpuzzle[r][c+1+x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c+1+x] == '.':
                                                break
                                elif p == (r+1, c-1):
                                    for x in range(25):
                                        if r+x < 7 and c-x > 0:
                                            if bpuzzle[r+1+x][c-1-x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c-1-x] == '.':
                                                break
                                elif p == (r+1, c):
                                    for x in range(25):
                                        if r+x < 7:
                                            if bpuzzle[r+1+x][c] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c] == '.':
                                                break
                                elif p == (r+1, c+1):
                                    for x in range(25):
                                        if r+x < 7 and c+x < 7:
                                            if bpuzzle[r+1+x][c+1+x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c+1+x] == '.':
                                                break

                    else:
                        b = []
                        for i in range(3):
                            for j in range(3):
                                if r-1+i >= 0 and c-1+j >= 0 and r-1+i < 8 and c-1+j < 8:
                                    if bpuzzle[r-1+i][c-1+j] == '@':
                                        b.append((r-1+i, c-1+j))
                        if not len(b) == 0:
                            for p in b:
                                if p == (r-1, c-1):
                                    for x in range(0, 25, 1):
                                        if r-x > 0 and c-x > 0:
                                            if bpuzzle[r-1-x][c-1-x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c-1-x] == '.':
                                                break
                                elif p == (r-1, c):
                                    for x in range(25):
                                        if r-x > 0:
                                            if bpuzzle[r-1-x][c] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c] == '.':
                                                break
                                elif p == (r-1, c+1):
                                    for x in range(25):
                                        if r-x > 0 and c+x < 7:
                                            if bpuzzle[r-1-x][c+1+x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c+1+x] == '.':
                                                break
                                elif p == (r, c-1):
                                    for x in range(25):
                                        if c-x > 0:
                                            if bpuzzle[r][c-1-x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c-1-x] == '.':
                                                break
                                elif p == (r, c+1):
                                    for x in range(25):
                                        if c+x < 7:
                                            if bpuzzle[r][c+1+x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c+1+x] == '.':
                                                break
                                elif p == (r+1, c-1):
                                    for x in range(25):
                                        if r+x < 7 and c-x > 0:
                                            if bpuzzle[r+1+x][c-1-x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c-1-x] == '.':
                                                break
                                elif p == (r+1, c):
                                    for x in range(25):
                                        if r+x < 7:
                                            if bpuzzle[r+1+x][c] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c] == '.':
                                                break
                                elif p == (r+1, c+1):
                                    for x in range(25):
                                        if r+x < 7 and c+x < 7:
                                            if bpuzzle[r+1+x][c+1+x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c+1+x] == '.':
                                                break
        return legalmoves

    def heuristic(self, board, player): #"if you walk in on your friends playing Othello" -- work in progress
        #from the strategy website on blackboard, heuristic is a function of:
        #corners, mobility (center/frontier/useful moves) c-squares & x-squares, tempo, parity, stability
        if player == WHITE:
            opp = BLACK
        else:
            opp = WHITE
        c = f = p = cx = s = 0 #instantiate corner, frontier, pieces, c and x squares
        board1 = ''
        for x in board:
            board1 += x
        a = len(self.legalMoves(board1, player))
        b = len(self.legalMoves(board1, opp))
        if a == 0 and b == 0:
            for x in range(99):
                if board[x] == player:
                    p += 1
                elif board[x] == opp:
                    p -= 1
                return p * pow(2, 20) #if win, multiply by infinity, if lose, multiply by -infinity, if tie, 0
        for x in range(99):        #evaluate pieces and frontier
            if board[x] != OUTER:
                if board[x] == player:
                    p += 1
                elif board[x] == opp:
                    p -= 1
                if board[x] != EMPTY:
                    for c in {-11, -10, -9, -1, 1, 9, 10, 11}:
                        if board[x + c] == EMPTY:
                            if board[x] == player:
                                f += 1
                            elif board[x] == opp:
                                f -= 1
                        elif board[x + c] == OUTER:
                            if board[x] == player:
                                f -= 2  #the higher f is, the worse off we are
                            elif board[x] == opp:
                                f += 2
                        if self.find_bracket2(x, player, board, c) is None:
                            s -= 1
                        elif self.find_bracket2(x, opp, board, c) is None:
                            s += 1
        for x in {11, 18, 81, 88}:
            if board[x] == player:
                c += 1
            elif board[x] == opp:
                c -= 1
            else:
                for z in {-11, -10, -9, -1, 1, 9, 10, 11}:
                    if board[x + z] == player:
                        cx += 1
                    elif board[x + z] == opp:
                        cx -= 1
        m = a - b
        if a == 0:
            m -= 100000000000
        if b == 0:
            m += 100000000000
        return p + 200000000000000*c + -5000*cx + 1000*m + -75*f + 650*s
    def is_legal(self, move, player, board):
        return True
    def find_bracket(self, square, player, board, direction):#used for OthelloCore.make_move() -- overrides superclass
        curr = square + direction
        while(True):
            if board[curr] == player:
                return curr
            elif board[curr] == OUTER or board[curr] == EMPTY:
                return None
            else:
                curr = curr + direction
    def find_bracket2(self, square, player, board, direction):
        curr = square + direction
        if board[curr] == player:
            return curr
        elif board[curr] == EMPTY:
            return curr
        elif board[curr] == OUTER:
            return None
        else:
            curr = curr + direction

if __name__ == '__main__':  #for testing and debugging purposes
    from multiprocessing import Value
    bm = Value('i', 0)
    boardstr = '???????????.o@@oo..??@o@o..o.??@.@@....??o.@@@@..??@.......??........??........??@@@@@@..???????????'
    boardlistasdf = []
    for i in boardstr:
        boardlistasdf.append(i)
    print(Strategy().legalMoves(boardstr, BLACK))
    Strategy().best_strategy(boardlistasdf, BLACK, bm, True)
    print(bm)
