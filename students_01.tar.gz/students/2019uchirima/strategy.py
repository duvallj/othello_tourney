import random
import math
import time

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
NEXT = {BLACK: WHITE, WHITE: BLACK}
PRUNE_DICT = {}
SCORE_DICT = {}
VALID_DICT = {}

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

SQUARE_SCORE = [
	0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
	0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
	0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
	0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
	0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
	0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
	0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
	0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
	0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
	0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

#SQUARE_SCORE_WHITE = [-n for n in SQUARE_SCORE_BLACK]

class Node():
	def __init__(self, state, m=-1, s=None):
		self.board = state
		self.move = m
		self.score = s

	def __lt__(self, other):
		return self.score < other.score

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

	def __init__(self):
		pass

	def get_starting_board(self):
		"""Create a new board with the initial black and white positions filled."""
		return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

	def get_pretty_board(self, board):
		"""Get a string representation of the board."""
		return '%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s' % (board[11:19], board[21:29], board[31:39], board[41:49], board[51:59], board[61:69], board[71:79], board[81:89])

	def opponent(self, player):
		"""Get player's opponent."""
		return NEXT[player]

	def make_move(self, board, player, move):
		"""Update the board to reflect the move by the specified player."""
		# returns a new board/string
		for d in DIRECTIONS:
			i = int(move)
			temp = self.find_match(board, player, move, d)
			if temp is not None:
				while i is not temp:
					board = board[:i] + player + board[i + 1:]
					i += d
		return board

	def find_match(self, board, player, square, direction):
		"""
		Find a square that forms a match with `square` for `player` in the given
		`direction`.  Returns None if no such square exists.
		"""
		square += direction
		while board[square] != OUTER:
			if board[square] == player:
				return square
			if board[square] == EMPTY:
				return None
			square += direction
		return None

	def is_move_valid(self, board, player, move):
		"""Is this a legal move for the player?"""
		for d in DIRECTIONS:
			if board[move + d] == NEXT[player] and self.find_match(board, player, move, d) != None:
				return True
		return False

	def get_valid_moves(self, board, player):
		"""Get a list of all legal moves for player."""
		return [n for n in range(11, 89) if board[n] == EMPTY and self.is_move_valid(board, player, n)]

	def has_any_valid_moves(self, board, player):
		"""Can player make any moves?"""
		return len(self.get_valid_moves(board, player)) > 0

	def next_player(self, board, prev_player):
		"""Which player should move next?  Returns None if no legal moves exist."""
		if not self.has_any_valid_moves(board, prev_player) and not self.has_any_valid_moves(board, NEXT[prev_player]):
			return None
		else:
			if not self.has_any_valid_moves(board, NEXT[prev_player]):
				return prev_player
			else: return NEXT[prev_player]

	def score(self, board):
		"""Compute player's score (number of player's pieces minus opponent's)."""
		b, w = 0, 0
		for ch in board:
			if ch == BLACK:
				b += 1
			if ch == WHITE:
				w += 1
		return b - w

	def smart_score(self, board, player, mv):
		s = self.score(board)
		if player == WHITE:
			weight = SQUARE_SCORE_WHITE[mv]
			s *= weight
			if mv is 11 or mv is 18 or mv is 88 or mv is 81:
				s -= 100
			if mv is 12 or mv is 21 or mv is 22 or mv is 17 or mv is 27 or mv is 28 or mv is 71 or mv is 72 or mv is 82 or mv is 78 or mv is 77 or mv is 87:
				s += 1000
		elif player == BLACK:
			weight = SQUARE_SCORE_BLACK[mv]
			s *= weight
			if mv is 11 or mv is 18 or mv is 88 or mv is 81:
				s += 100
			if mv is 12 or mv is 21 or mv is 22 or mv is 17 or mv is 27 or mv is 28 or mv is 71 or mv is 72 or mv is 82 or mv is 78 or mv is 77 or mv is 87:
				s -= 1000
		return s

	def test_score(self, board, player):
		score = 0
		score += self.score(board)
		score += ((25 * self.num_corner(board, BLACK)) - (25 * self.num_corner(board, WHITE)))
		score += ((-12.5 * self.num_corner_adj(board, BLACK)) + (12.5 * self.num_corner_adj(board, WHITE)))
		score += ((10 * self.num_stable_pieces(board, BLACK)) - (10 * self.num_stable_pieces(board, WHITE)))
		score += self.score_weight(board)
		return score

	def score_weight(self, board):
		count = 0
		for x in range(0, len(board)):
			if board[x] == BLACK:
				count += SQUARE_SCORE[x]
			elif board[x] == WHITE:
				count -= SQUARE_SCORE[x]
		return count

	def num_stable_pieces(self, board, piece):
		count = 0
		if board[11] == piece:
			index = 11
			while board[index] == piece:
				count += 1
				index += E
			index = 11
			while board[index] == piece:
				count += 1
				index += S
		if board[18] == piece:
			index = 18
			while board[index] == piece:
				count += 1
				index += W
			index = 18
			while board[index] == piece:
				count += 1
				index += S
		if board[81] == piece:
			index = 81
			while board[index] == piece:
				count += 1
				index += N
			index = 81
			while board[index] == piece:
				count += 1
				index += E
		if board[88] == piece:
			index = 88
			while board[index] == piece:
				count += 1
				index += W
			index = 88
			while board[index] == piece:
				count += 1
				index += N
		return count

	def num_corner_adj(self, board, piece):
		count = 0
		if piece == board[12]: count += 1 #and EMPTY == board[11]: count += 1
		if piece == board[21]: count += 1 #and EMPTY == board[11]: count += 1
		if piece == board[22]: count += 1 #and EMPTY == board[11]: count += 1
		if piece == board[17]: count += 1 #and EMPTY == board[18]: count += 1
		if piece == board[27]: count += 1 #and EMPTY == board[18]: count += 1
		if piece == board[28]: count += 1 #and EMPTY == board[18]: count += 1
		if piece == board[71]: count += 1 #and EMPTY == board[81]: count += 1
		if piece == board[72]: count += 1 #and EMPTY == board[81]: count += 1
		if piece == board[82]: count += 1 #and EMPTY == board[81]: count += 1
		if piece == board[78]: count += 1 #and EMPTY == board[88]: count += 1
		if piece == board[77]: count += 1 #and EMPTY == board[88]: count += 1
		if piece == board[87]: count += 1 #and EMPTY == board[88]: count += 1
		return count

	def num_corner(self, board, piece):
		count = 0
		if board[11] == piece: count += 1
		if board[18] == piece: count += 1
		if board[81] == piece: count += 1
		if board[88] == piece: count += 1
		return count

	def game_over(self, board, player):
		"""Return true if player and opponent have no valid moves"""
		return self.next_player(board, player) is None
	
	### Monitoring players

	class IllegalMoveError(Exception):
		def __init__(self, player, move, board):
			self.player = player
			self.move = move
			self.board = board

		def __str__(self):
			return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)


	def alpha_beta_search(self, node, player, depth, alpha=float('-inf'), beta=float('inf')):
		# determine best move for player recursively
		# it may return a move, or a search node, depending on your design
		# feel free to adjust the parameters
		board = node.board
		best = {BLACK: max, WHITE: min}
		if depth is 0:
			if board.count(EMPTY) > 11:
				node.score = self.test_score(board, player)
			else:
				node.score = self.score(board)
			return node
		my_moves = self.get_valid_moves(board, player)
		if (board, player) in PRUNE_DICT:
			index = my_moves.index(PRUNE_DICT[(board, player)])
			my_moves[0], my_moves[index] = my_moves[index], my_moves[0]
		children = []
		for move in my_moves:
			next_board = self.make_move(board, player, move)
			next_player = self.next_player(next_board, player)
			if next_player is None:
				c = Node(next_board, move, 10000000000 * self.score(next_board))
				children.append(c)
			else:
				c = Node(next_board, move)
				bonus = 0
				if player == next_player and next_player == BLACK:
					bonus += 10000
				elif player == next_player and next_player == WHITE:
					bonus -= 10000
				if player == BLACK and (move is 11 or move is 18 or move is 81 or move is 88):
						bonus += 1000
				if player == WHITE and (move is 11 or move is 18 or move is 81 or move is 88):
						bonus -= 1000
				c.score = self.alpha_beta_search(c, next_player, depth - 1, alpha, beta).score + bonus
				children.append(c)
			if player == BLACK:
				alpha = max(alpha, c.score)
			elif player == WHITE:
				beta = min(beta, c.score)
			if alpha >= beta:
				PRUNE_DICT[(board, player)] = move
				break
		winner = best[player](children)
		node.score = winner.score
		return winner
	
	def alpha_beta_strategy(self, board, player, depth=5):
		return self.alpha_beta_search(Node(board), player, depth).move

	def random_strategy(self, board, player):
		return random.choice(self.get_valid_moves(board, player))

	def best_strategy(self, board, player, best_move, still_running):
		board = ''.join(board)
		depth = 4
		while True:
			best_move.value = self.alpha_beta_strategy(board, player, depth)
			depth += 1

	standard_strategy = alpha_beta_strategy

class Strategy1():

	def __init__(self):
		pass

	def get_starting_board(self):
		"""Create a new board with the initial black and white positions filled."""
		return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

	def get_pretty_board(self, board):
		"""Get a string representation of the board."""
		return '%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s' % (board[11:19], board[21:29], board[31:39], board[41:49], board[51:59], board[61:69], board[71:79], board[81:89])

	def opponent(self, player):
		"""Get player's opponent."""
		return NEXT[player]

	def make_move(self, board, player, move):
		"""Update the board to reflect the move by the specified player."""
		# returns a new board/string
		for d in DIRECTIONS:
			i = int(move)
			temp = self.find_match(board, player, move, d)
			if temp is not None:
				while i is not temp:
					board = board[:i] + player + board[i + 1:]
					i += d
		return board

	def find_match(self, board, player, square, direction):
		"""
		Find a square that forms a match with `square` for `player` in the given
		`direction`.  Returns None if no such square exists.
		"""
		square += direction
		while board[square] != OUTER:
			if board[square] == player:
				return square
			if board[square] == EMPTY:
				return None
			square += direction
		return None

	def is_move_valid(self, board, player, move):
		"""Is this a legal move for the player?"""
		for d in DIRECTIONS:
			if board[move + d] == NEXT[player] and self.find_match(board, player, move, d) != None:
				return True
		return False

	def get_valid_moves(self, board, player):
		"""Get a list of all legal moves for player."""
		return [n for n in range(11, 89) if board[n] == EMPTY and self.is_move_valid(board, player, n)]

	def has_any_valid_moves(self, board, player):
		"""Can player make any moves?"""
		return len(self.get_valid_moves(board, player)) > 0

	def next_player(self, board, prev_player):
		"""Which player should move next?  Returns None if no legal moves exist."""
		if not self.has_any_valid_moves(board, prev_player) and not self.has_any_valid_moves(board, NEXT[prev_player]):
			return None
		else:
			if not self.has_any_valid_moves(board, NEXT[prev_player]):
				return prev_player
			else: return NEXT[prev_player]

	def score(self, board):
		"""Compute player's score (number of player's pieces minus opponent's)."""
		b, w = 0, 0
		for ch in board:
			if ch == BLACK:
				b += 1
			if ch == WHITE:
				w += 1
		return b - w

	def smart_score(self, board, player, mv=0):
		s = self.score(board)
		if player == BLACK:
			weight = SQUARE_SCORE[mv]
		else:
			weight = -SQUARE_SCORE[mv]
		if player == WHITE:
			s = s - weight
			if mv is 11 or mv is 18 or mv is 88 or mv is 81:
				if s < 0:
					s *= 1000
				else:
					s *= -1000
		elif player == BLACK:
			s = s + weight
			if mv is 11 or mv is 18 or mv is 88 or mv is 81:
				if s < 0: 
					s *= 1000
		return s

	def game_over(self, board, player):
		"""Return true if player and opponent have no valid moves"""
		return self.next_player(board, player) is None
	
	### Monitoring players

	class IllegalMoveError(Exception):
		def __init__(self, player, move, board):
			self.player = player
			self.move = move
			self.board = board

		def __str__(self):
			return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

	################ strategies #################

	def alpha_beta_search(self, node, player, depth, alpha=float('-inf'), beta=float('inf')):
		# determine best move for player recursively
		# it may return a move, or a search node, depending on your design
		# feel free to adjust the parameters
		board = node.board
		best = {BLACK: max, WHITE: min}
		if depth is 0 or self.next_player(board, player) is None:
			node.score = self.smart_score(board, player, node.move)
			return node
		my_moves = self.get_valid_moves(board, player)
		children = []
		for move in my_moves:
			next_board = self.make_move(board, player, move)
			next_player = self.next_player(next_board, player)
			if next_player is None:
				c = Node(next_board, move, 100000 * self.score(next_board))
				children.append(c)
			else:
				c = Node(next_board, move)
				bonus = 0
				if player == next_player and next_player == BLACK:
					bonus += 100
				elif player == next_player and next_player == WHITE:
					bonus -= 100
				c.score = self.alpha_beta_search(c, next_player, depth - 1, alpha, beta).score + bonus
				children.append(c)
			if player == BLACK:
				alpha = max(alpha, c.score)
			elif player == WHITE:
				beta = min(beta, c.score)
			if alpha >= beta:
				break
		winner = best[player](children)
		node.score = winner.score
		return winner
	
	def alpha_beta_strategy(self, board, player, depth=5):
		return self.alpha_beta_search(Node(board), player, depth).move

	def best_strategy(self, board, player, best_move, still_running):
		board = ''.join(board)
		depth = 1
		while True:
			best_move.value = self.alpha_beta_strategy(board, player, depth)
			depth += 1

	standard_strategy = alpha_beta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
from multiprocessing import Value, Process
import os, signal
silent = False

#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

	def __init__(self, time_limit = 5):
		self.black = Strategy()
		self.white = Strategy1()
		self.time_limit = time_limit

	def play(self):
		ref = Strategy()
		print("play")
		board = ref.get_starting_board()
		player = BLACK

		print("Playing Parallel Game")
		strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
		while player is not None:
			best_shared = Value("i", -99)
			best_shared.value = -99
			running = Value("i", 1)

			p = Process(target=strategy(player), args=(board, player, best_shared, running))
			# start the subprocess
			t1 = time.time()
			p.start()
			# run the subprocess for time_limits
			p.join(self.time_limit)
			# warn that we're about to stop and wait
			running.value = 0
			time.sleep(0.01)
			# kill the process
			p.terminate()
			time.sleep(0.01)
			# really REALLY kill the process
			if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
			# see the best move it found
			move = best_shared.value
			if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
			if not silent: print(board, ref.get_valid_moves(board, player))
			# make the move
			board = ref.make_move(board, player, move)
			if not silent: print(ref.score(board))
			if not silent: print(ref.get_pretty_board(board))
			player = ref.next_player(board, player)

		print("Final Score %i." % ref.score(board), end=" ")
		print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
	game = ParallelPlayer(float(input("Enter time: ")))
	# game = StandardPlayer()
	game.play()


