import sys
from timeit import default_timer
import random
start = default_timer()
player_to_token = {'@': 'x', 'o': 'o'}
if len(sys.argv) == 3:
    brd = sys.argv[1].lower().replace('?', '').replace('@', 'x')
    play = sys.argv[2].lower().replace('@', 'x')
corner_to_cx = {0: [1, 8, 9], 7: [6, 14, 15], 56: [48, 49, 57], 63: [54, 55, 62]}
corner_to_c = {0: [1, 8], 7: [6, 14], 56: [48, 49], 63: [54, 55]}
corners = [0, 7, 56, 63]
total_edges = [k for k in range(64) if not (k+1) % 8 or not k % 8 or k < 8 or k > 55]


def matrix_print(string):
    print('\n'.join(string[h:h+8] for h in range(len(string)) if not h % 8))


def is_valid(game, token, spot):
    if spot >= len(game) or game[spot] != '.':
        return []
    op_token = 'x'
    if token == 'x':
        op_token = 'o'
    row = spot % 8
    col = spot//8
    list_co = []
    for x, y in [[0, 1], [1, 0], [-1, 0], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]:
        t_row, t_col = row+x, col+y
        if t_row >= 8 or t_row < 0 or t_col >= 8 or t_col < 0 or game[t_row+t_col*8] != op_token:
            continue
        while game[t_row+t_col*8] == op_token:
            t_row, t_col = t_row+x, t_col+y
            if t_row >= 8 or t_row < 0 or t_col >= 8 or t_col < 0:
                break
        if t_row >= 8 or t_row < 0 or t_col >= 8 or t_col < 0:
            continue
        elif game[t_row+t_col*8] != token:
            continue
        list_co.append((x, y))
    return list_co


def list_moves(arg_board, arg_player):
    valid_moves = []
    for i in range(len(arg_board)):
        if is_valid(arg_board, arg_player, i):
            valid_moves.append(i)
            arg_board = arg_board[:i]+"*"+arg_board[i+1:]
    return valid_moves


def board_eval(game, pl):
    op = 'x'
    if pl == 'x':
        op = 'o'
    return game.count(pl)-game.count(op)


def fill_spaces(game, token, spot):
    temp_board = game
    temp_board = temp_board[:spot] + token + temp_board[spot+1:]
    for x_dir, y_dir in is_valid(game, token, spot):
        row = spot % 8+x_dir
        col = spot//8+y_dir
        op_token = 'x'
        if token == 'x':
            op_token = 'o'
        while game[row+col*8] == op_token:
            if row >= 8 or row < 0 or col >= 8 or col < 0:
                break
            temp_board = temp_board[:row+col*8]+token+temp_board[row+col*8+1:]
            row, col = row+x_dir, col+y_dir
        if row >= 8 or row < 0 or col >= 8 or col < 0 or temp_board[row+col*8] != token:
            return False
    return temp_board


def safe_edge(game, spot, token):
    directions = is_valid(game, token, spot)
    op_token = 'x'
    if token == 'x':
        op_token = 'o'
    for x_dir, y_dir in directions:
        row = spot % 8+x_dir
        col = spot//8+y_dir
        while -1 < row+col*8 < 64 and game[row+col*8] == op_token:
            if row >= 8 or row < 0 or col >= 8 or col < 0:
                break
            row, col = row+x_dir, col+y_dir
        if game[row+col*8] == token and row+col*8 in corners:
            return True
        elif row+col*8 in total_edges:
            while -1 < row+col*8 < 64 and game[row+col*8] == token:
                if row >= 8 or row < 0 or col >= 8 or col < 0:
                    break
                elif row+col*8 in corners:
                    return True
                row, col = row+x_dir, col+y_dir
            if -1 < row+col*8 < 64 and game[row+col*8] == token and row+col*8 in corners:
                return True
    return False


def heuristic(board, player):
    z = list_moves(board, player)
    move = -1
    edges = [k for k in z if not (k+1) % 8 or not k % 8 or k < 8 or k > 55]
    for i in z:
        if i in corners:
            move = i
            break
        elif i in edges and safe_edge(board, i, player):
            move = i
        else:
            for f in corners:
                if board[f] == player:
                    for j in corner_to_c[f]:
                        if j in z:
                            move = j
    if move == -1:
        for t in corners:
            if board[t] != player:
                for u in corner_to_cx[t]:
                    if u in z and len(z) != 1:
                        z.remove(u)
        for i in z:
            for x, y in [[0, 1], [0, -1], [1, 0], [-1, 0]]:
                row = i % 8
                col = i//8
                row, col = row+x, col+y
                while -1 < row+col*8 < 64 and board[row+col*8] == player:
                    if row+col*8 in corners:
                        move = i
                        break
                    row, col = row+x, col+y
        for s in edges:
            if s in z and len(z) != 1:
                z.remove(s)
        if move == -1:
            move = random.choice(z)
    return move


def n_max(board, token, improvable, hard_bound):
    enemy = 'x'
    if token == 'x':
        enemy = 'o'
    lm = list_moves(board, token)
    if not lm:
        if not list_moves(board, enemy):
            return [board_eval(board, token), -3]
        nm = n_max(board, enemy, -hard_bound, -improvable) + [-1]
        return [-nm[0]]+nm[1:]
    best = []
    new_hb = -improvable
    for mv in lm:
        nm = n_max(fill_spaces(board, token, mv), enemy, -hard_bound, new_hb) + [mv]
        if not best or nm[0] < new_hb:
            best = nm
            if nm[0] < new_hb:
                new_hb = nm[0]
                if new_hb >= hard_bound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]


class Strategy():
   def best_strategy(self, board, player, best_move, still_running):
        board1 = ''.join(board).lower().replace('?', '').replace('@', 'x')
        player = player.replace('@', 'x')
        n = 11
        if board1.count('.') <= n:
            nl = n_max(board1, player, -65, 65)
            move = nl[-1]
            best_move.value = 11 + (move//8)*10+(move % 8)
        else:
            move = heuristic(board1, player)
            best_move.value = 11 + (move//8)*10+(move % 8)

def main():
    n = 13
    if brd.count('.') <= n:
        nl = n_max(brd, play, -65, 65)
        print("At level {}, nm gives {}".format(n, nl))
        print("and I pick {}".format(nl[-1]))
    else:
        print(heuristic(brd, play))


if __name__ == "__main__":
    main()
