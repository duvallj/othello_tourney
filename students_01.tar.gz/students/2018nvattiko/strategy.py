#Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, board, move, score=None):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self, other):
        return self.score < other.score


class Strategy():

    def __init__(self):
        self.board = self.get_starting_board

    def get_starting_board(self):
        border = OUTER * 10
        emptyrow = OUTER + EMPTY * 8 + OUTER
        wb = OUTER + EMPTY * 3 + WHITE + BLACK + EMPTY * 3 + OUTER
        bw = OUTER + EMPTY * 3 + BLACK + WHITE + EMPTY * 3 + OUTER

        return border + emptyrow * 3 + wb + bw + emptyrow * 3 + border

    def get_pretty_board(self, board):
        pretty_board = ""
        i = 10
        while i <= 100:
            pretty_board = pretty_board + board[i-10:i] + '\n'
            i = i + 10
        return pretty_board

    def opponent(self, player):
        if player == BLACK:
            return WHITE
        else:
            return BLACK

    def find_match(self, board, player, square, direction): #used to generate valid moves
        next_square = square + direction
        if next_square < 0 or next_square > 100:
            return None
        check = False
        while board[next_square] == self.opponent(player):
            check = True
            next_square = next_square + direction
        if board[next_square] == EMPTY and check:
            return next_square
        else:
            return None

    def is_move_valid(self, board, player, move):
        return move in get_valid_moves(board, player)

    def close_bracket(self, board, player, square, direction): #used for make move
        next_square = square + direction
        check = False
        while board[next_square] == self.opponent(player):
            check = True
            next_square = next_square + direction
        if board[next_square] == player and check:
            return next_square
        else:
            return None

    def make_move(self, board, player, move):
        new_board = list(board)
        new_board[move] = player
        for d in DIRECTIONS:
            m = self.close_bracket(board, player, move, d)
            if m != None:
                current = move + d
                while board[current] == self.opponent(player):
                    new_board[current] = player
                    current = current + d
        return ''.join(new_board)

    def get_valid_moves(self, board, player):
        valid_moves = set()
        index = 0
        for square in board:
            if square == player:
                for d in DIRECTIONS:
                    match = self.find_match(board, player, index, d)
                    if match != None:
                        valid_moves.add(match)
            index = index + 1
        return list(valid_moves)

    def has_any_valid_moves(self, board, player):
        return len(self.get_valid_moves(board, player)) != 0

    def next_player(self, board, prev_player):
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        else:
            return None

    def weighted_score(self, board, player = BLACK):
        original_weighted_matrix = [
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
        0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
        0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
        0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
        0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,]

        weighted_matrix = [
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0, 200, -20,  20,   5,   5,  20, -20, 200,   0,
        0, -20, -60,  -5,  -5,  -5,  -5, -60, -20,   0,
        0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
        0, -20, -60,  -5,  -5,  -5,  -5, -60, -20,   0,
        0, 200, -20,  20,   5,   5,  20, -20, 200,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,]
        player_score = 0
        opponent_score = 0
        count = 0

        for i in board:
            if i == player:
                player_score = player_score + weighted_matrix[count]
            if i == self.opponent(player):
                opponent_score = opponent_score + weighted_matrix[count]
            count = count + 1

        score = player_score - opponent_score + 5*random.random()

        if player == BLACK:
            return score
        else:
            return score*-1

    def score(self, board, player=BLACK):
        player_score = 0
        opponent_score = 0
        for i in board:
            if i == player:
                player_score = player_score + 1
            if i == self.opponent(player):
                opponent_score = opponent_score + 1
        return player_score - opponent_score + random.random()

    def game_over(self, board, player):
        return self.has_any_valid_moves(board, player) == False and self.has_any_valid_moves(board, self.opponent(player)) == False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        board = node.board
        if depth == 0 or self.game_over(board, player):
            return self.weighted_score(board, player)
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_board != None:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth = depth-1)
                children.append(c)

        if player == BLACK: winner = max(children)
        else: winner = min(children)

        node.score = winner.score
        return winner

    def alphabeta(self, node, player, alpha, beta, depth):
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board, player)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_board = ''.join(next_board)
            next_player = self.next_player(next_board, player)
            c = Node(next_board, move)
            if next_player is None:
                c = Node(next_board, move, score = 1000*self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alphabeta(c, next_player, alpha, beta, depth = depth-1).score
                children.append(c)

            if player == BLACK:
                best = max(children)
                alpha = max(best.score, alpha)
            else:
                best = min(children)
                beta = min(best.score, beta)

            if alpha >= beta:
                break

        return best

    def alphabeta_stategy(self, board, player, depth=5):
        root = Node(board, None)
        result = self.alphabeta(root, player, alpha = -math.inf, beta = math.inf, depth = 4)
        return result.move

    def minmax_strategy(self, board, player, depth=3):
        root = Node(board, None)
        result = self.minmax_search(root, player, depth)
        return result.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an example
            #best_move.value = self.random_strategy(board, player)
            best_move.value = self.alphabeta_stategy(board, player)
            depth += 1

    standard_strategy = alphabeta_stategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    #game =  ParallelPlayer(0.5)
    game = StandardPlayer()
    game.play()
