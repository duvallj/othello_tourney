import random
import time
from multiprocessing import Value
from multiprocessing import Process
import os
import signal

# import math

#    Othello Shell
#    P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}


# ------------------------------------------------------------
# -------------    -------------    -------------    ---------
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
# ------------------------------------------------------------
# ------------------------------------------------------------

class Strategy:
    def __init__(self):
        pass

    def get_starting_board(self):
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"

    def get_pretty_board(self, b):
        P = {"@": u"\u25CB", "o": u"\u25CF", ".": " "}  # B is for BLANK, F is for FILLED
        ins = "│ %s │ %s │ %s │ %s │ %s │ %s │ %s │ %s │"
        p = "┌───┬───┬───┬───┬───┬───┬───┬───┐"
        for i in range(1, 9):
            j = i*10
            p = p+"\n"+(ins % (P[b[j+1]], P[b[j+2]], P[b[j+3]], P[b[j+4]], P[b[j+5]], P[b[j+6]], P[b[j+7]], P[b[j+8]]))
            if i < 8:
                p = p+"\n"+"├───┼───┼───┼───┼───┼───┼───┼───┤"
            else:
                p = p+"\n"+"└───┴───┴───┴───┴───┴───┴───┴───┘"
        return p

    def opponent(self, player):
        if player == BLACK:
            return WHITE
        else:
            return BLACK

    def find_match(self, board, player, square, d):
        if board[square+d] == self.opponent(player):
            spot = square+d
            while board[spot] == self.opponent(player):
                spot = spot+d
            if board[spot] == player:
                return square
            else:
                return None
        return None

    def is_move_valid(self, board, player, move):
        for direction in DIRECTIONS:
            ans = self.find_match(board, player, move, direction)
            if ans is not None:
                return True
        # raise self.IllegalMoveError
        return False

    def make_move(self, board, player, move):
        b = list(board)
        matches = list()
        for direction in DIRECTIONS:
            if self.find_match(board, player, move, direction) is not None:
                matches.append(direction)
        if matches:
            b[move] = player
            for match in matches:
                m = move + match
                while b[m] != player:
                    b[m] = player
                    m = m + match
            return "".join(b)
        else:
            raise self.IllegalMoveError

    def get_valid_moves(self, board, player):
        moves = list()
        for i in range(11, 89):
            if board[i] == ".":
                for d in DIRECTIONS:
                    move = self.find_match(board, player, i, d)
                    if move is not None:
                        moves.append(move)
                        break
        return moves

    def has_any_valid_moves(self, board, player):
        if self.get_valid_moves(board, player):
            return True
        return False

    def next_player(self, board, prev_player):
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        else:
            return None

    def score(self, board, player=BLACK):  # BLACK is max strat, WHITE is min strat
        score = 0
        for i in range(11, 89):
            if board[i] == BLACK:
                score+=1
            elif board[i] == WHITE:
                score-=1
        return score

    def game_over(self, board, player):
        if not self.next_player(board, player):
            return True
        return False

    #   Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    # ///////////// strategies ///////////////

    def minmax_search(self, board, player, depth, m=0):
        strat = {BLACK: 1, WHITE: -1}
        best = {BLACK: max, WHITE: min}
        if depth == 0:
            return board, m, self.score(board, player)
        children = list()
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            pl = self.next_player(next_board, player)
            if pl == None:
                children.append((next_board, move, 10000*strat[player]))
            else:
                children.append((next_board, move, self.minmax_search(next_board, pl, depth-1, move)[2]))
        return best[player](children, key=lambda child: (child[2], random.random()))

    def minmax_strategy(self, board, player, depth=4):
        return self.minmax_search(board, player, depth)[1]

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        #  THIS IS the public function you must implement
        #  Run your best search in a loop and update best_move.value
        depth = 1
        while True:
            #  doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)  # self.random_strategy(board, player)
            depth += 1

    standard_strategy = random_strategy


# ------------------------------------------------------------
# The main game-playing code
# You can probably run this without modification
# ------------------------------------------------------------

# import time
# from multiprocessing import Value, Process
# import os, signal

silent = False

# ------------------------------------------------------------
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
# ------------------------------------------------------------
class StandardPlayer:
    def __init__(self):
        pass

    def play(self):
        #   create 2 opponent objects and one referee to play the game
        #   these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer:
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board)
        if black_score > 0:
            print("BLACK wins")
        elif black_score < 0:
            print("WHITE wins")
        else:
            print("TIE")

        return board, black_score


#################################################
# The main routine
################################################

if __name__ == "__main__":
    game = ParallelPlayer()
    game.play()
