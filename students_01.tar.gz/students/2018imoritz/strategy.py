
# coding: utf-8

# In[13]:

#Jan 12, 0952 version

import random
import math
import time
#### Othello Shell
#### P. White 2016-2018

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
##
M = [120, -20, 20, 5, -40, -5, -5, 15, 3, 3]
##
def makeMatrix(M):
    eM = [[M[0], M[1], M[2], M[3]], [M[4], M[5], M[6]], [M[7], M[8]], [M[9]]]
    qM = []
    qM.append([eM[0][0], eM[0][1], eM[0][2], eM[0][3]])
    qM.append([eM[0][1], eM[1][0], eM[1][1], eM[1][2]])
    qM.append([eM[0][2], eM[1][1], eM[2][0], eM[2][1]])
    qM.append([eM[0][3], eM[1][2], eM[2][1], eM[3][0]])
    
    for l in qM:
        l.extend(list(reversed(l)))
        l.append(0)
        l.insert(0,0)
    qM.extend(list(reversed(qM)))
    qM.insert(0, [0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    qM.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    return [item for sublist in qM for item in sublist]
##
##
WEIGHTING_MATRIX = makeMatrix(M)


# In[14]:

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    
    def __init__(self, board, move, score=None):
        self.board = board
        self.move = move
        self.score = score

class Strategy():
    
    def __init__(self):
        pass
    
    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        joined_board = " ".join(board)
        pretty_board = "\n".join([joined_board[i:i+20] for i in range(0, len(joined_board), 20)])
        return pretty_board

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        else:
            return BLACK
        
    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        #Initial Check of Neighboring Squares
        i = square+direction
        if board[i] != self.opponent(player):
            return None
        i = i+direction
        #
        while i >= 0 and i < len(board):
            if board[i] == EMPTY or board[i] == OUTER:
                break
            elif board[i] == player:
                return i
            i = i+direction
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] != EMPTY:
            return False   
        for direction in DIRECTIONS:
            if self.find_match(board, player, move, direction) is not None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        new_board = board[:move] + player + board[move+1:]
        for direction in DIRECTIONS:
            match = self.find_match(board, player, move, direction)
            if match is not None:
                for i in range(move, match, direction):
                    new_board = new_board[:i] + player + new_board[i+1:]
                    
        return new_board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves = []
        for i in range(len(board)):
            if self.is_move_valid(board, player, i):
                moves.append(i)
        return moves

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player)) > 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opponent = self.opponent(prev_player)
        if self.has_any_valid_moves(board, opponent):
            return opponent
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        else:
            return None

    def score(self, board, player=BLACK, weight=False):
        """Compute player's score (number of player's pieces minus opponent's)."""
        if weight:
            return self.weighted_score(board, player)
        else:
            return board.count(player)-board.count(self.opponent(player))
    
    def weighted_score(self, board, player=BLACK, matrix=WEIGHTING_MATRIX):
        opponent = self.opponent(player)
        board_vector = list(board)
        
        for index, item in enumerate(board_vector):
            if item == player:
                board_vector[index] = 1
            elif item == opponent:
                board_vector[index] = -1
            else:
                board_vector[index] = 0
        
        return sum([x*y for x,y in zip(board_vector, matrix)])
        
    
    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.next_player(board, player) is None:
            return True
        else:
            return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        board = node.board
        if depth == 0: return Node(board, None, self.score(board, weight=True)) 
        ###
        my_moves = self.get_valid_moves(board, player)
        ###
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            c = Node(next_board, move, None)
            #
            if next_player is None:
                s = 1000*self.score(next_board, weight=False)
            else:
                s = self.minmax_search(c, next_player, depth=depth-1).score
            #
            c.score = s
            children.append(c)
        ###
        if player == BLACK:
            winner = max(children, key = lambda x: x.score)
        if player == WHITE:
            winner = min(children, key = lambda x: x.score)
        
        node.score = winner.score
        return winner
    
    def alphabeta_search(self, node, player, depth, alpha, beta):
        board = node.board
        #
        if depth == 0:
            return Node(board, None, self.score(board, weight=True))
        
        my_moves = self.get_valid_moves(board, player)
        
        children = []
        if player == BLACK:
            v = -float("inf")
            for move in my_moves:
                #
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                #
                c = Node(next_board, move, None)
                if next_player is None:
                    v = 10000*self.score(next_board, weight=False)
                else:
                    v = max(v, self.alphabeta_search(c, next_player, depth-1, alpha, beta).score)
                c.score = v
                alpha = max(alpha, v)
                #
                children.append(c)
                if beta <= alpha:
                    break # β cut-off
            return max(children, key = lambda x: x.score)
        else:
            v = float("inf")
            for move in my_moves:
                #
                next_board = self.make_move(board, player, move)
                next_player = self.next_player(next_board, player)
                #
                c = Node(next_board, move, None)
                if next_player is None:
                    v = 10000*self.score(next_board, weight=False)
                else:
                    v = min(v, self.alphabeta_search(c, next_player, depth-1, alpha, beta).score)
                c.score = v
                beta = min(beta, v)
                #
                children.append(c)
                if beta <= alpha:
                    break # α cut-off
            return min(children, key = lambda x: x.score) #v
            
    def minmax_strategy(self, board, player, depth=2):
        c = Node(board, None, None)
        return self.minmax_search(c, player, depth).move ###??Dis rite?
    
    def alphabeta_strategy(self, board, player, depth=5):
        print(self.get_valid_moves(board, player))
        c = Node(board, None, None)
        return self.alphabeta_search(c, player, depth, -1*float("inf"), float("inf")).move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        if(isinstance(board, list)):
            board = "".join(board)
        ##
        best_move.value = self.random_strategy(board, player)
        ##
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board, player)
            depth += 1

    
    standard_strategy = alphabeta_strategy
    worse_strategy = random_strategy


# In[ ]:

###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False

#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self, verbose=True):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.worse_strategy}
        if verbose: print(ref.get_pretty_board(board))
        t_all = 0
        t1 = time.time()
        while player is not None:
            t1 = time.time()
            move = strategy[player](board, player)
            t2 = time.time()
            t_all = t_all+t2-t1
            row = int(move/10)
            col = move - row*10
            #print("Weighted score for player %s is %i" % (player, ref.weighted_score(board, player=player)))
            #print("Normal score for player %s is %i" % (player, ref.score(board, player=player)))
            board = ref.make_move(board, player, move)
            if(verbose):
                print("Player %s chooses %i" % (player, move))
                print("Move time: ", t2-t1)
                print(ref.get_pretty_board(board))
                print()
            player = ref.next_player(board, player)
        ###
        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))
        print("Game Time: ", t_all)


# In[ ]:


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self, verbose=True):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)
            ##
            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if verbose: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if verbose: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if verbose: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)
        ##
        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    #game =  ParallelPlayer()
    game = StandardPlayer()
    game.play()


# In[ ]:




# In[ ]:



