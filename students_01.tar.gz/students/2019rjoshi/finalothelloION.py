# >> COMPLETED

#====== { IMPORTS } ======

import sys
import re
import time

#====== { SETUP/GENERATION } ======

adjdiagl = {r*8+c: set().union({r*8+c+(1+8) if c<7 and r<7 else -1},
                              {r*8+c+(-1-8) if c>0 and r>0 else -1})-{-1} for c in range(8) for r in range(8)}
adjdiagr = {r*8+c: set().union({r*8+c+(1-8) if c<7 and r>0 else -1},
                              {r*8+c+(-1+8) if c>0 and r<7 else -1})-{-1} for c in range(8) for r in range(8)}
adjhoriz = {r*8+c: set().union({r*8+c+(1) if c<7 else -1},
                                  {r*8+c+(-1) if c>0 else -1})-{-1} for c in range(8) for r in range(8)}
adjvert = {r*8+c: set().union({r*8+c+(8) if r<7 else -1},
                            {r*8+c+(-8) if r>0 else -1})-{-1} for c in range(8) for r in range(8)}

adjacencies = {r*8+c: set().union({r*8+c+(1) if c<7 else -1}, #Left
                                  {r*8+c+(-1) if c>0 else -1}, #Right
                                  {r*8+c+(8) if r<7 else -1}, #Bottom
                                  {r*8+c+(-8) if r>0 else -1}, #Top
                                  {r*8+c+(1+8) if c<7 and r<7 else -1},
                                  {r*8+c+(1-8) if c<7 and r>0 else -1},
                                  {r*8+c+(-1+8) if c>0 and r<7 else -1},
                                  {r*8+c+(-1-8) if c>0 and r>0 else -1})-{-1} for c in range(8) for r in range(8)}

diagsetsl = [{n*9+x for n in range(0, 8) if n*9+x<64} for x in range(0, 64, 8)]+\
            [{n * 9 + x for n in range(0, 8) if n*9+x<64-8*x} for x in range(0, 8)]
diagsetsr = [{n*7+x for n in range(0, 8) if n*7+x<64} for x in range(7, 64, 8)]+\
            [{x+n*7 for n in range(0, 8) if x+n*7 <= 57-8*(7-x)} for x in range(7, -1, -1)]
rowsets = [{x*8+n for n in range(0, 8)} for x in range(0, 8)]
colsets = [{x+n*8 for n in range(0, 8)} for x in range(0, 8)]

def retunion(l):
    ret = set()
    for st in l:
        ret = ret | st
    return ret

rows = {x:retunion([rs for rs in rowsets if x in rs]) for x in range(0, 64)}
cols = {x:retunion([cs for cs in colsets if x in cs]) for x in range(0, 64)}
diagl = {x:retunion([ds for ds in diagsetsl if x in ds]) for x in range(0, 64)}
diagr = {x:retunion([ds for ds in diagsetsr if x in ds]) for x in range(0, 64)}

rsort = {x:sorted(list(rows[x])) for x in range(0, 64)}
csort = {x:sorted(list(cols[x])) for x in range(0, 64)}
dlsort = {x:sorted(list(diagl[x])) for x in range(0, 64)}
drsort = {x:sorted(list(diagr[x])) for x in range(0, 64)}

posSets = [rsort, csort, drsort, dlsort]

corners = {0, 7, 56, 63}
edges = cols[0] | cols[7] | rows[0] | rows[56]
edgeSort = [sorted(cols[0]), sorted(cols[7]), sorted(rows[0]), sorted(rows[56])]


opponent = {"x":"o", "o":"x"}

npositions = 10



#====== { METHODS } ======

def displayBoard(b):
    str = "╔"+"═"*17+"╗\n"+"".join(["║ "+"".join([b[(l-1)*8+c-1] + " " for c in range(1,9)])+"║\n" for l in range(1,9)])+"╚"+"═"*17+"╝\n"
    print(str)

def placesToMove(b, p):

    ptm = set()
    pattern = opponent[p] + "+" + p

    for space in {x for x in range(0, 64) if b[x] == "."}:

        spind = rsort[space].index(space)
        if re.match(pattern, "".join([b[i] for i in rsort[space][spind+1:]])) or re.match(pattern, "".join([b[i] for i in rsort[space][:spind][::-1]])): ptm.add(space)

        spind = csort[space].index(space)
        if re.match(pattern, "".join([b[i] for i in csort[space][spind + 1:]])) or re.match(pattern, "".join([b[i] for i in csort[space][:spind][::-1]])): ptm.add(space)

        spind = drsort[space].index(space)
        if re.match(pattern, "".join([b[i] for i in drsort[space][spind + 1:]])) or re.match(pattern, "".join([b[i] for i in drsort[space][:spind][::-1]])): ptm.add(space)

        spind = dlsort[space].index(space)
        if re.match(pattern, "".join([b[i] for i in dlsort[space][spind + 1:]])) or re.match(pattern, "".join([b[i] for i in dlsort[space][:spind][::-1]])): ptm.add(space)


    return ptm

def move(board, p, pos):
    b = board[:]
    b[pos] = p
    for posSet in posSets:
        posind = posSet[pos].index(pos)
        upperbound = posSet[pos][posind + 1:]
        lowerbound = posSet[pos][:posind][::-1]

        convertupper = set()
        uppervalid = False
        for x in upperbound:
            if b[x] == opponent[p]:
                convertupper.add(x)
            elif b[x] == p:
                uppervalid = True
                break
            elif b[x] == ".":
                convertupper = set()
                break
        if not uppervalid:
            convertupper = set()

        convertlower = set()
        lowervalid = False
        for x in lowerbound:
            if b[x] == opponent[p]:
                convertlower.add(x)
            elif b[x] == p:
                lowervalid = True
                break
            elif b[x] == ".":
                convertlower = set()
                break
        if not lowervalid:
            convertlower = set()

        for x in convertupper | convertlower:
            b[x] = p
    return b

def getBestMove(b, p, l):
    if b.count(".") < npositions:
        return negamax(b, p, l)[-1]
    else:
        ptm = placesToMove(b, p)
        for c in corners:
            if c in ptm: return c  # Go for corners
            if b[c] == p:
                for adj in adjacencies[c]:
                    if adj in ptm:
                        return adj  # Go for c or x squares if corner is filled in
                for e in edgeSort:
                    for pos in ptm:
                        if pos in e and c in e:
                            if c > pos:
                                if False not in [b[st] == p for st in e[pos:c]]:
                                    return pos
                            elif pos > c:
                                if False not in [b[st] == p for st in e[c:pos]]:
                                    return pos
        for pos in ptm:
            if pos not in edges:
                return pos
        return ptm.pop()

def boardEval(b, p):
    boardHeuristic = b.count(p) - b.count(opponent[p])
    possibleMovesHeuristic = len(placesToMove(b, p)) - len(placesToMove(b, opponent[p]))
    return boardHeuristic + possibleMovesHeuristic

def negamax(b, p, l):
    if not l:
        return [boardEval(b, p)]
    ptm = placesToMove(b, p)
    if not ptm:
        nm = negamax(b, opponent[p], l - 1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = []
    for mv in ptm:
        boardFromMove = move(b, p, mv)
        nm = negamax(boardFromMove, opponent[p], l - 1)
        nmList.append(nm + [mv])
    nmList = sorted(nmList)
    best = nmList[0]
    return [-best[0]] + best[1:]

#====== { RUN } ======o

#------ args ------o

# board = list(sys.argv[1].lower())
# player = sys.argv[2].lower()
#
#
# #------ output ------
#
#

class Strategy():
    # implement all the required methods on your own
    def best_strategy(self, board, player, best_move, running):
        if running.value:
            for x in range(5, 10):
                boardProc = list(board.replace("?", "").replace("@", "x").lower())
                playerProc = player.lower()
                mv = getBestMove(boardProc, playerProc, x)
                best_move.value = 11+(mv//8)*10 + (mv%8)



