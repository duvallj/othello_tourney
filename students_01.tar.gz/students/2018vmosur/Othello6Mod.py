import sys
import time
import random

inputs = sys.argv
if len(inputs) == 1:
    board = "...........................ox......xo..........................."
    turn = "x"
elif len(inputs) == 2:
    board = inputs[1].lower()
    emptys = {x for x in range(len(board)) if board[x] == "."}
    if len(emptys) % 2 == 0:
        turn = "x"
    else:
        turn = "o"
else:
    board = sys.argv[1].lower()
    turn = sys.argv[2].lower()

def display(s):
    [print(s[x-8:x] + "\n") for x in range(8,65,8)]
    print("__________________________________")

def opposite(turn):
    if turn.lower() == "x":
        return "o"
    if turn.lower() == "o":
        return "x"

def findEmptys(state):
    emptys = {x for x in range(len(state)) if state[x] == "."}
    return emptys

def generateConstraint(pos):
    row = [x for x in range(0,64) if x // 8 == pos // 8]
    col = [x for x in range(0,64) if x % 8 == pos % 8]
    diag = []
    for x in range(0,64):
        y = pos // 8 - x // 8
        z = pos % 8 - x % 8
        if y == z:
            diag.append(x)
    return row, col, diag

def generateAdjacent(pos):
    if pos == 0:
        return {1, 8, 9}
    elif pos == 63:
        return {62, 55, 54}
    elif pos == 56:
        return {57, 48, 49}
    elif pos == 7:
        return {6, 15, 14}
    elif pos % 8 == 0:
        return {pos+1, pos-8, pos+8, pos+9, pos-7}
    elif pos % 8 == 7:
        return {pos-1, pos-8, pos+8, pos-9, pos+7}
    else:
        return {pos-1, pos+1, pos-8, pos+8, pos-7, pos+7, pos-9, pos+9}

def check(state, pos):
    if state[pos] == opposite(turn):
        return True
    return False

def legalMoves(state, token):
    oppositeToken = opposite(token)
    moves = findEmptys(state)
    legals = dict()
    for each in moves:
        validset = set()
        for x in generateAdjacent(each):
            if x < 0 or x > 63:
                continue
            if state[x] == oppositeToken:
                validset.add(x)
        if not validset:
            continue
        for y in validset:
            temp = y
            if temp - each == 1:
                newset = [temp]
                while not (temp+1) % 8 == 0 and not temp+1 > 63:
                    temp = temp+1
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == -1:
                newset = [temp]
                while not (temp-1) % 8 == 7 and not temp-1 < 0:
                    temp = temp-1
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == 8:
                mod = temp%8
                newset = [temp]
                while temp % 8 == mod and temp+8 <= 63:
                    temp = temp+8
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == -8:
                mod = temp%8
                newset = [temp]
                while temp % 8 == mod and temp-8 >= 0:
                    temp = temp-8
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == 9:
                newset = [temp]
                while not temp >= 63 and not temp+9 >= 63 and not (temp+9)%8 == 0 and not temp%8==0:
                    temp = temp+9
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == -9:
                newset = [temp]
                while not temp <= 0 and not temp-9 <= 0 and not (temp-9)%8 == 7 and not temp%8==7:
                    temp = temp-9
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == 7:
                newset = [temp]
                while not temp >= 63 and not temp+7 >= 63 and not (temp+7)%8==7 and not temp%8==7:
                    temp = temp+7
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
            if temp - each == -7:
                newset = [temp]
                while not temp <= 0 and not temp-7 <= 0 and not (temp-7)%8 == 0 and not temp%8==0:
                    temp = temp-7
                    if not check(state, temp):
                        if not state[temp] == token:
                            break
                        if state[temp] == token:
                            if not each in legals.keys():
                                legals[each] = newset
                            else:
                                legals[each] = legals[each] + newset
                            break
                    newset.append(temp)
    return legals

def makeMove(state, token, mv, moveset):
    state = state[:mv] + token + state[mv+1:]
    for each in moveset[mv]:
        state = state[:each] + token + state[each+1:]
    return state
def evalBoard(state, token):
    mecount = (list)(state).count(token)
    enemycount = (list)(state).count(opposite(token))
    return mecount-enemycount
def negamax(brd, token, level):
    if not level:
        return [evalBoard(brd, token)]
    lm = legalMoves(brd, token)
    if len(lm) == 0 and len(legalMoves(brd, opposite(token))) == 0:
        return [evalBoard(brd, token)]
    if len(lm) == 0:
        nm = negamax(brd, opposite(token), level-1)
        return [-nm[0]]+nm[1:]
    nmList = sorted([negamax(makeMove(brd, token, mv, lm), opposite(token), level-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]]+best[1:]

edgeset = {0: {1, 2, 3, 4, 5, 6, 8, 16, 24, 32, 40, 48, 56, 7}, 7: {0, 1, 2, 3, 4, 5, 6, 15, 23, 31, 39, 47, 55, 63}, 56: {0, 8, 16, 24, 32, 40, 48, 57, 58, 59, 60, 61, 62, 63}, 63: {7, 15, 23, 31, 39, 47, 55, 62, 61, 60, 59, 58, 57, 56}}
closecorners = {0: {1, 8, 9}, 7: {6, 15, 14}, 56: {57, 48, 49}, 63: {62, 55, 54}}
def heuristicChoice(movein):
    for each in movein:
        if each in closecorners:
            return each
    for each in movein:
        for corner in edgeset:
            if each in edgeset[corner] and board[corner] == turn:
                if corner == 0 and each %8 ==0:
                    if not False in {board[x]==turn for x in range(0,each,8)}:
                        return each
                if corner == 0 and not each%8==0:
                    if not False in {board[x]==turn for x in range(0, each)}:
                        return each
                if corner == 56 and each%8==0:
                    if not False in {board[x]==turn for x in range(each+8, 56, 8)}:
                        return each
                if corner == 56 and not each%8==0:
                    if not False in {board[x]==turn for x in range(56, each)}:
                        return each
                if corner == 7 and each%7==7:
                    if not False in {board[x]==turn for x in range(7, each, 8)}:
                        return each
                if corner == 7 and not each%7==7:
                    if not False in {board[x]==turn for x in range(each+1, 8)}:
                        return each
                if corner == 63 and each%7==7:
                    if not False in {board[x]==turn for x in range(each+8, 64, 8)}:
                        return each
                if corner == 63 and not each%7==7:
                    if not False in {board[x]==turn for x in range(each+1, 64)}:
                        return each
    for corner in closecorners:
            for each in closecorners[corner]:
                if not board[corner] == turn and each in movein and not len(movein) == 1:
                        movein.remove(each)
    return random.choice([*movein])
def findBestMove(board, turn):
    moveset = legalMoves(board, turn)
    movein = set(moveset.keys())
    if len(moveset) == 0:
        moveset = None
        display(board)
        print("The legal moves are: ", moveset)
        return -1
        sys.exit()

    display(board)
    tempmoves = set(moveset.keys())
    print(tempmoves)
    move = heuristicChoice(movein)
    return move

    if len(findEmptys(board)) <= 8:
        result = negamax(board, turn, -1)
        return result[-1]
        #print("Negamax returns {} and I choose move {}".format(result, result[-1]))
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd="".join(board).replace("?","").replace("@","x")
        turn="x" if player == "@" else "o"
        mv = findBestMove(brd, turn)
        if mv == -1:
            mv1 = mv
        if not mv == -1:
            mv1 = 11+((mv//8)*10) + (mv%8)
        best_move.value=mv1

def main():
    moveset = legalMoves(board, turn)
    movein = set(moveset.keys())
    if len(moveset) == 0:
        moveset = None
        display(board)
        print("The legal moves are: ", moveset)
        sys.exit()

    display(board)
    tempmoves = set(moveset.keys())
    print(tempmoves)
    move = heuristicChoice(movein)
    print("My heuristic choice is {}".format(move))

    if len(findEmptys(board)) <= 8:
        result = negamax(board, turn, -1)
        print("Negamax returns {} and I choose move {}".format(result, result[-1]))
if __name__ == "__main__":
    main()
