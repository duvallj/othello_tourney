#strategy.py
import sys, random
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
sym1, sym2, symE, symA = "X", "O", ".", "#"
N = 11
bigN = 45
bToL = {}
bToLDict = {}
# listOfTests = [
#   ["OOOOOXXXOXOOOOXOOOOXOXX.OOXXXXXOOOXXXXXO.OXXXOXOOOXXOXOOOXXOOOOO x", 2,  {23}],
#   ["XXX.OXXX.XXXXXXXXXXXXOXXXXXXOXOXXXXOXOXXXXOXOXXX.XXOXXXXOXXXXXXX o", -6, {3}],
#   ["...ooooo ox.xoooo oxxxxooo oxoxxxoo oxxxxooo oxxoxooo oxxxxxoo oooooooo O", 42, {1}],
#   ["oooooo.. xoxxoo.. xxooooxx xxxoooxx xxoxooxx xxxoxoox .xxxxxxx xxxxxxxx o", 0, {48}],
#   ["O.X.O.XOXO..O.OXXOOOOOXXXOXOOXXXXOOXXXXXXOOXXXXXXXXXXXXXXXXXXXXX x", 50, {5}],
#   ["XXXXXXXOXXXXXXXOXXXXXXXOXXOXXX.OXOXOOO..XOOXO...XXXXXXX.XXXXXXXX X", 47, {30}],
#   ["....OOOOO...XXOOOOXXX.OOOXOXXOOOOOOOXOOOOOOOXXOOOOOOOOXOOOOOOOOO O", 60, {21, 9}],           # 21, 11, 9 ...
# ]

listOfTests = [
  ["OOOOOOOOO.XXXXO.OOXXXXX.OOXXXXO.OOXXXXXXOOOOOX..XXXXOOO.XXXXXXX. x", 0,  {9}],                     # 8 free
  ["OX.O.XX.OXXXXXXOOOXOOOOXOOXXOOX.OOOXOXXOO.OOOXXX.OOOOOXXXOO.OX.. o", 14, {7}],                     # 9 free
  ["X.OXXX..X.OOXXX.XOOXOXOOXXOOXOOOXXOXOXOOXOXOOXOOOOOOOO....OOOOO. X", 4,  {9}],                     # 10 free
  ["...OOOOO..XXXXXO.XOOOOXOXOOOOOXOXOOOXOXOXOOXOXOO..OOOOXO..OOOO.X O", 7,  {62}],                    # 11 free
  ["..XXXXXX.OOXXOOXXXOXOOOX..OOOXOX..OOOXOX.OOOXOOXOOOXXOOX..OXXO.. x", 26, {8, 25, 40, 57, 62}],     # 12 free
  ["XXXXOOOOOXXXOXO.OXXOOXOXOXXXOX.XOOXXX..XOOOXXX..OOOOOX..OOO..... o", -6, {46, 30}],                # 13 free
  ["XXXXXXXXXXXXOXXXXXXOXOXXXXOXOOOXXXOOOO.XXXOO.O.XXXO..O..X....... x", 61, {58}],                    # 14 free
#  [".........O.X...O.OOXXOOOXXXOXXXOXXXOOXXOXXXXXOXOXXXXXOOOXXXXXXXO X", 16, {12, 13}],                # 14 free
]

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        player = sym1 if player == BLACK else sym2
        enemy = sym1 if player == sym2 else sym2
        brd = ''.join(str(v) for v in board)
        brd = brd.replace(OUTER, '').replace(BLACK, sym1).replace(WHITE, sym2)

        mv = imp(brd, player)
        best_move.value = 11+(mv//8)*10+(mv%8)
        depth = -1
        # if brd.count(EMPTY) > bigN and not mv in [0, 7, 56, 63]:
        #     lm = legalMoves(brd, player)
        #     minPos, minLPos = -1, 62
        #     for m in lm:
        #         if m in [9, 14, 49, 54, 1, 8, 6, 15, 48, 57, 55, 62]:
        #             continue
        #         temp = len(legalMoves(makeMove(brd, player, m), enemy))
        #         if temp < minLPos:
        #             minPos = m
        #             minLPos = temp
        #     if minPos > -1:
        #         best_move.value = 11 + (minPos // 8) * 10 + (minPos % 8)
        mv = negamax(board, player, 9)
        best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
        
        if brd.count(EMPTY) < N:
            mv = negamaxTerminal(brd, player, -65, 65)[-1]
            best_move.value = 11+(mv//8)*10+(mv%8)
            #depth += 2

def posToRC(n):
    return n // 8, n % 8

def withinBounds(r, c):
    if r>7 or c>7:
        return False
    elif r<0 or c<0:
        return False
    return True
    # return r < 8 and c < 8 and r >= 0 and c >= 0

def legalMoves(board, turn):
    if board in bToL:
        # print("I USED A CACHED BOARD")
        return bToL[board]

    d1 = board
    board = make2D(board)
    legal, out = [], set()
    opp = sym1 if turn != sym1 else sym2
    for i in [a for a in range(64) if board[a // 8][a % 8] == opp]:
        moves = [(0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1), (-1, 0), (-1, 1)]
        r, c = posToRC(i)
        for e in moves:
            if withinBounds(r + e[0], c + e[1]) and board[r + e[0]][c + e[1]] == turn:
                mult = 1
                while withinBounds(r - e[0] * mult, c - e[1] * mult) and board[r - e[0] * mult][
                            c - e[1] * mult] != "." and board[r - e[0] * mult][c - e[1] * mult] != turn:
                    mult += 1
                if withinBounds(r - e[0] * mult, c - e[1] * mult) and board[r - e[0] * mult][
                            c - e[1] * mult] == ".":
                    legal.append((r - e[0] * mult, c - e[1] * mult))
    for n in legal:
        out.add(n[0]*8+n[1])
    bToL[d1] = out
    return out
def negamaxTerminal(brd, token, improvable, hardBound):
    d1 = brd
    enemy = sym1 if token == sym2 else sym2
    lm = lM(brd, token)
    brd = make2D(brd)
    if not lm:
        lm = legalMoves(d1, enemy)
        if not lm: return [evalBoard(brd, token)]
        nm = negamaxTerminal(d1, enemy, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best, newHB = [], -improvable
    for mv in lm:
        nm = negamaxTerminal(mM(d1, token, lm, mv), enemy, -hardBound, newHB)+[mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound: return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
def negamax(board, token, levels): #returns a score together with a move sequence leading to that score
    d1 = board
    board = make2D(board)
    enemy = sym1 if token == sym2 else sym2
    lm = lM(d1, token)
    #DONE

    if len(lm) == 0:
        if len(legalMoves(d1, enemy)) == 0:
            return [evalBoard(board, token), -3]
    if not levels: return [evalBoard(board, token)]
    # PASS
    if not lm:
        nm = negamax(d1, enemy, levels-1) + [-1]
        return [-nm[0]] + nm[1:]

    nmList = sorted([negamax(mM(d1, token, lm, mv), enemy, levels-1)+[mv] for mv in lm])
    best = nmList[0]
    return [-best[0]]+best[1:]

def evalBoard(board, token):
    enemy = sym1 if token != sym1 else sym2
    d = d1B(board)
    return d.count(token) - d.count(enemy)

def mM(board, turn, pTF, mv):
    board = make2D(board)
    for i in pTF[mv]:
        board[i[0]][i[1]] = turn
    board[posToRC(mv)[0]][posToRC(mv)[1]] = turn

    return d1B(board)
def makeMove(board, turn, mv):

    board = make2D(board)
    legal, out = [], set()
    posToFlip = {}
    opp = sym1 if turn != sym1 else sym2
    for i in [a for a in range(64) if board[a // 8][a % 8] == opp]:
        moves = [(0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1), (-1, 0), (-1, 1)]
        r, c = posToRC(i)
        for e in moves:
            if withinBounds(r + e[0], c + e[1]) and board[r + e[0]][c + e[1]] == turn:
                mult = 1
                wouldFlip = []
                tup = (r - e[0] * mult, c - e[1] * mult)
                wouldFlip.append((r, c))
                wouldFlip.append(tup)
                while withinBounds(*tup) and board[tup[0]][tup[1]] != "." and board[tup[0]][tup[1]] != turn:
                    wouldFlip.append(tup)
                    mult += 1
                    tup = (r - e[0] * mult, c - e[1] * mult)
                if withinBounds(*tup) and board[tup[0]][tup[1]] == ".":
                    legal.append((r - e[0] * mult, c - e[1] * mult))
                    x = (r - e[0] * mult) * 8 + (c - e[1] * mult)

                    if x in posToFlip:
                        tmp = posToFlip[x]
                    else:
                        tmp = []
                    posToFlip[x] = tmp + wouldFlip
    for i in posToFlip[mv]:
        board[i[0]][i[1]] = turn
    board[posToRC(mv)[0]][posToRC(mv)[1]] = turn

    return d1B(board)

def lM(board, turn):
    if board in bToLDict:
        return bToLDict[board]

    d1 = board
    board = make2D(board)
    legal, out = [], set()
    posToFlip = {}
    opp = sym1 if turn != sym1 else sym2
    for i in [a for a in range(64) if board[a // 8][a % 8] == opp]:
        moves = [(0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1), (-1, 0), (-1, 1)]
        r, c = posToRC(i)
        for e in moves:
            if withinBounds(r + e[0], c + e[1]) and board[r + e[0]][c + e[1]] == turn:
                mult = 1
                wouldFlip = []
                tup = (r - e[0] * mult, c - e[1] * mult)
                wouldFlip.append((r, c))
                wouldFlip.append(tup)
                while withinBounds(*tup) and board[tup[0]][tup[1]] != "." and board[tup[0]][tup[1]] != turn:
                    wouldFlip.append(tup)
                    mult += 1
                    tup = (r - e[0] * mult, c - e[1] * mult)
                if withinBounds(*tup) and board[tup[0]][tup[1]] == ".":
                    legal.append((r - e[0] * mult, c - e[1] * mult))
                    x = (r - e[0] * mult) * 8 + (c - e[1] * mult)

                    if x in posToFlip:
                        tmp = posToFlip[x]
                    else:
                        tmp = []
                    posToFlip[x] = tmp + wouldFlip
    bToL[d1] = posToFlip.keys()
    bToLDict[d1] = posToFlip
    return posToFlip

def printBoard(b):
    if type(b) == str:
        b = make2D(b)
    for i in range(8):
        for j in range(8):
            print(b[i][j], " ", end="")
        print()
    print("-----------------------")

def d1B(board):
    b = ""
    for m in range(8):
        b += "".join(board[m])
    return b

def make2D(b):
    nb = [[] for i in range(8)]
    for i in range(8):
        nb[i] = list(b[i*8:i*8+8])
    return nb

def imp(board, t):
    enemy = sym1 if t == sym2 else sym2
    l = legalMoves(board, t)

    corners, xsq, csq = [0, 7, 56, 63], [9, 14, 49, 54], [1, 8, 6, 15, 48, 57, 55, 62]
    edges = [*range(1, 7)] + [*range(57, 63)] + [*range(8, 56, 8)] + [*range(15, 63, 8)]
    # print(edges)
    ret = set()
    # GREEDY CORNERS
    for a in corners:
        if a in l:
            ret.add(a)
    if ret:
        return random.choice([*ret])
    elif t in [board[c] for c in corners]:
        if board[corners[0]] == t:
            ret = set(edges[:6] + edges[-6:])
        elif board[corners[1]] == t:
            ret = set(edges[:6] + edges[-12:-6])
        elif board[corners[2]] == t:
            ret = set(edges[6:-6])
        elif board[corners[3]] == t:
            ret = set(edges[6:12] + edges[-6:])
        ret = ret.intersection(l)
        if ret:
            return random.choice([*ret])
    ret = set().union(l)
    for i in range(4):
        if board[corners[i]] != enemy:
            ret.discard(xsq[i])
            ret.discard(csq[i * 2])
            ret.discard(csq[i * 2 + 1])
    if ret:
        return ret.pop()
    else:
        return random.choice([*l])

def main():
    b = symE * 27 + sym2 + sym1 + symE * 6 + sym1 + sym2 + symE * 27
    if len(sys.argv) > 1: b = (sys.argv[1]).upper()
    if len(sys.argv) == 3: t = (sys.argv[2]).upper()
    elif b.count(".") % 2 == 0: t = sym1
    else: t = sym2
    enemy = sym1 if t == sym2 else sym2
    # nb = [[] for i in range(8)]
    # for idx, sym in enumerate(b):
    #     nb[idx // 8].append(sym)
    # b = nb

    printBoard(make2D(b))
    print("Legal moves: ", legalMoves(b, t))
    h = imp(b,t)
    print("Heuristic: ", h)
    if b.count(EMPTY) > bigN and not h in [0, 7, 56, 63]:
        lm = legalMoves(b, t)
        minPos, minLPos = -1, 62
        for m in lm:
            if m in [9, 14, 49, 54, 1, 8, 6, 15, 48, 57, 55, 62]:
                continue
            temp = len(legalMoves(makeMove(b, t, m), enemy))
            if temp < minLPos:
                minPos = m
                minLPos = temp
        if minPos > -1:
            print("LIMIT legal moves: ", minPos)
    if b.count(EMPTY) < N:
        m = negamaxTerminal(b, t, -65, 65)
        print("Negamax: ", m)
if __name__=="__main__":
    main()


'''
def negamaxTerminal(brd, token, improvable, hardBound):
    lm = legalMoves(brd, token)
    if not lm:
        lm = legalMoves(brd, enemy)
        if not lm: return [evalBoard(brd, token)]
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best, newHB = [], -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(brd, token, mv), enemy, -hardBound, newHB)+[mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound: return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
'''