#cd Documents\2_school\11th grade\4 AI\Othello
import sys, random
class Strategy:
   def best_strategy(self, board, player, best_move, still_running):
      brd = ''.join(board).replace("?","").replace('@','X').replace('o','O')
      token = "X" if player=='@' else 'O'
      mv = lab6SmartMove(brd, token)
      mv1 = 11+(mv//8)*10+(mv%8)
      best_move.value=mv1
      mv = findBestMove(brd, token)
      mv1 = 11+(mv//8)*10+(mv%8)
      best_move.value=mv1
def findBestMove(game, turn):
   if isinstance(sys.argv[-1], int):
      n = int(sys.argv[-1])
   else:
      n=8 #default
   hmv = lab6SmartMove(game,turn)
   print ("My Heuristic move is {}".format(hmv))
   if game.count('.')<=n:
      nm = negaMax(game, turn, -1)
      print("negamax "+str(nm)+"; my move is {}".format(nm[-1]))
      return nm[-1]
   return hmv
def move(game, turn, pos):
   newGame = game[:pos]+turn+game[pos+1:]
   if pos%8!=0:
      temp = pos-1
      switch = []
      app = False
      while temp%8!=7:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp-=1
            continue
         else:
            if game[temp]==turn:
               app=True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos%8!=7:
      temp = pos+1
      switch = []
      app = False
      while temp%8!=0:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp+=1
            continue
         else:
            if game[temp]==turn:
               app=True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos//8!=0:
      temp = pos-8
      switch = []
      app = False
      while temp//8!=-1:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp-=8
            continue
         else:
            if game[temp]==turn:
               app = True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos//8!=7:
      temp = pos+8
      switch = []
      app = False
      while temp//8!=8:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp+=8
            continue
         else:
            if game[temp]==turn:
               app = True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos%8!=0 and pos//8!=0:
      temp = pos-9
      switch = []
      app = False
      while temp%8!=7 and temp//8>=0:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp-=9
            continue
         else:
            if game[temp]==turn:
               app = True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos%8!=7 and pos//8!=7:
      temp = pos+9
      switch = []
      app = False
      while temp%8!=0 and temp//8<=7:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp+=9
            continue
         else:
            if game[temp]==turn:
               app = True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos%8!=0 and pos//8!=7:
      temp = pos+7
      switch = []
      app = False
      while temp%8!=7 and temp//8<=7:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp+=7
            continue
         else:
            if game[temp]==turn:
               app = True
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   if pos%8!=7 and pos//8!=0:
      temp = pos-7
      switch = []
      app = False
      while temp%8!=0 and temp//8>=0:
         if game[temp] not in {'.',turn}:
            switch.append(temp)
            temp-=7
            continue
         else:
            if game[temp]==turn:
               app = True 
            break
      if app:
         for i in switch:
            newGame = newGame[:i]+turn+newGame[i+1:]
   return newGame
def legalMoves(game, turn):
   lms = set()
   conq = 'O' if turn=='X' else 'X'
   for pos in [i for i in range(64) if game[i]==conq]:
      if pos not in lms:
         if pos%8!=0 and game[pos-1]=='.':
            scout = pos
            while scout%8!=0 and game[scout]==conq:
               scout+=1
            if scout%8!=0 and game[scout]==turn:
               lms.add(pos-1)
         if pos%8!=7 and game[pos+1]=='.':
            scout = pos
            while scout%8!=7 and game[scout]==conq:
               scout-=1
            if scout%8!=7 and game[scout]==turn:
               lms.add(pos+1)
         if pos//8!=0 and game[pos-8]=='.':
            scout = pos
            while scout//8<8 and game[scout]==conq:
               scout+=8
            if scout//8!=8 and game[scout]==turn:
               lms.add(pos-8)
         if pos//8!=7 and game[pos+8]=='.':
            scout = pos
            while scout//8>=0 and game[scout]==conq:
               scout-=8
            if scout//8>=0 and game[scout]==turn:
               lms.add(pos+8)
         if pos//8!=7 and pos%8!=7 and game[pos+9]=='.':
            scout = pos
            while scout//8>=0 and scout%8!=7 and game[scout]==conq:
               scout-=9
            if scout//8>=0 and scout%8!=7 and game[scout]==turn:
               lms.add(pos+9)
         if pos//8!=0 and pos%8!=0 and game[pos-9]=='.':
            scout = pos
            while scout//8<8 and scout%8!=0 and game[scout]==conq:
               scout+=9
            if scout//8<8 and scout%8!=0 and game[scout]==turn:
               lms.add(pos-9)
         if pos//8!=7 and pos%8!=0 and game[pos+7]=='.':
            scout = pos
            while scout//8>=0 and scout%8!=0 and game[scout]==conq:
               scout-=7
            if scout//8>=0 and scout%8!=0 and game[scout]==turn:
               lms.add(pos+7)
         if pos//8!=0 and pos%8!=7 and game[pos-7]=='.':
            scout = pos
            while scout//8<8 and scout%8!=7 and game[scout]==conq:
               scout+=7
            if scout//8<8 and scout%8!=7 and game[scout]==turn:
               lms.add(pos-7)
   return lms
def eval(game, turn):
   return game.count(turn)-game.count('X' if turn=='O' else 'O')
   #return game.count(turn)-game.count('X' if turn=='O' else 'O')+count corners more
   #return len(legalMoves(game,turn))-len(legalMoves(game, 'X' if turn=='O' else 'O'))
def negaMax(game, turn, lvl):
   return negaMaxHelper(game, turn, lvl, False)
def negaMaxHelper(game, turn, lvl, enemyPassed):
   if lvl==0:
      return [eval(game, turn)]
   legs = legalMoves(game, turn)
   enemy = 'X' if turn=='O' else 'O'
   if not legs:
      if enemyPassed:
         return [eval(game, turn)]
      nm = negaMaxHelper(game, enemy, lvl-1, True)+[-1]
      return [-nm[0]]+nm[1:]
   best = min([negaMaxHelper(move(game,turn,leg),enemy,lvl-1, False) + [leg] for leg in legs])
   return ([-best[0]]+best[1:])
def switches(gameseg):
   count = 0
   curr = gameseg[0]
   for c in gameseg:
      if c!=curr:
         count+=1
         curr=c
   return count
def lab6SmartMove(game, turn):
   legs = legalMoves(game, turn)
   #heuristic 1: go to corner if possible
   cornersAvailable = {0,7,56,63}.intersection(legs)
   if cornersAvailable:
      return random.choice(list(cornersAvailable))

   #heuristic 2: get a "safe side" if possible
   sides = {1,2,3,4,5,6,8,16,24,32,40,48,15,23,31,39,47,55,57,58,59,60,61,62}
   safesides = {}
   topsides = {i for i in sides if i//8==0}
   topsidesAvailable = topsides.intersection(legs)
   if topsidesAvailable:
      topleft = [game[i] for i in range(min(topsidesAvailable))]
      if game[0]==turn and '.' not in topleft and switches(topleft)<=1:
         safesides[min(topsidesAvailable)] = min(topsidesAvailable) #or check # conquering
      topright = [game[i] for i in range(max(topsidesAvailable)+1,8)]
      if game[7] == turn and '.' not in topright and switches(topright)<=1:
         safesides[max(topsidesAvailable)] = 7-max(topsidesAvailable)
   botsides = {i for i in sides if i//8==7}
   botsidesAvailable = botsides.intersection(legs)
   if botsidesAvailable:
      botleft = [game[i] for i in range(56,min(botsidesAvailable))]
      if game[56]==turn and '.' not in botleft and switches(botleft)<=1:
         safesides[min(botsidesAvailable)] = min(botsidesAvailable)-56 #or check # conquering
      botright = [game[i] for i in range(max(botsidesAvailable)+1,64)]
      if game[63]==turn and '.' not in botright and switches(botright)<=1:
         safesides[max(botsidesAvailable)] = 63-max(botsidesAvailable)
   leftsides = {i for i in sides if i%8==0}
   leftsidesAvailable = leftsides.intersection(legs)
   if leftsidesAvailable:
      lefttop = [game[i] for i in range(0,min(leftsidesAvailable),8)]
      if game[0]==turn and '.' not in lefttop and switches(lefttop)<=1:
         safesides[min(leftsidesAvailable)] = min(leftsidesAvailable)//8 #or check # conquering
      leftbot = [game[i] for i in range(max(leftsidesAvailable)+8,57,8)]
      if game[56]==turn and '.' not in leftbot and switches(leftbot)<=1:
         safesides[max(leftsidesAvailable)] = (63-max(leftsidesAvailable))//8
   rightsides = {i for i in sides if i%8==7}
   rightsidesAvailable = rightsides.intersection(legs)
   if rightsidesAvailable:
      righttop = [game[i] for i in range(7,min(rightsidesAvailable),8)]
      if game[7]==turn and '.' not in righttop and switches(righttop)<=1:
         safesides[min(rightsidesAvailable)] = min(rightsidesAvailable)//8 #or check # conquering
      rightbot = [game[i] for i in range(max(rightsidesAvailable)+8,64,8)]
      if game[63]==turn and '.' not in rightbot and switches(rightbot)<=1:
         safesides[max(rightsidesAvailable)] = (63-max(rightsidesAvailable))//8
   if safesides:
      return max(safesides, key=safesides.get)

   #heuristic 3: Avoiding C or X if not control corner
   betterlegs = set(legs)
   if game[0]!=turn:
      betterlegs-={1,8,9}
   if game[7]!=turn:
      betterlegs-={6,14,15}
   if game[56]!=turn:
      betterlegs-={48,49,57}
   if game[63]!=turn:
      betterlegs-={54,55,62}
   if betterlegs:
      legs = set(betterlegs)

   #heuristic 4: Avoiding side if 1 and 2 dont' apply
   betterlegs = legs-sides
   if betterlegs:
      legs = set(betterlegs)

   #return any move      
   return random.choice(list(legs))
def display(game):
   print('\n'.join(game[8*r:8*r+8] for r in range(8)))
def main():
   args = sys.argv
   if isinstance(args[-1], int):
      args = args[:-1]
   if len(args)==3:
      oth=args[1].upper()
      whoup=args[2].upper()
   elif len(args)==2:
      if len(args[1])!=64:
         oth = '...........................OX......XO...........................'
         whoup = args[1]
      else:
         oth = args[1]
         whoup = 'X' if oth.count('.')%2==0 else 'O'
   else:
      oth = '...........................OX......XO...........................'
      whoup = 'X'
   display(oth)
   print("Legal moves: " + str(legalMoves(oth, whoup)))
   findBestMove(oth, whoup)
if __name__=="__main__":
   main()