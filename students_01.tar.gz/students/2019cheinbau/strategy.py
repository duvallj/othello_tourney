#Othello

#Name: Clare Heinbaugh
#Start Date: 12/12/2017

#############################################################################


#NOTES:

#12/14/2017

#use string and matrix representation
#matrix representation should have methods to convert back and forth with the string index
#find legal moves (must move if you can) -- only allowed to jump opponents pieces
#can jump vertical, horizontal, and diagonal
#return empty list if no moves are possible (game ends if either board full or neither player can make a move)

#1/2/2018

#Min wants smallest number
#Max wants biggest number
#Min tries to minimize payoff at end for max
#60 ply: number of ply is how far you have to go to get to leaf nodes
#only 60 free spaces at start
#BFS for minimax (cannot search to end of game)
#use heuristic to estimate how well max is doing at a certain state

#1/11/2018

#Alpha-beta pruning
#Find value of node by "squeezing" it between alpha and beta values
# on the lookout for refuting moves --> proves to you your move was foolish (move was good enough to refute your choice)
#find refuting node and then don't search rest of tree
#for heuristic, consider what moves are possible as well


##############################################################################

import time #use to time code
import cProfile #use to check run time of individual methods
import Othello_Core


global board_size
board_size = 8

global E
E = "?"
global B
B = "@"
global W
W = "o"
global D
D = "."

D, B, W, E = '.', '@', 'o', '?' #set initial values for blank, black, white, and border pieces


#CREATE ALL DICTIONARIES TO MAKE GETTING ROWS, COLUMNS, DIAGONALS, AND MORE FAST AND EASY

#make dictionary to convert row to column and back
global rc2i_dict
global i2rc_dict
rc2i_dict = {}
i2rc_dict = {}
def make_conversion_dicts():
    i = 0
    for r in range(board_size):
        for c in range(board_size):
            rc2i_dict[(r,c)] = i
            i2rc_dict[i] = (r, c)
            i+=1

#make row dictionary of indicies
global row_dict
row_dict = {}

def make_row_dict():
    for j in range(board_size):
        row_dict[j] = []
    for i in range(board_size * board_size):
        row_num = i//board_size
        row_dict.get(row_num).append(i)

#make column dictionary of indicies
global col_dict
col_dict = {}

def make_col_dict():
    for j in range(board_size):
        col_dict[j] = []
    for i in range(board_size * board_size):
        col_num = i % board_size
        col_dict.get(col_num).append(i)


#left diagonal dictionary of indicies
global left_di_dict
left_di_dict = {
    0 : [56],
    1 : [48, 57],
    2 : [40, 49, 58],
    3 : [32, 41, 50, 59],
    4 : [24, 33, 42, 51, 60],
    5 : [16, 25, 34, 43, 52, 61],
    6 : [8, 17, 26, 35, 44, 53, 62],
    7 : [0, 9, 18, 27, 36, 45, 54, 63],
    8 : [1, 10, 19, 28, 37, 46, 55],
    9 : [2, 11, 20, 29, 38, 47],
    10 : [3, 12, 21, 30, 39],
    11 : [4, 13, 22, 31],
    12 : [5, 14, 23],
    13 : [6, 15],
    14 : [7]
}

#right diagonal dictionary of indicies
global right_di_dict
right_di_dict = {
    0 : [0],
    1 : [1, 8],
    2 : [2, 9, 16],
    3 : [3, 10, 17, 24],
    4 : [4, 11, 18, 25, 32],
    5 : [5, 12, 19, 26, 33, 40],
    6 : [6, 13, 20, 27, 34, 41, 48],
    7 : [7, 14, 21, 28, 35, 42, 49, 56],
    8 : [15, 22, 29, 36, 43, 50, 57],
    9 : [23, 30, 37, 44, 51, 58],
    10 : [31, 38, 45, 52, 59],
    11 : [39, 46, 53, 60],
    12 : [47, 54, 61],
    13 : [55, 62],
    14 : [63]
}


global reverse_left_dict
reverse_left_dict = {}
for i in range(board_size*2-1):
    cur_list = left_di_dict.get(i)
    for m in cur_list:
        reverse_left_dict[m] = i

global reverse_right_dict
reverse_right_dict = {}
for i in range(board_size * 2 - 1):
    cur_list = right_di_dict.get(i)
    for m in cur_list:
        reverse_right_dict[m] = i



##############################################################################

#OBJECT BOARD CLASS KEEPS TRACK OF SPECIFIC BOARD CASES

class Board():
    #constructor takes in string representation of board and fills matrix representation of board
    def __init__(self, s):
        self.board_mat = []
        self.str_rep = s
        self.fill_board()

    #create matrix representation from string representation
    def fill_board(self):
        num = 0
        # create rows
        for r in range(board_size):
            self.board_mat.append([])
            # create columns
            for c in range(board_size):
                self.board_mat[r].append(self.str_rep[num])
                num += 1

    #return value at string representation index i
    def get_value(self, i):
        return self.str_rep[i]

    #return value at matrix (r,c)
    def get_value_rc(self, r, c):
        i = self.rc2i(r,c)
        return self.get_value(i)

    #return string index i given (r,c) matrix values
    def rc2i(self, r, c):
        return rc2i_dict.get((r,c)) #returns the string index of (r,c)

    #return (r,c) given current string index
    def i2rc(self, i):
        return i2rc_dict.get(i) #returns a tuple with (r,c)

    #return list of indicies in same row as i
    def get_row_list(self, i):
        r = self.i2rc(i)[0]
        return row_dict.get(r)

    #return list of indicies in same column as i
    def get_col_list(self, i):
        c = self.i2rc(i)[1]
        return col_dict.get(c)

    #returns list of indicies in same left diagonal as i
    def get_left_list(self, i):
        l = reverse_left_dict.get(i)
        return left_di_dict.get(l)

    #returns list of indicies in same right diagonal as i
    def get_right_list(self, i):
        r = reverse_right_dict.get(i)
        return right_di_dict.get(r)

    #set string representation value at (r,c) to "value"
    def set_rc(self, r, c, value):
        self.board_mat[r][c] = value
        i = self.rc2i(r, c)
        new = list(self.str_rep)
        new[i] = value
        self.str_rep = ''.join(new)

    #set string representation value at i to "value"
    def set_i(self, i, value):
        new = list(self.str_rep)
        new[i] = value
        self.str_rep = ''.join(new)
        rc_tup = self.i2rc(i)
        r = rc_tup[0]
        c = rc_tup[1]
        self.board_mat[r][c] = value

    #generate children (new board states) for current board object
    def get_children(self, poss, turn, other):

        children = {}

        move_dict = poss
        for i in move_dict:
            r = self.i2rc(i)[0]
            c = self.i2rc(i)[1]

            temp = Board(self.str_rep)  # set string representation of temp board
            temp.board_mat[r][c] = turn  # change the current cell index value to the new temporary value for temp board

            for m in move_dict.get(i):
                r = self.i2rc(m)[0]
                c = self.i2rc(m)[1]
                temp.board_mat[r][c] = turn #change the current cell index value to the new temporary value for temp board

            #copy the string with new row and column values
            s = ""
            for q in range(board_size):
                for u in range(board_size):
                    s+=temp.board_mat[q][u]

            temp.str_rep = s

            children[i] = temp #map index of move to board representing new move



        return children  # return the temporary puzzle with only one value changed


    #return string representation of "pretty" (formatted) matrix
    def pretty(self):
        s = " "
        for p in range(board_size*2+1):
            s+="-"
        s+="\n"
        for r in range(board_size):
            s+="| "
            for c in range(board_size):
                s+=self.board_mat[r][c] + " "
            s+="|\n"
        s+=" "
        for p in range(board_size*2+1):
            s+="-"
        return (s)

    #return string representation of matrix with all cells replaced with string representation index
    def pretty2(self):
        s = []
        for p in range(board_size+2):
            s.append(E)
        for r in range(board_size):
            s.append(E)
            for c in range(board_size):
                s.append(str(self.rc2i(r,c)))
            s.append(E)
        for p in range(board_size+2):
            s.append(E)
        return (s)

#repeated process used to look at a group and find possible moves
def eval_pos(b, i, turn, other, points_dict):
    loc_bool = False #keeps track of starting "turn" chip of a line (i.e. XOOOOO.. <-- would become true at X)
    mid_bool = False #keeps track of "other" player in the middle
    #iterate through each element in current group and check boolean conditions that determine possible moves

    flip_set = set()
    for w in i:
        cur = b.get_value(w)
        if (cur == D and mid_bool == True): #reached the end of a line of "other" chip and other end is "turn" chip
            mid_bool = False #end of middle "other" tokens

            if(points_dict.get(w) == None):
                points_dict[w] = flip_set
            else:
                new_flips = flip_set | points_dict.get(w)
                points_dict[w]=new_flips

        if(loc_bool == True and (cur==D or cur==turn)):
            mid_bool = False #end of middle "other" tokens
            loc_bool = False #not a possible group that leads to a move
            flip_set = set()
        if (cur == turn):
            loc_bool = True #possible start of a line for "turn" chip to be placed at the end
        if (cur == other and loc_bool == True):
            mid_bool = True #"other" chips follow "turn" chip --> possible move at end of "other" chips
            flip_set.add(w)

    #return updated set of possible moves in current group
    return points_dict


#determine possible moves for a current board
def get_possible(b, turn, other): #turn: either Black or White's turn
    #iterate through all row groups to determine possible moves; update points_dict

    # keeps track of possible points at each space
    points_dict = {}

    for f in row_dict.keys():
        i = row_dict.get(f)
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all row groups BACKWARDS to determine possible moves; update pow_moves set
    for f in row_dict.keys():
        i = row_dict.get(f)[::-1]
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all column groups to determine possible moves; update pow_moves set
    for f in col_dict.keys():
        i = col_dict.get(f)
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all column groups BACKWARDS to determine possible moves; update pow_moves set
    for f in col_dict.keys():
        i = col_dict.get(f)[::-1]
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all left diagonal groups to determine possible moves; update pow_moves set
    for f in left_di_dict.keys():
        i = left_di_dict.get(f)
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all left diagonal groups BACKWARDS to determine possible moves; update pow_moves set
    for f in left_di_dict.keys():
        i = left_di_dict.get(f)[::-1]
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all right diagonal groups to determine possible moves; update pow_moves set
    for f in right_di_dict.keys():
        i = right_di_dict.get(f)
        points_dict = eval_pos(b, i, turn, other, points_dict)
    # iterate through all right diagonal groups BACKWARDS to determine possible moves; update pow_moves set
    for f in right_di_dict.keys():
        i = right_di_dict.get(f)[::-1]
        points_dict = eval_pos(b, i, turn, other, points_dict)

    return points_dict


#dictionary of corner indices
global corners
corners = {0, 7, 56, 63}
#attempt at weighted matrix
global point_matrix
point_matrix = [[15, -8, 5, 5, 5, 5, -8, 15],
                [-8, -10, 0, 0, 0, 0, -10, -8],
                [5, 0, 0, 0, 0, 0, 0, 5],
                [5, 0, 0, 0, 0, 0, 0, 5],
                [5, 0, 0, 0, 0, 0, 0, 5],
                [5, 0, 0, 0, 0, 0, 0, 5],
                [-8, -10, 0, 0, 0, 0, -10, -8],
                [15, -8, 5, 5, 5, 5, -8, 15]]

#CURRENT HEURISTIC: count up black tiles and return number
#plus 5 for edges and plus 10 for corners
def get_heur(b, everPlayer):
    turn = everPlayer
    other = W
    if (other == turn):
        other = B
    heur_1 = subtracted_value(b, turn, other)
    heur_2 = move_value(b, turn, other)
    return heur_1+heur_2

def subtracted_value(b, turn, other):
    count_turn = 0
    count_other = 0
    for r in range(board_size):
        for c in range(board_size):
            temp = b.get_value_rc(r, c)
            if(temp==turn):
                count_turn+=1
                if i in corners:
                   count_turn += 30 #points added to take corner
            if(temp==other):
                count_other+=1
                if i in corners:
                    count_other += 30 #points given to other player if they get the corner (boo!)
    count_turn+=edge_value(b, turn, other)
    return (count_turn - count_other)

#generate a value based on edge/corner weighting (avoid moves that allow the other player to get a corner)
def edge_value(b, turn, other):
    cur_val = 0
    if (b.get_value(0) != turn):
        if (b.get_value(1) == turn):
            cur_val -= 10
        if (b.get_value(9) == turn):
            cur_val -= 15
        if (b.get_value(8) == turn):
            cur_val -= 10
    if (b.get_value(7) != turn):
        if (b.get_value(6) == turn):
            cur_val -= 10
        if (b.get_value(14) == turn):
            cur_val -= 15
        if (b.get_value(15) == turn):
            cur_val -= 10
    if (b.get_value(56) != turn):
        if (b.get_value(48) == turn):
            cur_val -= 10
        if (b.get_value(49) == turn):
            cur_val -= 15
        if (b.get_value(57) == turn):
            cur_val -= 10
    if (b.get_value(63) != turn):
        if (b.get_value(62) == turn):
            cur_val -= 10
        if (b.get_value(54) == turn):
            cur_val -= 15
        if (b.get_value(55) == turn):
            cur_val -= 10
    return cur_val

#heuristic part to choose moves that yield lots of additional possible moves
def move_value(b, turn, other):
    poss = get_possible(b, turn, other)
    count = len(poss.keys())*2
    return count

#method to convert raw index generated by alphabeta to index that accounts for border elements
def get_converted_index(b, index_val):
    cur_list = b.pretty2()
    for u in range(len(cur_list)):
        if(cur_list[u]==str(index_val)):
            return int(u)
    return 0

#heuristic for end of game to only make best moves
def get_end_game_heur(b, everPlayer):
    turn = everPlayer
    other = W
    if (other == turn):
        other = B
    count_turn = 0
    count_other = 0
    for r in range(board_size):
        for c in range(board_size):
            temp = b.get_value_rc(r, c)
            if (temp == turn):
                count_turn += 1
            if (temp == other):
                count_other += 1
    return (count_turn - count_other)

######################################################################################################

#Alphabeta Search Algorithm

def alphabeta(board, depth, a, b, maximizingPlayer, everPlayer):#, special_heur):
    if(maximizingPlayer==True):
        turn = B
        other = W
    else:
        turn = W
        other = B

    poss = get_possible(board, turn, other)

    if(depth==0 or poss=={}):
        # if(special_heur==True):
        #     return get_end_game_heur(board, everPlayer)
        return get_heur(board, everPlayer)

    if(maximizingPlayer==True):
        v = -9999
        children1 = board.get_children(poss, turn, other)
        for c in children1:
            kid1 = children1.get(c)
            v = max(v, alphabeta(kid1, depth-1, a, b, False, everPlayer))#special_heur))
            a = max(a, v)
            if b <= a:
                break #b cut-off
        return v
    else:
        v = 9999
        children2 = board.get_children(poss, turn, other)
        for c in children2:
            kid2 = children2.get(c)
            v = min(v, alphabeta(kid2, depth-1, a, b, True, everPlayer))#special_heur))
            b = min(b, v)

            if b <= a:
                break #a cut-off
        return v

######################################################################################################

# Othello Strategy Class for Tournament


# PLAYERS = {BLACK: 'Black', WHITE: 'White'}
class Strategy(Othello_Core.OthelloCore):
    def best_strategy(self, boa, player, best_move, still_running):
        depth = 1

        # initial setup methods are run
        make_conversion_dicts()
        make_row_dict()
        make_col_dict()

        #establish initial values for indicies
        temp_val = -9999
        best_val = -9999
        best_i = -9999
        board = ""

        #make board from string representation passed to best_strategy
        for u in range(len(boa)):
            if(boa[u]!=E):
                board+=boa[u]
        cur_board = Board(board)
        bool_1 = False
        print(cur_board.pretty2())
        #coordinate whether current player is black or white and determine color of other player as well
        if(player == "@"):
            turn = B
            other = W
        else:
            bool_1 = True
            turn = W
            other = B

        # final moves of the game: play best othello
        open_space_count = 0
        for f in range(len(board)):
            if (board[f] == D):
                open_space_count += 1

        #runs until Tournament Manager terminates code
        while (True):
            print(depth)
            poss = get_possible(cur_board, turn, other)
            print(poss)
            children = cur_board.get_children(poss, turn, other)

            # get children of current board and get value of each using alphabeta search
            for c in children.keys():
                temp_val = alphabeta(children.get(c), depth, -9999, 9999, bool_1, turn)
                if (temp_val >= best_val):
                    best_move.value = get_converted_index(cur_board, c)
                    best_val = temp_val
            depth += 1 #search at next depth if first depth complete