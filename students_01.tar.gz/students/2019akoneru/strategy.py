
import random
import math
import time

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,S,E,W,NE,NW,SE,SW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
SWITCH = {'@' : 'o', 'o' : '@'}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__ (self, board, move, score = 0):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self,other):
        return self.score < other.score

class Strategy():

    def __init__(self):
        self.switch = {BLACK: WHITE, WHITE: BLACK}
        self.funct = {BLACK: max, WHITE: min}
        self.corners = {11: (S, E), 18: (S, W), 81: (N, E), 88: (N, W)}
        self.inner = {22: 11, 27: 18, 72: 82, 77: 88}

    def get_starting_board(self):
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        for x in range(90, -1, -10):
            board = board[0:x] + "\n" + board[x::]
        return board

    def opponent(self, player):
        return SWITCH[player]

    def find_match(self, board, player, direction, index):
        op = self.opponent(player)
        if board[index + direction] == op:
            index = index + direction
            while (board[index] == op):
                index = index + direction
            if (board[index] == player):
                return index
        return False

    def make_move(self, board, player, move):
        copy = board
        for dir in DIRECTIONS:
            if (self.find_match(board, player, dir, move)):
                index = move
                while (copy[index] != player):
                    board = board[:index] + player + board[index + 1:]
                    index += dir
        return board

    def get_valid_moves(self, board, player):
        moves = list()
        for x in range(11, 91):
            found = False
            if (board[x] == '.'):
                for dir in (DIRECTIONS):
                    if (self.find_match(board, player, dir, x)):
                        moves.append(x)
                        break
        #return moves
        moves = list(set(moves))
        sect = set(moves).intersection(self.corners.keys())
        if len(sect) > 0:
            return list(sect)
        else:
            if board.count(EMPTY) > 20:  ### NEW   (CHECK how many spaces are empty)
                sect = list(set(moves).intersection(self.inner.keys()))
                if len(moves) > len(sect):
                    for x in sect:
                        if not self.inner[x] == player:
                            moves.remove(x)
            return (moves)

    def next_player(self, board, prev_player):
        if (len(self.get_valid_moves(board, SWITCH[prev_player])) > 0):
            return SWITCH[prev_player]
        if (len(self.get_valid_moves(board, prev_player)) > 0):
            return prev_player
        return None

    '''def score(self, board):
        black = board.count(BLACK)
        white = board.count(WHITE)
        return (black - white)'''

    '''def weightMoveAndMobility(self, board, player, move):
        weight = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]

        # print("Player " + str(player))
        if (board[11] == SWITCH[player]):
            weight[12] = 100
            weight[21] = 100
            weight[22] = 100

        if (board[18] == player):
            weight[17] = 100
            weight[28] = 100
            weight[27] = 100

        if (board[81] == player):
            weight[71] = 100
            weight[72] = 100
            weight[82] = 100

        if (board[88] == player):
            weight[78] = 100
            weight[77] = 100
            weight[87] = 100

        mult = -1
        if (player == BLACK):
            mult = 1

        if (weight[int(move)] <= -20):
            return 10000 * mult + random.random()
        if (self.stableEdges(board, move, player) > 0):
            return -10000 * mult + random.random()
        if (weight[int(move)] == 120):
            return -5000 * mult + random.random()
        if (weight[int(move)] == 100):
            return -3000 * mult + random.random()

        return len(self.get_valid_moves(board, player)) * mult + random.random()

    def weightDiff(self, board, player, move):
        weight = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 5020, -200, 20, 5, 5, 20, -200, 5020, 0,
            0, -200, -1000, -5, -5, -5, -5, -1000, -200, 0,
            0, 200, -5, 15, 3, 3, 15, -5, 200, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 200, -5, 15, 3, 3, 15, -5, 200, 0,
            0, -200, -1000, -5, -5, -5, -5, -1000, -200, 0,
            0, 5020, -200, 20, 5, 5, 20, -200, 5020, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]

        if (board[11] == SWITCH[player]):
            weight[12] = 100
            weight[21] = 100
            weight[22] = 100

        if (board[18] == SWITCH[player]):
            weight[17] = 100
            weight[28] = 100
            weight[27] = 100

        if (board[81] == SWITCH[player]):
            weight[71] = 100
            weight[72] = 100
            weight[82] = 100

        if (board[88] == SWITCH[player]):
            weight[78] = 100
            weight[77] = 100
            weight[87] = 100

        total = 0
        for x in range(0, 99):
            if (board[x] == BLACK):
                total += weight[x]
            elif (board[x] == WHITE):
                total -= weight[x]

        return total

    def stableEdges(self, board, player, move):
        for m in self.get_valid_moves(board, player):
            b = self.make_move(board, player, m)
            if (b[move] == SWITCH[player]):
                return 99999 + self.weightDiff(board, player, move)

        return self.weightDiff(board, player, move)'''

    def score(self, board, player=None):
        """Compute player's score (number of player's pieces minus opponent's)."""
        cp = 70
        m = 150
        mx = 300
        st = 80
        if board.count(EMPTY) < 30:
            cp = 200
            m = 60
            mx = 125
            st = 170

        if player == None:
            # print("SCORE: " + str(board.count(BLACK) - board.count(WHITE)))
            return (board.count(BLACK) - board.count(WHITE))
        mat_sub = 0

        '''matrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1500, -300, 300, 300, 300, 300, -300, 1500, 0,
            0, -300, -750, -55, -55, -55, -55, -750, -300, 0,
            0, 300, -55, 10, -3, -3, 10, -55, 300, 0,
            0, 300, -55, -3, -3, -3, -3, -55, 300, 0,
            0, 300, -55, -3, -3, -3, -3, -55, 300, 0,
            0, 300, -55, 10, -3, -3, 10, -55, 300, 0,
            0, -300, -750, -55, -55, -55, -55, -750, -300, 0,
            0, 1500, -300, 300, 300, 300, 300, -300, 1500, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        '''
        matrix = [
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
            0, 750, -20,  50,  20,  20,  50, -20, 750,   0,
            0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
            0,  50,  -5,  15,   3,   3,  15,  -5,  50,   0,
            0,  20,  -5,   3,   3,   3,   3,  -5,  20,   0,
            0,  20,  -5,   3,   3,   3,   3,  -5,  20,   0,
            0,  50,  -5,  15,   3,   3,  15,  -5,  50,   0,
            0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
            0, 750, -20,  50,  20,  20,  50, -20, 750,   0,
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        ]
        '''edges = board[11:19] + board[11:99:10] + board[18:99:10] + board[81:99]
        check = board.count(EMPTY) < 25 or edges.count(player) > 13  ############################
        if check:  ###     NEW
            matrix = [
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 400, -150, 90, 90, 90, 90, -150, 400, 0,
                0, -150, -50, 10, 10, 10, 10, -50, -150, 0,
                0, 90, 10, 15, 5, 5, 15, 10, 90, 0,
                0, 90, 10, 5, 5, 5, 5, 10, 90, 0,
                0, 90, 10, 5, 5, 5, 5, 10, 90, 0,
                0, 90, 10, 15, 5, 5, 15, 10, 90, 0,
                0, -150, -50, 10, 10, 10, 10, -50, -150, 0,
                0, 400, -150, 90, 90, 90, 90, -150, 400, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            ]'''
        for c in self.corners.keys():
            if board[c] == player:
                sum = 0
                for d in self.corners[c]:
                    cur = c + d
                    sum += d
                    # while not cur in self.corners.keys():
                    matrix[cur] = 200
                    while not cur + d in self.corners.keys():
                        cur += d
                        matrix[cur] += 75

                matrix[c + sum] = 100
        blk_mat = 0
        whi_mat = 0

        blk_stab = 0
        whi_stab = 0
        inte = list(range(0, 100))
        blk = [i for i in range(0, 100) if board[i] == BLACK]
        for i in blk:
            blk_mat += matrix[i]
            for d in DIRECTIONS:
                if board[i+d] == EMPTY:
                    blk_stab+=1
                    break
                if i in inte[11:19] + inte[11:99:10] + inte[18:99:10] + inte[81:99]:
                    blk_stab-=4
                    break

        whi = [i for i in range(0, 100) if board[i] == WHITE]
        for i in whi:
            whi_mat += matrix[i]
            for d in DIRECTIONS:
                if board[i+d] == EMPTY:
                    whi_stab+=1
                    break
                if i in inte[11:19] + inte[11:99:10] + inte[18:99:10] + inte[81:99]:
                    whi_stab-=4
                    break
        if not blk_mat + whi_mat == 0:
            mat_sub = mx * ((blk_mat - whi_mat) / ((blk_mat + whi_mat) * 1.0))

        stability = 0
        if not blk_stab + whi_stab == 0:
            stability = st*((blk_stab - whi_stab)/((blk_stab + whi_stab)*1.0))

        coin_p = cp * ((board.count(BLACK) - board.count(WHITE)) / ((board.count(BLACK) + board.count(WHITE)) * 1.0))

        blk_move = len(self.get_valid_moves(board, BLACK))  ###     MOBILITY
        whi_move = len(self.get_valid_moves(board, WHITE))
        mobility = 0
        mobility = m * (blk_move - whi_move) / ((blk_move + whi_move) * 1.0)

        return mat_sub + mobility + coin_p - stability #+ coin_p + mobility - stability

    def alphabeta(self, node, player, depth, alpha, beta):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if (depth == 0):
            node.score = self.score(board, player) + random.random()  # self.weight(board, player, node.move)
            return node

        children = []
        for m in self.get_valid_moves(board, player):
            nextBoard = self.make_move(board, player, m)
            nextPlayer = self.next_player(nextBoard, player)
            if (nextPlayer == None):
                c = Node(nextBoard, m, self.score(nextBoard, None) * 100000000)
                children.append(c)
            else:
                c = Node(nextBoard, m)
                c.score = self.alphabeta(c, nextPlayer, depth - 1, alpha, beta).score
                children.append(c)

            if (player == BLACK):
                alpha = max(alpha, c.score)
            else:
                beta = min(beta, c.score)
            if (alpha >= beta):
                break

        winner = best[player](children)
        node.score = winner.score
        return (winner)

    def ab_strategy(self, board, player, depth=3):
        beg = Node(board, 0)
        winner = self.alphabeta(beg, player, depth, -math.inf, math.inf)
        return winner.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        while (True):
            board = "".join(board)
            best_move.value = self.ab_strategy(board, player, depth)
            depth += 1
            print(depth)


'''
class Strategy():
    def __init__(self):
        self.switch = {BLACK: WHITE, WHITE: BLACK}
        self.funct = {BLACK: max, WHITE: min}
        self.corners = {11: (S, E), 18: (S, W), 81: (N, E), 88: (N, W)}
        self.inner = {22: 11, 27: 18, 72: 82, 77: 88}
        # self.neigh = {12: 11, 17: 18, 21: 11, 28: 18, 71: 81, 78: 88, 82: 81, 87: 88}

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        for x in range(90, -1, -10):
            board = board[0:x] + "\n" + board[x::]
        return board

    def opponent(self, player):
        return self.switch[player]

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        pass

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def make_move(self, board, player, move):  ### edit to use strings
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board = str(board)
        board = board[0:move] + player + board[move + 1::]  # place

        for d in DIRECTIONS:
            r = move + d
            while board[r] == self.switch[player]:
                r += d
            if board[r] == player:
                r -= d
                while board[r] == self.switch[player]:
                    board = board[0:r] + player + board[r + 1::]
                    r -= d
        return (board)

    def get_valid_moves(self, board, player):
        moves = []
        for x in range(len(board)):
            m = board[x]
            if not (m == "?") and m == player:
                for d in DIRECTIONS:
                    r = (self.direct_move(board, x + d, player, d))
                    if r is not None:
                        moves.append(r)
        return list(set(moves))
        #moves = list(set(moves))
        ''''''sect = set(moves).intersection(self.corners.keys())
        if len(sect) > 0:
            return list(sect)
        else:
            if board.count(EMPTY) > 20:  ### NEW   (CHECK how many spaces are empty)
                sect = list(set(moves).intersection(self.inner.keys()))
                if len(moves) > len(sect):
                    for x in sect:
                        if not self.inner[x] == player:
                            moves.remove(x)
            return (moves)''''''

    def direct_move(self, board, r, player, direct):
        if board[r] == self.switch[player]:
            while board[r] == self.switch[player]:
                r += direct
            if board[r] == ".":
                return r
        return None

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return not len(self.get_valid_moves(board, player)) == 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.switch[prev_player]):
            return self.switch[prev_player]
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=None):
        """Compute player's score (number of player's pieces minus opponent's)."""
        if player == None:
            # print("SCORE: " + str(board.count(BLACK) - board.count(WHITE)))
            return (board.count(BLACK) - board.count(WHITE))

        ''''''matrix = [
                  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
                  0, 400,-100,  70,  25,  25,  70,-100, 400,   0,
                  0,-100,-950,  -5,  -5,  -5,  -5,-950,-100,   0,
                  0,  70,  -5,  35,  -3,  -3,  35,  -5,  70,   0,
                  0,  25,  -5,  -3,  -3,  -3,  -3,  -5,  25,   0,
                  0,  25,  -5,  -3,  -3,  -3,  -3,  -5,  25,   0,
                  0,  70,  -5,  35,  -3,  -3,  35,  -5,  70,   0,
                  0,-100,-950,  -5,  -5,  -5,  -5,-950,-100,   0,
                  0, 400,-100,  70,  25,  25,  70,-100, 400,   0,
                  0,   0,   0,   0,   0,   0,   0,   0,   0,   0]
        ''''''
        matrix = [
                    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
                    0, 300,-150,  20,   5,   5,  20,-150, 300,   0,
                    0,-150,-300,  -5,  -5,  -5,  -5,-300,-150,   0,
                    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
                    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
                    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
                    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
                    0,-300,-300,  -5,  -5,  -5,  -5,-300,-150,   0,
                    0, 300,-150,  20,   5,   5,  20,-150, 300,   0,
                    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
                ]#'''
'''
        for c in self.corners.keys():
            if board[c] == player:
                sum = 0
                for d in self.corners[c]:
                    cur = c+d
                    sum+=d
                    #while not cur in self.corners.keys():
                    matrix[cur]=200
                        #cur+=d
                matrix[c+sum] = 100
        subscore = 0

        blk = [i for i in range(0,100) if board[i] == BLACK]
        for i in blk:
            subscore += matrix[i]
        whi = [i for i in range(0,100) if board[i] == WHITE]
        for i in whi:
            subscore -= matrix[i]
        return (board.count(BLACK) - board.count(WHITE)) + subscore
        cp = 70
        m = 200
        mx = 150
        st = 100
        if board.count(EMPTY) < 30:
            cp = 150
            m = 60

        if player == None:
            # print("SCORE: " + str(board.count(BLACK) - board.count(WHITE)))
            return (board.count(BLACK) - board.count(WHITE))
        mat_sub = 0

        matrix = [
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
            0,1500,-300, 300, 300, 300, 300,-300,1500,   0,
            0,-300,-300, -55, -55, -55, -55,-300,-300,   0,
            0, 300, -55,  10,  -3,  -3,  10, -55, 300,   0,
            0, 300, -55,  -3,  -3,  -3,  -3, -55, 300,   0,
            0, 300, -55,  -3,  -3,  -3,  -3, -55, 300,   0,
            0, 300, -55,  10,  -3,  -3,  10, -55, 300,   0,
            0,-300,-300, -55, -55, -55, -55,-300,-300,   0,
            0,1500,-300, 300, 300, 300, 300,-300,1500,   0,
            0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        ]
        matrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 120, -20, 20, 20, 20, 20, -20, 120, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 20, -5, 3, 3, 3, 3, -5, 20, 0,
            0, 20, -5, 3, 3, 3, 3, -5, 20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 120, -20, 20, 20, 20, 20, -20, 120, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        edges = board[11:19] + board[11:99:10] + board[18:99:10] + board[81:99]
        check = board.count(EMPTY) < 25 or edges.count(player) > 13  ############################
        if check:  ###     NEW
            matrix = [
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 400, -150, 90, 90, 90, 90, -150, 400, 0,
                0, -150, -50, 10, 10, 10, 10, -50, -150, 0,
                0, 90, 10, 15, 5, 5, 15, 10, 90, 0,
                0, 90, 10, 5, 5, 5, 5, 10, 90, 0,
                0, 90, 10, 5, 5, 5, 5, 10, 90, 0,
                0, 90, 10, 15, 5, 5, 15, 10, 90, 0,
                0, -150, -50, 10, 10, 10, 10, -50, -150, 0,
                0, 400, -150, 90, 90, 90, 90, -150, 400, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            ]
        for c in self.corners.keys():
            if board[c] == player:
                sum = 0
                for d in self.corners[c]:
                    cur = c + d
                    sum += d
                    # while not cur in self.corners.keys():
                    matrix[cur] = 200
                    while not cur + d in self.corners.keys():
                        cur += d
                        matrix[cur] += 75

                matrix[c + sum] = 100
        blk_mat = 0
        whi_mat = 0

        blk_stab = 0
        whi_stab = 0
        inte = list(range(0, 100))
        blk = [i for i in range(0, 100) if board[i] == BLACK]           #dont loop thru twice
        for i in blk:
            blk_mat += matrix[i]
            for d in DIRECTIONS:
                if board[i + d] == EMPTY:
                    blk_stab += 1
                    break
                if i in inte[11:19] + inte[11:99:10] + inte[18:99:10] + inte[81:99]:
                    blk_stab -= 4
                    break

        whi = [i for i in range(0, 100) if board[i] == WHITE]
        for i in whi:
            whi_mat += matrix[i]
            for d in DIRECTIONS:
                if board[i + d] == EMPTY:
                    whi_stab += 1
                    break
                if i in inte[11:19] + inte[11:99:10] + inte[18:99:10] + inte[81:99]:
                    whi_stab -= 4
                    break
        if not blk_mat + whi_mat == 0:
            mat_sub = mx * ((blk_mat - whi_mat) / ((blk_mat + whi_mat) * 1.0))

        stability = 0
        if not blk_stab + whi_stab == 0:
            stability = st * ((blk_stab - whi_stab) / ((blk_stab + whi_stab) * 1.0))

        coin_p = cp * ((board.count(BLACK) - board.count(WHITE)) / ((board.count(BLACK) + board.count(WHITE)) * 1.0))

        blk_move = len(self.get_valid_moves(board, BLACK))  ###     MOBILITY
        whi_move = len(self.get_valid_moves(board, WHITE))
        mobility = 0
        mobility = m * (blk_move - whi_move) / ((blk_move + whi_move) * 1.0)'''

        #return mat_sub #+ mobility + coin_p - stability
'''
    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return self.next_player(board, player) is None

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth, parent_move):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters

        if depth == 0: return (self.score(board, player), random.random(), parent_move)

        pmoves = self.get_valid_moves(board, player)
        # print("PLAYER: " + player)
        # print("pMOVES: " + str(pmoves))

        scenario = []  # children
        for m in pmoves:
            n_board = self.make_move(board, player, m)
            n_player = self.next_player(n_board, player)

            if n_player is None:
                scenario.append(
                    (self.score(n_board, None) * 100000, random.random(), parent_move))  # score PLAYER or n_player?
            else:
                scenario.append(self.minmax_search(n_board, n_player, depth - 1, parent_move))
        return self.funct[player](scenario)

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        pmoves = self.get_valid_moves(board, player)
        scenario = []
        for m in pmoves:
            n_board = self.make_move(board, player, m)
            n_player = self.next_player(n_board, player)

            if n_player is None:
                scenario.append((self.score(n_board, None) * 100000, random.random(), m))  # score player or n_player?
            else:
                scenario.append(self.minmax_search(n_board, n_player, depth - 1, m))
        # print(board.count(EMPTY))
        return self.funct[player](scenario)[2]

    def alpha_beta(self, node, player, depth, alpha, beta):                          #(self, board, player, depth, alpha, beta, parent):
        if depth == 0:
            node.score = self.score(node.board, player)
            return node      #(self.score(board, player), random.random(), parent)

        pmoves = self.get_valid_moves(node.board, player)
        scenario = []  # children
        for m in pmoves:
            n_board = self.make_move(node.board, player, m)
            n_player = self.next_player(n_board, player)

            if n_player is None:
                #t = (self.score(n_board, None) * 100000, random.random(), m)  # score PLAYER or n_player?
                t = Node(self.score(n_board, None) * 100000, n_board, node.parent)
                scenario.append(t)
            else:
                t = Node(0, n_board, node.parent)
                t.score = self.alpha_beta(t, player, depth - 1, alpha, beta).score
                scenario.append(t)

            if player == BLACK:  ###     PLAYER OR n_player???
                alpha = max(alpha, t.score)
            else:
                beta = min(beta, t.score)
            if alpha >= beta:
                break
        #return self.funct[player](scenario)
        winner = self.funct[player](scenario)
        node.score = winner.score
        return (winner)

    def ab_strategy(self, board, player, depth=6):
        pmoves = self.get_valid_moves(board, player)
        scenario = []  # children
        alpha = -math.inf
        beta = math.inf
        for m in pmoves:
            n_board = self.make_move(board, player, m)
            n_player = self.next_player(n_board, player)

            if n_player is None:
                #t = (self.score(n_board, None) * 100000, random.random(), m)  # score PLAYER or n_player?
                t = Node(self.score(n_board, None) * 100000, n_board, m)
                scenario.append(t)
            else:
                t = Node(0, n_board, m)
                t.score = self.alpha_beta(t, player, depth - 1, alpha, beta).score
                scenario.append(t)
            if player == BLACK:  ###     PLAYER OR n_player???
                # print("hello")
                alpha = max(alpha, t.score)
            else:
                beta = min(beta, t.score)
            if alpha >= beta:
                break
        return self.funct[player](scenario).parent
        #alpha = -math.inf
        #beta = math.inf
        #node = Node(0 , board, )
        #return self.alpha_beta(node, player, depth, alpha, beta)

    def sri_search(self, node, player, depth, alpha, beta):
        board = node.board
        if (depth == 0):
            node.score = self.score(node.board, player)
            return node

        children = []
        for m in self.get_valid_moves(board, player):
            nextBoard = self.make_move(board, player, m)
            nextPlayer = self.next_player(nextBoard, player)
            if (nextPlayer == None):
                c = Node(self.score(nextBoard) * 100000000, nextBoard, m)
                children.append(c)
            else:
                c = Node(0, nextBoard, m)
                c.score = self.sri_search(c, player, depth - 1, alpha, beta).score
                children.append(c)

            if (player == BLACK):
                alpha = max(alpha, c.score)
            else:
                beta = min(beta, c.score)
            if (alpha >= beta):
                break
        winner = self.funct[player](children)
        node.score = winner.score
        return (winner)
    def sri_strat(self, board, player, depth = 6):
        node = Node(0, board, board)
        winner = self.sri_search(node, player, depth, -999999, 999999)
        return winner.parent

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.sri_strat(board, player, depth)
            depth += 1
            #print(depth)
        #print("DONE")

    standard_strategy = sri_strat

class Node():
    def __init__(self, score, board, move):
        self.score = score
        self.board = board
        self.parent = move
    def __lt__(self, other):
        return self.score < other.score
'''