import sys
   
def partitionMoves(game,player):
   moves = rows(game,player)
   moves1 = cols(game,player)
   moves2 = diags(game,player)
   moves3 = moves.union(moves1)
   finalmoves = moves3.union(moves2)
   return finalmoves

def cols(game,player):
   if player == "X":
      sets = ["XO.","XOO.","XOOO.","XOOOO.","XOOOOO.","XOOOOOO."]
      sets2 = [".OX",".OOX",".OOOOX",".OOOOOX",".OOOOOOX",".OOOX"]
   else:
      sets = ["OX.","OXX.","OXXX.","OXXXX.","OXXXXX.","OXXXXXX."]
      sets2 = [".XO",".XXO",".XXXO",".XXXXO",".XXXXXO",".XXXXXXO"]
   moves = set()
   for i in col:
      sequence = [game[x] for x in i]
      seqstring = ''.join(sequence) 
      for a in sets:
         if a in seqstring:
            moves.add(i[seqstring.index(a)+len(a)-1])
      for b in sets2:
         if b in seqstring:
            moves.add(i[seqstring.index(b)])
   return moves

def diags(game,player):
   if player == "X":
      sets = ["XO.","XOO.","XOOO.","XOOOO.","XOOOOO.","XOOOOOO."]
      sets2 = [".OX",".OOX",".OOOOX",".OOOOOX",".OOOOOOX",".OOOX"]
   else:
      sets = ["OX.","OXX.","OXXX.","OXXXX.","OXXXXX.","OXXXXXX."]
      sets2 = [".XO",".XXO",".XXXO",".XXXXO",".XXXXXO",".XXXXXXO"]
   moves = set()
   for i in diag:
      sequence = [game[x] for x in i]
      seqstring = ''.join(sequence)   
      for a in sets:
         if a in seqstring:
            moves.add(i[seqstring.index(a)+len(a)-1])
      for b in sets2:
         if b in seqstring:
            moves.add(i[seqstring.index(b)])
   return moves

def rows(game,player):
   if player == "X":
      sets = ["XO.","XOO.","XOOO.","XOOOO.","XOOOOO.","XOOOOOO."]
      sets2 = [".OX",".OOX",".OOOOX",".OOOOOX",".OOOOOOX",".OOOX"]
   else:
      sets = ["OX.","OXX.","OXXX.","OXXXX.","OXXXXX.","OXXXXXX."]
      sets2 = [".XO",".XXO",".XXXO",".XXXXO",".XXXXXO",".XXXXXXO"]
   moves = set()
   for i in row:
      sequence = [game[x] for x in i]
      seqstring = ''.join(sequence)   
      for a in sets:
         if a in seqstring:
            moves.add(i[seqstring.index(a)+len(a)-1])
      for b in sets2:
         if b in seqstring:
            moves.add(i[seqstring.index(b)])
   return moves  
      
def chooseBest(moves):
   if len(moves) == 0:
      return 64
   copy = set(moves)
   listt = list(moves)
   #greedy corners
   for i in moves:
      if i in [0,7,56,63]:
         return i
   game2 = game[:]
   for i in moves:
      game2[i] = player
      moves2 = partitionMoves(game,opp)
      copy2 = set(moves2)
      for x in copy2:
         if x in [0,7,56,63] and i in moves2:
            moves.remove(i)
      game2[i] = "."
   if len(moves) == 0:
      moves = set(copy)
   #safe edges
   CX = {1:0,8:0,9:0,6:7,15:7,14:7,57:56,48:56,49:56,62:63,55:63,54:63}
   pre3 = set(moves)
   #c or x moves
   for i in listt:
      if i in CX:
         if game[CX.get(i)] != player:
            copy.remove(i)
   if len(copy) == 0:
      return chooseBest2(pre3)
   else:
      return chooseBest2(copy)

def chooseBest2(set):
   if len(set) == 1:
      return set.pop()
   dict = {}
   edges = [0,1,2,3,4,5,6,7,8,16,24,32,40,48,56,57,58,59,60,61,62,63,55,47,39,31,23,15]
   for i in set:
      if i in edges:
         return i
      countt = 0
      game[i] = player
      countt += flipTokens(game,i,row,player,opp)
      countt += flipTokens(game,i,col,player,opp)
      countt += flipTokens(game,i,diag,player,opp)
      dict[i] = countt
   inverse = [(value, key) for key, value in dict.items()]
   return max(inverse)[1]
      
def flipTokens(game,pos,table,player,opp):
   count = 0
   for i in table:
      if pos in i:
         positions = i[:]
         characters = [game[x] for x in i]
         if player in characters and opp in characters:
            fragment = ''.join(characters)
            setsX = ["XOX","XOOX","XOOOX","XOOOOX","XOOOOOX","XOOOOOOX"]
            setsO = ["OXO","OXXO","OXXXO","OXXXXO","OXXXXXO","OXXXXXXO"]
            if player == "X":
               for x in setsX:
                  if x in fragment:
                     length = len(x)
                     index = positions.index(pos)
                     frag1 = fragment[index:index + length]
                     frag2 = fragment[index-length+1:index+1]
                     if frag1 == x:
                        for y in range(index, index+length):
                           count+=1
                     if frag2 == x:
                        for y in range(index-length+1,index):
                           count+=1
            else:
               for x in setsO:
                  if x in fragment:
                     length = len(x)
                     index = positions.index(pos)
                     frag1 = fragment[index:index + length]
                     frag2 = fragment[index-length+1:index+1]
                     if frag1 == x:
                        for y in range(index, index+length):
                           count+=1
                     if frag2 == x:
                        for y in range(index-length+1,index):
                           count+=1
   return count
   
def negamax2(game,player,level):
   #need to change this to terminate when there are no moves left      
   moves = partitionMoves(game,player)
   opp = "O" if player == "X" else "X"
   oppmoves = partitionMoves(game,opp)
   if len(moves) == 0 and len(oppmoves) == 0:
      return [evalGame(game,player)]
   negMax = [negamax(makeMove(game,player,move),opp,level-1) + [move] for move in moves]
   if len(negMax) > 0:
      best = negMax[0]
      return [-best[0]] + best[1:]
   else:
      return [evalGame(game,player)]
      
def negamax3(game,player,level):
   if level == 0:
      return [evalGame(game,player)]
   moves = partitionMoves(game,player)
   opp = "O" if player == "X" else "X"
   if len(moves) == 0:
      negMax = negamax(game,opp,level-1)
      return [-negMax[0]] + negMax[1:]
   negMax = sorted([negamax(makeMove(game,player,move),opp,level-1) + [move] for move in moves])
   best = negMax[0]
   return [-best[0]] + best[1:]

def negamax(game, player, levels):
  if levels == 0: 
     return [evalGame(game, player)]
  opp = "O" if player == "X" else "X"
  lm = partitionMoves(game, player)
  if len(lm) == 0: 
     best = negamax(game, opp, levels-1)
  else: 
     best = sorted([negamax(makeMove(game, player, mv), opp, levels-1) + [mv] for mv in lm])[-1]
  return [-best[0]] + best[1:]

def makeMove(game,player,pos):
   game[int(pos)] = player
   opp = "O" if player == "X" else "X" 
   game = flipTokens2(game,pos,row,player,opp)
   game = flipTokens2(game,pos,col,player,opp)
   game = flipTokens2(game,pos,diag,player,opp)
   return game

def evalGame(game,player):
   opp = "X" if player == "O" else "O"
   return(game.count(player) - game.count(opp))

def flipTokens2(game,pos,table,player,opp):
   for i in table:
      if pos in i:
         positions = i[:]
         characters = [game[x] for x in i]
         if player in characters and opp in characters:
            fragment = ''.join(characters)
            setsX = ["XOX","XOOX","XOOOX","XOOOOX","XOOOOOX","XOOOOOOX"]
            setsO = ["OXO","OXXO","OXXXO","OXXXXO","OXXXXXO","OXXXXXXO"]
            if player == "X":
               for x in setsX:
                  if x in fragment:
                     length = len(x)
                     index = positions.index(pos)
                     frag1 = fragment[index:index + length]
                     frag2 = fragment[index-length+1:index+1]
                     if frag1 == x:
                        for y in range(index, index+length):
                           game[positions[y]] = player
                     if frag2 == x:
                        for y in range(index-length+1,index):
                           game[positions[y]] = player
            else:
               for x in setsO:
                  if x in fragment:
                     length = len(x)
                     index = positions.index(pos)
                     frag1 = fragment[index:index + length]
                     frag2 = fragment[index-length+1:index+1]
                     if frag1 == x:
                        for y in range(index, index+length):
                           game[positions[y]] = player
                     if frag2 == x:
                        for y in range(index-length+1,index):
                           game[positions[y]] = player
   return game
      
col = [[0,8,16,24,32,40,48,56],[1,9,17,25,33,41,49,57],
      [2,10,18,26,34,42,50,58],[3,11,19,27,35,43,51,59],
      [4,12,20,28,36,44,52,60],[5,13,21,29,37,45,53,61],
      [6,14,22,30,38,46,54,62],[7,15,23,31,39,47,55,63]]
row = [
      [0,1,2,3,4,5,6,7],[8,9,10,11,12,13,14,15],
      [16,17,18,19,20,21,22,23],[24,25,26,27,28,29,30,31],
      [32,33,34,35,36,37,38,39],[40,41,42,43,44,45,46,47],
      [48,49,50,51,52,53,54,55],[56,57,58,59,60,61,62,63]]
diag = [
      [0],[8,1],[16,9,2],[24,17,10,3],[32,25,18,11,4],
      [40,33,26,19,12,5],[48,41,34,27,20,13,6],
      [56,49,42,35,28,21,14,7],[57,50,43,36,29,22,15],
      [58,51,44,37,30,23],[59,52,45,38,31],[60,53,46,39],
      [61,54,47],[62,58],[63],[7],[6,15],[5,14,23],
      [4,13,22,31],[3,12,21,30,39],[2,11,20,29,38,47],
      [1,10,19,28,37,46,55],[0,9,18,27,36,45,54,63],
      [8,17,26,35,44,53,62],[16,25,34,43,52,61],[56],
      [24,33,42,51,60],[32,41,50,59],[40,49,58],[48,57]]

game = list(sys.argv[1])
game1 = game[:]
for i in range(len(game)):
   if game[i] == "x" or game[i] == "o":
      game[i] = game[i].upper()
player = sys.argv[2].upper()
opp = "O" if player == "X" else "X"
#print 2D board
#show possible moves on the board (lab1)
#print my heuristic choice is + the choice
for i in range(8): print(''.join(game[i*8:i*8 + 8]))
print()
moves = partitionMoves(game,player)
print(moves)
if len(moves) == 1:
   print(moves.pop())
elif chooseBest(moves) == 64:
   print("-1")
else:
   print("My heuristic gives: " + str(chooseBest(moves)))
   #if empties less than 8 then run negamax with levels = -1
   #this guarantees that negamax gives you a terminal answer bc if you subtract, the level will never be 0
   #ISSUE IS THAT I'M PRINTING THE DIFFERENCE NOT THE END GAME SCORE FOR O
   if game1.count(".") <= 8:
      nm = negamax(game, player, game1.count("."))
      print("At level {}, negamax gives {}".format(game1.count("."), nm))
      print("and I pick {}".format(nm[-1]))