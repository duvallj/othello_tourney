import random
import math

#### Othello Shell
#### P. White 2016-2018
import collections

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, SW, W, NW, S)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
DIR_OPPOSITES = {N: S, E: W, NE: SW, NW: SE}
DEPTH = 1
OPPONENT = {WHITE: BLACK, BLACK: WHITE}
# table, frontier, stability, mobility
WEIGHTS = (455, 432, 332, 543, 0)

SCORE = [
    # 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    # 0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
    # 0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
    # 0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
    # 0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
    # 0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
    # 0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
    # 0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
    # 0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
    # 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 120, -20, 0, 0, 0, 0, -20, 120, 0,
    0, -20, -40, 0, 0, 0, 0, -40, -20, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, -20, -40, 0, 0, 0, 0, -40, -20, 0,
    0, 120, -20, 0, 0, 0, 0, -20, 120, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, board, parent=None, move=None):
        self.parent = parent
        self.board = board
        self.score = None
        self.frontier_score = None
        self.real_score = None
        self.table_score = None
        self.stability_score = None
        self.valid_moves = {BLACK: None, WHITE: None}
        self.num_moves_score = None
        self.edges = None
        self.frontier = None
        self.move = move
        self.stable = None

    def get_frontier(self):
        if self.frontier is not None:
            return self.frontier
        if self.parent is not None:
            self.frontier = set(self.parent.frontier) - {self.move}
            for dir in DIRECTIONS:
                if self.board[self.move + dir] == EMPTY:
                    self.frontier.add(self.move + dir)
            return self.frontier
        self.frontier = set()
        for square in range(11, 89):
            for dir in DIRECTIONS:
                if self.board[square + dir] == EMPTY:
                    self.frontier.add(square + dir)
        return self.frontier

    def get_edges(self):
        if self.edges is not None:
            return self.edges
        if self.parent is not None:
            self.edges = set(self.parent.edges)
            if any(self.board[self.move + dir] == EMPTY for dir in DIRECTIONS):
                self.edges.add(self.move)
            for dir in DIRECTIONS:
                if self.board[self.move + dir] in PLAYERS:
                    if all(self.board[self.move + dir + dira] != EMPTY for dira in DIRECTIONS):
                        self.edges.discard(self.move + dir)
            return self.edges
        self.edges = set()
        for i in range(11, 89):
            if not self.board[i] in PLAYERS:
                continue
            if any(self.board[i + dir] == EMPTY for dir in DIRECTIONS):
                self.edges.add(i)
        return self.edges


class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [[EMPTY for i in range(10)] for j in range(10)]
        for i in range(10):
            for j in range(10):
                if i == 0 or i == 9 or j == 9 or j == 0:
                    board[i][j] = OUTER
        board[4][4], board[5][5] = WHITE, WHITE
        board[4][5], board[5][4] = BLACK, BLACK
        out = ''.join([''.join(c) for c in board])
        return out

    def get_pretty_board(self, node):
        board = node.board
        """Get a string representation of the board."""
        return (''.join(board[i:i + 10] + '\n' for i in range(0, 100, 10)))[:-1]
        pass

    def find_match(self, node, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        board = node.board
        if board[square + direction] == OPPONENT[player]:
            square += direction
            while board[square] == OPPONENT[player]:
                square = square + direction
            if board[square] == player:
                return square
            else:
                return None
        else:
            return None

    def is_move_valid(self, node, player, move):
        """Is this a legal move for the player?"""
        for d in DIRECTIONS:
            if self.find_match(node, player, move, d) is not None:
                return True
        return False

    def make_move(self, node, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        b = [c for c in node.board]
        matches = {}
        for d in DIRECTIONS:
            match = self.find_match(node, player, move, d)
            if match is not None:
                matches[d] = match
        b[move] = player
        for d in matches:
            s = move + d
            while b[s] == OPPONENT[player]:
                b[s] = player
                s = s + d
        return Node(''.join(b), node, move)

    def get_valid_moves(self, node, player):
        """Get a list of all legal moves for player."""
        if node.valid_moves[player] is not None:
            return node.valid_moves[player]
        moves = []
        for index in node.get_frontier():
            c = node.board[index]
            if c == EMPTY and self.is_move_valid(node, player, index):
                moves.append(index)
        node.valid_moves[player] = moves
        return moves

    def has_any_valid_moves(self, node, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(node, player)) != 0

    def next_player(self, node, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(node, OPPONENT[prev_player]):
            return OPPONENT[prev_player]
        if self.has_any_valid_moves(node, prev_player):
            return prev_player
        return None

    def score(self, node, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        if node.score is not None:
            return node.score if player == BLACK else -node.score
        sum = 0
        for c in node.board:
            if c == BLACK:
                sum += 1
            if c == WHITE:
                sum -= 1
        node.score = sum
        return sum if player == BLACK else -sum

    def game_over(self, node, player):
        """Return true if player and opponent have no valid moves"""
        return self.next_player(node, player) is None

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def stability_score(self, node, player=BLACK):
        if node.stability_score is not None:
            return node.stability_score if player == BLACK else -1 * node.stability_score
        board = node.board
        # required = {11, 12, 21, 18, 17, 28, 81, 82, 71, 88, 87, 78}
        # if all(board[s] == EMPTY for s in required):
        #     return 0
        diag_r = set()
        for i in list(range(11, 19)) + list(range(21, 82, 10)):
            current = set()
            while board[i] != EMPTY and board[i] != OUTER:
                current.add(i)
                i += 11
            if board[i] == OUTER:
                diag_r |= current
        diag_l = set()
        for i in list(range(81, 89)) + list(range(11, 72, 10)):
            current = set()
            while board[i] != EMPTY and board[i] != OUTER:
                current.add(i)
                i -= 9
            if board[i] == OUTER:
                diag_l |= current
        rows = set()
        for i in range(11, 82, 10):
            current = set()
            while board[i] != EMPTY and board[i] != OUTER:
                current.add(i)
                i += 1
            if board[i] == OUTER:
                rows |= current
        cols = set()
        for i in range(11, 22):
            current = set()
            while board[i] != EMPTY and board[i] != OUTER:
                current.add(i)
                i += 10
            if board[i] == OUTER:
                cols |= current
        stable = rows & cols & diag_r & diag_l
        if len(stable) == 0:
            node.stability_score = 0
            node.stable = stable
            return 0

        def search(square, direction):
            s = square + direction
            if board[s] in stable:
                return True
            while board[s] == BLACK or board[s] == WHITE:
                s = s + direction
            if s == OUTER:
                return True
            return False

        while True:
            prev_stable = set(stable)
            for i in range(11, 89):
                if i in stable or board[i] == EMPTY or board[i] == OUTER:
                    continue
                if all(search(i, dir) or search(i, DIR_OPPOSITES[dir]) for dir in DIR_OPPOSITES):
                    stable.add(i)
            if prev_stable == stable:
                score = sum(1 if board[i] == BLACK else -1 for i in stable)
                node.stability_score = score
                node.stable = stable
                return score if player == BLACK else -score

    def num_moves_score(self, node, player=BLACK):
        if node.num_moves_score is not None:
            return node.num_moves_score if player == BLACK else -node.num_moves_score
        board = node.board
        score = len(self.get_valid_moves(node, BLACK)) - len(self.get_valid_moves(node, WHITE))
        node.num_moves_score = score
        if player == BLACK:
            return score
        else:
            return score * -1

    def table_score(self, node, player=BLACK):
        if node.table_score is not None:
            return node.table_score if player == BLACK else -1 * node.table_score
        board = node.board
        total = 0
        for index in range(11, 89):
            character = board[index]
            if character == EMPTY or character == OUTER:
                continue
            else:
                score = SCORE[index]
                if character == BLACK:
                    total += score
                else:
                    total -= score
        node.table_score = total
        return total if player == BLACK else -total

    def get_children(self, node, weights, player):
        moves = list(self.get_valid_moves(node, player))
        moves.sort(key=lambda x: (self.move_score(x, node, weights, player), random.random()),
                   reverse=True)
        return [self.make_move(node, player, move) for move in moves]

    def frontier_score(self, node, player=BLACK):
        if node.frontier_score is not None:
            return node.frontier_score if player == BLACK else -1 * node.frontier_score
        total = sum(1 if node.board[x] == BLACK else -1 for x in node.get_frontier())
        node.frontier_score = total
        return total if player == BLACK else -total

    def real_score(self, node, weights, player=BLACK):
        if node.real_score is not None:
            return node.real_score if player == BLACK else -node.real_score
        if self.game_over(node, player):
            node.real_score = self.score(node) * float('inf')
            return node.real_score if player == BLACK else -node.real_score
        score = self.table_score(node)*weights[0] + self.frontier_score(
            node) * weights[1] + self.stability_score(
            node) * weights[2] + self.num_moves_score(node) * weights[3]
        node.real_score = score
        return score if player == BLACK else -score

    def alphabeta(self, node, depth, a, b, weights, player):
        if player is None:
            return self.real_score(node, weights)
        if depth == 0 or self.game_over(node, player):
            return self.real_score(node, weights)
        if player == BLACK:
            v = -float('inf')
            for child in self.get_children(node, weights, player):
                v = max(v, self.alphabeta(child, depth - 1, a, b, weights, self.next_player(child, player)))
                a = max(a, v)
                if b <= a:
                    break
            return v
        else:
            v = float('inf')
            for child in self.get_children(node, weights, player):
                v = min(v, self.alphabeta(child, depth - 1, a, b, weights, self.next_player(child, player)))
                b = min(b, v)
                if b <= a:
                    break
            return v

    def minmax_strategy(self, node, player, weights=(40, 1, 0.5, 1, 1, 1), depth=DEPTH):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move:
        self.valid_moves_black = dict()
        self.valid_moves_white = dict()
        children = self.get_valid_moves(node, player)
        children.sort(key=lambda x: (self.move_score(x, node, weights, player), random.random()),
                      reverse=True)
        methods = {BLACK: max, WHITE: min}
        boards = {'inf': float('inf'), 'neginf': -float('inf')}
        a = 'neginf'
        b = 'inf'
        if player == BLACK:
            v = 'neginf'
            for child in children:
                boards[child] = self.alphabeta(self.make_move(node, player, child), depth - 1, boards[a], boards[b],
                                               weights,
                                               self.next_player(self.make_move(node, player, child), player))
                v = max(v, child, key=lambda x: boards[x]) if v != 'neginf' else child
                a = max(a, v, key=lambda x: boards[x])
                if boards[b] <= boards[a]:
                    break
        else:
            v = 'inf'
            for child in children:
                boards[child] = self.alphabeta(self.make_move(node, player, child), depth - 1, boards[a], boards[b],
                                               weights,
                                               self.next_player(self.make_move(node, player, child), player))
                v = min(v, child, key=lambda x: boards[x]) if v != 'inf' else child
                a = min(a, v, key=lambda x: boards[x])
                if boards[b] <= boards[a]:
                    break
        return v

    def move_score(self, move, node, weights, player):
        return random.random()
        # return self.real_score(self.make_move(node, player, move), weights, player)

    def random_strategy(self, node, player):
        return random.choice(list(self.get_valid_moves(node, player)))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        node = Node(''.join(board))
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(node, player, WEIGHTS, depth)
            depth += 1

    def parallel_random_strategy(self, board, player, best_move, still_running):
        best_move.value = self.random_strategy(Node(board), player)

    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = Node(ref.get_starting_board())
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


class TestPlayer():
    def __init__(self, games):
        self.num_games = games

    def play(self, vals_a, vals_b):
        scores = {WHITE: 0, BLACK: 0}
        for i in range(self.num_games):
            if random.random() < 0.5:
                winner = self.run_game(vals_a, vals_b)
                if winner == BLACK:
                    scores[BLACK] += 1
                else:
                    scores[WHITE] += 1
            else:
                winner = self.run_game(vals_b, vals_a)
                if winner == BLACK:
                    scores[WHITE] += 1
                else:
                    scores[BLACK] += 1
            scores[winner] += 1
        return max(scores, key=lambda x: scores[x])
        # print('Black: %i \tWhite: %i' % (scores[BLACK], scores[WHITE]))

    def run_game(self, vals_a, vals_b):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()
        vals = {BLACK: vals_a, WHITE: vals_b}
        board = Node(ref.get_starting_board())
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}

        while player is not None:
            move = strategy[player](board, player, vals[player])
            board = ref.make_move(board, player, move)
            player = ref.next_player(board, player)

        score = ref.score(board)
        if score >= 0:
            # print('Black Wins %i' % score)
            return BLACK
        else:
            # print('White Wins %i' % score)
            return WHITE


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = Node(ref.get_starting_board())
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.parallel_random_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board.board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board.board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        print(winner)
        return board, ref.score(board, BLACK)


################################################
# The main routine
################################################
if __name__ == "__main__":
    # t = TestPlayer(10)
    # default = ()
    # adsf = True
    # i = 3
    # step = 0.2
    # running_total = 0
    # last_50 = 0
    # for j in range(1, 10000):
    #     last_50+=vals_a[i]
    #     running_total += vals_a[i]
    #     print(vals_b[i], '\t', vals_a[i], '\t', running_total/j)
    #     winner = t.play(vals_a, vals_b)
    #     if winner == BLACK:
    #         vals_a = (*vals_a[:i], vals_a[i] + step, *vals_a[i + 1:])
    #     else:
    #         vals_a = (*vals_a[:i], vals_a[i] - step, *vals_a[i + 1:])
    #     if j%5 == 0:
    #         vals_b = (*vals_a[:i], last_50/5, *vals_a[i + 1:])
    #         last_50 = 0
    def merge(a, b):
        binb = format(b, '010b')
        bina = format(a, '010b')
        breakpoint = random.randint(0, len(binb))
        s = bina[:breakpoint] + binb[breakpoint:]
        for i in range(len(binb)):
            if random.random()<0.001:
                s = s[:i] + bin(int(s[i])+1)[-1] + s[i+1:]
        return int(s, 2)


    def generate_child(a, b):
        return tuple([merge(a[i], b[i]) for i in range(5)])


    pool = [tuple([random.randint(0, 1023) for i in range(5)]) for j in range(100)]
    t = TestPlayer(10)
    while True:
        
        pairs = [tuple([pool[i], pool[i + 1]]) for i in range(0, len(pool), 2)]
        new_pool = []
        for pair in pairs:
            winner = t.run_game(pair[0], pair[1])
            if winner == BLACK:
                new_pool.append(pair[0])
            else:
                new_pool.append(pair[1])
        print(' '.join([str(sum(new_pool[i][j] / len(new_pool) for i in range(len(new_pool)))) for j in range(5)]))
        children = [generate_child(new_pool[i], new_pool[i + 1]) for i in range(0, len(new_pool), 2)] + [
            generate_child(new_pool[i], new_pool[i + 1]) for i in range(0, len(new_pool), 2)]
        pool = children + new_pool
        random.shuffle(pool)
