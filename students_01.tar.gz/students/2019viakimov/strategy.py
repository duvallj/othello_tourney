#
#Vasil Iakimovitch
import sys
from time import time
emptyBoard=['.']*27+['o','x']+['.']*6+['x','o']+['.']*27 #...........................ox......xo...........................
edgePositions={1,2,3,4,5,6, 8,16,24,32,40,48, 15,23,31,39,47,55, 57,58,59,60,61,62} #Does not include corners
neighbors=[(-1, -1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)]

class Strategy():
  def best_strategy(self, board, player, best_move, still_running):
    brd=[] #Don't use board
    for letter in board:
      if(letter!='?'):
        if(letter=='@'):
          brd.append('x')
        else:
          brd.append(letter)
    if player == '@':
      token, otherToken='x', 'o'
    else:
      token, otherToken='o', 'x'
    mv=selectMove(legalMoves(brd, token, otherToken), brd[:], token, otherToken) #selectMove(brd, token, otherToken)
    best_move.value=11+(mv//8)*10+(mv%8)
    
    for x in range(5, 100):
      nmMV=negamaxTerminal(brd[:], token, otherToken, -65, 65, x)[-1]
      best_move.value=11+(nmMV//8)*10+(nmMV%8)

def printBoard(board):
  toPrint=""
  for x in range(0,8):
    toPrint+="".join(board[x*8:(x*8)+8])+'\n'
  print(toPrint)

def nextPiece(board):
  if(board.count('.')%2==0):
    return 'x', 'o' #Next, other
  else:
    return 'o', 'x' #Next, other

def outOfBounds(board, position, neighbor):
  col=position%8
  row=position//8
  if((neighbor[0]==-1 and col==0) or (neighbor[0]==1 and col==7)): #X shift
    return True
  elif((neighbor[1]==-1 and row==0) or (neighbor[1]==1 and row==7)): #Y shift
    return True
  return False

def legalMoves(board, piece, otherPiece):
  possibleMoves=set()
  for position in range(0,64):
    if(board[position] != '.'):
      continue #x, y
    for neighbor in neighbors:
      neighborPos=position
      count=1
      while(not outOfBounds(board, neighborPos, neighbor)):
        neighborPos=neighborPos+neighbor[0]+(neighbor[1]*8)
        if(board[neighborPos] == '.'):
          break
        elif(board[neighborPos]==piece):
          if(count>1):
            count+=1
          break
#         elif(board[neighborPos]==piece and count>1):
#           count+=1
#           break
        count+=1
      if(count>=3 and board[neighborPos]==piece):
        possibleMoves.add(position)
      
  return possibleMoves

def playMove(board, piece, position, otherPiece):
  movesPlayed, spacesFilled, validNeighbor = set(), set(), None
  
  if(board[position] != '.'):
    print("Invalid Move: Space is not empty")
    return [], {-1}
  for neighbor in neighbors:
    tempSpacesFilled=set()
    neighborPos=position
    count=1
    while(not outOfBounds(board, neighborPos, neighbor)):
      neighborPos=neighborPos+neighbor[0]+(neighbor[1]*8)
      if(board[neighborPos] == '.'):
        break
      elif(board[neighborPos]==piece and count==1):
        break
      elif(board[neighborPos]==piece and count>1):
        count+=1
        #tempSpacesFilled.add(neighborPos)
        break
      count+=1
      tempSpacesFilled.add(neighborPos)
    if(count>=3 and board[neighborPos]==piece):
      movesPlayed.add(position)
      spacesFilled=spacesFilled.union(tempSpacesFilled)
      validNeighbor=neighbor
    
  if(movesPlayed):
    for space in spacesFilled:
      board[space]=piece
    board[position]=piece
    return board, {str(movesPlayed.pop())}, spacesFilled, validNeighbor #Make moves played a single var?
  else:
    print("Invalid Move: No possible moves")
    return [], {-1}, set(), None

def a1toint(a1): #A1 string input (letter is column, number is row)
  letters='abcdefgh'
  numbers='12345678'
  return letters.find(a1[0].lower())+(numbers.find(str(a1[1]))*8)

#Input Format: Board (optional), Piece that moves next(optional) (assume inputed in any order)
def processInputs(): #Receives, inputs convert to lowercase and indexes
  board, nextToken, positions, otherToken = emptyBoard, None, [], None
  for arg in sys.argv[1:]: #['..O...O...OXXO...XO.X...OOOXX.O.OOOOXOO..OXXXOO..XX.XOO.X.....OX', 'x']:  #sys.argv[1:]: # ['...........................oxx.....xo...........................','19','x','c5','44']: #['...........................oxx.....xo...........................', '19']:
    if(len(arg)==64):
      board=list(arg.lower())
    elif(arg.lower()=='x'):
      nextToken, otherToken='x','o'
    elif(arg.lower()=='o'):
      nextToken, otherToken='o','x'
    elif(arg.isdigit()):
      positions.append(int(arg))
    elif(arg[0].isalpha() and arg[1].isdigit()):
      positions.append(a1toint(arg))
  if(nextToken==None):
    nextToken, otherToken=nextPiece(board)
  if(board != ['.']*64 and not legalMoves(board, nextToken, otherToken)):
    nextToken, otherToken = otherToken, nextToken
  return board, nextToken, positions, otherToken

def safeEdgeMoves(possibleMoves, board, piece, otherPiece):
  possibleEdgeMoves=possibleMoves.intersection(edgePositions)
  list1, list2, spacesFilled, neighbor=[],[], None, None
  for position in possibleEdgeMoves:
    board, position, spacesFilled, neighbor = playMove(board, piece, position, otherPiece)
    if(position in {1,2,3,4,5,6}):
      edge=board[0:8]
      list1, list2 = edge[0:position], edge[position:]  
    elif(position in {8,16,24,32,40,48}):
      edge=board[0]+board[8]+board[16]+board[24]+board[32]+board[40]+board[48]+board[56]
      list1, list2 = edge[0:position//8], edge[position//8:]
    elif(position in {15,23,31,39,47,55}):
      edge=board[7]+board[15]+board[23]+board[31]+board[39]+board[47]+board[55]+board[63]
      list1, list2 = edge[0:position//8], edge[position//8:]
    elif(position in {57,58,59,60,61,62}):
      edge=board[56:64]
      list1, list2 = edge[0:position%8], edge[position%8:]
    
    if(set(list1)=={piece} or set(list2)=={piece}):
      return {position} #Can modify to add position to safeEdgeMoves set and return that
    else:
      for space in spacesFilled:
        board[space]=otherPiece
  
  return {}

def evalBoard(board, token, otherToken):
  return board.count(token)-board.count(otherToken)

def negamax(board, token, levels, otherToken, looping):
  if levels==0:# or looping: #Levels have ended
    return [evalBoard(board,token, otherToken)]
  lm=legalMoves(board, token, otherToken)
  if not lm: #Passing
    #looping=True #Deals with the -1 level looping
    nm=negamax(board, otherToken, levels-1, token, looping)+[-1]
    return [-nm[0]]+nm[1:]
  nmList=sorted([negamax(playMove(board[:], token, mv, otherToken)[0], otherToken, levels-1, token, looping)+[mv] for mv in lm])
  best=nmList[0]
  return [-best[0]]+best[1:]

def negamaxTerminal(brd, token, otherToken, improvable, hardBound, level):
  if not level:
    return [evalBoard(brd, token, otherToken), -3]
  lm=legalMoves(brd, token, otherToken)
  if not lm:
    lm=legalMoves(brd, otherToken, token)
    if not lm: return [evalBoard(brd, token, otherToken), -3]
    nm=negamaxTerminal(brd[:], otherToken, token, -hardBound, -improvable, level-1)+[-1]
    return [-nm[0]]+nm[1:]
  best=[] #What gets returned
  newHB=-improvable
  for mv in lm:
    nm=negamaxTerminal(playMove(brd[:], token, mv, otherToken)[0], otherToken, token, -hardBound, newHB, level-1)+[mv]
    if not best or nm[0]<newHB:
      best=nm
      if nm[0]<newHB:
        newHB=nm[0]
        if -newHB>=hardBound: return [-best[0]]+best[1:] #Prune, comment out to do standard negamax
  return [-best[0]]+best[1:]

def selectMove(possibleMoves, board, piece, otherPiece):  
  if(0 in possibleMoves): return 0 #Play into a corner if possible
  elif(7 in possibleMoves): return 7
  elif(56 in possibleMoves): return 56
  elif(63 in possibleMoves): return 63
  safeEdges=safeEdgeMoves(possibleMoves, board, piece, otherPiece)
  if(safeEdges): return safeEdges.pop() #Play into a safe edge move if possible
  
  #Can I drop the corner checking here?
  if(board[0]!=piece and possibleMoves-{1,8,9}): #Remove x and c squares from possible moves if your piece is not in that corner
    possibleMoves=possibleMoves-{1,8,9}
  if(board[7]!=piece and possibleMoves-{6,14,15}):
    possibleMoves=possibleMoves-{6,14,15}
  if(board[56]!=piece and possibleMoves-{48,49,57}):
    possibleMoves=possibleMoves-{48,49,57}
  if(board[63]!=piece and possibleMoves-{54,55,62}):
    possibleMoves=possibleMoves-{54,55,62}
    
  if(possibleMoves-edgePositions):
    possibleMoves=possibleMoves-edgePositions
    
  return possibleMoves.pop()

def fromCommandLine():
  starttime=time()
  board=list(sys.argv[1].lower())
  if(sys.argv[2].lower()=='x'):
    nextToken, otherToken='x','o'
  else:
    nextToken, otherToken='o','x'
#   board=list('...........................ox......xo...........................'.lower())
#   nextToken='x'
#   otherToken='o'
#   board=list('XXXXXXXXOXOXXXOXOOXXXXOXOOXXXXOXOOOOXXXXXXOXXXXX..OOOOOX......OX'.lower())
#   nextToken='x'
#   otherToken='o'
  printBoard(board)
  possibleMoves=legalMoves(board, nextToken, otherToken)
  print("Possible Moves: {}".format(possibleMoves))
  print("My heuristic choice is {}".format(selectMove(possibleMoves, board[:], nextToken, otherToken)))
    #nmreturned= negamax(board, nextToken, board.count('.')*2, otherToken, False)
  for x in range(5, 100):
    nmreturned=negamaxTerminal(board[:], nextToken, otherToken, -65, 65, x)
    print("Negamax returns {} and I choose move {}".format(nmreturned, nmreturned[-1]))
    
#   if board.count('.')<=12:
#     nmreturned=negamaxTerminal(board, nextToken, otherToken, -65, 65, 14)
#     print("Negamax returns {} and I choose move {}".format(nmreturned, nmreturned[-1]))
  # for move in possibleMoves:
  #   inputBoard[move]='*'
  # #printBoard(inputBoard)
  
def debugOnline():
  best_move, still_running=-1, True
  Strategy.best_strategy('???????????@@@oooo.??o@ooo@..??.ooooooo??o@@o@@o.??o@oo@o@@??@@o@o@oo??..ooooo.??...oo.o@???????????'.lower(), '@'.lower(), best_move, still_running)
  print(best_move)
  
  
if __name__=="__main__":
  fromCommandLine()
  #debugOnline()

#0.7718 Script ran in 54.04549860954285 seconds