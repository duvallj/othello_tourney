# Phillip Reeves
import sys, random

directional_increments = {(y, x) for x in {-1, 0, 1} for y in {-1, 0, 1} if
                          x != 0 or y != 0}  # {(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)}
corners = {0, 7, 56, 63}
c_x = {1, 6, 8, 9, 14, 15, 48, 49, 54, 55, 57, 62}
top_edge = {i for i in range(1, 7)}
bottom_edge = {i for i in range(57, 63)}
left_edge = {i for i in range(8, 55, 8)}
right_edge = {i for i in range(15, 56, 8)}
edge_set = top_edge | bottom_edge | left_edge | right_edge
top_dct = {i: [0, -1, 0, 1] for i in range(1, 7)}
bottom_dct = {i: [0, -1, 0, 1] for i in range(57, 63)}
left_dct = {i: [-1, 0, 1, 0] for i in range(8, 55, 8)}
right_dct = {i: [-1, 0, 1, 0] for i in range(15, 56, 8)}
edge_dct = {}
edge_dct.update(top_dct)
edge_dct.update(bottom_dct)
edge_dct.update(left_dct)
edge_dct.update(right_dct)
midGameWeightings = {0:20, 1:1, 2:15, 3:15, 4:15, 5:15, 6:1, 7:20, 8:1, 9:2, 10:6, 11:6, 12:6, 13:6, 14:2, 15:1, 16:15, 17:6, 18:12, 19:8, 20:8, 21:12, 22:6, 23:15, 24:15, 25:6, 26:8, 27:10, 28:10, 29:8, 30:6, 31:15, 32:15, 33:6, 34:8, 35:10, 36:10, 37:8, 38:6, 39:15, 40:15, 41:6, 42:12, 43:8, 44:8, 45:12, 46:6, 47:15, 48:1, 49:2, 50:6, 51:6, 52:6, 53:6, 54:2, 55:1, 56:20, 57:1, 58:15, 59:15, 60:15, 61:15, 62:1, 63:20}


def explore_dir(brd, turn, row, col, dr, dc):
    if row < 0 or col < 0 or row > 7 or col > 7 or brd[row * 8 + col] == ".":
        return -1
    elif brd[row * 8 + col] == turn:
        return 0
    if dc < 0 and col == 0: return -1
    if dc > 0 and col == 7: return -1
    explore = explore_dir(brd, turn, row + dr, col + dc, dr, dc)
    if explore >= 0:
        return explore + 1
    else:
        return explore


def legalMoves(brd, turn):
    lm = set()
    flips = {}
    spaces = {i for i in range(64) if brd[i] == "."}
    for space in spaces:
        for dir in directional_increments:
            dr = dir[0]
            dc = dir[1]
            tmpR = space // 8 + dr
            tmpC = space % 8 + dc
            flip = explore_dir(brd, turn, tmpR, tmpC, dr, dc)
            if flip > 0:
                lm.add(space)
            if space not in flips: flips[space] = set()
            for i in range(flip):
                flips[space] = flips[space] | {tmpR * 8 + tmpC}
                tmpR += dr
                tmpC += dc
    return lm, flips


def flipTokens(brd, token, index, flips):
    brd = brd[:index] + token + brd[index + 1:]
    for idx in flips:
        brd = brd[:idx] + token + brd[idx + 1:]
    return brd


def negaMax(brd, token, level):
    enemy = list({"x", "o"} - {token})[0]
    if brd.count(".") == 0: return [brd.count(token) - brd.count(enemy)]
    lm, flips = legalMoves(brd, token)
    enemy_lm, notUsed = legalMoves(brd, enemy)
    if len(lm) <= 0 and len(enemy_lm) <= 0: return [brd.count(token) - brd.count(enemy)]
    if not lm:
        nm = negaMax(brd, enemy, level - 1) + [-1]
        return [-nm[0]] + nm[1:]
    nmlist = [negaMax(flipTokens(brd, token, mv, flips[mv]), enemy, level - 1) + [mv] for mv in lm]
    best = sorted(nmlist)[0]
    return [-best[0]] + best[1:]

def alphaBeta(brd, token, enemy, lower, upper):
    lm, flipsForLM = legalMoves(brd, token)
    if not lm:
        elm, flipsForELM = legalMoves(brd, enemy)
        if not elm:
            return [brd.count(token)-brd.count(enemy), -3]  #game over
        ab = alphaBeta(brd, enemy, token, -upper, -lower) + [-1]
        return [-ab[0]] + ab[1:]
    newUpper = -lower
    seq = []
    for mv in lm:
        ab = alphaBeta(flipTokens(brd, token, mv, flipsForLM[mv]), enemy, token, -upper, newUpper) + [mv]
        if not seq or ab[0] < newUpper:
            seq = ab
            if ab[0] < newUpper:
                newUpper = ab[0]
                if -newUpper >= upper:
                    return [-seq[0]] + seq[1:]
    return [-seq[0]] + seq[1:]

def testEdge(brd, r, c, dr, dc, turn):
    if r * 8 + c not in range(64): return False
    if brd[r * 8 + c] != turn: return False
    if r * 8 + c in corners: return True
    return testEdge(brd, r + dr, r + dc, dr, dc, turn)

def weightedScore(brd, token):
    count = 0
    toCount = {i for i in range(64) if brd[i] == token}
    for index in toCount:
        count += midGameWeightings[index]
    return count


class Strategy():
    # implement all the required methods on your own
    def best_strategy(self, board, player, best_move, running):
        # time.sleep(1)
        if running.value:
            turn = "x" if player == "@" else "o"
            brd = "".join(board)
            brd = brd.replace("?", "")
            brd = brd.replace("@", "x")
            lm, flipsForLM = legalMoves(brd, turn)
            enemy = "o" if turn == "x" else "x"

            blank = True
            myMove = random.choice(list(lm))
            # Greedy Corners:
            corn = corners & lm
            if len(corn) > 0:
                myMove = random.choice(list(corn))
                blank = False

            # Safe Edges:
            possible_edges = edge_set & lm
            possMoves = []
            for index in possible_edges:
                if blank:
                    d = edge_dct[index]
                    bord = brd[:index] + turn + brd[index + 1:]
                    for idx in flipsForLM[index]:
                        bord = bord[:idx] + turn + bord[idx + 1:]
                    if len(bord) != 64: sys.exit()
                    currow = index // 8 + d[0]
                    curcol = index % 8 + d[1]
                    while blank and currow * 8 + curcol in range(64) and bord[currow * 8 + curcol] == turn:
                        if currow * 8 + curcol in corners:
                            possMoves.append(index)
                            blank = False
                        currow += d[0]
                        curcol += d[1]
                    currow = index // 8 + d[2]
                    curcol = index % 8 + d[3]
                    while blank and currow * 8 + curcol in range(64) and bord[currow * 8 + curcol] == turn:
                        if currow * 8 + curcol in corners:
                            possMoves.append(index)
                            blank = False
                        currow += d[2]
                        curcol += d[3]
                    if not blank and len(possMoves) > 0: myMove = random.choice(possMoves)

            if blank:
                # Avoid C or X
                for index in c_x:
                    if index in lm:
                        if len(lm) > 1: lm.remove(index)

                # Avoid Edges
                for index in edge_set:
                    if index in lm:
                        if len(lm) > 1: lm.remove(index)

                myMove = random.choice(list(lm))

            best_move.value = 10 + (myMove // 8) * 10 + 1 + (myMove % 8)

            if board.count(".") <= 15:
                ab = alphaBeta(brd, turn, enemy, -65, 65)
                mv = ab[-1]
                best_move.value = 10 + (mv // 8) * 10 + 1 + (mv % 8)
            else:
                heuristicToIdx, minimizationLst, noMove, moveIdx = {}, [], 10000, -1
                for move in lm:
                    tmpBrd = flipTokens(brd, turn, move, flipsForLM[move])
                    ELM, flipsForELM = legalMoves(tmpBrd, enemy)
                    sc = weightedScore(tmpBrd, enemy)
                    if len(ELM) == 0 and sc < noMove:
                        noMove = sc
                        moveIdx = move
                    tokensWeight = 0
                    for mv in ELM:
                        tokensWeight += midGameWeightings[mv]
                    heuristic = len(ELM)*8 + tokensWeight
                    heuristicToIdx[heuristic] = move
                    minimizationLst.append(heuristic)
                if moveIdx != -1: 
                    myMove = moveIdx
                else:
                    myMove = heuristicToIdx[sorted(minimizationLst)[0]]
                best_move.value = 10 + (myMove // 8) * 10 + 1 + (myMove % 8)

if __name__ == '__main__':
    if len(sys.argv) >= 2:
        board = sys.argv[1].lower()
    else:
        board = "...........................ox......xo..........................."
        print(board)
    if len(sys.argv) >= 3:
        turn = sys.argv[2].lower()
    else:
        turn = "x" if sum(1 for i in range(64) if board[i] != ".") % 2 == 0 else "o"
    lm, flipsForLM = legalMoves(board, turn)
    brd = board[:]
    for index in lm:
        brd = brd[:index] + "*" + brd[index + 1:]
    print("\n".join(" ".join(brd[i * 8:i * 8 + 8]) for i in range(8)))
    print("Legal/possible moves: %s" % (list(lm)))
    enemy = "o" if turn == "x" else "x"

    blank = True
    myMove = ("None", -1)
    # Greedy Corners:
    corn = corners & lm
    if len(corn) > 0:
        myMove = ("\'Greedy Corners\'", random.choice(list(corn)))
        blank = False

    # Safe Edges:
    possible_edges = edge_set & lm
    possMoves = []
    for index in possible_edges:
        if blank:
            d = edge_dct[index]
            brd = board[:index] + turn + board[index + 1:]
            for idx in flipsForLM[index]:
                brd = brd[:idx] + turn + brd[idx + 1:]
            if len(brd) != 64: sys.exit()
            currow = index // 8 + d[0]
            curcol = index % 8 + d[1]
            while blank and currow * 8 + curcol in range(64) and brd[currow * 8 + curcol] == turn:
                if currow * 8 + curcol in corners:
                    possMoves.append(index)
                    blank = False
                currow += d[0]
                curcol += d[1]
            currow = index // 8 + d[2]
            curcol = index % 8 + d[3]
            while blank and currow * 8 + curcol in range(64) and brd[currow * 8 + curcol] == turn:
                if currow * 8 + curcol in corners:
                    possMoves.append(index)
                    blank = False
                currow += d[2]
                curcol += d[3]
            if not blank: myMove = ("\'Safe Edges\'", random.choice(possMoves))

    if blank:
        # Avoid C or X
        for index in c_x:
            if index in lm:
                if len(lm) > 1: lm.remove(index)

        # Avoid Edges
        for index in edge_set:
            if index in lm:
                if len(lm) > 1: lm.remove(index)

        myMove = ("\'Avoid C or X, then avoid edges\'", random.choice(list(lm)))

    print("My heuristic choice is %s and my move is %s" % myMove)

    if board.count(".") <= 15:
        ab = alphaBeta(board, turn, enemy, -65, 65)
        print("Negamax returns: %s and my move is %s" % (ab, ab[-1]))
    else:
        heuristicToIdx, minimizationLst, noMove, moveIdx = {}, [], 10000, -1
        for move in lm:
            tmpBrd = flipTokens(brd, turn, move, flipsForLM[move])
            ELM, flipsForELM = legalMoves(tmpBrd, enemy)
            sc = weightedScore(tmpBrd, enemy)
            if len(ELM) == 0 and sc < noMove:
                noMove = sc
                moveIdx = move
            tokensWeight = 0
            for mv in ELM:
                tokensWeight += midGameWeightings[mv]
            heuristic = len(ELM)*8 + tokensWeight
            heuristicToIdx[heuristic] = move
            minimizationLst.append(heuristic)
        if moveIdx != -1: 
            print("The enemy has no legal moves if I play here and my move is %s" %(moveIdx))
        else:
            print("The weighted minimization of position strength and enemy moves produces the best move of %s" %(heuristicToIdx[sorted(minimizationLst)[0]]))
