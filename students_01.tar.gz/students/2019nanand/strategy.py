import sys
import collections
import random
class Strategy:
  def best_strategy(self, board, player, best_move, still_running):
      s=''.join(board).replace('@','x').replace('?','')
      if player=='@':
        c='x'
      else:
        c='o'
      f=collections.Counter(s)
      n=7
      if(f['.']<=n):
        levels=9
        nm = negamax(s,c,levels)
        mv=nm[-1]
      else:
        mv=choose(findPossibleMoves(s, c),s,c).pop()
      mv=11+(mv//8)*10+(mv%8)
      best_move.value=mv
def main():
  if len(sys.argv)==1:
    s='...........................xo......ox...........................'
    c=whoTurn(s)
  elif len(sys.argv)==2:
    s=sys.argv[1].lower()
    c=whoTurn(s)
  elif len(sys.argv)==3:  
    c=sys.argv[2].lower()
    s=sys.argv[1].lower()
  f=collections.Counter(s)
  shape(s, findPossibleMoves(s,c))
  print("Possible Moves: ",end="")
  print(findPossibleMoves(s, c))
  print("Heuristic: ", end="")
  print(choose(findPossibleMoves(s, c),s,c).pop())
  n=8
  if(f['.']<=n):
    levels=9
    nm = negamax(s,c,levels)
    print("Negamax score: ",end="")
    print(nm[0])
    print("Negamax move: ", end="")
    print(nm[-1])
def choose(p, board, c):
  corners={0,7,56,63}
  if p.intersection(corners):
    p=p.intersection(corners)
  else:
    newp=set()
    for pos in p:
      if edgePath(pos, board, c):
        newp.add(pos)
    if newp:
      p=newp
    else: 
      if(board[0]!=c):
        p.remove(1)
        p.remove(8)
        p.remove(9)
      if(board[7]!=c):
        p.remove(6)
        p.remove(15)
        p.remove(14)
      if(board[56]!=c):
        p.remove(48)
        p.remove(49)
        p.remove(57)
      if(board[63]!=c):
        p.remove(62)
        p.remove(55)
        p.remove(54)
      for thing in p:
        if True in bounds(thing):
          p.remove(thing)
  return Random.choice(p)
def negamax(board, token, levels):
    if not levels: return [evalBoard(board,token)]
    lm = findPossibleMoves(board, token)
    if not lm:
        nm = negamax(board, opponent(token), levels-1) + [-1]
        return [-nm[0]]+nm[1:]
    nmList = sorted([negamax(makeMove(board,token,move), opponent(token), levels-1)+[move] for move in findPossibleMoves(board, token)])
    best = nmList[0]
    return [-best[0]] + best[1:]
def evalBoard(board, token):
  f=collections.Counter(board)
  num = f[token] - f[opponent(token)]
  return num
def choose(p, board, c):
  corners={0,7,56,63}
  if p.intersection(corners):
    return p.intersection(corners)
  else:
    newp=set()
    for pos in p:
      if edgePath(pos, board, c):
        newp.add(pos)
    if newp:
      pass
    else:
      if(board[0]!=c):
        try:
          if(len(p)>1):
            p.remove(1)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(8)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(9)
        except KeyError:
          pass
      if(board[7]!=c):
        try:
          if(len(p)>1):
            p.remove(6)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(15)
        except KeyError:
          pass
        try:
          if(len(p)>1):			
            p.remove(14)
        except KeyError:
          pass
      if(board[56]!=c):
        try:
         if(len(p)>1):
          p.remove(48)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(49)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(57)
        except KeyError:
          pass
      if(board[63]!=c):
        try:
          if(len(p)>1):
            p.remove(62)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(55)
        except KeyError:
          pass
        try:
          if(len(p)>1):
            p.remove(54)
        except KeyError:
          pass
      news=set()
      for thing in p:
        news.add(thing)
      for thing in news:
        if True in bounds(thing) and len(p)>1:
          p.remove(thing)
  return p
def shape(board, p):
  b=[*board]
  #for j in p:
    #b[j]='#'
  board=''.join(b)
  print('\n'.join([board[i:i+8] for i in range(0,64,8)]))
  print('\n')
def findPossibleMoves(board, c):
  possible=set()
  if c=='x':
    o='o'
  else:
    o='x'
  for i in range(len(board)):
    if board[i]==c:
      for x in findLines(board, i, c, o):
        possible.add(x)
  return possible
def findLines(board, pos, c, o):
  possibles=set()
  directions=[-9,-8,-7,-1,+7,+8,+9,+1]
  edges=[(0,2),(2),(1,2),(0),(0,3),(3),(1,3),(1)]
  for i in range(0,8,2):
    d=directions[i]
    if(pos+d>=0 and pos+d<=63):
      if(board[pos+d]==o):
        curr=pos
        while bounds(curr)[edges[i][0]]==False and bounds(curr)[edges[i][1]]==False:
          curr=curr+d
          if(board[curr]==c):
            break
          elif(board[curr]==o):
            continue
          elif(board[curr]=='.'):
            possibles.add(curr)
            break
  for i in range(1,8,2):
    d=directions[i]
    if(pos+d>=0) and pos+d<=63:
      if(board[pos+d]==o):
        curr=pos
        while bounds(curr)[edges[i]]==False:
          curr=curr+d
          if(board[curr]==c):
            break
          elif(board[curr]==o):
            continue
          elif(board[curr]=='.'):
            possibles.add(curr)
            break
  return possibles
def edgePath(pos, board, c):
  if bounds(pos)[0] or bounds(pos)[1]:
    temp=pos
    while bounds(temp)[2]==False:
      if board[temp]!=c:
        break
      temp += -8
      if bounds(temp)[2] and board[temp]==c:
        return True
        break
    temp=pos
    while bounds(temp)[3]==False:
      if board[temp]!=c:
        break
      temp += 8
      if bounds(temp)[3] and board[temp]==c:
        return True
        break
  if bounds(pos)[2] or bounds(pos)[3]:
    temp=pos
    while bounds(temp)[0]==False:
      if board[temp]!=c:
        break
      temp += -1
      if bounds(temp)[0] and board[temp]==c:
        return True
    temp=pos
    while bounds(temp)[1]==False:
      if board[temp]!=c:
        break
      temp += 1
      if bounds(temp)[1] and board[temp]==c:
        return True
  return False
def whoTurn(game):
  f=collections.Counter(game)
  if f['.']%2==0:
    return 'x'
  else:
    return 'o'  
def bounds(i):
  leftEdge=(i%8==0)
  rightEdge=(i%8==7)
  topEdge=(i<8)
  bottomEdge=(i>55)
  return [leftEdge,rightEdge,topEdge,bottomEdge]
def opponent(token):
  if token=='x':
    return 'o'
  else:
    return 'x'
def makeMove(board, token, move):
  if(token=='o'):
    opponent='x'
  else:
    opponent='o'
  dirs, ends = flipdirections(board, move, token, opponent)
  return flip(board, move, token, opponent, dirs, ends)
def flip(board, pos, c, o, dirs, ends):
  b=[*board]
  for i in range(len(dirs)):
    d=dirs[i]
    e=ends[i]
    curr=pos+d
    while curr!=e:
      b[curr]=c
      curr+=d
  b[pos]=c
  return ''.join(b)
def flipdirections(board, pos, c, o):
  dirs, ends = [],[]
  directions=[-9,-8,-7,-1,+7,+8,+9,+1]
  edges=[(0,2),(2),(1,2),(0),(0,3),(3),(1,3),(1)]
  for i in range(0,8,2):
    d=directions[i]
    if pos+d>=0 and pos+d<64:
      if(board[pos+d]==o):
        curr=pos
        while bounds(curr)[edges[i][0]]==False and bounds(curr)[edges[i][1]]==False:
          curr=curr+d
          if(board[curr]==c):
            if(curr!=pos+d):
              dirs.append(d)
              ends.append(curr)
            break
          elif(board[curr]==o):
            continue
          elif(board[curr]=='.'):
            break
  for i in range(1,8,2):
    d=directions[i]
    if pos+d>=0 and pos+d<64:
      if(board[pos+d]==o):
        curr=pos
        while bounds(curr)[edges[i]]==False:
          curr=curr+d
          if(board[curr]==c):
            if(curr!=pos+d):
              dirs.append(d)
              ends.append(curr)
            break
          elif(board[curr]==o):
            continue
          elif(board[curr]=='.'):
            break
  return dirs,ends
if __name__=='__main__':
  main()
