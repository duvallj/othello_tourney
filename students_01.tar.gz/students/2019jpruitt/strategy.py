#!
#Jenny Pruitt p3
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        #format
        game=''.join(board).replace("?","").replace("@","X").replace("o","O")
        tile = "X" if player=="@" else"O"
        #variables
        global cornerTiles, cornerDictionary, computer, neighboringIndexes, n, BLACK, WHITE, EMPTY, SIZE, LENGTH
        n=64
        BLACK, WHITE, EMPTY, SIZE, LENGTH = "X", "O", ".", 64, 8
        cornerTiles = {0, 7, 63, 56}
        cornerDictionary = {0: [1, 1], 7: [-1, 1], 63: [-1, -1], 56: [1, -1]}
        edgeTiles = {1, 8, 6, 15, 48, 57, 62, 55, 16, 2, 5, 23, 40, 58, 61, 47, 3, 4, 24, 32, 59, 60, 31, 39}
        neighboringIndexes = {
                index: [(index + r + c, r, c) for c in range(-1, 2) for r in range(-LENGTH, LENGTH + 1, LENGTH) if
                SIZE > index + r > -1 and (index + c) // LENGTH == index // LENGTH and
                index + r + c != index] for index in range(SIZE)}
        legalMovesTable = {} #board token
        opp = returnOther(tile)

        #heuristic first
        move = -1
        lm = legalMoves(game, tile, opp)
        lmStrategy = lm.keys()
        if lmStrategy:
            continuedEdges = checkCorners(game, tile)&lmStrategy
            notProtect = XCpieces(game, tile)&lmStrategy
            if cornerTiles & lmStrategy:
                move = random.choice([*cornerTiles & lmStrategy])  # pick corner
            elif continuedEdges:
                move = random.choice([*continuedEdges])  # pick safe edges
            if lmStrategy - notProtect: lmStrategy = lmStrategy - notProtect  # don't pick X,C if possible
            if lmStrategy - edgeTiles: lmStrategy = lmStrategy - edgeTiles  # don't pick edges if possible
            if move == -1:  # if the move is not already chosen
                move = random.choice([*lmStrategy])  # pick out of legalMoves
                # lmStrategy.remove(move)  # this part makes sure the move doesn't give the person a corner
                # tempGame = changeTiles(game, move, tile, opp)
                # tempLegalMoves = legalMoves(tempGame, opp, tile)
                # while lmStrategy and cornerTiles & tempLegalMoves:
                #     move = random.choice([*lmStrategy])
                #     lmStrategy.remove(move)
                #     tempGame = changeTiles(game, move, tile, opp)
                #     tempLegalMoves = legalMoves(tempGame, opp, tile)
            best_move.value = 11+(move//8)*10+move%8
        if game.count(EMPTY) <= n:
            nm = negamaxTerminal(game, tile, opp, -65, 65, legalMovesTable)
            best_move.value=11+(nm[-1]//8)*10+nm[-1]%8
        # else:
        #     for i in range(2,10, 2):
        #         nm = negamax(game, i, tile, opp, legalMovesTable)
        #         best_move.value=11+(nm[-1]//8)*10+nm[-1]%8

import sys, random
def main():
    global cornerTiles, cornerDictionary, computer, neighboringIndexes, n, BLACK, WHITE, EMPTY, SIZE, LENGTH

    BLACK, WHITE, EMPTY, SIZE, LENGTH = "X", "O", ".", 64, 8
    cornerTiles = {0, 7, 63, 56}
    cornerDictionary = {0: [1, 1], 7: [-1, 1], 63: [-1, -1], 56: [1, -1]}
    edgeTiles = {1,8,6,15,48,57,62,55,16,2,5,23,40,58,61,47,3,4,24,32,59,60,31,39}
    neighboringIndexes = {index:[(index + r + c, r, c) for c in range(-1, 2) for r in range(-LENGTH, LENGTH+1,LENGTH) if
                    SIZE > index + r > -1 and (index + c) // LENGTH == index // LENGTH and
                 index + r + c != index] for index in range(SIZE)}
    legalMovesTable = {} #X is in 0 and O is in 1
    if len(sys.argv)==3:game, computer, n=sys.argv[1].upper(), sys.argv[2].upper(), 64
    else:game, computer, n=sys.argv[1].upper(), sys.argv[2].upper(), int(sys.argv[3])
    tile=computer
    opp = returnOther(computer)
    displayGame(game)
    print(" ")
    print("Legal Moves: {}".format(legalMoves(game, tile, opp)))
    move = -1
    lm = legalMoves(game, tile, opp)
    lmStrategy = lm.keys()
    if lmStrategy:
        continuedEdges = checkCorners(game, tile)&lmStrategy
        notProtect = XCpieces(game, tile)&lmStrategy
        if cornerTiles&lmStrategy: move = random.choice([*cornerTiles&lmStrategy])  # pick corner
        elif continuedEdges:  move = random.choice([*continuedEdges])  # pick safe edges
        if lmStrategy - notProtect: lmStrategy = lmStrategy - notProtect  # don't pick X,C if possible
        if lmStrategy-edgeTiles: lmStrategy=lmStrategy-edgeTiles  # don't pick edges if possible
        if move ==-1:  # if the move is not already chosen
            move = random.choice([*lmStrategy])  #pick out of legalMoves
            # lmStrategy.remove(move)  # this part makes sure the move doesn't give the person a corner
            # tempGame = changeTiles(game, move, opp, tile)
            # tempLegalMoves = legalMoves(tempGame, opp, tile)
            # while lmStrategy and cornerTiles&tempLegalMoves:
            #     move = random.choice([*lmStrategy])
            #     lmStrategy.remove(move)
            #     tempGame = changeTiles(game, move, opp, tile)
            #     tempLegalMoves = legalMoves(tempGame, opp, tile)
        print("My heuristic choice is {}".format(move))
    if game.count(EMPTY) <= n:
        nm = negamaxTerminal(game, computer, opp, -65, 65, legalMovesTable)
        print("Negamax Terminal returns {} and I choose move {}".format(nm,nm[-1]))
        print(nm[-1])
    # else:
    #     for i in range(2, 10,2):
    #         nm = negamax(game, i, tile, opp, legalMovesTable)
    #         print("Negamax returns {} at level {} and I choose move {}".format(nm, i, nm[-1]))
    #         print(nm[-1])


def XCpieces(game, tile):
    XCtiles = set()
    for corner in cornerTiles:
        x,y = cornerDictionary[corner]
        if game[corner]!=tile: XCtiles= XCtiles | {corner+x, corner+y*LENGTH, corner+x+y*LENGTH}
    return XCtiles


def checkCorners(game, tile):
    edges=set()
    for corner in cornerTiles:
        pos = corner
        if game[corner]==tile:
            while(pos//LENGTH==corner//LENGTH):
                if game[pos]==EMPTY:
                    edges.add(pos)
                    break
                pos+=cornerDictionary[corner][0]
            pos = corner
            while(-1<pos<SIZE):
                if game[pos]==EMPTY:
                    edges.add(pos)
                    break
                pos+=cornerDictionary[corner][1]*LENGTH
    return edges

def legalMoves(game, tile, opp):
    possibleMoves={}
    for pos in range(len(game)):
        if game[pos]==EMPTY:
            allFlips = []
            for neighbor in neighboringIndexes[pos]:
                if game[neighbor[0]]==opp:
                    posTemp, rtrans, ctrans = neighbor
                    flips=[]
                    while(LENGTH > posTemp // LENGTH and posTemp // LENGTH >= 0 and 0 <= posTemp and posTemp <= 63):
                        if game[posTemp]==tile:
                            allFlips+=flips
                            break
                        if game[posTemp]!=opp:break
                        if (posTemp + ctrans) // LENGTH != posTemp // LENGTH: break
                        flips.append(posTemp)
                        posTemp+=rtrans+ctrans
            if allFlips:
                allFlips.append(pos)
                possibleMoves[pos]=allFlips
    return possibleMoves

def changeTiles(game, tile, flips):
    for i in flips:
        game=game[:i]+tile+game[i+1:]
    return game


def heuristic(game, tile, opp):
    if game.count(EMPTY)<30:
        toReturn = game.count(tile)-game.count(opp)
    else:
        toReturn = game.count(opp) - game.count(tile)

    continuedEdges = checkCorners(game, tile)
    notProtect = XCpieces(game, tile)

    continuedEdgesO = checkCorners(game, opp)
    notProtectO = XCpieces(game, opp)

    for pos in notProtectO:
        toReturn+=4
    for pos in continuedEdgesO:
        toReturn-=3
    for pos in continuedEdges:
        toReturn+=2
    for pos in notProtect:
        toReturn -=5
    for pos in cornerTiles:
        if game[pos]== tile: toReturn+=4
        elif game[pos]==opp: toReturn-=10
    toReturn-=len(legalMoves(game, opp, tile))
    return toReturn

def negamax(game, depth, tile, opp, legalMovesTable):
    if depth==0: return [heuristic(game, tile, opp)]
    key = game+" "+tile
    if key in legalMovesTable:
        lm = legalMovesTable[key]
    else:
        lm = legalMoves(game, tile, opp)
        legalMovesTable[key]=lm
    if not lm:
        if not legalMoves(game,opp,tile):
            return [heuristic(game, tile, opp)]
        nm = negamax(game, depth-1,opp,tile, legalMovesTable) + [-1]
        return[-nm[0]]+nm[1:]
    nmList=sorted([negamax(changeTiles(game,tile, lm[move]),depth-1,opp,tile, legalMovesTable) + [move] for move in lm])
    best=nmList[0]
    return [-best[0]]+best[1:]


def negamaxTerminal(game, tile, opp, a, b, legalMovesTable):
    key = game+" "+tile
    if key in legalMovesTable: lm = legalMovesTable[key]
    else:
        lm = legalMoves(game, tile, opp)
        legalMovesTable[key]=lm
    if not lm:
        if not legalMoves(game, opp, tile):
            return [game.count(tile) - game.count(opp), -3]
        nm = negamaxTerminal(game, opp, tile, -b, -a, legalMovesTable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    for move in lm:
        if not best:
            nm = negamaxTerminal(changeTiles(game, tile, lm[move]), opp, tile, -b,-a, legalMovesTable)+[move]
            nm = [-nm[0]]+nm[1:]
        a, best = max(a, nm[0]), max(best,nm)
        if a>b: break
    return best


# helpers
def whoesMove(game):
    return WHITE if game.count(EMPTY) % 2 else BLACK


def returnOther(tile):
    return WHITE if tile == BLACK else BLACK


def displayGame(game):
    print("\n".join(" ".join(game[r * LENGTH:r * LENGTH + LENGTH]) for r in range(LENGTH)))


if __name__=="__main__":
    main()
