import sys
import time

nums = [1, 7, 8, 9]
bad = [1, 6, 8, 9, 10, 14, 15, 48, 49, 54, 55, 57, 62]
baddie = {0: [1, 9, 8], 7: [6, 14, 15], 56: [48, 49, 57], 63: [62, 54, 55]}
good = [0, 7, 56, 63]

def display(othello):
    if not (len(othello) == 0):
        print(othello[0:8])
        othello = othello[8:]
        display(othello)

def finder(ch, toe):
    returner = []
    for x in range(0, len(toe)):
        if toe[x] == ".":
            returner.append(x)
    return returner

def inBounds(index):
    if index > 63 or index < 0:
        return False
    else:
        return True

def edges(size):
    edges = []
    for x in range(0, 8):
        edges.append(x)
    y = 0
    while not(y==56):
        y = y + 8
        edges.append(y)
    for x in range(57, 64):
        edges.append(x)
    i = 7
    while not(i == 63):
        i = i + 8
        edges.append(i)
    return edges

def opponent(ch):
    if ch == 'X':
        return 'O'
    else:
        return 'X'

def places(initial, index, oppo):
    for i in nums:
        x = index + i
        if x < 64 and x > -1:
            while x < 64 and x > -1 and initial[x] == oppo:
                if inBounds(x + i):
                    if initial[x + i] == ch:
                        x = x + i
                        if i == 1:
                            if x // 8 == index // 8:
                                return True
                            else:
                                x = x + 64
                        if i == 7:
                            if x % 8 < index % 8:
                                return True
                            else:
                                x = x + 64
                        if i == 8:
                            if x % 8 == index % 8:
                                return True
                            else:
                                x = x + 64
                        if i == 9:
                            if x % 8 > index % 8:
                                return True
                            else:
                                x = x + 64
                else:
                    break
                x = x + i
                if x > 63 or x < 0:
                    break
        y = index - i
        if y < 64 and y > -1:
            while y < 64 and y > -1 and initial[y] == oppo:
                if initial[y - i] == ch:
                    y = y - i
                    if i == 1:
                        if y // 8 == index // 8:
                            return True
                        else:
                            y = y + 64
                    if i == 7:
                        if y % 8 > index % 8:
                            return True
                        else:
                            y = y + 64
                    if i == 8:
                        if y % 8 == index % 8:
                            return True
                        else:
                            y = y + 64
                    if i == 9:
                        if y % 8 < index % 8:
                            return True
                        else:
                            y = y + 64
                y = y - i
                if y > 63 or y < 0:
                    break
    return False


def moves(othello, ch):
    possibilities = []
    oppo = opponent(ch)
    spots = finder(oppo, othello)
    for x in spots:
        adder = places(othello, x, oppo)
        if adder:
            possibilities.append(x)
    return possibilities

def adder(string, index, symbol):
    return string[:index] + symbol + string[index + 1:]

def adderTwo(string, symbol, index):
    return string[:index] + symbol + string[index + 1:]


def displayWithPos(initial, pos, character):
    ch = character
    returner = initial
    for x in pos:
        returner = returner[:x] + ch + returner[x + 1:]
    return returner

def flip(initial, position, ch):
    oppo = opponent(ch)
    returner = set()
    for i in nums:
        pos = position
        list = set()
        while pos + i < 64 and pos + i > -1 and initial[pos + i] == oppo:
            pos += i
            list.add(pos)
        pos += i
        if pos < 64 and pos > -1:
            if initial[pos] == ch:
                if i == 1:
                    if pos//8 == position//8:
                        returner.update(list)
                if i == 7:
                    if pos%8 < position%8:
                        returner.update(list)
                if i == 8:
                    if pos%8 == position%8:
                        returner.update(list)
                if i == 9:
                    if pos%8 > position%8:
                        returner.update(list)
    for i in nums:
        pos = position
        list = set()
        while pos - i < 64 and pos - i > -1 and initial[pos - i] == oppo:
            pos -= i
            list.add(pos)
        pos -= i
        if pos < 64 and pos > -1:
            if initial[pos] == ch:
                if i == 1:
                    if pos//8 == position//8:
                        returner.update(list)
                if i == 7:
                    if pos%8 > position%8:
                        returner.update(list)
                if i == 8:
                    if pos%8 == position%8:
                        returner.update(list)
                if i == 9:
                    if pos%8 < position%8:
                        returner.update(list)
    return returner


def translate(input):
    return ((int(input[1])-1) * 8)+ (ord(input[0].upper()) - ord("A"))


def scoreCount(initial):
    counterX = 0
    counterO = 0
    for x in initial:
        if x == "X":
            counterX = counterX +1
        if x == "O":
            counterO = counterO + 1
    return counterX, counterO

def findbest(initial, done, ch):
    x = finder(ch, initial)
    edge = edges(9)
    notters = []
    for i in done:
        if i in good:
            return i
    for i in done:
        if i in edge:
            notters.append(i)
            poss = flip(initial, i, ch)
            for dub in poss:
                for y in good:
                    if dub == y:
                        return i
    done = set(done)
    notters = set(notters)
    final = done - notters
    for x in final:
        return x
    wow = done.pop()
    return wow


def flipper(initial, done, position, ch):
    returner = initial
    if position in done:
        #print("")
        #print("This move is valid!")
        flippy = flip(initial, position, ch)
        flippy.add(position)
        returner = displayWithPos(initial, flippy, ch)
        #print("")
        # display(returner)
        #print("")
    else:
        # print("")
        pass
        #print("Sorry this move is not valid")
    #scoreX, scoreO = (scoreCount(returner))
    #print("X has: " + str(scoreX) + " spots")
    #print("O has: " + str(scoreO) + " spots")
    return returner
def flipy(initial, pos, c, o):
  dirs, ends = [],[]
  directions=[-9,-8,-7,-1,+7,+8,+9,+1]
  edges=[(0,2),(4, 2),(1,2),(4, 0),(0,3),(4, 3),(1,3),(4, 1)]
  for i in range(0,8):
    d=directions[i]
    if pos+d>-1 and pos+d<64:
      if(initial[pos+d]==o):
        curr=pos
        while boundaries(curr)[edges[i][0]]==False and boundaries(curr)[edges[i][1]]==False:
          curr=curr+d
          if(initial[curr]==c):
            if(curr!=pos+d):
              dirs.append(d)
              ends.append(curr)
            break
          elif(initial[curr]==o):
            continue
          elif(initial[curr]=='.'):
            break
  b=[*initial]
  for i in range(len(dirs)):
    d=dirs[i]
    e=ends[i]
    curr=pos+d
    while curr!=e:
      b[curr]=c
      curr+=d
  b[pos]=c
  return ''.join(b)

def boardEval(game, turn):
    movers = len(moves(game, turn)) - len(moves(game, opponent(turn)))
    return game.count(turn) - game.count(opponent(turn)) + movers

def Negamax(game, turn, level):
    if not level: return[boardEval(game, turn)]
    lm = moves(game, turn)
    if not lm:
        nm = Negamax(game, opponent(turn), level-1) + [-1]
        return[-nm[0]] + nm[1:]
    best = sorted([Negamax(adderTwo(game, turn, mv), opponent(turn), level-1) + [mv] for mv in lm])[0]
    return [-best[0]] + best[1:]

def boundaries(i):
  left=(i%8==0)
  right=(i%8==7)
  top=(i<8)
  bottom=(i>55)
  return [left,right,top,bottom,False]
position, initial, ch = [], "...........................OX......XO...........................", None
for x in sys.argv[1:]:
    if len(x) == 100:
        initial = x
    elif x.isnumeric():
        position.append(x)
    elif x.isalpha():
        ch = x
    else:
        position.append(translate(x))
numbers = finder(".", initial)
if not ch:
    if len(numbers) % 2 == 0:
        ch = "X"
    else:
        ch = "O"

playerToToken = {'@': 'x', 'o': 'o'}
initial = ''.join(initial)
initial = initial.replace('@', 'x')
token = playerToToken[ch]
ch = token
initial = initial.upper()
ch = ch.upper()
#display(initial)
done = moves(initial, ch)
if len(numbers) > 8:
    hi = findbest(initial, done, ch)
elif len(numbers) < 8:
    for depth in range(1, 100, 1):
        hi = Negamax(initial, ch, 5)
else:
    for depth in range(1, 100, 1):
        hi = Negamax(initial, ch, 5)
hi = 11 + (mv // 8) * 10 + (mv % 8)
best_move.value = hi
print(hi)

#display(initial)
# x = displayWithPos(initial, done)
# display(x)

class Strategy():
    def best_strategy(self, initial, ch, best_move, still_running):
        playerToToken = {'@': 'x', 'o': 'o'}
        initial = "".join(initial[i + i:8] for i in range(11, 91,10))
        initial = initial.replace('@', 'x')
        token = playerToToken[ch]
        ch = token
        initial = initial.upper()
        ch = ch.upper()
        hi = Negamax(initial, ch, 5)
        hi = hi[-1]
        mv = 11 + (hi // 8) * 10 + (hi % 8)
        best_move.value = mv