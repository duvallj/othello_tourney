import Othello_Core as core
import random
import math
#Vibhu Kundeti
from multiprocessing import Value

#

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

# To refer to neighbor squares we can add a direction to a square.
UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)

class Strategy():
    def squares(self):
        """List all the valid squares on the board."""
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]


    def initial_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [OUTER] * 100
        for i in self.squares():
            board[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        return board


    def print_board(self,board):
        """Get a string representation of the board."""
        rep = ''
        rep += '  %s\n' % ' '.join(map(str, list(range(1, 9))))
        for row in range(1, 9):
            begin, end = 10 * row + 1, 10 * row + 9
            rep += '%d %s\n' % (row, ' '.join(board[begin:end]))
        return rep


    def is_valid(self, move):
        
        return isinstance(move, int) and move in self.squares()

    def opponent(self, player):
        if player == 'o':
            return '@'
        return 'o'
        
    def find_bracket(self, square, player, board, direction):
        
        bracket = square + direction
        
        if bracket > 0:
            if board[bracket] == player:
                return None
            opp = self.opponent(player)
            while board[bracket] == opp:
                bracket += direction
            return None if board[bracket] in (core.OUTER, core.EMPTY) else bracket


    def is_legal(self, move, player, board):
        
        hasbracket = lambda direction: self.find_bracket(move, player, board, direction)
        return board[move] == core.EMPTY and any(map(hasbracket, core.DIRECTIONS))

            

    
    def make_move(self, move, player, board):
##        if not self.is_legal(move, player, board):
##            raise self.IllegalMoveError(player, move, board)
        board[int(move)] = player
        for d in DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board

    def make_flips(self, move, player, board, direction):
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction
    def legal_moves(self, board,player):
##        x = []
##        for row in range(1, 9):
##            for column in range(10 * row +1, 10 * row +9):
##               if self.is_legal( column, player, board):
##                   x.append(column)
##                                
##        return x
        return [sq for sq in self.squares() if self.is_legal(sq, player, board)]

    
    

    def any_legal_move(self, player, board):
        return any(self.is_legal(sq, player, board) for sq in self.squares())
##            if len(self.legal_moves( player, board)) > 0:
##                return True
##            return False
    
                

    def next_player(self,board, prev_player):
##        if prev_player == '@':
##            if self.any_legal_move( 'o', board):
##                return 'o'
##            if self.any_legal_move( '@', board):
##                return '@'
##        if prev_player == 'o':
##            if self.any_legal_move( '@', board):
##                return '@'
##            if self.any_legal_move( 'o', board):
##                return 'o'
##        return None
        opp = self.opponent(prev_player)
        if self.any_legal_move(opp, board):
            return opp
        elif self.any_legal_move(prev_player, board):
            return prev_player
        return None
        
        
    def score(self,player, board):
        score = 0
        
        for x in board:
            
                
            if x == player:
                score = score +1
            if x == '.' or '?':
                score = score
            else:
                score = score -1
            return score
    def score(self,player, board):
        score = 0
        
        for x in board:
            if board[11] or board[18] or board[81] or board[88] == player:
                score = score +10
                
            if x == player:
                score = score +1
            if x == '.' or '?':
                score = score
            else:
                score = score -1
            return score
    def score2(self,player, board):
        score = 0
        m = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

        
        for x in range(0, len(board)):
            if x < len(m):
                if board[x] == player: score = score + m[x]
                if board[x] == self.opponent(player): score  = score - m[x]
        return score
        
        #, best_move, still_running
    def best_strategy(self, board, player, best_move, still_running):
        while(still_running):
            moves = self.legal_moves( board,player)
            hscore = -99999999
            hmove = 0
            for x in moves:
                
                tscore = self.alphabeta(self.make_move(x,player,board[:]),3,-9999999,9999999, True, player)
                #tscore = self.score2(player,self.make_move(x,player,board))
                if tscore >= hscore:
                    hscore = tscore
                    hmove = x   
                
            best_move.value = x
           # return x
    def alphabeta(self, node, depth,a,b, maxPlayer, player):
        
        if depth == 0:
                return self.score2(player, node)
        if maxPlayer:
                v = -b
                moves = self.legal_moves(node, player)
                for x in moves:
                    
                    if player == BLACK: t = WHITE
                    else: t = BLACK
                    v = max(v, self.alphabeta(self.make_move(x,player,node[:]), depth -1, a, b, False, t))
                    a = max(a,v)
                    if b <= a: break
                return v
        if maxPlayer == False:
                va = -a
                moves = self.legal_moves(node, player)
                for x in moves:
                    if player == BLACK: t = WHITE
                    else: t = BLACK
                    va = min(va, self.alphabeta(self.make_move(x,player,node[:]), depth -1, a, b, True, t))
                    b = min(b, va)
                    if b <= a: break
                return va
        

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):

            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

