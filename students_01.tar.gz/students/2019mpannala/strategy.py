#
# Mahima Pannala
import sys
from functools import lru_cache
import random
import time
def opposite(token):
    if token.lower() == 'x':
        return 'o'
    else:
        return 'x'
global checkMoves
checkMoves = {}
def legalMoves(game, move):
    returnList = set()
    if move == 'x': opposite = 'o'
    else: opposite = 'x'
    for x in range(64):
        if game[x] == opposite:
            neighbors, operation, operations = [], [1, 8, 7, 9], []
            for l in operation:
                if x - l >=0 and x + l < 64:
                    if l == 7:
                        if x % 8 == 0:
                            neighbors.append(x-l)
                            operations.append(-l)
                        elif x % 8 == 7:
                            neighbors.append(x+l)
                            operations.append(l)
                        else:
                            neighbors.append(x - l)
                            neighbors.append(x + l)
                            operations.append(-l)
                            operations.append(l)
                    elif l == 9:
                        if x % 8 == 0:
                            neighbors.append(x+l)
                            operations.append(l)
                        elif x % 8 == 7:
                            neighbors.append(x-l)
                            operations.append(-l)
                        else:
                            neighbors.append(x - l)
                            neighbors.append(x + l)
                            operations.append(-l)
                            operations.append(l)
                    elif l == 1:
                        if x % 8 == 0:
                            neighbors.append(x+l)
                            operations.append(l)
                        elif x % 8 == 7:
                            neighbors.append(x-l)
                            operations.append(-l)
                        else:
                            neighbors.append(x - l)
                            neighbors.append(x + l)
                            operations.append(-l)
                            operations.append(l)
                    else:
                        neighbors.append(x-l)
                        neighbors.append(x+l)
                        operations.append(-l)
                        operations.append(l)
            for y in range(len(neighbors)):
                n = neighbors[y]
                if game[n] == ".":
                    operation = -operations[y]
                    next = n + operation + operation
                    if next in neighbors:
                        nextSpace = game[next]
                        while nextSpace != ".":
                            if nextSpace == move:
                                returnList.add(n)
                                break
                            if nextSpace == opposite:
                                next = next + operation
                                if operation == 1 and next % 8 == 0:
                                    break
                                elif operation == -1 and next % 8 == 7:
                                    break
                                elif operation == 7 and next % 8 == 7:
                                    break
                                elif operation == -7 and next % 8 == 0:
                                    break
                                elif operation == 9 and next % 8 == 0:
                                    break
                                elif operation == -9 and next % 8 == 7:
                                    break
                                elif next < 64 and next >= 0:
                                    nextSpace = game[next]
                                else:
                                    break
    checkMoves[game+move] = returnList
    return returnList
def getlegalMoves(game, move):
    if game+move in checkMoves.keys():
        return checkMoves[game+move]
    else:
        return legalMoves(game, move)
def makeMove(game, move, position):
    if move == 'x':
        opposite = 'o'
    else:
        opposite = 'x'
    x = position
    neighbors = []
    operation = [1, 8, 7, 9]
    operations = []
    for l in operation:
        if x + l >= 0 and x + l < 64:
            if l == 7:
                if x % 8 != 0:
                    neighbors.append(x+l)
                    operations.append(l)
            elif l == 9:
                if x % 8 != 7:
                    neighbors.append(x + l)
                    operations.append(l)
            elif l == 1:
                if x % 8 != 7:
                    neighbors.append(x + l)
                    operations.append(l)
            else:
                neighbors.append(x + l)
                operations.append(l)
        if x - l < 64 and x - l >= 0:
            if l == 7:
                if x % 8 != 7:
                    neighbors.append(x-l)
                    operations.append(-l)
            elif l == 9:
                if x % 8 != 0:
                    neighbors.append(x - l)
                    operations.append(-l)
            elif l == 1:
                if x % 8 != 0:
                    neighbors.append(x - l)
                    operations.append(-l)
            else:
                neighbors.append(x - l)
                operations.append(-l)
    for y in range(len(neighbors)):
        n = neighbors[y]
        if game[n] == opposite:
            operation = operations[y]
            next = n
            nextSpace = game[n]
            while nextSpace == opposite:
                next = next + operation
                if operation == 1 and next % 8 == 0:
                    break
                elif operation == -1 and next % 8 == 7:
                    break
                elif operation == 7 and next % 8 == 7:
                    break
                elif operation == -7 and next % 8 == 0:
                    break
                elif operation == 9 and next % 8 == 0:
                    break
                elif operation == -9 and next % 8 == 7:
                    break
                elif next < 64 and next >= 0:
                    nextSpace = game[next]
                else:
                    break
                if nextSpace == move:
                    reverse = next - operation
                    while reverse != x:
                        game = game[0:reverse] + move + game[reverse+1:]
                        reverse = reverse - operation
    game = game[0:position] + move + game[position+1:]
    return game
def evalBoard(board, token):
    enemy = opposite(token)
    return board.count(token.lower()) - board.count(enemy)
@lru_cache(maxsize=1000000000)
def negamaxTerminal(brd, token, improvable, hardBound):
    enemy = opposite(token)
    lm = getlegalMoves(brd, token)
    if not lm:
        lm = getlegalMoves(brd, enemy)
        if not lm:  return [evalBoard(brd, token), -3]
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(brd, token, mv), enemy, -hardBound, newHB) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound: return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
def leastMoves(game, moves, move):
    if len(moves) == 1:
        minMove = moves[0]
    else:
        newBoard = makeMove(game, move, moves[0])
        minMoves = len(getlegalMoves(newBoard, opposite(move)))
        minMove = moves[0]
        for x in moves:
            board = makeMove(game, move, x)
            amount = len(getlegalMoves(board, opposite(move)))
            if amount < minMoves:
                minMoves = amount
                minMove = x
    return minMove
def findMove(game, move, moves):
    moves = [*moves]
    if len(moves) == 1:
        return moves[0]
    finalMove = []
    for x in moves:
        if x in {0, 7, 56, 63}:
            finalMove.append(x)
    if finalMove != []:
        return leastMoves(game, finalMove, move)
    for x in moves:
        if x / 8 == 0 or x / 8 == 7 or x % 8 == 0 or x % 8 == 7:
            newGame = makeMove(game, move, x)
            if x / 8 == 0:
                if newGame[0] == move:
                    nextMove = 1
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove + 1
                if newGame[7] == move:
                    nextMove = 6
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove - 1
            elif x / 8 == 7:
                if newGame[56] == move:
                    nextMove = 57
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove + 1
                if newGame[63] == move:
                    nextMove = 62
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove - 1
            elif x % 8 == 0:
                if newGame[0] == move:
                    nextMove = 8
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove + 8
                if newGame[56] == move:
                    nextMove = 48
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove - 8
            else:
                if newGame[7] == move:
                    nextMove = 15
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove + 8
                if newGame[63] == move:
                    nextMove = 55
                    while newGame[nextMove] == move:
                        if nextMove == x:
                            finalMove.append(x)
                            break
                        nextMove = nextMove - 8
    if finalMove != []:
        return leastMoves(game, finalMove, move)
    unMoves = []
    dct = {0: [1, 8, 9], 7: [6, 15, 14], 56: [48, 57, 49], 63: [62, 55, 54]}
    for x in moves:
        for x in {0, 7, 56, 63}:
            if game[x] != move:
                for y in dct[x]:
                    if y in moves:
                        moves.remove(y)
                        unMoves.append(y)
    if moves == []:
        for x in unMoves:
            moves.append(x)
    for x in moves:
        if x / 8 != 0 and x / 8 != 7 and x % 8 != 0 and x % 8 != 7:
            finalMove.append(x)
    if finalMove == []:
        return leastMoves(game, moves, move)
    return leastMoves(game, finalMove, move)
def findBestMove(brd, token):
    game = brd
    move = token
    n = 10
    if game.count(".") <= n:
        nm = negamaxTerminal(game, move, -65, 65)
        return nm[-1]
    moves = getlegalMoves(game, move)
    return findMove(game, move, moves)
def main():
    start = time.time()
    defaultGame = "...........................ox......xo..........................."
    defaultMove = "x"
    if len(sys.argv) == 1:
        game = defaultGame
        move = defaultMove
    elif len(sys.argv) == 2:
        game = sys.argv[1]
        game = game.lower()
        count = game.count(".")
        if count % 2 == 0:
            move = 'x'
        else:
            move = 'o'
    else:
        game = sys.argv[1]
        game = game.lower()
        move = sys.argv[2]
        move = move.lower()
    print("\n".join(game[x:x + 8] for x in range(0, 63, 8)))
    print("Possible Moves " + str(getlegalMoves(game, move)))
    n = 10
    print("My heuristic choice is {}".format(str(findMove(game, move, legalMoves(game, move)))))
    if game.count(".") <= n:
        nm = negamaxTerminal(game, move, 0, 65)
        print(("Negamax Terminal returns {} and I choose move {}").format(nm, nm[-1]))
    print(time.time() - start)
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?','').replace('@', 'x')
        token = 'x'if player == '@' else 'o'
        mv = findBestMove(brd, token)
        mv1 = 11 + (mv//8)*10 + (mv%8)
        print("My choice is {}".format(mv1))
        best_move.value = mv1
if __name__ == "__main__":
    main()
#average capture rate = 20 games