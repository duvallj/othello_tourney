import sys
directions = {(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, -1), (-1, 1)}
corners = [0,7,63,56]
enemies={"x":"o","o":"x"}

class Strategy():
    # if __name__== "__main__":
    #     main()
    def findBestMove(self,brd, token):
        if brd.count(".") > 13:
            return heuristic(brd, fidxChoices(brd,token),token)
        else:
            return negamaxTerminal(brd,token,-65,65)[-1]
    def best_strategy(self,board,player,best_move,still_running):
        brd= ''.join(board).replace("?","").replace("@","x")
        token = "x" if player == "@" else "o"
        mv = heuristic(brd,fidxChoices(brd,token),token)
        mv1=11+(int(mv)//8)*10+int(mv)%8
        best_move.value=mv1
        mv2 = self.findBestMove(brd, token)
        if mv2 != mv:
            mv1 = 11 + (int(mv) // 8) * 10 + int(mv) % 8
            best_move.value = mv1

def checkTurn(game):
    moves = sum([1 for x in game if x!= "."])
    if moves%2 is 0:
        return "x", "o"
    else:
        return "o","x"
def boardEval(b,p,e):
    return b.count(p)- b.count(e)
def isValidPos(r, c):
    """ Returns whether a move is a valid position """
    return 0 <= r < 8 and 0 <= c < 8
def gamecheck(board, move, token):
    (R, C), enemy = divmod(move, 8), enemies[token]

    def checkDirection(dr, dc):
        flips, r, c = set(), R + dr, C + dc
        while isValidPos(r, c) and board[r * 8 + c] == enemy:
            flips.add(r * 8 + c)
            r, c = r + dr, c + dc
        return flips if isValidPos(r, c) and board[r * 8 + c] == token and (
        abs(R - r) > 1 or abs(C - c) > 1) else set()

    flips = {move}.union(*(checkDirection(dr, dc) for dr, dc in directions))
    return ''.join(v if k not in flips else token for k, v in enumerate(board))

def fidxChoices(board, turn):
    adjacent = []
    for x in range(len(board)):
        if board[x] == turn:
            neighbors = fidxNext(board, x)
            if len(neighbors) > 0:
                for x in neighbors:
                    adjacent.append(x)
    adjacent = list(set(adjacent))
    return adjacent
def fidxNext(board, idx):
    row = int(idx/ 8)
    col = idx % 8
    tempdirectionst = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    if col in [0,1]:
        tempdirectionst = [i for i in tempdirectionst if i[1] != -1]
    if row in [0,1]:
        tempdirectionst = [i for i in tempdirectionst if i[0] != -1]
    if col in [7,6]:
        tempdirectionst = [i for i in tempdirectionst if i[1] != 1]
    if row in [7,6]:
        tempdirectionst = [i for i in tempdirectionst if i[0] != 1]
    possibilities = []
    for i in range(len(tempdirectionst)):
        z = tempdirectionst[i]
        nrow = row
        ncol = col
        checker = False
        while True:
            nrow += z[0]
            ncol += z[1]
            if nrow < 0 or nrow > 7 or ncol < 0 or ncol > 7:
                tempdirectionst[i] = ""
                break
            if board[nrow * 8 + ncol] == board[idx]:
                tempdirectionst[i] = ""
                break
            if board[nrow * 8 + ncol] == '.' and not checker:
                tempdirectionst[i] = ""
                break
            if board[nrow * 8 + ncol] == '.' and checker:
                possibilities.append(nrow * 8 + ncol)
                break
            else:
                checker = True
    return possibilities
def negamaxTerminal(b,p,improvable,hard):
    lm = fidxChoices(b,p)
    if not lm:
        lm = fidxChoices(b,enemies[p])
        if not lm: return [boardEval(b,p,enemies[p]),-3]
        nm = negamaxTerminal(b,enemies[p],-hard,-improvable)+[-1]
        return [-nm[0]]+nm[1:]
    best = []
    newHB= -improvable
    for mv in lm:
        nm = negamaxTerminal(gamecheck(b,mv,p),enemies[p],-hard,newHB)+ [mv]
        if not best or nm[0]<newHB:
            best = nm
            if nm[0]<newHB:
                newHB=nm[0]
            if -newHB>hard: return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]
def edges(board,count,idx,p):
    game = gamecheck(board, idx, p)
    stopper=True
    while True:
        idx += count
        if  int(idx/8) > 7 or int(idx/8) < 0 or  idx > 63 or idx < 0:
            break
        elif game[idx]!=p:
            stopper=False
            break
    if stopper:
        return True
    return False
def heuristic(game,possibilities,p):
    ultimate = []
    worstmoves = []
    goodmoves = []
    lastchoice = []
    for x in possibilities:
        x= int(x)
        if x in corners:
            ultimate+=[x]
        if int(x/8) in [0,7]:
            if edges(game,-1,x,p) or edges(game,1,x,p):
                ultimate+=[x]
            elif x in [1, 6, 57, 62]:
                worstmoves+=[x]
            else:
                lastchoice+=[x]
        if x%8 in [0,7]:
            if edges(game,8,x,p) or edges(game,-8,x,p):
                ultimate.append(x)
            elif x in [55,48,15,8]:
                worstmoves+=[x]
            else:
                lastchoice+=[x]
        else:
            if game[0] == p and x ==9:
                goodmoves+=[x]
            if game[7]== p and x ==14:
                goodmoves+=[x]
            if game[56]== p and x ==49:
                goodmoves+=[x]
            if game[63]== p and x ==54:
                goodmoves+=[x]
            if x in [9,49,14,54]:
                worstmoves+=[x]
            else:
                goodmoves+=[x]
    if  ultimate:
        return ultimate[0]
    elif goodmoves:
        return goodmoves[0]
    elif lastchoice:
        return lastchoice[0]
    elif worstmoves:
        return worstmoves[0]
if len(sys.argv) is 3:
    if sys.argv[2] in "xXoO":
        match = "...........................ox......xo..........................."
        match = sys.argv[1].lower()
        turn, enemy = checkTurn(match)
        if len(sys.argv) > 2:
            turn = sys.argv[2].lower()
        possiblemoves = fidxChoices(match, turn)
        if match.count(".") <= 15:
            temp = negamaxTerminal(match, turn, -65,65)
            print(str(temp[-1]))
        else:
            print(heuristic(match, possiblemoves, turn))
