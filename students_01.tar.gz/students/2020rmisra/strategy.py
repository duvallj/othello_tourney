# Rishabh Misra; Period 6 White

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
best = {WHITE: min, BLACK: max}


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, board, score, move=None):
        self.board = board
        self.score = score
        self.move = move
    def __lt__(self, other):
        return self.score < other.score
class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = "???????????........??........??........??........??........??........??........??........???????????"
        board = board[:44] + WHITE + BLACK + board[46:]
        board = board[:54] + BLACK + WHITE + board[56:]
        #print(board)
        return board

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        string = ""
        #temp = []
        i = 0
        while (i + 10 < 101):
            string += (board[i:i + 10] + "\n")
            i += 10
        # for thing in list(board):
        #     if(thing == "?"):
        #         temp.append(0)
        #     else:
        #         temp.append(1)
        # print(temp)
        return string

    def opponent(self, player):
        """Get player's opponent."""
        if(player == WHITE):
            return BLACK
        else: return WHITE

    def find_match(self, board, player, direction, index):
        if(player == BLACK):
            if(board[index+direction] != WHITE):
                return False
        else:
            if(board[index+direction] != BLACK):
                return False
        index += direction
        while(True):
            if(board[index] == "?" or board[index] == EMPTY):
                return False
            elif(board[index] == player):
                return True
            index += direction

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        for thing in DIRECTIONS:
            #print(thing)
            if(self.find_match(board, player, thing, move)):
                return True
        return False

    def make_move(self, board, player, index):
        board = board[:index] + player + board[index+1:]
        #board[index] = player
        #print("--------------------------------------------------------------")
        for thing in DIRECTIONS:
            if(self.find_match(board, player, thing, index) == True):
                #print("Flipping Tiles for " , thing)
                board = self.flip_tiles(board, thing, index, player)
        #print("--------------------------------------------------------------")
        return board

    def flip_tiles(self, board, direction, index, player):
        index += direction
        while(board[index] != player):
            board = board[:index] + player + board[index + 1:]
            index += direction
        #self.get_pretty_board(board)
        return board

    def get_valid_moves(self, board, player):
        index = 0
        moves = set([])
        while(index < len(board)):
            #print(board[index])
            if(board[index] == "."):
                if(self.is_move_valid(board, player, index)):
                    moves.add(index)
            index += 1
        return list(moves)

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return(len(self.get_valid_moves(board, player)) > 0)

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        next_player = self.opponent(prev_player)
        if(self.has_any_valid_moves(board, next_player) == False):
            if(self.has_any_valid_moves(board, prev_player) == False):
                return None
            next_player = prev_player
        return next_player

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""

        black = 0
        white = 0

        #IMPLEMENT SCORING MATRIX!!
        for thing in list(board):
            if(thing == BLACK):
                black += 1
            elif(thing == WHITE):
                white += 1
        return black-white
    def number_pieces(self, board):
        count = 0
        for thing in [board]:
            if(thing == WHITE or thing == BLACK):
                count += 1
        return count
    def modify(self, matrix, player):
        if(matrix[11] == player):
            matrix[12] += 16
            matrix[21] += 16
            matrix[22] += 16
        if (matrix[81] == player):
            matrix[82] += 16
            matrix[72] += 16
            matrix[71] += 16
        if (matrix[18] == player):
            matrix[17] += 16
            matrix[28] += 16
            matrix[27] += 16
        if (matrix[11] == player):
            matrix[12] += 16
            matrix[21] += 16
            matrix[22] += 16
        if (matrix[88] == player):
            matrix[87] += 16
            matrix[77] += 16
            matrix[78] += 16
        return matrix
    def weigted_score(self, board):
        # scorematrix = [
        #     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        #     0, 180, -40, 20, 5, 5, 20, -40, 180, 0,
        #     0, -40, -60, -5, -5, -5, -5, -60, -40, 0,
        #     0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        #     0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        #     0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        #     0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        #     0, -40, -60, -5, -5, -5, -5, -60, -40, 0,
        #     0, 180, -40, 20, 5, 5, 20, -40, 180, 0,
        #     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        # ]
        # if(self.number_pieces(board) < 24):
        # scorematrix = [
        #     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        #     0, 16.16, -3.03, 0.99, 0.43, 0.43, 0.99, -3.03, 16.16, 0,
        #     0, -4.12, -1.81, -0.08, -0.27, -0.27, -0.08, -1.81, -4.12, 0,
        #     0, 1.33, -0.04, 0.51, 0.07, 0.07, 0.51, -0.04, 1.33, 0,
        #     0, 0.63, -0.18, -0.04, -0.01, -0.01, -0.04, -0.18, 0.63, 0,
        #     0, 0.63, -0.18, -0.04, -0.01, -0.01, -0.04, -0.18, 0.63, 0,
        #     0, 1.33, -0.04, 0.51, 0.07, 0.07, 0.51, -0.04, 1.33, 0,
        #     0, -4.12, -1.81, -0.08, -0.27, -0.27, -0.08, -1.81, -4.12, 0,
        #     0, 16.16, -3.03, 0.99, 0.43, 0.43, 0.99, -3.03, 16.16, 0,
        #     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        # ]
        scorematrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 120, -80, 20, 5, 5, 20, -80, 120, 0,
            0, -80, -80, -5, -5, -5, -5, -80, -80, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -80, -80, -5, -5, -5, -5, -80, -80, 0,
            0, 120, -80, 20, 5, 5, 20, -80, 120, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        #scorematrix = self.modify(scorematrix, player)
        # else:
        #     scorematrix = [
        #         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        #         0, 8, -3, 0.99, 0.43, 0.43, 0.99, -1, 8, 0,
        #         0, -3, -3, -0.08, -0.27, -0.27, -0.08, -1, -1, 0,
        #         0, 1.33, -0.04, 0.51, 0.07, 0.07, 0.51, -0.04, 1.33, 0,
        #         0, 0.63, -0.18, -0.04, -0.01, -0.01, -0.04, -0.18, 0.63, 0,
        #         0, 0.63, -0.18, -0.04, -0.01, -0.01, -0.04, -0.18, 0.63, 0,
        #         0, 1.33, -0.04, 0.51, 0.07, 0.07, 0.51, -0.04, 1.33, 0,
        #         0, -3, -3, -0.08, -0.27, -0.27, -0.08, -3, -3, 0,
        #         0, 8, -3, 0.99, 0.43, 0.43, 0.99, -3, 8, 0,
        #         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        #     ]
        index = 0
        black = 0
        white = 0
        while(index < len(board)):
            if(board[index] == BLACK):
                black += scorematrix[index]
            elif(board[index] == WHITE):
                white += scorematrix[index]
            index += 1
        return black-white


    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if(self.has_any_valid_moves(board, player) == False and self.has_any_valid_moves(board, self.opponent(player))):
            return True
        return False
    def frontier_score(self, board, player):
        me = 0
        opp = 0

        index = 0
        while(index < len(board)):
            if(board[index] == player):
                for dir in DIRECTIONS:
                    if(board[index+dir] == "."):
                        me += 1
            elif(board[index] == self.opponent(player)):
                for dir in DIRECTIONS:
                    if(board[index+dir] == "."):
                        opp += 1
            index += 1
        return opp-me

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        values = {BLACK: 1, WHITE: -1}
        board = node.board
        if(depth == 0):
            if(self.number_pieces(board) < 12):
                node.score = len(self.get_valid_moves(board, player))*self.weigted_score(board)#*self.weigted_score(board)#*self.frontier_score(board, player)
            # #
            # else:#(self.number_pieces(board) < 50):
            #     node.score = self.weigted_score(board)+ 2*self.frontier_score(board, player)*values[player]
            else:
                node.score = self.weigted_score(board)+5*self.frontier_score(board, player)*values[player]
            #node.score = self.weigted_score(board)
            # else:
            #     node.score = self.score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if(next_player == None):
                c = Node(next_board, 100000*self.score(next_board), move)
                children.append(c)
            else:
                c = Node(next_board, self.weigted_score(next_board), move)
                c.score = self.minmax_search(c, next_player, depth-1, alpha, beta).score
                children.append(c)
            if(player == BLACK):
                alpha = max([alpha, c.score])
            if(player == WHITE):
                beta = min([beta, c.score])
            if(alpha >= beta):
                break
        winner = best[player](children)
        node.score = winner.score
        return winner


    def minmax_strategy(self, board, player, depth=3):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node = Node(board, self.score(board))
        move = self.minmax_search(node, player, depth, -math.inf, math.inf)
        return move.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            board = list(board)
            board = ''.join(board)
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.standard_strategy(board, player)
            depth += 1

    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()
        black.standard_strategy = black.random_strategy

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (PLAYERS[player], move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    #game =  ParallelPlayer(1)
    game = StandardPlayer()
    game.play()
