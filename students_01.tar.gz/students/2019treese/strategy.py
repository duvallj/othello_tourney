class Strategy():

    def best_strategy(self, board, player, best_move, still_running):
        depth =1
        while(True):
           best_move.value = self.my_search_strategy(board, player, depth)
           print(str(best_move))
           depth += 1

    def possiblemoves(self, board, player):
       possiblemoves = set()
       if player == '@':
          opponent = 'o'
       if player == 'o':
          opponent = '@'

  
       for x in range(11, 89):
         if board[x] == player:
           if x - 1 > 0 and board[x - 1] == opponent:
              v = x - 2
              while v > 0 and board[v] == opponent:
                  v = v-1
              if v > 0 and board[v] == '.':
                  possiblemoves.add(v)
           if x + 1 < 89 and board[x + 1] == opponent:
              v = x + 2
              while v < 89 and board[v] == opponent:
                  v = v+1
              if v < 89 and board[v] == '.':
                  possiblemoves.add(v)           
           if x + 10 < 89 and board[x + 10] == opponent:
              v = x + 20
              while v < 89 and board[v] == opponent:
                  v = v+10
              if v < 89 and board[v] == '.':
                  possiblemoves.add(v)
           if x - 10 > 0 and board[x - 10] == opponent:
              v = x - 20
              while v > 0 and board[v] == opponent:
                  v = v-10
              if v > 0 and board[v] == '.':
                  possiblemoves.add(v)
           if x - 11 > 0 and board[x - 11] == opponent:
             v = x - 22
             while v > 0 and board[v] == opponent:
                 v = v-11
             if v > 0 and board[v] == '.':
                 possiblemoves.add(v)
           if x - 9 > 0 and board[x - 9] == opponent:
             v = x - 18
             while v > 0 and board[v] == opponent:
                 v = v-9
             if v > 0 and board[v] == '.':
                 possiblemoves.add(v)
           if x + 11 < 89 and board[x + 11] == opponent:
             v = x + 22
             while v < 89 and board[v] == opponent:
                 v = v+11
             if v < 89 and board[v]== '.':
                 possiblemoves.add(v)
           if x + 9 < 89 and board[x + 9] == opponent:
             v = x + 18
             while v < 89 and board[v] == opponent:
                 v = v+9
             if v < 89 and board[v] == '.':
                 possiblemoves.add(v)

       return possiblemoves


    def move(self, board, player, index):
       if player == 'o':
            opponent = '@'
       if player == '@':
            opponent = 'o'
       if index - 1 > 0 and board[index - 1] == opponent:
            j = [index-1]
            v = index - 2
            while v > 0 and board[v] == opponent:
                j.append(v)
                v = v-1
            if v > 0 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index + 1 < 89 and board[index + 1] == opponent:
            j = [index+1]
            v = index + 2
            while v < 89 and board[v] == opponent:
                j.append(v)
                v = v+1
            if v < 89 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index + 10 < 89 and board[index + 10] == opponent:
            j = [index+10]
            v = index + 20
            while v < 89 and board[v] == opponent:
                j.append(v)
                v = v+10
            if v < 89 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index - 10 > 0 and board[index - 10] == opponent:
            j = [index-10]
            v = index - 20
            while v > 0 and board[v] == opponent:
                j.append(v)
                v = v-10
            if v > 0 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index - 11 > 0 and board[index - 11] == opponent:
            j = [index-11]
            v = index - 22
            while v > 0 and board[v] == opponent:
                j.append(v)
                v = v-11
            if v > 0 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index - 9 > 0 and board[index - 9] == opponent:
            j = [index-9]
            v = index - 18
            while v > 0 and board[v] == opponent:
                j.append(v)
                v = v-9
            if v > 0 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index + 11 < 89 and board[index + 11] == opponent:
            j = [index+11]
            v = index + 22
            while v < 89 and board[v] == opponent:
                j.append(v)
                v = v+11
            if v < 89 and board[v]== player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       if index + 9 < 89 and board[index + 9] == opponent:
            j = [index+9]
            v = index + 18
            while v < 89 and board[v] == opponent:
                j.append(v)
                v = v+9
            if v < 89 and board[v] == player:
                for h in j:
                   board = board[0:h] + [player] + board[h+1:]
       board = board[0:index] + [player] + board[index + 1:]
       return board


    def alphabeta(self, node, depth, a, b, mP, player):
      if depth == 0 or len(self.possiblemoves(node, '@')) == 0 and len(self.possiblemoves(node, 'o')) == 0:
            return self.heuristic(node, player)

      if mP:
          v = -999
          l = self.possiblemoves(node, player)
          for k in l:
              v = max(v, self.alphabeta(self.move(node, player, k), depth-1, a, b, False, player))
              a = max(a, v)
              if b <= a:
                  break
      
          return v
          
      else:
          if player == 'o':
            opponent = '@'
          if player == '@':
            opponent = 'o'
          v = 999
          l = self.possiblemoves(node, opponent)
          for k in l:
              v = min(v, self.alphabeta(self.move(node, opponent, k), depth-1, a, b, True, player))
              b  = min(b, v)
              if b <= a:
                 break
          return v
      return None



    def heuristic(self, board, player):
        r=t=j=k=0
        if player == 'o':
            opponent = '@'
        if player == '@':
            opponent = 'o'
        for aq in range(11, 89):

            if board[aq] == player:
                j+=1
                
            if board[aq] == opponent:
                  k+=1

        
        if(board[11] == player):
          r = r + 10
          r = r + self.heuristic2(board, player, 11)
        if (board[18] == player):
          r = r + 10
          r = r +self.heuristic2(board, player, 18)
        if (board[81] == player):
          r = r + 10
          r = r +self.heuristic2(board, player, 81)
        if (board[88] == player):
          r = r + 10
          r = r +self.heuristic2(board, player, 88)


        if(board[11] == opponent):
          t = t + 10
          t = t +self.heuristic2(board, opponent, 11)
        if (board[18] == opponent):
          t = t + 10
          t = t +self.heuristic2(board, opponent, 18)
        if (board[81] == opponent):
          t = t + 10
          t = t +self.heuristic2(board, opponent, 81)
        if (board[88] == opponent):
          t = t + 10
          t = t +self.heuristic2(board, opponent, 88)
        if not r + t == 0:
          return (r-t)/(r+t) + .2*((j-k)/(j+k))
        else:
          return .2*((j-k)/(j+k))
    
    def heuristic2(self, board, player, pos):
      h = pos
      g = 0
      if board[pos] == 11 or board[pos] == 81:
        h = pos + 1
        while board[h] == player:
          g = g + 1
          h = h + 1
      if board[pos] == 18 or board[pos] == 88:
        h = pos - 1
        while board[h] == player:
          g = g + 1
          h = h - 1
      if board[pos] == 11 or board[pos] == 18:
        h = pos + 10
        while board[h] == player:
          g = g + 1
          h = h + 10
      if board[pos] == 81 or board[pos] == 88:
        h = pos - 10
        while board[h] == player:
          g = g + 1
          h = h - 10
      return g
      
      
          
      

    def my_search_strategy(self, board, player, depth):
       l = self.possiblemoves((board), player)
       v = -999
       move = None
       for k in l:
          h = self.alphabeta(self.move(board, player, k), depth - 1, -999, 999, False, player)
          if h > v:
            v = h
            move = k
       return move
