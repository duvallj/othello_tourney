#strategy.py
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

class Strategy():
 def best_strategy(self, board, player, best_move, still_running):
  depth =1
  while(True):
    best_move = self.my_search_strategy(board, player, depth)
    depth += 1
 def possiblemoves(board, player):
  possiblemoves = set()
  if player == '@':
    opponent = 'o'
  if player == 'o':
    opponent = '@'

  
  for x in range(11, 89):
   if board[x] == player:
     if x - 1 > 0 and board[x - 1] == opponent:
        v = x - 2
        while v > 0 and board[v] == opponent:
            v = v-1
        if v > 0 and board[v] == '.':
            possiblemoves.add(v)
     if x + 1 < 89 and board[x + 1] == opponent:
        v = x + 2
        while v < 89 and board[v] == opponent:
            v = v+1
        if v < 89 and board[v] == '.':
            possiblemoves.add(v)           
     if x + 10 < 89 and board[x + 10] == opponent:
        v = x + 20
        while v < 89 and board[v] == opponent:
            v = v+10
        if v < 89 and board[v] == '.':
            possiblemoves.add(v)
     if x - 10 > 0 and board[x - 10] == opponent:
        v = x - 20
        while v > 0 and board[v] == opponent:
            v = v-10
        if v > 0 and board[v] == '.':
            possiblemoves.add(v)
     if x - 11 > 0 and board[x - 11] == opponent:
        v = x - 22
        while v > 0 and board[v] == opponent:
            v = v-11
        if v > 0 and board[v] == '.':
            possiblemoves.add(v)
     if x - 9 > 0 and board[x - 9] == opponent:
        v = x - 18
        while v > 0 and board[v] == opponent:
            v = v-9
        if v > 0 and board[v] == '.':
            possiblemoves.add(v)
     if x + 11 < 89 and board[x + 11] == opponent:
        v = x + 22
        while v < 89 and board[v] == opponent:
            v = v+11
        if v < 89 and board[v]== '.':
            possiblemoves.add(v)
     if x + 9 < 89 and board[x + 9] == opponent:
        v = x + 18
        while v < 89 and board[v] == opponent:
            v = v+9
        if v < 89 and board[v] == '.':
            possiblemoves.add(v)

  return possiblemoves


 def move(board, player, index):
   if player == 'o':
            opponent = '@'
   if player == '@':
            opponent = 'o'
   if index - 1 > 0 and board[index - 1] == opponent:
        j = [index-1]
        v = index - 2
        while v > 0 and board[v] == opponent:
            j.append(v)
            v = v-1
        if v > 0 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index + 1 < 89 and board[index + 1] == opponent:
        j = [index+1]
        v = index + 2
        while v < 89 and board[v] == opponent:
            j.append(v)
            v = v+1
        if v < 89 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index + 10 < 89 and board[index + 10] == opponent:
        j = [index+10]
        v = index + 20
        while v < 89 and board[v] == opponent:
            j.append(v)
            v = v+10
        if v < 89 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index - 10 > 0 and board[index - 10] == opponent:
        j = [index-10]
        v = index - 20
        while v > 0 and board[v] == opponent:
            j.append(v)
            v = v-10
        if v > 0 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index - 11 > 0 and board[index - 11] == opponent:
        j = [index-11]
        v = index - 22
        while v > 0 and board[v] == opponent:
            j.append(v)
            v = v-11
        if v > 0 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index - 9 > 0 and board[index - 9] == opponent:
        j = [index-9]
        v = index - 18
        while v > 0 and board[v] == opponent:
            j.append(v)
            v = v-9
        if v > 0 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index + 11 < 89 and board[index + 11] == opponent:
        j = [index+11]
        v = index + 22
        while v < 89 and board[v] == opponent:
            j.append(v)
            v = v+11
        if v < 89 and board[v]== player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   if index + 9 < 89 and board[index + 9] == opponent:
        j = [index+9]
        v = index + 18
        while v < 89 and board[v] == opponent:
            j.append(v)
            v = v+9
        if v < 89 and board[v] == player:
            for h in j:
               board = board[0:h] + player + board[h+1:]
   board = board[0:index] + player + board[index + 1:]
   return board


 def alphabeta(node, depth, a, b, mP, player):

      if depth == 0 or len(Strategy.possiblemoves(node, '@')) == 0 and len(Strategy.possiblemoves(node, 'o')) == 0:
          return Strategy.heuristic(node, player)

      if mP:
          v = -999
          l = Strategy.possiblemoves(node, player)
          for k in l:
              v = max(v, Strategy.alphabeta(Strategy.move(node, player, k), depth-1, a, b, False, player))
              a = max(a, v)
              if b <= a:
                  break
      
          return v
          
      else:
          if player == 'o':
            opponent = '@'
          if player == '@':
            opponent = 'o'
          v = 999
          l = Strategy.possiblemoves(node, opponent)
          for k in l:
              v = min(v, Strategy.alphabeta(Strategy.move(node, opponent, k), depth-1, a, b, True, player))
              b  = min(b, v)
              if b <= a:
                 break
          return v
      return None

 def heuristic(board, player):
    r=t=0
    if player == 'o':
            opponent = '@'
    if player == '@':
            opponent = 'o'
    for aq in range(11, 89):
            if board[aq] == player:
                r+=1
                if aq - 10 > 0 and board[aq-10] == '?':
                  r+=1
                if aq + 10 < 89 and board[aq+10] == '?':
                  r+=1
                if board[aq - 1] == '?':
                  r+=1
                if board[aq + 1] == '?':
                  r+=1
                
            if board[aq] == opponent:
                  t+=1
                  if aq - 10 > 0 and board[aq-10] == '?':
                   t+=1
                  if aq + 10 < 89 and board[aq+10] == '?':
                    t+=1
                  if board[aq - 1] == '?':
                    t+=1
                  if board[aq + 1] == '?':
                    t+=1
    
    return (r-t)/(r+t)



               
            
         
 def my_search_strategy(board, player, depth):
  l = Strategy.possiblemoves((board), player)
  v = -999
  move = None
  for k in l:
        h = Strategy.alphabeta(Strategy.move(board, player, k), depth - 1, -999, 999, False, player)
        if h > v:
          v = h
          move = k
  return move


 
      

