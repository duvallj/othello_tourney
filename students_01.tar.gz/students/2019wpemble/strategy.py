translate = {"x" : "X", "o" : "O", ".":".","X":"X","O":"O"}
trans = {"A":0,"B":1,"C":2,"D":3,"E":4,"F":5,"G":6,"H":7}
directions = {}
corners = [0,7,56,63]
xorc = {1:0,6:7,8:0,15:7,48:56,57:56,62:63,55:63,9:0,14:7,49:56,54:63}
for x in range(0,64):
  directions[x] = set()
class Strategy():
  def best_strategy(sef,board,player,best_move,still_running):
    brd = list("".join(board).replace("?","").replace("@","X").upper())
    token ="X" if player == "@" else "O"
    mv = findBestMove(brd,token)
    mv1 = 11 + (mv//8)*10+ (mv%8)
    best_move.value = mv1
    if mv not in corners and mv not in xorc:
      numDots = 0
      for val in brd:
        if val == ".":
          numDots += 1
      if numDots > 10:
        for n in range(3,9,2):
          mv = nega(brd,token,n)
          mv1= 11 + (mv//8)*10+ (mv%8)
          best_move.value = mv1
      else:
        mv = negamaxTerminal(brd,token,-65,65)[-1]
        mv1= 11 + (mv//8)*10+ (mv%8)
        best_move.value = mv1
def evalBoard2(board,token):
  val = 0 
  enemy = opp(token)
  numTeam = len(possibleMoves(board,token))
  numEnemy = len(possibleMoves(board,enemy))
  val += (numTeam - numEnemy)
  numTeam = numToken(board,token) * 2
  numEnemy = numToken(board, enemy)
  val += (numTeam - numEnemy)* .25
  return val
def findBestMove(board,token):
  possibilities = possibleMoves(board,token)
  mymove = -1
  for pos in xorc:
    if pos in possibilities and board[xorc[pos]] != token and len(possibilities) > 1:
      possibilities.remove(pos)
    elif pos in possibilities and board[xorc[pos]] == token and len(possibilities) > 1:
      mymove = pos
  for pos in corners:
    if pos in possibilities:
      mymove = pos
  if mymove == -1:
    mymove = possibilities.pop()
  return mymove
def negamaxTerminal(board, token, improvable,hardbound):
  lm = possibleMoves(board,token)
  opposite = opp(token)
  if not lm:
    lm2 = possibleMoves(board,opposite)
    if not lm2:
      return [evalBoard(board,token),-3]
    nm = negamaxTerminal(board,opposite,-hardbound,-improvable) + [-1]
    return [-nm[0]] + nm[1:]
  best = []
  newHB = -improvable
  for move in lm:
    nm = negamaxTerminal(makeMove(board,token,move),opposite,-hardbound, newHB) + [move]
    if not best or nm[0] < newHB:
      best = nm
      if nm[0] < newHB:
        newHB = nm[0]
        if -newHB >= hardbound:
          return [-best[0]] + best[1:]
  return [-best[0]] + best[1:]
def nega(board,token,lev):
  out = negaMax(board,token,lev)
  return out[-1]
def numDots(game):
  count = 0
  for val in game:
    if val == ".":
      count += 1
  return count
def numToken(game,token):
  count = 0
  for val in game:
    if val == token:
      count += 1
  return count
def whoseMove(game):
  count = 0
  for val in game:
    count+=1
  if count % 2 == 0:
    return "X"
  else:
    return "O"
def opp(token):
  if token == "X": 
    return "O"
  else: 
    return "X"
def copy(inpt):
  return inpt[:]
def display(puzl):
  string = ""
  for i in range(64):
    string += puzl[i] + " "
    if i % 8 == 7 and i != 0:
      print(string)
      string = ""
  print("\n")
def evalBoard(board,token):
  val = 0 
  enemy = opp(token)
  numTeam = numToken(board,token)
  numEnemy = numToken(board, enemy)
  val += numTeam - numEnemy
  return val
def negaMax(board,token,levels):
  if not levels:
    return [evalBoard(board,token)]
  lm = possibleMoves(board,token)
  om = possibleMoves(board,opp(token))
  if not om and not lm:
    return [evalBoard2(board,token)]
  elif not lm:
    nm = negaMax(board, opp(token), levels-1) + [-1]
    return [-nm[0]] + nm[1:]
  nmList = sorted([negaMax(makeMove(board,token,move), opp(token), levels-1) + [move] for move in lm])
  best = nmList[0]
  return [-best[0]] + best[1:]
def possibleMoves(game,team):
  for x in range(0,64):
    directions[x] = set()
  possible = set()
  if team == "X": 
    opp = "O"
  else: 
    opp = "X"
  options = [1,-1,-9,-8,-7,8,7,9]
  for position in range(64):
   if game[position] == team:
      for move in options:
        pos = position
        rowvar,posvar,negvar = int(pos/8),int(pos/8),int(pos/8)
        colvar,poscol,negcol = pos%8,pos%8,pos%8
        pos += move
        posvar += 1
        poscol += 1
        negvar -= 1
        negcol -= 1
        if pos >= 0 and pos < 64 and game[pos] == opp:
          while pos >= 0 and pos < 64 and game[pos] == opp:
            pos += move
            posvar += 1
            poscol += 1
            negvar -= 1
            negcol -= 1
          currRow = int(pos/8)
          currCol = pos%8
          if move == 1:
            if pos < 64 and game[pos] == "." and currRow == rowvar and poscol == currCol and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
          elif move == -1:
            if pos < 64 and game[pos] == "." and currRow == rowvar and negcol == currCol and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
          elif move == 7: 
            if pos < 64 and game[pos] == "." and currRow == posvar and negcol == currCol and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
          elif move == 9: 
            if pos < 64 and game[pos] == "." and currRow == posvar and poscol == currCol and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
          elif move == -9: 
            if pos < 64 and game[pos] == "." and currRow == negvar and negcol == currCol and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
          elif move == -7: 
            if pos < 64 and game[pos] == "." and currRow == negvar and poscol == currCol and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
          else: 
            if pos < 64 and game[pos] == "." and pos >= 0:
              directions[pos].add(move)
              possible.add(pos)
  return possible 
def score(board):
  tup = [0,0]
  for val in board:
    if val == "X":
      tup[0] += 1
    elif val == "O":
      tup[1] += 1
  return str(tup[0]) + "/" + str(tup[1])
def makeMove(board,team,inpt):
  game = board[:]
  options = [1,-1,-9,-8,-7,8,7,9]
  possible = possibleMoves(board,team)
  if team == "X": 
    opp = "O"
  else: 
    opp = "X"
  inpt = str(inpt)
  if inpt[0].isdigit() == False:
    inptMove = (int(inpt[1]) - 1) * 8 + trans[inpt[0].upper()]
  else:
    inptMove = int(inpt)
  for move in directions[inptMove]:
    pos = inptMove
    move = move * -1
    pos += move
    while pos <= 63 and game[pos] == opp:
      game[pos] = team
      pos += move
  game[inptMove] = team
  return game
import sys,time
def main():
  team = ""
  board = ""
  possibilities = set()
  moves = []
  if len(sys.argv) == 1:
    board = ["."] * 64
    board[27],board[28],board[35],board[36] = "O","X","X","O"
  elif len(sys.argv) == 2:
    inpt = sys.argv[1]
    if len(inpt) > 1:
      board = list(inpt)
      for i in range(len(board)):
        board[i] = translate[board[i]]
    else:
      board = ["."] * 64
      board[27],board[28],board[35],board[36] = "O","X","X","O"
      team = inpt.upper()
  elif len(sys.argv) == 3:
    team = sys.argv[2].upper()
    board = list(sys.argv[1])
    for i in range(len(board)):
      board[i] = translate[board[i]]
  if team == "":
    team = "X"
  team = team.upper()
  numDots = 0
  nm = -1
  for val in board:
    if val == ".":
      numDots += 1
  display(board)
  possibilities = possibleMoves(board,team)
  print("legal moves: " + str(possibilities))
  mymove = -1
  corn = False
  xc = False
  for pos in xorc:
    if pos in possibilities and board[xorc[pos]] != team and len(possibilities) > 1:
      possibilities.remove(pos)
    elif pos in possibilities and board[xorc[pos]] == team and len(possibilities) > 1:
      mymove = pos
      xc = True
  for pos in corners:
    if pos in possibilities:
      corn = True
      mymove = pos
  if mymove == -1:
    mymove = possibilities.pop()
  print("Heuristic move is: " + str(mymove))
  if numDots > 10 and not corn and not xc:
    for n in range(3,9,2):
      nm = negaMax(board,team,n)
      print("Move: " + str(nm))
  print()
  if numDots <= 10:
    mymove = negamaxTerminal(board,team,-65,65)
    print("Minimax - Minimum score: " + str(mymove[0]) + " Move: " + str(mymove[1:]))
if __name__ == "__main__":
  main()
