import random
import time
import sys



class Strategy():
    # implement all the required methods on your own
    def best_strategy(self, board, player, best_move, running):
        self.bestMove(''.join(board).replace('?','').replace('@','x'),player,best_move,False)
    
    def getTurn(self, board):
      num = 1
      for item in board:
        if not(item == '.'):
          num+=1
      return num%2
    
    def display(self, board):
      for i in range(0,64,8):
        print(' '.join(board[i:i+8]))
    
    def score(self, board):
      x,o = 0,0
      for char in ''.join(board):
        if char == 'x':
          x +=1
        if char == 'o':
          o +=1
      print('Scores: x-%i, o-%i'%(x,o))
    
    def validHelper(self, board,position,turn,direction):
      p = position%8
      if (p == 7 and (direction == -9 or direction == 7 or direction == -1))    or    (p == 0 and (direction == 9 or direction == -7 or direction == 1)):
        return False
      if position<0 or position>63 or board[position] == '.':
        return False
      if (board[position] == 'x') == turn and ((board[position-direction] == 'o') == turn) and (not board[position-direction] == '.'):
        return True
      if (board[position] == 'x') == turn:
        return False
      return self.validHelper(board,position+direction,turn,direction)
    
    
    def valid(self,board,position,turn):
      if not board[position] == '.':
        return False
      return self.validHelper(board,position+1,turn,1) or self.validHelper(board,position-1,turn,-1) or self.validHelper(board,position+8,turn,8) or self.validHelper(board,position-8,turn,-8) or self.validHelper(board,position+9,turn,9) or self.validHelper(board,position-9,turn,-9) or self.validHelper(board,position+7,turn,7) or self.validHelper(board,position-7,turn,-7)
    
    def getPossibleCoor(self,board,turn):
      possible = set()
      for i in range(0,64):
        if self.valid(board,i,turn):
          possible.add((i//8,i%8))
      return possible
    
    def getPossibleIndex(self,board,turn):
      possible = set()
      for i in range(0,64):
        if self.valid(board,i,turn):
          possible.add(i)
      return possible
    
    #Taking input
    
     
     # End of Lab 5
     
    def placeHelper(self,board,position,turn,direction):
      p = position%8
      if (p == 7 and (direction == -9 or direction == 7 or direction == -1))    or    (p == 0 and (direction == 9 or direction == -7 or direction == 1)):
        return False
      if position<0 or position>63 or board[position] == '.':
        return False
      if (board[position] == 'x') == turn and ((board[position-direction] == 'o') == turn) and (not board[position-direction] == '.'):
        return True
      if (board[position] == 'x') == turn:
        return False
      if self.placeHelper(board,position+direction,turn,direction):
        board[position] = 'x' if turn else 'o'
        return True
    
    def place(self,board,position,turn):
      if self.placeHelper(board,position+1,turn,1):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position-1,turn,-1):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position+8,turn,8):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position-8,turn,-8):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position+9,turn,9):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position-9,turn,-9):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position+7,turn,7):
        board[position] = 'x' if turn else 'o'
      if self.placeHelper(board,position-7,turn,-7):
        board[position] = 'x' if turn else 'o'
     
     # Start of selection algorithm
    
    # Heuristic Selection
    def bestMove(self,board,turn,best_move,fromCommandLine):
      if board.count('.')<8:
        return self.choose(board,turn,best_move,fromCommandLine)
      
      possibleMoves = self.getPossibleIndex(board,turn)
      
      for x in {0,7,63,56}:
        if x in possibleMoves:
          print(x)
          sys.exit()
      
      for move in possibleMoves:
        if move&7 == 0 or move&7 == 7:
          if self.validHelper(board,move+8,turn,8) or self.validHelper(board,move-8,turn,-8):
            #print(move)
            #sys.exit()
            best_move.value = move
            return move
        if move < 7 or move >56:
          if self.validHelper(board,move+1,turn,1) or self.validHelper(board,move-1,turn,-1):
            #print(move)
            #sys.exit()
            best_move.value = move
            return move
      
      copyMove = {a for a in possibleMoves}
      if not(board[0] == ('x' if turn else 'o')):
        copyMove = copyMove - {1,8,9}
      if not(board[7] == ('x' if turn else 'o')):
        copyMove = copyMove - {6,14,15}
      if not(board[56] == ('x' if turn else 'o')):
        copyMove = copyMove - {48,49,57}
      if not(board[63] == ('x' if turn else 'o')):
        copyMove = copyMove - {54,55,62}
      
      if not copyMove:
        #print(move.pop())
        #print(list(move).pop(random.randrange(len(move))))
        #sys.exit()
        return self.choose(board,turn,best_move,fromCommandLine)
      
      move = copyMove
      copyMove = copyMove - {0,1,2,3,4,5,6,7, 8,16,24,32,40,48, 56, 57,58,59,60,61,62, 63, 15,23,31,39,47,55}
      
      if copyMove:
        #print(copyMove.pop())
        #print(list(copyMove).pop(random.randrange(len(copyMove))))
        return self.choose(board,turn,best_move, fromCommandLine)
      else:
        #print(move.pop())
        #print(list(move).pop(random.randrange(len(move))))
        return self.choose(board,turn,best_move, fromCommandLine)
        
      #"""
    
    # MinMax
    """
    def evalBoard(self,board,token):
      positionValue = {0: 5 ,  7: 5 , 63: 5 , 56:5,
                     1:-1 ,  8:-1 ,  9:-2 ,
                     6:-1 , 15:-1 , 14:-2 ,
                    48:-1 , 57:-1 , 49:-2 ,
                    62:-1 , 55:-1 , 54:-2 ,}
      score = board.count('x')-board.count('o')
      for key in positionValue:
        if board[key] == 'x':
          score += positionValue[key]
        if board[key] == 'o':
          score -= positionValue[key]
      return score if token else -score
    """
    def evalBoard(self, board,token):
      return board.count('x')-board.count('o') if token else board.count('o')-board.count('x')
    
    def negamax(self,board,token,levels):
      if not levels: return [self.evalBoard(board,token)]
      lm = self.getPossibleIndex(board,token)
      if not lm:
        nm = self.negamax(board,not token,levels-1)+[-1]
        return [-nm[0]]+nm[1:]
      nmList = []
      for mv in lm:
        cBoard = [a for a in board]
        self.place(cBoard,mv,token)
        nmList.append(self.negamax(cBoard,not token,levels-1)+[mv])
      nmList = sorted(nmList)
      best = nmList[0]
      return [-best[0]]+best[1:]
    
    n = 8
    
    def choose(self,board,turn,best_move,fromCommandLine):
      level = 1
      while level < self.n or (not fromCommandLine) :
        best_move.value = self.negamax(board,turn,level)[-1]
        level +=2
      return best_move.value

class b():
  value = 0

def main():
  startTime = time.clock()
  s = Strategy()
  if len(sys.argv)>2:
    board= list(sys.argv[1].lower())
    turn = sys.argv[2].lower() == 'x'
  elif len(sys.argv)>1:
    if len(sys.argv[1])>60:
      board= list(sys.argv[1].lower())
      turn = s.getTurn(board)
    else:
      board = list('...........................ox......xo...........................')
      turn = sys.argv[1].lower() == 'x'
  else:
    
    board = list('...........................ox......xo...........................')
    turn = True
  
  s.display(board)
  print(s.getPossibleIndex(board,turn))
  best_move = b()
  s.bestMove(board,turn,best_move,True)
  endTime = time.clock() - startTime
  if endTime>5: print(str(endTime)+'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
  print("My Heuristic choice is: "+ str(best_move.value))
  if board.count('.')<8:
    l = s.negamax(board,turn,s.n-1)
    print('Score of %i expected from this sequence of moves: '%l[0] + str(l[1:][::-1]))
    print(l[-1])
if __name__ == "__main__":
  main()














