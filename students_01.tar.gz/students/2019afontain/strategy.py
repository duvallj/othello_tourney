#Alice Fontaine 1/11/18
import random
board = []
psize = 8
global hm
hm = {}
global vm
vm = dict()
global dm
dm = dict()
global dm2
dm2 = dict()

#READS IN THE BOARD
def readBoard():
    with open ("PracticeOthelloBoards.txt", "r") as file:
        tot = file.read()
    lis = tot.split("\n")
    for el in lis:
        if not el == "":
            board.append(el)

def posMoves(m, boo):
    q = ''
    e = ''
    vmoves = {}
    hmoves = {}
    dmoves1 = {}
    dmoves2 = {}
    moves = []
    if boo:
        q = '@'
        e = 'o'
    else:
        q = 'o'
        e = '@'
    #CHECKS POSSIBLE MOVES FOR COLUMNS
    for c in range(0, psize):
        path = False
        dubpath = False
        possible = False
        firstnum = ''
        for r in range(0, psize):
            rc = str(r) + ' ' + str(c)
            if possible == True and m[r][c] == '.':
                possible = False
                firstnum = ''
            if possible == True and m[r][c] == q:
                if not firstnum == '':
                    #If the ones to be changed are below it
                    if firstnum in vmoves:
                        vmoves.update({firstnum:'3'})
                    else:
                        vmoves.update({firstnum:'1'})
                    if not firstnum in moves:
                        moves.append(firstnum)
                firstnum = ''
            if not int(r) == (psize-1):
                if m[r][c] == '.' and m[r+1][c] == e:
                    possible = True
                    firstnum = rc
            if m[r][c] == '.' and path == True and dubpath == True:
                if not rc in moves:
                    moves.append(rc)
                #If ones to be changed are above it
                if rc in vmoves:
                    vmoves.update({rc:'3'})
                else:
                    vmoves.update({rc:'2'})
                path = False
                dubpath = False
            if m[r][c] == q and dubpath == True:
                dubpath = False
            if m[r][c] == q and dubpath == False:
                path = True
            if m[r][c] == e and path == True:
                dubpath = True
            if m[r][c] == '.' and path == True and dubpath == False:
                path = False
    #CHECKS POS MOVES FOR ROWS
    for r in range(0, psize):
        path = False
        dubpath = False
        possible = False
        firstnum = ''
        for c in range(0, psize):
            rc = str(r) + ' ' + str(c)
            if possible == True and m[r][c] == '.':
                possible = False
                firstnum = ''
            if possible == True and m[r][c] == q:
                if not firstnum == '':
                    if firstnum in hmoves:
                        hmoves.update({firstnum:'3'})
                    else:
                        hmoves.update({firstnum:'1'})
                    if not firstnum in moves:
                        moves.append(firstnum)
                firstnum = ''
            if not int(c) == (psize-1):
                if m[r][c] == '.' and m[r][c+1] == e:
                    possible = True
                    firstnum = rc
            if m[r][c] == '.' and path == True and dubpath == True:
                if not rc in moves:
                    moves.append(rc)
                if rc in hmoves:
                    hmoves.update({rc:'3'})
                else:
                    #If values to be changed are to the left
                    hmoves.update({rc:'2'})
                path = False
                dubpath == False
            if m[r][c] == q and dubpath == True:
                dubpath = False
            if m[r][c] == q and dubpath == False:
                path = True
            if m[r][c] == e and path == True:
                dubpath = True
            if m[r][c] == '.' and path == True and dubpath == False:
                path = False
    global diagdict1
    global diagdict2
    diagdict1 = {}
    diagdict2 = {}
    #MAKES DICTIONARIES OF THE DIAGONALS
    for el in range(0,psize):
        x = el
        newDiag = False
        while x < (psize*psize):
            if x%8 == 0 and not el == 0:
                newDiag = True
            if newDiag == False:
                if not diagdict1.get(el) == None:
                    lis = diagdict1.get(el)
                    lis.append(x)
                    diagdict1.update({el:lis})
                else:
                    diagdict1.update({el:[x]})
            else:
                t = el + 8
                if not diagdict1.get(t) == None:
                    lis = diagdict1.get(t)
                    lis.append(x)
                    diagdict1.update({t:lis})
                else:
                    diagdict1.update({t:[x]})
            x = x + 9
    diagdict1.update({16:[8]})
    a = 17
    while a < 64:
        lis = diagdict1.get(16)
        lis.append(a)
        diagdict1.update({16:lis})
        a = a+9
    #SECOND DIAGONAL DICTIONARY (TWO DIRECTIONS OF DIAGONALS)
    for el in range(56,64):
        x = el
        newDiag = False
        while x > 0:
            if x%8 == 0:
                newDiag = True
            if newDiag == False:
                if not diagdict2.get(el) == None:
                    lis = diagdict2.get(el)
                    lis.append(x)
                    diagdict2.update({el:lis})
                else:
                    diagdict2.update({el:[x]})
            else:
                t = el + 8
                if not diagdict2.get(t) == None:
                    lis = diagdict2.get(t)
                    lis.append(x)
                    diagdict2.update({t:lis})
                else:
                    diagdict2.update({t:[x]})
            x = x - 7
    #GOES THROUGH DIAGONAL DICTIONARIES AND CHECKS FOR POS MOVES
    for key in diagdict1.keys():
        path = False
        dubpath = False
        possible = False
        firstnum = ''
        for el in diagdict1[key]:
            r = int(el/psize)
            c = int(el%psize)
            rc = str(r) + ' ' + str(c)
            if possible == True and m[r][c] == '.':
                possible = False
                firstnum = ''
            if possible == True and m[r][c] == q:
                if not firstnum == '':
                    if firstnum in dmoves1:
                        dmoves1.update({firstnum:'3'})
                    else:
                        #If values to be changed are to the right
                        dmoves1.update({firstnum:'1'})
                    if not firstnum in moves:
                        moves.append(firstnum)
                firstnum = ''
            if not int(c) == (psize-1) and not int(r) == (psize-1):
                if m[r][c] == '.' and m[r+1][c+1] == e:
                    possible = True
                    firstnum = rc
            if m[r][c] == '.' and path == True and dubpath == True:
                if not rc in moves:
                    moves.append(rc)
                if rc in dmoves1:
                    dmoves1.update({rc:'3'})
                else:
                    #If values to be changed are to the left
                    dmoves1.update({rc:'2'})
                path = False
                dubpath == False
            if m[r][c] == q and dubpath == True:
                dubpath = False
            if m[r][c] == q and dubpath == False:
                path = True
            if m[r][c] == e and path == True:
                dubpath = True
            if m[r][c] == '.' and path == True and dubpath == False:
                path = False

    #SECOND DIAGONAL DICTIONARY POS MOVES
    for key in diagdict2.keys():
        path = False
        dubpath = False
        possible = False
        firstnum = ''
        for el in diagdict2[key]:
            r = int(el/psize)
            c = int(el%psize)
            rc = str(r) + ' ' + str(c)
            if possible == True and m[r][c] == '.':
                possible = False
                firstnum = ''
            if possible == True and m[r][c] == q:
                if not firstnum == '':
                    if firstnum in dmoves2:
                        dmoves2.update({firstnum:'3'})
                    else:
                        #If values to be changed are to the right
                        dmoves2.update({firstnum:'1'})
                    if not firstnum in moves:
                        moves.append(firstnum)
                firstnum = ''
            if not int(c) ==  (psize-1) and not int(r)  < 0 :
                if m[r][c] == '.' and m[r-1][c+1] == e:
                    possible = True
                    firstnum = rc
            if m[r][c] == '.' and path == True and dubpath == True:
                if not rc in moves:
                    moves.append(rc)
                if rc in dmoves2:
                    dmoves2.update({rc:'3'})
                else:
                    #If values to be changed are to the left
                    dmoves2.update({rc:'2'})
                path = False
                dubpath == False
            if m[r][c] == q and dubpath == True:
                dubpath = False
            if m[r][c] == q and dubpath == False:
                path = True
            if m[r][c] == e and path == True:
                dubpath = True
            if m[r][c] == '.' and path == True and dubpath == False:
                path = False
    global hm
    hm = hmoves

    global vm
    vm = vmoves

    global dm
    dm = dmoves1

    global dm2
    dm2 = dmoves2

    
    return moves


def getBoard(rc, ma, boo):
    a = convert(ma)
    m = makeMatrix(a, psize)
    q = ''
    e = ''
    if boo:
        q = '@'
        e = 'o'
    else:
        q = 'o'
        e = '@'
    #Horizontal Filling
    temp = rc.split()
    r = int(temp[0])
    c = int(temp[1])
    if rc in hm.keys():
        if hm.get(rc) == '1' or hm.get(rc) == '3':
            x = r
            y = c+1
            while m[x][y] == e:
                m[x][y] = q
                y = y+1
        if hm.get(rc) == '2' or hm.get(rc) == '3':
            x = r
            y = c-1
            while m[x][y] == e:
                m[x][y] = q
                y = y-1
    #Vertical Filling
    if rc in vm.keys():
        if vm.get(rc) == '1' or vm.get(rc) == '3':
            x = r + 1
            y = c
            while m[x][y] == e:
                m[x][y] = q
                x = x+1
        if vm.get(rc) == '2' or vm.get(rc) == '3':
            x = r - 1
            y = c
            while m[x][y] == e:
                m[x][y] = q
                x = x-1
    #Diagonal Filling
    if rc in dm.keys():
        key = ''
        dex = int(temp[0])*psize + int(temp[1])
        for val in diagdict1.keys():
            temp = rc.split()
            if dex in diagdict1[val]:
                key = val
                break

        lis = diagdict1[key]

        ind = lis.index(dex)

        if dm[rc] == '1' or dm[rc] == '3':
            i = ind + 1
            b = True
            while b == True:
                ra = int(lis[i]/psize)
                ca = int(lis[i]%psize)
                if m[ra][ca] == e:
                    m[ra][ca] = q
                else:
                    b = False
                i= i+1
        if dm.get(rc) == '2' or dm.get(rc) == '3':
            i = ind - 1
            b = True
            while b == True:
                ra = int(lis[i]/psize)
                ca = int(lis[i]%psize)
                if m[ra][ca] == e:
                    m[ra][ca] = q
                else:
                    b = False
                i= i-1
                
    #Diagonal Filling
    if rc in dm2.keys():
        key = ''
        dex = int(temp[0])*psize + int(temp[1])
        for val in diagdict2.keys():
            temp = rc.split()
            if dex in diagdict2[val]:
                key = val
                break
        lis = diagdict2[key]
        ind = lis.index(dex)
        if dm2.get(rc) == '1' or dm2.get(rc) == '3':
            i = ind + 1
            b = True
            while b == True and i < len(lis):
                ra = int(lis[i]/psize)
                ca = int(lis[i]%psize)
                if m[ra][ca] == e:
                    m[ra][ca] = q
                else:
                    b = False
                i= i+1
        if dm2.get(rc) == '2' or dm2.get(rc) == '3':
            i = ind - 1
            b = True
            while b == True:
                ra = int(lis[i]/psize)
                ca = int(lis[i]%psize)
                if m[ra][ca] == e:
                    m[ra][ca] = q
                else:
                    b = False
                i= i-1
    m[r][c] = q
    return m

def getValue(m, boo):
    q = ''
    e = ''
    if boo:
        q = '@'
        q = 'e'
    else:
        q = 'o'
        e = '@'
    value = 0
    for r in range(0, psize):
        for c in range(0, psize):
            if m[r][c] == q:
                value = value+5
                if r == 0 or r == psize-1 or c == 0 or c == psize-1:
                    value = value + 200
                if (r == 0 and c == 1) or (r == 0 and c == psize-2) or (r == psize - 1 and c == 1) or (r == psize-1 and c == psize-2):
                    value = value - 1000
                if (r == 1 and c == 0) or (r == psize-2 and c == 0) or (r == 1 and c == psize-1) or (r == psize-2 and c == psize-1):
                    value = value - 1000
                if (r == 1 and c == 1) or (r == psize-2 and c == 1) or (r == 1 and c == psize-2) or (r == psize-2 and c == psize-2):
                    value = value - 1000
                if (r == 0 and c == 0) or (r == 0 and c == psize-1) or (r == psize - 1 and c == 0) or (r == psize-1 and c == psize-1):
                    value = value + 10000
            if m[r][c] == e:
                value = value-1
                if r == 0 or r == psize-1 or c == 0 or c == psize-1:
                    value = value - 100
                if (r == 0 and c == 1) or (r == 0 and c == psize-2) or (r == psize - 1 and c == 1) or (r == psize-1 and c == psize-2):
                    value = value + 100
                if (r == 1 and c == 0) or (r == psize-2 and c == 0) or (r == 1 and c == psize-1) or (r == psize-2 and c == psize-1):
                    value = value + 100
                if (r == 1 and c == 1) or (r == psize-2 and c == 1) or (r == 1 and c == psize-2) or (r == psize-2 and c == psize-2):
                    value = value + 100
                if (r == 0 and c == 0) or (r == 0 and c == psize-1) or (r == psize - 1 and c == 0) or (r == psize-1 and c == psize-1):
                    value = value - 100000
    #if len(posMoves(m, boo)) > len(posMoves(m, not boo)):
        #value + 100
    return value

def dumbConvert(m):
    temp = [[0 for x in range(psize+2)] for y in range(psize+2)]
    for x in range(0, psize+2):
        temp[0][x] = '?'
    for row in range(1, psize+1):
        for col in range(0, psize+2):
            if col == 0 or col == psize+1:
                temp[row][col] = '?'
            else:
                temp[row][col] = m[row-1][col-1]
    for x in range(0, psize+2):
        temp[psize+1][x] = '?'
    return convert(temp)

def indCon(index):
    q = []
    for x in range(0,64):
        q.append(str(63-x))
    lis = []
    for x in range(0, 10):
        lis.append('?')
    for x in range(10, 90):
        if x%10 == 0 or x%10 == 9:
            lis.append('?')
        else:
            e = q.pop()
            lis.append(e)
    for x in range(0, 10):
        lis.append('?')
    i = 0
    for val in lis:
        if val == str(index):
            i = lis.index(val)
            break;
    return i

def display(og, pzl):
    a = [[0 for x in range(psize)] for y in range(psize)]
    for x in range(0, len(pzl)):
            row = int(x/psize)
            col = int(x%psize)
            a[row][col] = og[x]
    #DISPLAY FUNCTION
    print("ORIGINAL MATRIX:")
    for k in range(0, psize):
        print(a[k])
    d = [[0 for x in range(psize)] for y in range(psize)]
    for x in range(0, len(pzl)):
            row = int(x/psize)
            col = int(x%psize)
            d[row][col] = pzl[x]
    print("FINAL: " + pzl)
    print("MATRIX:")
    for k in range(0, psize):
        print(d[k])
    print("_______________________________________")

    
#CONVERTS A MATRIX INTO STRING
def convert(m):
    p = ''
    for x in range(0, len(m[0])):
        for y in range(0, len(m[0])):
            p = p + str(m[x][y])
    return p

import math
def makeMatrix(b, size):
    i = int(math.sqrt(len(b)))
    m = [[0 for a in range(i)] for e in range(i)]
    for x in range(0, len(b)):
        row = int(x/i)
        col = int(x%i)
        m[row][col] = b[x]
    return m

#Standard display function showing whatever the matrix is while solving is in progress           
def disp(m):
    for k in range(0, len(m[0])):
        print(str(k) + ' : ' + str(m[k]))
    print('')        
import random
import time

def childlist(board, boo):
    t = convert(board)
    childlis = {}
    moves = posMoves(makeMatrix(t, psize), boo)
    for rc in moves:
        b = getBoard(rc, makeMatrix(t, psize), boo)
        childlis.update({rc : b})

    return childlis

def negamaxD(board,token,im,hb,depth):
    print(token)
    disp(board)
    if token:
        flip = False
    else:
        flip = True
    if not depth:
        print(getValue(board,token))
        return [getValue(board,token)]
    if not posMoves(board,token):
        lm2 = posMoves(board,flip)
        if not lm2:
            return [getValue(board,token),-3]
        nm = negamaxD(board,flip,-hb,-im,depth-1)+[-1]
        return [-nm[0]]+nm[1:]
    best = []
    newhb = -im
    for move in posMoves(board,token):
        nm = negamaxD(getBoard(move, board, token),flip,-hb,newhb,depth-1)+[move]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0] < newhb:
                newhb = nm[0]
                if -newhb >= hb:
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]

def alphabeta(node, depth, alpha, beta, maxPlayer, player):
    #print("Depth: "+ str(depth))
    disp(node)
    if depth == 0 or len(posMoves(node, maxPlayer)) == 0:
        #print("Value: " + str(getValue(node, maxPlayer)))
        return getValue(node, maxPlayer)
    if maxPlayer:
        v = -9999
        c = childlist(node, player)
        for child in c.keys():
            #print("My Turn: ")
            #disp(child)
            temp = alphabeta(c[child], depth-1, alpha, beta, False, player)
            #print("ALPHABETAMAX: " + str(temp))
            if not temp == None:
                v = max(v, temp)
                alpha = max(alpha, v)
            if beta <= alpha:
                    break
        return v
    else:
        v = 9999
        if player:
            play = False
        else:
            play = True
        c = childlist(node, play)
        for child in c.keys():
            #print("Their Turn: ")
            #disp(child)
            #print("ALPHABETAMIN: " + str(alphabeta(child, depth-1, alpha, beta, True)))
            v = min(v, alphabeta(c[child], depth-1, alpha, beta, True, player))
            beta = min(beta, v)
            if beta <= alpha:
                break
            return v

import random

class Strategy():
    # implement all the required methods on your own
    def best_strategy(self, board, player, best_move, running):
        brd = ''.join(board).replace('?', '')
        x = 1
        play = True
        if player == "@":
            play = True
        else:
            play = False
        while (True):
            mv = negamaxD(makeMatrix(brd,8), play,-float("inf"),float("inf"), x)[-1]
            print(mv)
            t = mv.split()
            r = int(t[0])
            c = int(t[1])
            ind = r*8 + c
            mv1 = 11 + (ind // 8) * 10 + (ind % 8)
            print(mv1)
            best_move.value = mv1
            x += 1
        

        


def main():
    d = Strategy.best_strategy(Strategy, "???????????..@@@@.o??.o@@@@o.??.o@ooo@@??.@o@o@@@??@.@oo@o@??.@.oooo@??....o.o.??........???????????", "@", makeMatrix("???????????........??........??........??...o@...??...@o...??........??........??........???????????", 10), True)
    """readBoard()
    childlis = []
    t = board[3].split()
    dumbConvert(makeMatrix(t[0]))
        if t[1] == '@':
        moves = posMoves(makeMatrix(t[0]))
        for rc in moves:
            childlis.append(getBoard(rc, makeMatrix(t[0])))

        for a in childlis:
            disp(a)
            print('')
        print(alphabeta(makeMatrix(t[0]), 5, -9999, 9999, True))



        
    hm.clear()
    vm.clear()
    dm.clear()
    dm2.clear()
    diagdict1.clear()
    diagdict2.clear()"""
        
    
    """for puzz in board:
        if not puzz == '':
            t = puzz.split()
            if t[1] == 'x':
                m = makeMatrix(t[0])
                print(posMoves(m))"""
    



#BEST MOVES CODE

"""b = ''
        for x in range(len(board)):
            if not board[x] == '?':
                b = b + board[x]
        play = True
        if player == "@":
            play = True
        else:
            play = False
        disp(makeMatrix(b, psize))
        moves = posMoves(makeMatrix(b, psize), play)
        print(moves)
        rando = random.sample(moves, 1)
        print(rando)
        t = rando[0].split()
        r = int(t[0])
        c = int(t[1])
        index = r*(psize) + c
        mv1 = 11 + (index // 8) * 10 + (index % 8)
        print(mv1)
        best_move.value = mv1

        brd = ''.join(board).replace('?', '')
        x = 1
        if player == "BLACK":
            play = True
        else:
            play = False
        while x < 5:
            mv = alphabeta(makeMatrix(brd,8),x,-9999,9999,True,play)
            [eval, mvf.......m1] 
            mv1 = 11 + (mv // 8) * 10 + (mv % 8)
            best_move = mv1
            x += 1
        print(best_move)
        
        
        b = ''
        for x in range(len(board)):
            if not board[x] == '?':
                b = b + board[x]
        play = True
        if player == "@":
            play = True
        else:
            play = False
        v = -9999
        c = {}
        i = int(math.sqrt(len(b)))
        m = [[0 for a in range(i)] for e in range(i)]
        for x in range(0, len(b)):
            row = int(x/i)
            col = int(x%i)
            m[row][col] = b[x]
        c = childlist(m, play)
        temp = ''
        index = 0
        for child in c.keys():
            val = alphabeta(makeMatrix(b, psize), 3, -999999999999, 99999999999, True, play)            
            if val > v:
                v = val
                temp = child
                t = child.split()
                r = int(t[0])
                c = int(t[1])
                index = r*(psize) + c
        q = []
        for x in range(0,64):
            q.append(str(63-x))
        lis = []
        for x in range(0, 10):
            lis.append('?')
        for x in range(10, 90):
            if x%10 == 0 or x%10 == 9:
                lis.append('?')
            else:
                e = q.pop()
                lis.append(e)
        for x in range(0, 10):
            lis.append('?')
        
        for ind in range(0, len(lis)):
            if lis[ind] == str(index):
                print(ind)
                best_move.value = ind""" 
    

if __name__ == "__main__":
        main()
