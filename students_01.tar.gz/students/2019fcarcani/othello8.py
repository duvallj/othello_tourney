import sys
class Strategy(): 
  def best_strategy(self, board, player, best_move, still_running): 
    brd = ''.join(board).replace('?','').replace('@','x')
    token = 'x' if player =='@' else 'o'
    other = 'o' if player =='@' else 'x'
    mv = findBestMove(brd, token, other)
    mv1 = 11+(mv//8)*10+(mv%8)
    best_move.value = mv1

corners = {0, 7, 56, 63}
edges = {1, 2, 3, 4, 5, 6, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 57, 58, 59, 60, 61, 62}
nextToC1 = {1, 8}
nextToC2 = {6, 15}
nextToC3 = {48, 57}
nextToC4 = {55, 62}
def createMatrix(game): 
  matrix = []
  for y in range(8): 
    row = [game[y*8+x] for x in range(8)]
    matrix.append(row)
  return matrix
def onBoard(x, y): 
  if x>7 or x <0 or y>7 or y<0: 
    return False
  return True
def isPossible(game, mine, other, xcoord, ycoord): 
  if not onBoard(xcoord, ycoord):
    return False
  if game[xcoord][ycoord]!='.':
    return False
  possible = False
  for (xmove, ymove) in [(1, 1), (1, 0), (0, 1), (1, -1), (-1, 1), (0, -1), (-1, 0), (-1, -1)]:
    thisCase = True
    x, y = xcoord, ycoord
    x = x+xmove 
    y = y+ymove
    if not onBoard(x, y) or game[x][y]!=other:	
      thisCase = False	
      continue
    x = x+xmove
    y = y+ymove
    while onBoard(x, y) and game[x][y] == other:
      x = x+xmove
      y = y+ymove
    if not onBoard(x, y):
      thisCase = False	
      continue
    if game[x][y]==mine and thisCase: 
      possible = True
  return possible
def posMoves(game, mine, other): 
  posMoves = []
  for x in range(8): 
    for y in range(8): 
      if isPossible(game, mine, other, x, y):
        posMoves.append(x*8+y)
  return posMoves
'''def pickMove(board, mine, possibleMoves): 
  game = createMatrix(board)
  badMoves = set()
  edgeMoves = set()
  for move in possibleMoves: 
    if move in corners: 
      return move
  for move in possibleMoves: 
    if move in edges:
      edgeMoves.add(move)
      x, y = int(move/8), move%8
      if x == 0 or x == 7: 
        for ycoord in range(0, y-1):
          if game[x][ycoord] != mine: 
            badMoves.add(move)
            continue
        for ycoord in range(y+1, 8): 
          if game[x][ycoord] != mine: 
            badMoves.add(move)
            continue
      if y == 0 or y == 7:
        for xcoord in range(0, x-1):
          if game[xcoord][y] != mine: 
            badMoves.add(move)
            continue
        for xcoord in range(x+1, 8): 
          if game[xcoord][y] != mine: 
            badMoves.add(move)
            continue
      myMoves = edgeMoves - badMoves
      if len(myMoves) > 0: 
        return myMoves.pop()
  badMoves = set()
  for move in possibleMoves: 
    if move in nextToC1 and game[0][0]!=mine:
      badMoves.add(move)
    if move in nextToC2 and game[0][7]!=mine: 
      badMoves.add(move)
    if move in nextToC3 and game[7][0]!=mine: 
      badMoves.add(move)
    if move in nextToC4 and game[7][7]!=mine: 
      badMoves.add(move)
  if len(set(possibleMoves)-badMoves) > 0: 
    return (set(possibleMoves)-badMoves).pop()
  for move in possibleMoves: 
    if move not in edges: 
      return move 
  return set(possibleMoves).pop()'''
def findBestMove(board, mine, other): 
  return alphabeta(board, mine, other, 10, -100000000, 100000000)[1]
def alphabeta(board, mine, other, alpha, beta, depth):
  if depth == 0:
    return evalBoard(board, mine, other), None
  def value(board, alpha, beta):
    return -alphabeta(board, other, mine, -beta, -alpha, depth-1)[0]
  moves = posMoves(createMatrix(board), mine, other)
  if not moves:
    if not posMoves(createMatrix(board), other, mine):
      return evalBoard(board, mine, other), None
    return value(board, alpha, beta), None
  bestMove = moves[0]
  for move in moves:
    if alpha >= beta:
      break
    val = value(make_move(move, player, list(board)), alpha, beta)
    if val > alpha:
      alpha = val
      best_move = move
  return alpha, bestMove
def evalBoard(board, mine, other):
  scores = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
  myScore = 0
  otherScore = 0
  for i in range(len(board)): 
    if board[i]==mine: 
      myScore += scores[i]
    elif board[i]==other: 
      otherScore += scores[i]
  return myScore - otherScore
def makeMove(board, mine, mv): 
  return (board[0:mv]+str(mine)+board[mv+1:])
'''def nearestCorners(idx): 
  if idx in {1, 2, 3, 4, 5, 6}: 
    return [0, 7]
  elif idx in {8, 16, 24, 32, 40, 48}:
    return [0, 56]
  elif idx in {15, 23, 31, 39, 47, 55}:
    return [8, 63]
  elif idx in {57, 58, 59, 60, 61, 62}:
    return [56, 63]'''
def printGame(game): 
  for i in range(0, 64, 8): 
    print(game[i:8+i])
def main(): 
  game = '...........................ox......xo...........................'
  mine = 'x'
  if len(sys.argv)>1:
    game = sys.argv[1].lower()
    if len(sys.argv)>2:
      mine = sys.argv[2].lower()
    elif game.count('.')%2==0:
      mine = 'x'
    else: 
      mine = 'o'
  if mine == 'x':
    other = 'o'
  else: other = 'x'
  gameMatrix = createMatrix(game)
  printGame(game)
  print(game)
  possibleMoves = posMoves(gameMatrix, mine, other)
  if(len(possibleMoves)==0):
    print("No moves are possible")
  else: 
    print("Possible Move: "+str(findBestMove(game, mine, other)))
if __name__ == "__main__": 
  main()