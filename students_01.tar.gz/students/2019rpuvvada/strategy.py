import sys
def enemy(token):
    d = {'x':'o', 'o':'x', 'O':'X', 'X':'O'}
    return d[token]
def mover(val):
    x =8
    if val%x==0:
        return True
    else:
        return False
def mover2(val):
    x =8
    if val%x==7:
        return True
    else:
        return False
def checker1(tempObj,index,amount):
    x = tempObj
    if x%8==amount or index%8==amount:
        return True
    else:
        return False
def checker2(tempObj,index,amount):
    if int((tempObj)/amount) != int(index/amount):
        return True
    else:
        return False
def possibleMoves(token,board):
    poss = set()
    for index in [i for i, letter in enumerate(board) if letter == "."]:
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]
        for x in directions:
            tempObj = index + x
            while 63 >= (tempObj + x) >= 0:
                if board[tempObj] == enemy(token):
                    if x == 1 or x == -1:
                        if checker2(tempObj+x,index,8):
                            break
                    if x == 7 or x == -9:
                        if checker1(tempObj,index,0):
                            break
                    if x == 9 or x == -7:
                        if checker1(tempObj,index,7):
                            break
                    tempObj += x
                else: break
            if 63 >= (tempObj) >= 0 and board[tempObj] == token and tempObj!=index+x:
                poss.add(index)
    return list(poss)
def nm(board, token, levels):
    if not board.count('.') or not (possibleMoves(token, board) + possibleMoves(enemy(token),board)):
        return [evalBoard(board, token)]
    lm = possibleMoves(token,board)
    if not lm:
        best = nm(board, enemy(token), levels-1) + [-1]
    else:
        best = sorted([nm(makeMove(list(board), token, mv), enemy(token), levels-1) + [mv] for mv in lm])[0]
    return [-best[0]] + best[1:]
def makeMove(board, token, index):
    end = False
    copyBoard = list(board)
    directions = [(1, -1),(-1, 0), (-1, 1), (1, 0), (0, 1),  (1, 1),  (-1, -1), (0, -1)]
    switchedPositions = [index]
    for x in directions:
        obfoolx = index%8
        obfooly = index//8
        positionsPassed = []
        while True:
            obfoolx += x[0]
            obfooly += x[1]
            if obfoolx < 0 or obfoolx > 7 or obfooly < 0 or obfooly > 7:
                break
            obfool = 8*obfooly+obfoolx
            if board[obfool] == enemy(token):
                positionsPassed.append(obfool)
            elif board[obfool] == token and len(positionsPassed)>0:
                end = True
                break
            elif board[obfool] == '.':
                break
            else:
                break
        obfool = 8*obfooly+obfoolx
        if len(positionsPassed)>0 and end:
            for z in positionsPassed:
                switchedPositions.append(z)
    for pos in switchedPositions:
        copyBoard[pos] = token
    finalBoard = "".join(copyBoard)
    return finalBoard
def negamaxTerminal (brd, token, improvable, hardBound):
    lm = possibleMoves(token, brd)
    if not lm:
        lm = possibleMoves(enemy(token), brd)
        if not lm:
            return[evalBoard(brd,token),-3]  ##The -3 means game is over
        nmx = negamaxTerminal(brd, enemy(token), hardBound, -improvable) + [-1]
        return [-nmx[0]] + nmx[1:]
    best = []  #what gets returned
    newHB = -improvable
    for mv in lm:
        nmx = negamaxTerminal(makeMove(brd, token, mv), enemy(token), -hardBound, newHB) + [mv]
        if not best or nmx[0] < newHB:    #######Both nm[0] && newHB are negative
            best = nmx
            if nmx[0] < newHB:
                newHB = nmx[0]
                if -newHB > hardBound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
def evalBoard(board, token):
    return board.count(token) - board.count(enemy(token))
def printBoard(board):
    n1=-8
    n2=-1
    for each1 in range(0,8):
        n1+=8
        n2+=8
        for each in range(n1,n2):
            print(board[each],end="")
        print("")
def isBorderHorizontal(move):
    border = [1,2,3,4,5,6,62,61,60,59,58,57,]
    if move in border:
        return True
    else:
        return False
def isBorderVertical(move):
    border = [8,16,24,32,40,48,15,23,31,39,47]
    if move in border:
        return True
    else:
        return False
def corners(poss):
    if 0 in poss:
        return int(0)
    elif 7 in poss:
        return int(7)
    elif 63 in poss:
        return int(63)
    elif 56 in poss:
        return int(56)
    else:
        return int(-100)
def sidePiece(poss):
    possNew = poss[:]
    if 9 in poss:
        possNew.remove(9)
    if 14 in poss:
        possNew.remove(14)
    if 49 in poss:
        possNew.remove(49)
    if 54 in poss:
        possNew.remove(54)
    if len(possNew) == 0:
        return poss
    else:
        return possNew
def containsin(move,board,token):
    if board[move] == token:
        return False
    else:
        return True
def sidePiece2(poss,board,token):
    possNew = poss[:]

    if 1 in poss and containsin(0,board,token):
        possNew.remove(1)
    if 8 in poss and containsin(0,board,token):
        possNew.remove(8)
    if 6 in poss and containsin(7,board,token):
        possNew.remove(6)
    if 15 in poss and containsin(7,board,token):
        possNew.remove(15)
    if 57 in poss and containsin(56,board,token):
        possNew.remove(57)
    if 48 in poss and containsin(56,board,token):
        possNew.remove(48)
    if 62 in poss and containsin(63,board,token):
        possNew.remove(62)
    if 55 in poss and containsin(63,board,token):
        possNew.remove(55)
    if len(possNew) == 0:
        return poss
    else:
        return possNew
def inBetween(poss,board,token):
    for each in poss:
        if isBorderHorizontal(each) == True:
            if board[each+1] == enemy(token) and board[each-1] == enemy(token):
                return each
        elif isBorderVertical(each) == True:
            if board[each-8] == enemy(token) and board[each+8] == enemy(token):
                return each
        else:
            return int(-100)
    return int(-100)
def mobility(token,board,poss):
    currMax = []
    x = -1
    holder = 0
    for each in poss:
        currTest = possibleMoves(enemy(token),makeMove(board,token,each))
        if len(currTest) >= x:
            x = len(currTest)
            holder = each
    #print (holder)
    return holder
def cornerDiagonal(board,token,poss):
    if board[0] == token and board[1] == token and board[8] == token:
        if 9 in poss:
            return 9
    elif board[7] == token and board[6] == token and board[15] == token:
        if 14 in poss:
            return 14
    elif board[62] == token and board[55] == token and board[63] == token:
        if 54 in poss:
            return 54
    elif board[56] == token and board[57] == token and board[48] == token:
        if 49 in poss:
            return 49
    else:
        return int(-100)
def edgeFiller(board,token,poss):
    possMove = []
    if board[0] == token:
        x = 0
        z = 0
        while board[x+1] == token:
            x += 1
        x += 1
        if x in poss:
            return int(x)
        while z+8 < 63 and board[z+8] == token:
            z += 8
        z += 8
        if z in poss:
            return int(z)
    elif board[7] == token:
        x = 7
        z = 7
        while board[x-1] == token:
            x -= 1
        x -= 1
        if x in poss:
            return int(x)
        while z+8 < 63 and board[z+8] == token:
            z += 8
        z+=8
        if z in poss:
            return int(z)
    elif board[56] == token:
        x = 56
        z = 56
        while x+1 > 63 and board[x+1] == token:
            x += 1
        x+=1
        if x in poss:
            return int(x)
        while board[z-8] == token:
            z -= 8
        z-=8
        if z in poss:
            return int(z)
    elif board[63] == token:
        x = 63
        z = 63
        while board[x-1] == token:
            x -= 1
        x-=1
        if x in poss:
            return int(x)
        while board[z-8] == token:
            z -= 8
        z -=8
        if z in poss:
            return int(z)

    return int(-100)
def stoner(board,token,poss):
    index = 9
    trap = 1
    current = makeMove(board,token,9)
    while trap == 1 and index<=63:
        if current[index] == token:
            index += 9
        elif current[index] == enemy(token):
            trap = -1
        else:
            trap = 2
    if board[0] == '.' and 9 in poss and trap >= 1:
        return 9
    index = 14
    trap = 1
    current = makeMove(board,token,14)
    while trap == 1 and index<=63:
        if current[index] == token:
            index += 7
        elif current[index] == enemy(token):
            trap = -1
        else:
            trap = 2
    if board[7] == '.' and 14 in poss and trap >= 1:
        return 14
    index = 49
    trap = 1
    current = makeMove(board,token,49)
    while trap == 1 and index>=0:
        if current[index] == token:
            index -= 9
        elif current[index] == enemy(token):
            trap = -1
        else:
            trap = 2
    if board[56] == '.' and 49 in poss and trap > 0:
        return 49
    index = 54
    trap = 1
    current = makeMove(board,token,54)
    while trap == 1 and index>=0:
        if current[index] == token:
            index -= 7
        elif current[index] == enemy(token):
            trap = -1
        else:
            trap = 2
    if board[63] == '.' and 54 in poss and trap > 0:
        return 54
    return int(-100)


def heuristic(board, token, worth,dictionaryHolderO,dictionaryHolderX):
    if board.upper() in dictionaryHolderO.keys():
        return dictionaryHolderO[board.upper()]
    if board.upper() in dictionaryHolderX.keys():
        return dictionaryHolderX[board.upper()]
    count = 0
    countWorthList = []
    countWorth = 0
    poss2 = 0
    poss1 = 0
    poss = possibleMoves(token,board)
    check = corners(poss)
    if(check >= -1):
        return check
    hello = edgeFiller(board,token,poss)
    print(hello)
    if(hello >= -1):
       return hello
    # hello2 = stoner(board,token,poss)
    # if(int(hello2) > -1):
    #     return int(hello2)
    poss1 = sidePiece(poss)
    poss2 = sidePiece2(poss1,board,token)
    check2 = inBetween(poss,board,token)
    if(int(check2) >= -1):
        return check2
    countWorth = poss2[0] #equal to first index of possible moves
    for each in poss2:
        if worth[countWorth] <= worth[each]:
            countWorthList.append(each)
            countWorth = each
    return mobility(token,board,countWorthList)
dictionaryHolderO = {'OXXXX.O.OOOOOO..OXXOO.XXOXOXOOXXOXOOOOXXOOXOOOX.OXOOOXXOOOOOOOXO':5,"..........................XXX......XO...........................":18,}
dictionaryHolderX = {'XOOOO.X.XXXXXX..XOOXX.OOXOXOXXOOXOXXXXOOXXOXXXO.XOXXXOOXXXXXXXOX':5,'XXX.X...OXXX....OXOXX...OXOOXOO.OOOXOXOXOOXOOOX..XOOOOOXXO...XXX':48}
worth = [0,0,0,0,0,0,0,0,0,0,0,120,-20,20,5,5,20,-20,120,0,0,-20,-40,-5,-5,-5,-5,-40,-20,0,0,20,-5,15,3,3,15,-5,20,0,0,
5,-5,3,3,3,3,-5,5,0,0,5,-5,3,3,3,3,-5,5,0,0,20,-5,15,3,3,15,-5,20,0,0,-20,-40,-5,-5,-5,-5,-40,-20,0,0,120,-20,20,
5,5,20,-20,120,0,0,0,0,0,0,0,0,0,0,0,]
def findBestMove(board,token):
    count = 0
    for x in board:
        if x == '.':
            count+=1
    if count <= 10:
        return(negamaxTerminal(board,token,-65,65)[-1])
    else:
        return(heuristic(board,token,worth,dictionaryHolderO,dictionaryHolderX))
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        brd = ((''.join(board)).replace('?','')).replace('@', 'x').lower()
        #brd = "".join(board).replace("?","").replace("@","X").replace("o","O")
        token = "x" if player == "@" else "o"
        mv = findBestMove(brd,token)
        move = 11 + (mv // 8)*10 + (mv%8)
        best_move.value = move
def doThisThing():
    board = sys.argv[1].lower()
    token = sys.argv[2].lower()
    print(findBestMove(board,token))
if __name__ == "__main__":
    doThisThing()
