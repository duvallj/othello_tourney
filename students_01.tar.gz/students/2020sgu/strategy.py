import sys
import time
import random

startTime = time.clock()
rowlookup = [[i for i in range(8*j, 8*j + 8)] for j in range(8)]
collookup = [[i for i in range(j, 64 , 8)] for j in range(8)]
diaglookup = []
l1 = [0,1,2,3,4,5,6,7,15,23,31,39,47]
l2 = [0,1,2,3,4,5,6,7,8,16,24,32,40,48,56]
for j in l1:
    newset = []
    for i in range(j, 63, 7):
        if i%8!= 7:
            newset.append(i)
        elif j %8 == 7:
            newset.append(i)
        else:
            break
    if len(newset) > 2:
        diaglookup.append(newset)
for j in l2:
    newset = []
    for i in range(j, 64, 9):
        if i %8 != 0:
            newset.append(i)
        elif j%8 == 0:
            newset.append(i)
        else:
            break
    if len(newset) > 2:
       diaglookup.append(newset)

setList = []
for nbrlist in rowlookup:
    setList.append(nbrlist)
for nbrList in collookup:
    setList.append(nbrList)
for nbrList in diaglookup:
    setList.append(nbrList)

idxnbr = {idx: [nbrList for nbrList in setList if idx in nbrList] for idx in range(64)}

def findPosMoves(board, player): 
    possMoves = []
    boolcheck= 0 #0 means looking for first playerpos, 1 = check for stuff between, 2 = found stuff between looking for next empty
    if player == 'X':
        opp = 'O'
    else:
        opp = 'X'
    for nbrList in setList:
        nbrList2 = nbrList[::-1]
        boolcheck = 0
        nbrCheck = [board[idx] for idx in nbrList]
        revnbrCheck = nbrCheck[::-1]
        if player in nbrCheck and opp not in nbrCheck:
            continue
        for idx in nbrList:

            if board[idx] == player and boolcheck == 0:
                boolcheck = 1
            elif boolcheck == 1 and board[idx] == '.':
                boolcheck = 0
            elif boolcheck == 1 and board[idx] == opp:
                boolcheck = 2
            elif boolcheck == 2 and board[idx] == '.':

                if idx not in possMoves:
                    possMoves.append(idx)
                boolcheck = 0
            elif boolcheck == 2 and board[idx] == player:
                boolcheck = 1
            if len(set(nbrCheck)) == 1:
                break
            nbrCheck.pop(0)
        boolcheck = 0
        for idx in nbrList2:

            if board[idx] == player and boolcheck == 0:
                boolcheck = 1
            elif boolcheck == 1 and board[idx] == '.':
                boolcheck = 0
            elif boolcheck == 1 and board[idx] == opp:
                boolcheck = 2
            elif boolcheck == 2 and board[idx] == '.':
                if idx not in possMoves:
                    possMoves.append(idx)
                boolcheck = 0
            elif boolcheck == 2 and board[idx] == player:
                boolcheck = 1
            if len(set(revnbrCheck)) == 1:
                break
            revnbrCheck.pop(0)
    return possMoves
def findMove(pzl):
    xlist = {i for i in range(len(pzl)) if pzl[i] == '.'}
    if len(xlist) %2 == 0:
        return 'X'
    else:
        return 'O'
def startingMove(board, token):
    startdict = {('...........................OX......XO...........................', 'X'): 19}
    startdict[('...................X.......XX......XO...........................', 'O')] = 34
    startdict[('...................X.......XX.....OOO...........................', 'X')] = 45
    startdict[('...........................OX......XX.......X...................', 'O')] = 29
    if (board,token) in startdict:
        return startdict[(board,token)]
    return random.choice([*findPosMoves(board,token)])
        
def replacepuz(pzl, newnum, index):
    return pzl[:index] + newnum + pzl[index +1:]
def fliptokens(board, player,pos):
    if player == 'X':
        opp = 'O'
    else:
        opp = 'X'
    board2 = replacepuz(board, player, pos)
    for nbrList in idxnbr[pos]:
        check = 0
        indecestoChange = []
        for idx in nbrList:
            if idx == pos:
                check= 1
            elif check == 1 and board2[idx] == player:
                for mv in indecestoChange:
                    board2 = replacepuz(board2, player, mv)
                break
            elif check == 1 and board2[idx] == '.':
                break
            elif check == 1 and board2[idx] ==opp:
                indecestoChange.append(idx)
    
    for nbrList in idxnbr[pos]:
        nbrList = nbrList[::-1]
        check = 0
        indecestoChange = []
        for idx in nbrList:
            if idx == pos:
                check= 1
            elif check == 1 and board2[idx] == player:
                for mv in indecestoChange:
                    board2 = replacepuz(board2, player, mv)
                break
            elif check == 1 and board2[idx] == '.':
                break
            elif check == 1 and board2[idx] ==opp:
                indecestoChange.append(idx)
    return board2
def xvso(pzl, token):
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    xlist = {i for i in range(len(pzl)) if pzl[i] == token}
    ylist = {i for i in range(len(pzl)) if pzl[i] == enemy}
    return len(xlist) - len(ylist)
def fakexvso(pzl,token):
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    xlist = {i for i in range(len(pzl)) if pzl[i] == token}
    ylist = {i for i in range(len(pzl)) if pzl[i] == enemy}
    if len(xlist) - len(ylist) > 0:
        return 1
    elif len(xlist)-len(ylist) == 0:
        return 0
    return -1
def mobilityxvso(board, token):
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    length = len(findPosMoves(board, enemy))
    return 64-length
def modboard(board,token,pos):
    idxlist = findPosMoves(board, token)
    board2 = board
    for idx in idxlist:
        if idx == pos:
            board2 = replacepuz(board2, '+', idx)
        else:
            board2 = replacepuz(board2, '*', idx)
    return board2
def edgeCovered(board, token, pos):
    if token== 'X':
        opp = 'O'
    else:
        opp = 'X'
    edges = [0,1,2,3,4,5,6,8,16,24,32,40,48,56,57,58,59,60,61,62,63,55,47,39,31,23,15,7]
    board = fliptokens(board, token, pos)
    arrstoCheck = idxnbr[pos]
    for arr in arrstoCheck:
        check = 0
        for mv in arr:
            if check == 1 and mv == pos:
                return True
            elif mv in edges and board[mv] == token:
                check = 1
            elif check == 1 and board[mv] != token:
                break
        for mv in arr[::-1]:
            if check == 1 and mv == pos:
                return True
            elif mv in edges and board[mv] == token:
                check = 1
            elif check == 1 and board[mv] != token:
                break
    return False
def mobilitybest(board, token, movelist):
    if token== 'X':
        opp = 'O'
    else:
        opp = 'X'
    temp = 100
    bestmv = 100
    for mv in movelist:
        length = len(findPosMoves(fliptokens(board, token, mv), opp))
        if length < temp:
            temp == length
            bestmv = mv
    return bestmv
def edgeSafe(board,token, mv):
    if token== 'X':
        opp = 'O'
    else:
        opp = 'X'
    edgeList = [[0,1,2,3,4,5,6,7], [0,8,16,24,32,40,48,56], [56,57,58,59,60,61,62,63], [7,15,23,31,39,47,55,63]]
    idx = 10
    if mv in edgeList[0]:
        idx = 0
    elif mv in edgeList[1]:
        idx = 1
    elif mv in edgeList[2]:
        idx = 2
    elif mv in edgeList[3]:
        idx = 3
    parity = 0
    boardrow = [ board[nidx] for nidx in edgeList[idx]]
    if boardrow.count(opp) < 2:
        return False
    positionarr = edgeList[idx].index(mv)
    posArr2 = positionarr
    if boardrow[positionarr-1]== opp:
        while positionarr < len(boardrow)-1 and boardrow[positionarr + 1] == '.' :
            parity += 1
            positionarr += 1
        if boardrow[positionarr] == opp and parity %2 !=0:
            return True
    if boardrow[posArr2+1] == opp:
        while posArr2 > 0 and boardrow[posArr2  - 1] == '.' :
            parity += 1
            posArr2 -= 1
        if boardrow[posArr2 ] == opp and parity %2 !=0:
            return True
    return False
            
def findBestMove(board, token):
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    corners = [0,7,63, 56]
    dictborder =  {1:0, 8:0, 9:0, 6:7, 14:7, 15:7, 55:63, 54:63, 62:63, 48:56, 49: 56, 57:56}
    edgeList = []
    nonEdge = []
    edges = {0,1,2,3,4,5,6,7,8,16,24,32,40,48,56, 57,58,59,60,61,62,63,55,47,39,31,23,15}
    posMoves = findPosMoves(board, token)
    tempMoves = posMoves[:]
    temp2Moves = posMoves[:]
    for corn in corners:
        if corn in posMoves:
            return corn
    for move in temp2Moves:
        if move in edges:
            if edgeSafe(board,token,move):
                return move
    for move in posMoves:
        if move in dictborder:
            if board[dictborder[move]] == '.' or board[dictborder[move]] == enemy:
                tempMoves.remove(move)
            else:
                return move
    for move in tempMoves: 
        if move in edges:
            edgeList.append(move)
            if edgeSafe(board,token,move):
                return move
            if edgeCovered(board,token,move):
                return move

        else:
            nonEdge.append(move)
    
    if len(nonEdge) != 0:
        return mobilitybest(board, token, nonEdge)
    elif len(tempMoves) != 0:
        return mobilitybest(board, token, tempMoves)
    else:
        return mobilitybest(board, token, posMoves) 

def negamax(board, token,levels): #returns a score together with a move sequence leading to that score
    if token == 'O':
        enemy = 'X'
    else:
        enemy = 'O'
    if len(findPosMoves(board,token)) == 0 and len(findPosMoves(board,enemy)) == 0:
        return [xvso(board, token)] #first element is score, remaining elements are moves used to get to that score
    lm = findPosMoves(board, token)
    if not lm: 
        nm = negamax(board, enemy, levels-1) + [-1]
        return [-nm[0]] +nm[1:]
    nmList = sorted( [negamax(replacepuz(board, token, mv), enemy, levels-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]
def alphabeta(brd, token, improvable, hardbound):
    if token == 'X':
        enemy = 'O'
    else:
        enemy = 'X'
    lm = findPosMoves(brd, token)
    if not lm:
        lm = findPosMoves(brd, enemy)
        if not lm: return [fakexvso(brd,token), -3]
        nm = alphabeta(brd, enemy, -hardbound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newhardbound = -improvable
    for move in lm:
        nm = alphabeta(fliptokens(brd, token, move), enemy, -hardbound, newhardbound) + [move]
        if not best or nm[0]<newhardbound:
            best = nm
            if nm[0] < newhardbound:
                newhardbound = nm[0]
                if -newhardbound>=hardbound: return[-best[0]] + best[1:]
    return [-best[0]] + best[1:]
class Strategy():
 def best_strategy(self, board, player, best_move, still_running):
    board2 = ''.join(board).replace('?', '').replace('@','X')
    board2 = board2.upper()
    token = 'X' if player == '@' else 'O'
    pds = board2.count('.')
    if pds<=10:
        nm = alphabeta(board2, token, -65,65)
        mv1 = 11+ (nm[-1]//8)*10+(nm[-1]%8)
        best_move.value = mv1
    elif pds >= 58:
        mv= startingMove(board2,token)
        mv1 = 11+ (mv//8)*10+(mv%8)
        best_move.value = mv1
    else:
        mv = findBestMove(board2, token)
        mv1 = 11+ (mv//8)*10+(mv%8)
        best_move.value= mv1
def showBoard(pzl):
    count = 1
    for num in range(8):
        line = ''
        for j in range(8*num, 8*num +8):
            line += pzl[j] + ' '
        print( line)
        count += 1
def main():
    emptyboard = '...........................OX......XO...........................'
    if len(sys.argv) > 1:
        if len(sys.argv[1]) == 1:
            token = sys.argv[1].upper()
            board2 = emptyboard
        else:
            board2 = sys.argv[1].upper()
            if len(sys.argv)>2:
                token = sys.argv[2].upper()
            else:
                token = findMove(board2)

    else:
        board2 = emptyboard
        token = findMove(board2)
    board2 = ''.join(board2).replace('?', '').replace('@','X')
    board2 = board2.upper()
    posMoves = board2.count('.')
    showBoard(board2)
    print("Possible Moves:", findPosMoves(board2, token))
    print("My Heuristic Move is:", findBestMove(board2, token))
    if posMoves<= 14:
        nm = alphabeta(board2, token, -65,65)
        print("Negamax:", nm, "and my move is", nm[-1])

##        nm = negamax(board2, token, 3)
##        mv = nm[-1]
##        print(mv)
##        nm = negamax(board2, token, 5)
##        mv = nm[-1]
##        print(mv)
##
##        nm = negamax(board2, token, 7)
##        mv = nm[-1]
##        print(mv)
    elif posMoves >=58:
        print(startingMove(board2,token))
    else:
        mv = findBestMove(board2, token)
        print(mv)
if __name__ == "__main__":
    main()
    
print("time:" , time.clock() - startTime)
#earlygame
