import sys, random
## 27, 28, 35, 36  O, X, X, O
## Option input of gameboard/who's move

# game = "...........................OX......XO..........................."
#
# whoT = "X"

##This is the option sys.argv stuff
def showBoard(game): #Prints the board
	print("\n".join([game[i:i+8] for i in range(0,64,8)]))

def whoTurn(game): #Figures out who's turn it is
	#A faster way would be to count the number of periods. (Do that in a speed up)
	count = 0
	for each in game:
		if each == ".":
			count += 1
	if count%2 == 0:
		if "x" in game:
			return "x"
		else:
			return "X"
	else:
		if "x" in game:
			return "o"
		else:
			return "O"

def whoOpp(whoT):
	if "x" not in game:
		if whoT == "X":
			return "O"
		else:
			return "X"
	else:
		if whoT == "x":
			return "o"
		else:
			return "x"

def move(game, player, position):
	game[position] = player
	checkUp, checkDown, oppo = {0,6,7,8}, {(54,9),(55,8),(56,7),(63,1)}, whoOpp(player)
	for check in checkUp:
		if position > check:
			if ((not(check == 0 or check == 8 or check == 6)) or (((check == 0 or check == 8) and position%8 != 0) or ((check == 6 and position%8 !=7)))):
				if game[position-(check+1)] == oppo:
					temp = position-(check+1)
					pos = 0
					c = 0
					while temp >= 0:
						if(not(((check == 0 or check == 8) and temp%8 == 0) or ((check == 6 and temp%8 ==7)))):
							if game[temp] == ".":
								break
							elif game[temp] == player:
								c = 1
								pos = temp
								break
						else:
							if game[temp] == player:
								c = 1
								pos = temp
							break
						temp = temp - (check+1)
					pos = temp
					while pos != position:
						if c != 1:
							break
						pos = pos + (check+1)
						game[pos] = player
	for check in checkDown:
		if position < check[0]:
			if ((not(check[0] == 63 or check[0] == 54 or check[0] == 56)) or (((check[0] == 63 or check[0] == 54) and position%8 != 7) or ((check[0] == 56 and position%8 != 0)))):
				if game[position+check[1]] == oppo:
					temp = position+check[1]
					pos = 0
					c = 0
					# print(position)
					while temp <= 63:
						if(not(((check[0] == 63 or check[0] == 54) and temp%8 == 7) or ((check[0] == 56 and temp%8 == 0)))):
							if game[temp] == ".":
								break
							elif game[temp] == player:
								c = 1
								pos = temp
								break
						else:
							if game[temp] == player:
								c = 1
								pos = temp
							break
						temp = temp + check[1]
					pos = temp
					# print(c)
					while pos != position:
						if c != 1:
							break
						pos = pos - check[1]
						game[pos] = player
	game = "".join(game)
	return game

if len(sys.argv) > 1:
	game = sys.argv[1]
	if len(sys.argv) == 3:
		if "x" in game:
			whoT = sys.argv[2].lower()
		else:
			whoT = sys.argv[2].upper()
	else:
		whoT = whoTurn(game)
else:
	whoT = "X"
	game = "...........................OX......XO..........................."


def possibleMoves(game, whoT):
	checkUp, checkDown, poss, oppo = {0,6,7,8}, {(54,9),(55,8),(56,7),(63,1)}, set(), whoOpp(whoT) ##
	for each in range(len(game)):
		if game[each] == whoT:
			for check in checkUp:
				if each > check:
					if ((not(check == 0 or check == 8 or check == 6)) or (((check == 0 or check == 8) and each%8 != 0) or ((check == 6 and each%8 !=7)))):
						if game[each-(check+1)] == oppo:
							temp = each-(check+1)
							while temp >= 0:
								if game[temp] == whoT and temp != each-(check+1):
									break
								if game[temp] == ".":
									poss.add(temp)
									break
								if(not(((check == 0 or check == 8) and temp%8 == 0) or ((check == 6 and temp%8 ==7)))):
									if game[temp] == ".":
										poss.add(temp)
										break
									temp = temp - (check+1)
								else:
									break
			for check in checkDown:
				if each < check[0]:
					if ((not(check[0] == 63 or check[0] == 54 or check[0] == 56)) or (((check[0] == 63 or check[0] == 54) and each%8 != 7) or ((check[0] == 56 and each%8 != 0)))):
						if game[each+check[1]] == oppo:
							temp = each+check[1]
							while temp <= 63:
								if game[temp] == whoT and temp != each+check[1]:
									break
								if game[temp] == ".":
									poss.add(temp)
									break
								if(not( ((check[0] == 63 or check[0] == 54) and temp%8 == 7) or ((check[0] == 56 and temp%8 == 0)))):
									if game[temp] == ".":
										poss.add(temp)
										break
									temp = temp + check[1]
								else:
									break
	return poss


# print("State of game: ")
# print(game)
# print("")
# showBoard(game)
# print("")
# # if len(sys.argv) == 1:
# game = list(game)
# print("Possible Moves: ", end = "")
# moves = possibleMoves(game, whoT)
# if len(moves) == 0:
#     print("No Moves")
# else:
#     print(moves)
# print("")
# for each in moves:
#     game[each] = "*"
# print("")
# showBoard("".join(game))

def evalBoard(board, token):
	#num = number of tokens you have - the number of tokens the enemy has
	countT = 0
	countNoT = 0
	for x in range(0,len(board)-1):
		if board[x] == token:
			countT += 1
		elif board[x] == whoOpp(token):
			countNoT += 1
	num = countT - countNoT
	return num
##Negamax: assumes the two sides are negatives of  each other
 ## Returns a score together with a move sequence leading to that score.
 #preferred # of levels: 3
 #Test with only 1 level
def negamax(board, token, levels):
  if not levels:
	  return [evalBoard(board, token)]

  lm = possibleMoves(board, token)
  # print(lm)
  if not lm:
	  best = negamax(board, whoOpp(token), levels-1) + [-1]
  else:
	  best = sorted([negamax(move(list(board), token, mv), \
							   whoOpp(token), levels-1) + [mv] for mv in lm])[0]
  return [-best[0]] + best[1:]

def takeCorner(setMoves):
    corners = {0,7,56,63}
    theCorner = set()
    for each in corners:
        if each in setMoves:
            theCorner.add(each)
    if len(theCorner) == 0:
        return set()
    else:
        return theCorner

def notEdge(setMoves):
    edgeL, edgeR  = {0,8,16,24,32,40,48,56}, {7,15,23,31,39,47,55,63}
    edgeUp, edgeD = {0,1,2,3,4,5,6,7}, {56,57,58,59,60,61,62,63}
    possMoves = set()
    for each in setMoves:
        if each not in edgeL or each not in edgeR or each not in edgeUp or each not in edgeD:
            possMoves.add(each)
    if len(possMoves) == 0:
        return set()
    else:
        return possMoves

def noXorC(setMoves,whoT):
    XandC = {((1,6,8),0),((9,14,15),7),((48,49,57),56),((54,55,62),63)}
    lastChance = set(setMoves)
    for each in XandC:
        if game[each[1]] != whoT:
            for some in each[0]:
                if some in setMoves:
                    lastChance.remove(some)
    return lastChance

def playEdge(setMoves,whoT,game):
    edgeL, edgeR  = {0,8,16,24,32,40,48,56}, {7,15,23,31,39,47,55,63}
    edgeUp, edgeD = {0,1,2,3,4,5,6,7}, {56,57,58,59,60,61,62,63}
    possMoves = set()
    count = 0
    for each in setMoves:
        tempGame = game[:]
        move(tempGame,whoT,each)
        if each in edgeL:
            if tempGame[0] == whoT:
                temp = each
                while temp >= 0:
                    if tempGame[temp] == whoT:
                        if temp == 0:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 8
            if tempGame[56] == whoT:
                temp = each
                while temp <= 56:
                    if tempGame[temp] == whoT:
                        if temp == 56:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 8
        if each in edgeR:
            if tempGame[7] == whoT:
                temp = each
                while temp >= 7:
                    if tempGame[temp] == whoT:
                        if temp == 7:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 8
            if tempGame[63] == whoT:
                temp = each
                while temp <= 63:
                    if tempGame[temp] == whoT:
                        if temp == 63:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 8
        if each in edgeUp:
            if tempGame[0] == whoT:
                temp = each
                while temp >= 0:
                    if tempGame[temp] == whoT:
                        if temp == 0:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 1
            if tempGame[7] == whoT:
                temp = each
                while temp <= 7:
                    if tempGame[temp] == whoT:
                        if temp == 7:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 1
        if each in edgeD:
            if tempGame[56] == whoT:
                temp = each
                while temp >= 56:
                    if tempGame[temp] == whoT:
                        if temp == 56:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp - 1
            if tempGame[63] == whoT:
                temp = each
                while temp <= 63:
                    if tempGame[temp] == whoT:
                        if temp == 63:
                            possMoves.add(each)
                    else:
                        break
                    temp = temp + 1
    if len(possMoves) == 0:
        return set()
    else:
        return possMoves

def spaceCount(game):
	count = 0
	for each in range(0,len(game)-1):
		if game[each] == ".":
			count+=1
	return count

def findBestMove(game, whoT):
	if(spaceCount(game) > 8):
		# print("State of game: ")
		# print(game)
		# print("")
		# showBoard(game)
		# print("")
		# # if len(sys.argv) == 1:
		game = list(game)
		# print("Possible Moves: ", end = "")
		moves = possibleMoves(game, whoT)
		# if len(moves) == 0:
		#     print("No Moves")
		# else:
		#     print(moves)
		# print("")
		# for each in moves:
		#     game[each] = "*"
		# print("")
		# showBoard("".join(game))
		myMove = -1
		cornerMoves = takeCorner(moves)
		connEdges = playEdge(moves,whoT,game)
		allowed = noXorC(moves,whoT)
		notEdges = notEdge(allowed)
		if len(cornerMoves) > 0:
		    myMove = (random.sample(list(cornerMoves),1))
		    print("Heuristic Move: ", end="")
		    print(myMove)
		elif len(connEdges) > 0:
		    myMove = (random.sample(list(connEdges),1))
		    print("Heuristic Move: ", end="")
		    print(myMove)
		elif len(notEdges) > 0:
		    myMove = (random.sample(list(notEdges),1))
		    print("Heuristic Move: ", end="")
		    print(myMove)
		elif len(allowed) > 0:
		    myMove = (random.sample(list(allowed),1))
		    print("Heuristic Move: ", end="")
		    print(myMove)
		else:
		    print("Heuristic Move: ", end="")
		    print ((random.sample(list(moves),1)))
		return(myMove)
	else:
		levels = 7
		nm = negamax(game,whoT,levels)
		print("At level {} nm gives {} and I pick move {}".format(levels,nm,nm[-1]))
		# return(nm[-1])
		return(nm)


# print("")
# showBoard("".join(game))
# print("Possible Moves: ", end="")
# print(possibleMoves(game,whoT))
# print(findBestMove(game,whoT))
#
# class Strategy():
# 	def best_strategy(self, board, player, best_move, still_running):
# 		depth = 1
# 		brd = "".join(board).replace("?","").replace("@","X")
#
# 		token = "X" if player == "@" else "O"
#
# 		mv = findBestMove(brd,token)
# 		move = 11 + (mv || 8)*10 + (mv%8)
#
# 		best_move.value = mv
#
# #
#
#
# print("Move: ", end="")
# print(moves.pop())

class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		depth = 1
		# brd = "".join(board).replace("?","").replace("@","X")

		token = "X" if player == "@" else "O"

		mv = findBestMove(brd,token)
		move = 11 + (mv // 8)*10 + (mv%8)

		best_move.value = mv

# Strategy()

# if __name__ == "__main__":
# 	main()
