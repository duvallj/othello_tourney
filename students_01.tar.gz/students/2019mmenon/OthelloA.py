#Mahesh Menon
import sys, random

def main():
   turn=""
   board = "...........................ox......xo..........................."
   
   if len(sys.argv)==2:
      if len(sys.argv[1])>1:
         board = sys.argv[1].lower()
      else:
         turn = sys.argv[1].lower()
   elif len(sys.argv)==3:
      board = sys.argv[1].lower()
      turn = sys.argv[2].lower()

   if turn=="":
      if (board.count("x")+board.count("o"))%2==0:
         turn = "x"
      else:
         turn = "o"
   
   # for x in range(8):
#       print (board[8*x:8*x+8])
#       
#    print("Possible moves:", legalMoves(board,turn))
#    print("Heuristic move:",bestMove(legalMoves(board,turn), board,turn))
#     
   n = 7
   if board.count(".")<=n:
      print(negamax(board, turn, -1))
   else:
      print(bestMove(legalMoves(board,turn), board, turn))
class Strategy():
   def best_strategy(self, board, player, best_move, still_running):
      board = ''.join(board).lower().replace('?', '').replace('@', 'x')
      turn = "x" if player=="@" else 'o'    
      depth = 1
      n = 7
      if board.count(".")<=n:
         move = negamax(board, turn, -1)[-1]
         best_move.value = 11+(move//8)*10 + (move%8)
      else:
         move = bestMove(legalMoves(board,turn), board,turn)
         best_move.value = 11+(move//8)*10 + (move%8)

def negamax(board,token,levels): #returns score together with a move sequence linking to that score  
   enemy = ""
   if token.lower() == "o":
      enemy = "x"
   else:
      enemy = "o"
   
   if len(legalMoves(board, token)) + len(legalMoves(board,enemy))==0: 
      score = evalBoard(board,token, enemy)
      return [score]
      
   lm = legalMoves(board, token)
   #print(lm, board, token)
   if not lm:
      nm = negamax(board,enemy,levels-1) + [-1]
      return [-nm[0]] + nm[1:]
   nmList = sorted([negamax(makeMove(board,token, mv), enemy, levels-1) + [mv] for mv in lm])
   best = nmList[0]
   
   return [-best[0]]+best[1:]

def evalBoard(board, turn, enemy):
   return board.count(turn)


def legalMoves(board1, token):
   turn=token.lower()
   board = board1.lower()    
   oppTurn = ""
   if turn == "x":
      oppTurn = "o"
   else:
      oppTurn = "x"
   
   symbols = [x for x in range(64) if board[x]==oppTurn ]
   possiblePos = set()
   
   for pos in symbols:
      for x in [pos-9,pos-8,pos-7,pos-1,pos+1,pos+7,pos+8,pos+9]:
         if not abs(x%8-pos%8)<=1:
            continue
         if x>=0 and x<64 and board[x]==".":
            diff = x-pos
            y = pos-diff
            if diff==-7 or diff==9 or diff==1:
               while y>=0 and y<64 and y%8<(pos)%8:
                  if board[y]==".":
                     break
                  elif board[y]==turn:
                     possiblePos.add(x)
                     break
                  else:
                     y-=diff
            elif diff==-9 or diff==7 or diff==-1:
               while y>=0 and y<64 and y%8>(pos)%8:
                  if board[y]==".":
                     break
                  elif board[y]==turn:
                     possiblePos.add(x)
                     break
                  else:
                     y-=diff
            else:
               while y>=0 and y<64:
                  if board[y]==".":
                     break
                  elif board[y]==turn:
                     possiblePos.add(x)
                     break
                  else:
                     y-=diff
   return (possiblePos)
   
def makeMove(board1, token1, move1):
   board = board1.lower()
   pos = move1
   turn = token1.lower()
   letters = "abcdefgh"  
   oppTurn = ""
   if turn == "x":
      oppTurn = "o"
   else:
      oppTurn = "x"
   
   for x in [pos-9,pos-8,pos-7,pos-1,pos+1,pos+7,pos+8,pos+9]:        
      if not abs(x%8-pos%8)<=1:
         continue
      if x<0 or x>63:
         continue
      
      if board[x]==oppTurn:
         turnover = {x, pos}
         diff = pos - x
         y = x
         if diff==-7 or diff==9 or diff==1:
            while y>=0 and y<64 and y%8<(pos)%8:
               if board[y]==".":
                  break
               elif board[y]==turn:
                  for num in turnover:
                     board = board[:num] + turn + board[num+1:]
                  break
               else:
                  turnover.add(y)
                  y-=diff
         elif diff==-9 or diff==7 or diff==-1:
            while y>=0 and y<64 and y%8>(pos)%8:
               if board[y]==".":
                  break
               elif board[y]==turn:
                  for num in turnover:
                     board = board[:num] + turn + board[num+1:]                     
                  break
               else:
                  turnover.add(y)
                  y-=diff
         else:
            while y>=0 and y<64:
               if board[y]==".":
                  break
               elif board[y]==turn:
                  for num in turnover:
                     board = board[:num] + turn + board[num+1:]                    
                  break
               else:
                  turnover.add(y)
                  y-=diff
   return (board) 
   
def bestMove(possiblePos, board, turn):
   for x in [0, 7, 63, 56]:
      if x in possiblePos:
         print(x)
         sys.exit()
         
   goodSet = set()
   for x in possiblePos:
      if x//8==0 or x//8==7:
         y = x
         while y!=x//8*8:  
            y+=-1
            if board[y]==".":
               break
            if y==x//8*8 and board[y]==turn:
               goodSet.add(x)
               break
         y = x
         if x in goodSet:
            continue
            
         while y!=x//8*8+7:
            y+=1
            if board[y]==".":
               break
            if y==x//8*8+7 and board[y]==turn:
               goodSet.add(x)
               break
      elif x%8==0 or x%8==7:
         y = x
         while y!=x%8:
            y+=-8
            if board[y]==".":
               break
            if y==x%8 and board[y]==turn:
               goodSet.add(x)
               break
         y = x
         if x in goodSet:
            continue
         while y!=56+x%8:
            y+=8
            if board[y]==".":
               break
            if y==56+x%8 and board[y]==turn:
               goodSet.add(x)
               break
   if len(goodSet)>0:
      return(random.choice([*goodSet]))               
         
   removeList = []
   for x in possiblePos:
      if x in [1,8,9] and board[0]==".":
         removeList.append(x)
      elif x in [6,14,15] and board[7]==".":
         removeList.append(x)
      elif x in [48,49,57] and board[56]==".":
         removeList.append(x)
      elif x in [62,54,55] and board[63]==".":
         removeList.append(x)
   for x in removeList:
      if len(possiblePos)>1:
         possiblePos.remove(x)
   
   for x in possiblePos:
      if not(x%8==0 or x%8==7 or x//8==0 or x//8==7):
         return(x)
   
   return(random.choice([*possiblePos])) 

if __name__ == "__main__":
   main()

#1  ................O.OXXX...OOXXX....OXXX.....XX......XO...........
   # if move==-1:
#       return board.count(turn)
#       
#    if move in [0,7,56,63]:
#       return (1000)   
#    
#    x = move
#    if x//8==0 or x//8==7:
#       y = x
#       while y!=x//8*8:  
#          y+=-1
#          if board[y]=="." or board[y] == enemy:
#             break
#          if y==x//8*8 and board[y]==turn:
#             return (900)
#       y = x         
#       while y!=x//8*8+7:
#          y+=1
#          if board[y]=="." or board[y] == enemy:
#             break
#          if y==x//8*8+7 and board[y]==turn:
#             return (900)
#    elif x%8==0 or x%8==7:
#       y = x
#       while y!=x%8:
#          y+=-8
#          if board[y]=="." or board[y] == enemy:
#             break
#          if y==x%8 and board[y]==turn:
#             return (900)
#       y = x
#       
#       while y!=56+x%8:
#          y+=8
#          if board[y]=="." or board[y] == enemy:
#             break
#          if y==56+x%8 and board[y]==turn:
#             return (900)
#             
#    
#    x = move
#    if x in [1,8,9] and board[0]==".":
#       return (-100)
#    elif x in [6,14,15] and board[7]==".":
#       return (-100)
#    elif x in [48,49,57] and board[56]==".":
#       return (-100)
#    elif x in [62,54,55] and board[63]==".":
#       return (-100)
#    
#    if not(x%8==0 or x%8==7 or x//8==0 or x//8==7): 
#       return (board.count(turn))
#    else:
#       return(-50)
   
   #look for how many tiles cannot be flipped (locked tiles)
   #evaporation strategy?