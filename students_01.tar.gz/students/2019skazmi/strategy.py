import random
import math
import numpy
import time

#### Othello Shell
#### P. White 2016-2018

#last win = -8

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
WEIGHTED_MATRIX = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 125, -25, 25, 10, 10, 25, -25, 125, 0,
        0, -25, -50, -10, -10, -10, -10, -50, -25, 0,
        0, 25, -15, 20, 10, 10, 20, -15, 25, 0,
        0, 10, -10, 10, 3, 3, 10, -10, 10, 0,
        0, 10, -10, 10, 3, 3, 10, -10, 10, 0,
        0, 25, -15, 20, 10, 10, 20,-15, 25, 0,
        0, -25, -50, -10, -10, -10, -10, -50, -25, 0,
        0, 125, -25, 25, 10, 10, 25, -25, 125, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

EDGE_MATRIX = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 125, -25, 50, 50, 50, 50, -25, 125, 0,
        0, -25, -50, -10, -10, -10, -10, -50, -25, 0,
        0, 25, -10, 10, 10, 10, 10, -10, 50, 0,
        0, 10, -10, 10, 5, 5, 10, -10, 50, 0,
        0, 10, -10, 10, 5, 5, 10, -10, 50, 0,
        0, 25, -10, 10, 10, 10, 10,-10, 50, 0,
        0, -25, -50, -10, -10, -10, -10, -50, -25, 0,
        0, 125, -25, 50, 50, 50, 50, -25, 125, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

CENTER_MATRIX = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 50, -20, 10, 10, 10, 10, -20, 50, 0,
        0, -20, -50, -10, -10, -10, -10, -50, -10, 0,
        0, 10, -10, 20, 20, 20, 20, -10, 10, 0,
        0, 10, -10, 20, 5, 5, 20, -10, 10, 0,
        0, 10, -10, 20, 5, 5, 20, -10, 10, 0,
        0, 10, -10, 20, 20, 20, 20,-10, 10, 0,
        0, -20, -50, -10, -10, -10, -10, -50, -20, 0,
        0, 50, -20, 10, 10, 10, 10, -20, 50, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

WEIGHTED_MATRIX_OG = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

WEIGHTED_MATRIX_TEST = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0]



########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = ""
        for x in range(0, 10):
            board += OUTER
        for x in range (10, 90):
            if x == 44 or x == 55:
                board += WHITE
            elif x == 45 or x == 54:
                board += BLACK
            elif x % 10 == 0 or x % 10 == 9:
                board += OUTER
            else:
                board += EMPTY
        for x in range(90, 100):
            board += OUTER
        return board

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pboard = ""
        for r in range(0, 100, 10):
            pboard += board[r : r + 10] + "\n"
        return pboard

    def opponent(self, player):
        """Get player's opponent."""
        if player == WHITE:
            return BLACK
        if player == BLACK:
            return WHITE
        pass

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        x = square + direction
        while board[x] == self.opponent(player):
            x = x + direction
        if board[x] == player:
            return x
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] != EMPTY:
            return False
        for d in DIRECTIONS:
            if board[move+d] == self.opponent(player):
                if self.find_match(board, player, move, d) != None:
                    return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        assert (board[move] == EMPTY)
        b = "".join(board)
        new_board = b[:move] + player + b[move + 1:]
        matches = []
        for d in DIRECTIONS:
            match = self.find_match(b, player, move, d)
            if match != None:
                matches.append((match, d))
        for match, d in matches:
            if move < match:
                for x in range(move, match, d):
                    new_board = new_board[:x] + player + new_board[x + 1:]
            elif move > match:
                for x in range(match, move, -d):
                    y = x
                    new_board = new_board[:x] + player + new_board[x + 1:]
        return new_board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves = []
        for x in range(11, 89):
            if self.is_move_valid(board, player, x):
                moves.append(x)
        return moves

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if len(self.get_valid_moves(board, player)) == 0:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        nextp = self.opponent(prev_player)
        if not self.has_any_valid_moves(board, nextp):
            if not self.has_any_valid_moves(board, prev_player):
                return None
            return prev_player
        return nextp

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        score = 0
        for r in range(0, 100, 10):
            for c in range(1, 9):
                if board[r+c] == BLACK: score += 1
                elif board[r+c] == WHITE: score += -1
        return score

    def weighted_score(self, board, player=BLACK):
        board_matrix = []
        for x in range(0, 100):
            if board[x] == BLACK: board_matrix.append(1)
            elif board[x] == WHITE: board_matrix.append(-1)
            else: board_matrix.append(0)
        weight = numpy.dot(board_matrix, WEIGHTED_MATRIX)
        return weight #+ random.random()

    def center_weighted_score(self, board, player=BLACK):
        board_matrix = []
        for x in range(0, 100):
            if board[x] == BLACK: board_matrix.append(1)
            elif board[x] == WHITE: board_matrix.append(-1)
            else: board_matrix.append(0)
        weight = numpy.dot(board_matrix, CENTER_MATRIX)
        return weight #+ random.random()

    def edge_weighted_score(self, board, player=BLACK):
        board_matrix = []
        for x in range(0, 100):
            if board[x] == BLACK: board_matrix.append(1)
            elif board[x] == WHITE: board_matrix.append(-1)
            else: board_matrix.append(0)
        weight = numpy.dot(board_matrix, EDGE_MATRIX)
        return weight #+ random.random()

    #to test my weighted matrix against orginal weighted matrix
    def test_score_og(self, board, player=BLACK):
        board_matrix = []
        for x in range(0, 100):
            if board[x] == BLACK:
                board_matrix.append(1)
            elif board[x] == WHITE:
                board_matrix.append(-1)
            else:
                board_matrix.append(0)
        weight = numpy.dot(board_matrix, WEIGHTED_MATRIX_OG)
        return weight #+ random.random()

    # to test my weighted matrix against new matrix
    def test_score_new(self, board, player=BLACK):
        board_matrix = []
        for x in range(0, 100):
            if board[x] == BLACK:
                board_matrix.append(1)
            elif board[x] == WHITE:
                board_matrix.append(-1)
            else:
                board_matrix.append(0)
        weight = numpy.dot(board_matrix, NEW_MATRIX)
        return weight  # + random.random()

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        pass

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            node.score = self.score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, move, score = 1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth = depth -1).score
                children.append(c)
        winner = best[player](children)
        node.score = winner.score
        return winner

    def minmax_search_weighted(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            #use regular score when its the end of game
            if self.next_player(board, player) == None:
                node.score = 1000 * self.score(board)
            else:
                #to test my weighted matrix against different matrix
                #if player == WHITE:
                #    node.score = 1000 * self.test_score_new(board)
                #    return node
                node.score = 1000 * self.weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search_weighted(c, next_player, depth=depth - 1).score
                children.append(c)
        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
        #to test my weighted matrix against different matrix
            #if player == WHITE:
            #    node.score = 1000 * self.test_score_new(board)
            #    return node
            node.score = 1000 * self.weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alpha_beta(c, next_player, depth - 1, a, b).score
                children.append(c)
            if player == BLACK:
                a = max(a, c.score)
            else:
                b = min(b, c.score)
            if a >= b:
                #print("Alpha ( " + str(a) + ") is greater than Beta (" + str(b) + "), so break")
                break

        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta_leastmoves(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            #if self.count > 10:
            #    node.score = 1000 * self.weighted_score(board)
            #    return node
            score_minus = len(self.get_valid_moves(board, self.next_player(board, player)))
            plainscore = self.weighted_score(board, player)
            if player == BLACK:
                node.score = 1000 * self.weighted_score(board) - score_minus*5000
            if player == WHITE:
                node.score = 1000 * self.weighted_score(board) + score_minus * 5000
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alpha_beta_leastmoves(c, next_player, depth - 1, a, b).score
                children.append(c)
            if player == BLACK:
                a = max(a, c.score)
            else:
                b = min(b, c.score)
            if a >= b:
                #print("Alpha ( " + str(a) + ") is greater than Beta (" + str(b) + "), so break")
                break

        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta_other(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            if self.count > 10:
                node.score = 1000 * self.weighted_score(board)
            elif self.count > 40:
                node.score = 1000 * self.edge_weighted_score(board)
            else:
                node.score = 1000 * self.center_weighted_score(board)
            if self.count <= 20:
                score_minus = len(self.get_valid_moves(board, self.next_player(board, player)))
                node.score = node.score - score_minus * 1000 * (20 - self.count)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alpha_beta_other(c, next_player, depth - 1, a, b).score
                children.append(c)
            if player == BLACK:
                a = max(a, c.score)
            else:
                b = min(b, c.score)
            if a >= b:
                # print("Alpha ( " + str(a) + ") is greater than Beta (" + str(b) + "), so break")
                break

        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta_twomatrix(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            if self.count > 10:
                node.score = 1000 * self.weighted_score(board)
                return node
            node.score = 1000 * self.center_weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alpha_beta_twomatrix(c, next_player, depth - 1, a, b).score
                children.append(c)
            if player == BLACK:
                a = max(a, c.score)
            else:
                b = min(b, c.score)
            if a >= b:
                # print("Alpha ( " + str(a) + ") is greater than Beta (" + str(b) + "), so break")
                break

        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta_threematrix(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            if self.count > 5: #*2:
                node.score = 1000 * self.weighted_score(board)
                return node
            elif self.count > 20: #*2:
                node.score = 1000 * self.edge_weighted_score(board)
            node.score = 1000 * self.center_weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alpha_beta_threematrix(c, next_player, depth - 1, a, b).score
                children.append(c)
            if player == BLACK:
                a = max(a, c.score)
            else:
                b = min(b, c.score)
            if a >= b:
                # print("Alpha ( " + str(a) + ") is greater than Beta (" + str(b) + "), so break")
                break

        winner = best[player](children)
        node.score = winner.score
        return winner

    def alpha_beta_reverselogic(self, node, player, depth, a, b):
        best = {BLACK: max, WHITE: min}
        board = node.board
        if depth == 0:
            if self.count <= 5:  # *2:
                node.score = 1000*self.score(board)*(-1)
            elif self.count > 27: #*2
                node.score = 1000*self.score(board)
            score_minus = len(self.get_valid_moves(board, self.next_player(board, player)))
            node.score = 1000 * self.weighted_score(board) - 2000 * score_minus
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                # use regular score when its the end of game
                c = Node(next_board, move, score=1000 * self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.alpha_beta_threematrix(c, next_player, depth - 1, a, b).score
                children.append(c)
            if player == BLACK:
                a = max(a, c.score)
            else:
                b = min(b, c.score)
            if a >= b:
                # print("Alpha ( " + str(a) + ") is greater than Beta (" + str(b) + "), so break")
                break

        winner = best[player](children)
        node.score = winner.score
        return winner


    count = 0

    def minmax_strategy(self, board, player, depth = 4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        start_node = Node(board)
        tic = time.time()
        if player == BLACK:
            next_node = self.alpha_beta_leastmoves(start_node, player, depth, -1*math.inf, math.inf)
            #next_node = self.minmax_search_weighted(start_node, player, depth)
        else:
            next_node = self.alpha_beta_leastmoves(start_node, player, depth, -1*math.inf, math.inf)
        toc = time.time()
        #print(str(toc - tic))
        self.count +=1
        return next_node.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = minmax_strategy

class Node():
    def __init__(self, board, move = None, score = None):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self, other):
        if other.score == None:
            return False
        else:
            return self.score < other.score

###############################################
# The main game-playing code
# You can probably run this without modification
################################################
#import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGTERM)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    #game =  ParallelPlayer(5)
    game = StandardPlayer()
    game.play()
