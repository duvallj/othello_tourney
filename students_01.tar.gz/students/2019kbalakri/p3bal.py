import sys, itertools, time

def seconds_removed(board,arg,tk):
    copy = arg.copy()
    snds = [1,8,9]
    if board[0//8][0%8]!=tk:
        for each in snds:
            if each in copy:
                del copy[copy.index(each)]
    snds = [6,14,15]
    if board[7//8][7%8]!=tk:
        for each in snds:
            if each in copy:
                del copy[copy.index(each)]
    snds = [48,49,57]
    if board[56//8][56%8]!=tk:
        for each in snds:
            if each in copy:
                del copy[copy.index(each)]
    snds = [54,55,62]
    if board[63//8][63%8]!=tk:
        for each in snds:
            if each in copy:
                del copy[copy.index(each)]

    if len(copy)>0:
        return copy
    else:
        return arg
def avoid_edges(arg):
    copy = arg.copy()
    snds = [0,1,2,3,4,5,6,7,8,16,24,32,40,48,56,57,58,59,60,61,62,63,7,15,23,31,39,47,55,63] #the list of second away from the side
    for each in snds:
        if each in copy:
            del copy[copy.index(each)]
    if len(copy)>0:
        return copy
    else:
        return arg
def get_good_edges(board,lm,tk):
    copy = lm
    good_edges = set()
    lm2 = set(lm)
    if board[0//8][0%8] == tk:
        start_x = 0
        start_y = 0
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x + 1
                start_y = start_y + 0
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[0//8][0%8] == tk:
        start_x = 0
        start_y = 0
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x + 0
                start_y = start_y + 1
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[7//8][7%8] == tk:
        start_x = 7//8
        start_y = 7%8
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x - 1
                start_y = start_y + 0
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[7//8][7%8] == tk:
        start_x = 7//8
        start_y = 7%8
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x + 0
                start_y = start_y + 1
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[56//8][56%8] == tk:
        start_x = 56//8
        start_y = 56%8
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:
                start_x = start_x + 1
                start_y = start_y + 0
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[56//8][56%8] == tk:
        start_x = 56//8
        start_y = 56%8
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x + 0
                start_y = start_y - 1
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[63//8][63%8] == tk:
        start_x = 63//8
        start_y = 63%8
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x - 0
                start_y = start_y - 1
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))

    if board[63//8][63%8] == tk:
        start_x = 63//8
        start_y = 63%8
        if on_board(start_x,start_y):
            while board[start_x][start_y] == tk:

                start_x = start_x - 1
                start_y = start_y + 0
                if not on_board(start_x,start_y):
                    break
        if on_board(start_x,start_y) and board[start_x][start_y]=='.' and convert_coordinate(start_x,start_y) in lm:
            good_edges.add(convert_coordinate(start_x,start_y))
    un = good_edges.union(lm2)
    if un:
        return un
    else:
        return lm
def convert_to_matrix(string):
    empty_matrix = [['.' for x in range(8)] for y in range(8)]
    x_list = find(string,'X'); o_list = find(string, 'O')
    for index in x_list:
        empty_matrix[index//8][index%8] = 'X'
    for index2 in o_list:
        empty_matrix[index2//8][index2%8] = 'O'
    return empty_matrix
def matrix_to_string(item):
    return "".join(itertools.chain(*item))
def find(string, ch):
    return [i for i, ltr in enumerate(string) if ltr == ch]
def print_board(config):
    print("\n".join([config[i:i+8] for i in range(0,64,8)]))
def opposite(move):
    if move == 'X':
        return 'O'
    return 'X'
def on_board(x,y):
    return x>=0 and x<=7 and y>=0 and y<=7
def convert_coordinate(x,y):
    return (x*8) + y
def get_move(config):
    empty_count = config.count('.')
    if empty_count % 2 == 0:
        return 'X'
    return 'O'
def legal_move(config, piece, x_coord, y_coord):
    if config[x_coord][y_coord] != '.':
        return False
    config[x_coord][y_coord] = piece
    for xplus, yplus in [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]:
        xdir = x_coord + xplus
        ydir = y_coord + yplus
        if on_board(xdir,ydir):
            while config[xdir][ydir] == opposite(piece):
                xdir = xdir + xplus
                ydir = ydir + yplus
                if not on_board(xdir,ydir):
                    break
                #if on_board(xdir,ydir):
                if config[xdir][ydir] == piece:
                    config[x_coord][y_coord] = '.'
                    return True
    config[x_coord][y_coord] = '.'
    return False
def return_legal_moves(board,piece):
    leg_moves = []
    for i in range(8):
        for j in range(8):
            if legal_move(board,piece,i,j):
                leg_moves.append(convert_coordinate(i,j))
    return leg_moves
def flipped_tiles(config, piece, index):
    #print(piece)
    x_coord = index//8
    y_coord = index%8
    flipped_tiles = []
    if config[x_coord][y_coord] != '.':
        return None
    config[x_coord][y_coord] = piece
    for xplus, yplus in [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]:
        xdir = x_coord + xplus
        ydir = y_coord + yplus
        if on_board(xdir,ydir):
            while config[xdir][ydir] == opposite(piece):
                xdir = xdir + xplus
                ydir = ydir + yplus
                if not on_board(xdir,ydir):
                    break
                if on_board(xdir,ydir):
                    if config[xdir][ydir] == piece:
                        while True:
                            xdir = xdir-xplus
                            ydir = ydir-yplus
                            if xdir == x_coord and ydir == y_coord:
                                break
                            flipped_tiles.append(convert_coordinate(xdir,ydir))
    config[x_coord][y_coord] = '.'
    if len(flipped_tiles) > 0:
        return (flipped_tiles)
    return None
def play_move(board,tok,legalmoves):
    print(type(board))
    print(legalmoves)
    if 7 in legalmoves:
        return 7
    if 0 in legalmoves:
        return 0
    if 63 in legalmoves:
         return 63
    if 56 in legalmoves:
        return 56
    ge = False
    if get_good_edges(board,legalmoves,tok):
        ge = True
        legalmoves = list(get_good_edges(board,legalmoves,tok))
    legalmoves = seconds_removed(board,legalmoves,tok)

    max_one = -1
    max_two = -1
    if ge==False:
        legalmoves = avoid_edges(legalmoves)
    for i in range(len(legalmoves)):
        if flipped_tiles(convert_to_matrix(board), tok, legalmoves[i])[1] > max_one:
            max_one = flipped_tiles(board, tok, legalmoves[i])[1]
            max_two = legalmoves[i]
    #return random.choice(legalmoves)
    return max_two

# New Lab 7 Methods

def evaluate(b, t):
    """ Mobility heuristic evaluation (brunt of code comes from here) """
    nb = convert_to_matrix(b); return len(return_legal_moves(nb,t)) - len(return_legal_moves(nb,opposite(t)))

def update(b, t, m):
    """ Updates board (string) """
    nb = convert_to_matrix(b); f = flipped_tiles(nb, t, m)
    for tf in f:
        nb[tf//8][tf%8] = t
    return matrix_to_string(nb)

def negamax(b, t, l):
    """ Returns move based on evaluation method """
    if not l: return [evaluate(b,t)]  #termination case
    lm = return_legal_moves(convert_to_matrix(b),t)
    if not lm:  #pass
        nm = negamax(b,opposite(t),l-1) + [-1]; return [-nm[0]]+nm[1:]
    r = min(negamax(update(b,t,m), opposite(t), l-1) + [m] for m in lm)
    return [-r[0]] + r[1:]

def pm(b,t):
    if matrix_to_string(b).count('.') <= 8:
        return negamax(b,t,3)[-1]
    else:
        print("Not negamax")
        return play_move(convert_to_matrix(b),t,return_legal_moves((b),t))
    return -1

def main():
    l = 3
    b = "...........................OX......XO...........................".upper()
    t = get_move(b)
    b = convert_to_matrix(sys.argv[1].upper())
    t = sys.argv[2].upper()
    nm = negamax(matrix_to_string(b), t, l)
    print("At level {}, nm gives {} and I pick move {}".format(l, nm, nm[-1]))
    #print(pm(b,t))



class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        b = ''.join(board).replace('?','').replace('@','X')
        t = 'X' if player== '@' else 'O'
        m = pm(b,t)
        mf = 11 + (m//8)*10 + (mv%8)
        best_move.value = mf


if __name__ == "__main__":
    main()
