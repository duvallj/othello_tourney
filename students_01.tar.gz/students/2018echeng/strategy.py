import sys
corners = {0,7,63,56}
edges = {0:[[1,2,3,4,5,6],[8,16,24,32,40,48]],7:[[6,5,4,3,2,1],[15,23,31,39,47,55]],56:[[57,58,59,60,61,62],[48,40,32,24,16,8]],63:[[62,61,60,59,58,57],[55,47,39,31,23,15]]}
danger = {0:{1,8,9}, 7:{6,14,15}, 63:{62,53,54}, 56:{56,47,48}}
class Strategy():
	 def best_strategy(self,board,player,best_move, still_running):
		 brd = ''.join(board).replace('?', '').replace('@','X')
		 token = "X" if player == '@' else 'o'
		 a = findMoves(brd, token)
		 mv= goodMove(brd, a, token)
		 mv1 = 11 + (mv // 8) *10 + (mv % 8)
		 best_move.value = mv1
		 empty=board.count('.')
		 if empty<8:
		 	nm = negamax(brd, token, -1)
		 	mv = nm[-1]
		 	mv1 = 11 + (mv // 8) *10 + (mv % 8)
		 	best_move.value = mv1

def main():
	board = "...........................ox......xo..........................."
	try:
		print("in")
		board = sys.argv[1].lower()
		turn = curTurn(board)
		levels=7
		if len(sys.argv) > 2:
			turn = sys.argv[2].lower()
		if len(sys.argv) >3:
			levels=int(sys.argv[3])
		empty=board.count('.')
		if empty<9:
			nm = negamax(board, turn, levels)
			print ("At level {}, nm gives {}".format(levels, nm))
			print ("and I pick {}".format(nm[-1]))
		else:
			a = findMoves(board, turn)
			print(goodMove(board,a, turn))
	except IndexError:
		print("error")
def nextTurn(turn):
	if turn == "x": return "o"
	return "x"
def curTurn(board):
	return ['x','o'][len([1 for x in range(64) if board[x] == '.']) %2]
def goodMove(board,possMoves, turn):
	copy=possMoves
	for i in possMoves:
		if i in corners:
			return i
	for i in corners:
		if board[i]!=turn:
			possMoves=possMoves-danger[i]
	if possMoves:
		ret = possMoves.pop()
		print(ret)
		return ret
	ret = copy.pop()
	print(ret)
	return ret
def negamax(board, turn, levels):
	if not levels: return [heur(board[:], turn)]

	lm = findMoves(board[:], turn)
	enemy=nextTurn(turn)
	unsorted=[]
	if not lm: 
		enemylm=findMoves(board[:],enemy)
		if not enemylm:
			# print(board[:])
			# print(heur(board[:],turn))
			return [heur(board[:], turn)]
		nm = negamax(board[:], enemy, levels) + [-1]
		return [-nm[0]] + nm[1:]
	#else: 
	unsorted=[negamax(makeMove(board[:], turn, mv), enemy, levels-1) + [mv] for mv in lm]
	best = sorted(unsorted)[0]
	'''if levels==8:
		print(levels)
		print("legal moves: "+str(lm))
		print("unsorted: "+str(unsorted))'''
	#print(best)
	return [-best[0]] + best[1:] 
def makeMove(board, turn, mv):
	ret=''
	stones=sorted(stonesToTurn(board, mv, turn)+[mv])
	for ind in range(len(stones)):
		ret+=board[len(ret):stones[ind]]+turn
	ret+=board[len(ret):64]
	return ret
def heur(board,turn):
	enemy=nextTurn(turn)
	us=0
	them=0
	for i in board:
		if i ==turn:
			us+=1
		elif i==enemy:
			them+=1
	return them-us
def findMoves(board, turn):
	neigh = set()
	for x in range(len(board)):
		if board[x] == turn:
			mySet = findNeigh(board, x)
			if mySet:
				for i in mySet:
					neigh.add(i)
	# print(neigh)
	# print(neigh[0][0])
	return neigh
def findNeigh(board, ind):
	row = ind // 8
	col = ind % 8
	mySet = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
	if col == 0:# or col == 1:
		mySet = [i for i in mySet if i[1] != -1]
	if row == 0:# or row == 1:
		mySet = [i for i in mySet if i[0] != -1]
	if col == 7:# or col == 6:
		mySet = [i for i in mySet if i[1] != 1]
	if row == 7:# or row == 6:
		mySet = [i for i in mySet if i[0] != 1]
	possValues = []
	for i in range(len(mySet)):
		z = mySet[i]
		newrow = row
		newcol = col
		changed = False
		while True:
			newrow += z[0]
			newcol += z[1]
			if newrow < 0 or newrow > 7 or newcol < 0 or newcol > 7:
				mySet[i] = ""
				break
			if board[newrow * 8 + newcol] == board[ind]:
				mySet[i] = ""
				break
			if board[newrow * 8 + newcol] == '.' and not changed:
				mySet[i] = ""
				break
			if board[newrow * 8 + newcol] == '.' and changed:
				possValues.append(newrow * 8 + newcol)
				break
			else:
				changed = True
	# if possValues:
	return possValues
def stonesToTurn(board, ind, turn):
	row = ind // 8
	col = ind % 8
	mySet = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
	if col == 0 or col == 1:
		mySet = [i for i in mySet if i[1] != -1]
	if row == 0 or row == 1:
		mySet = [i for i in mySet if i[0] != -1]
	if col == 7 or col == 6:
		mySet = [i for i in mySet if i[1] != 1]
	if row == 7 or row == 6:
		mySet = [i for i in mySet if i[0] != 1]
	possValues = []
	for i in range(len(mySet)):
		z = mySet[i]
		newrow = row
		newcol = col
		changed = False
		stoneLine = []
		while True:
			newrow += z[0]
			newcol += z[1]
			if newrow < 0 or newrow > 7 or newcol < 0 or newcol > 7:
				mySet[i] = ""
				break
			if board[newrow * 8 + newcol] == turn and not changed:
				mySet[i] = ""
				break
			if board[newrow * 8 + newcol] == '.':
				mySet[i] = ""
				break
			if board[newrow * 8 + newcol].lower() == nextTurn(turn):
				stoneLine.append(newrow * 8 + newcol)
				changed = True
			elif board[newrow * 8 + newcol].lower() == turn.lower() and changed:
				possValues+=stoneLine
				break
			else:
				changed = True
	# if possValues:
	return possValues
if __name__=="__main__":
	main()
