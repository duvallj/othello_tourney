import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():
    def __init__(self, board, last_move, last_node, score = None):
        self.board = board
        self.score = score
        self.last_move = last_move
        self.last_node = last_node
    def __lt__(self, other):
        if self.score != other.score:
            return self.score < other.score
        else:
            return random.random() < random.random()

class Strategy():

    def __init__(self):
        self.board = self.get_starting_board()
        self.player = BLACK
        self.valid_moves = self.get_valid_moves(self.board, self.player)

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        temp_board = ""
        for n in range(0, 100):
            if n <= 9 or n >= 90 or n%10 == 0 or (n+1)%10 == 0:
                temp_board += OUTER
            elif n == 44 or n == 55:
                temp_board += WHITE
            elif n == 45 or n == 54:
                temp_board += BLACK
            else:
                temp_board += EMPTY
        return temp_board

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pretty_board = ""
        for i in range(0,10):
            pretty_board += board[i*10:i*10+10] + "\n"
        return pretty_board

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            opponent = WHITE
        else:
            opponent = BLACK
        return opponent

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        count = 0
        while board[square+direction] in PLAYERS.keys() and board[square+direction] == self.opponent(player):
            square += direction
            count += 1
        if count > 0 and board[square+direction] in PLAYERS.keys() and board[square+direction] == player:
            return square+direction
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if move < 11 or move > 99:
            return False
        for dirs in DIRECTIONS:
            if self.find_match(board, player, move, dirs) != None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        new_board = board[:move] + player + board[move+1:]
        for dirs in DIRECTIONS:
            if self.find_match(board, player, move, dirs) != None:
                move_copy = move
                while board[move_copy + dirs] in PLAYERS.keys() and board[move_copy + dirs] == self.opponent(player):
                    new_board = new_board[:move_copy+dirs] + player + new_board[move_copy+dirs+1:]
                    move_copy += dirs
        return new_board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valid_moves = []
        for n in range(11, 99):
            if board[n] == EMPTY and self.is_move_valid(board, player, n):
                valid_moves.append(n)
        return valid_moves

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if self.get_valid_moves(board, player) != []:
            return True
        return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def approx_score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's). I changed corners to 300 from 120"""
        matrix = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 100, -3.03, 0.99, 0.43, 0.43, 0.99, -3.03, 100, 0,
 0, -4.12, -1.81, -0.08, -0.27, -0.27, -0.08, -1.81, -4.12, 0,
 0, 1.33, -0.04, 0.51, 0.07, 0.07, 0.51, -0.04, 1.33, 0,
 0, 0.63, -0.18, -0.04, -0.01, -0.01, -0.04, -0.18, 0.63, 0,
 0, 0.63, -0.18, -0.04, -0.01, -0.01, -0.04, -0.18, 0.63, 0,
 0, 1.33, -0.04, 0.51, 0.07, 0.07, 0.51, -0.04, 1.33, 0,
 0, -4.12, -1.81, -0.08, -0.27, -0.27, -0.08, -1.81, -4.12, 0,
 0, 100, -3.03, 0.99, 0.43, 0.43, 0.99, -3.03, 100, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,]
        player_score = 0
        opponent_score = 0
        player_count = 0
        opponent_count = 0
        for n in range(11, 90):
            if board[n] == player:
                player_score += matrix[n]
                player_count += 1
            elif board[n] == self.opponent(player):
                opponent_score += matrix[n]
                opponent_score += 1
        opponent_moves = len(self.get_valid_moves(board,self.opponent(player)))
        weighting = (player_count+opponent_count)/8
        return player_score - opponent_score - opponent_moves * weighting
    
    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        player_count = 0
        opponent_count = 0
        for n in range(11, 90):
            if board[n] == player:
                player_count += 1
            elif board[n] == self.opponent(player):
                opponent_count += 1
        return player_count - opponent_count


    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.has_any_valid_moves(board, player) == False and self.has_any_valid_moves(board, self.opponent(player)) == False:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        if depth == 0:
            node.score = self.approx_score(node.board)
            #print(str(node.score) + "\n")
            return node
        children = []
        for move in self.get_valid_moves(node.board, player):
            next_board = self.make_move(node.board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, move, node, 1000*self.score(next_board))
                children.append(c)
            else:
                c = Node(next_board, move, node)
                c.score = self.minmax_search(c, next_player, depth-1).score
                children.append(c)
        winner = best[player](children)
        return winner

    def minmax_ab(self, node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK: max, WHITE: min}
        if depth == 0:
            node.score = self.approx_score(node.board)
            #print(str(node.score) + "\n")
            return node
        children = []
        for move in self.get_valid_moves(node.board, player):
            next_board = self.make_move(node.board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = Node(next_board, move, node, 1000*self.score(next_board))
                children.append(c)
            # elif move == 11 or move == 19 or move == 89 or move == 81:
            else:
                c = Node(next_board, move, node)
                c.score = self.minmax_ab(c, next_player, depth-1, alpha, beta).score
                children.append(c)
                if player == BLACK:
                    alpha = max([alpha, c.score])
                    if beta <= alpha:
                        break
                else:
                    beta = min([beta, c.score])
                    if beta <= alpha:
                        break
        winner = best[player](children)
        return winner

    def minmax_strategy(self, board, player, depth = 4, alpha = -math.inf, beta = math.inf):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        root = Node(board, None, None)
        last = self.minmax_ab(root, player, depth, alpha, beta)
        while last.last_node != root:
            last = last.last_node
        return last.last_move

    
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = "".join(board)
        depth = 3
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)
            print(depth)
            depth += 2
    standard_strategy = minmax_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.random_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy #change back to best
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    game =  ParallelPlayer()
    game.play()

    """cool_mans = Strategy()
    print(cool_mans.minmax_strategy(cool_mans.board, BLACK))"""
