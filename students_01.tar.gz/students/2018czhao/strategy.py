import numpy as np
import random
import time
import pickle
size = 10
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
best = {BLACK:max, WHITE:min}
#other
OTHER = {BLACK:WHITE, WHITE:BLACK}
MAX = BLACK
MIN = WHITE

pieces_changed = 0
maxdirection = 0
# with open("weights.pkl", "rb") as f:
#     weights = pickle.load(f)

weights = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -100,  20,   5,   5,  20, -100, 120,   0,
    0, -100, -150,  -5,  -5,  -5,  -5, -150, -100,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -200, -400,  -5,  -5,  -5,  -5, -400, -200,   0,
    0, 120, -200,  20,   5,   5,  20, -200, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

corners = [11, 18, 91, 98]

#DAY 1: 2/14/18
"""I added backpropogation for when I train my AI on hundreds of games to optimize.
Then, I went back and optimized: find_match, is_move_valid, opponent, and 'find of string objects' """

#DAY 2: 2/16/18
"""Work on backpropogation after game over. Also worked on patterns"""



#initial is a 8x8 board with a border around it; 100-length string
def replace_char(board, character, index):
    return board[:index] + character + board[index+1:]

initial = EMPTY*(size**2)
l = [np.arange(0, size**2, size), np.arange(0, size), np.arange(size-1, size**2, size), np.arange((size-1)*size, size**2)]
for arrange in l:
    for index in arrange:
        initial = replace_char(initial, OUTER, index)


class Node:
    def __init__(self, board, score=0, move=None, children=None, parent = None, pieceschanged = 0, maxdirection = 0):
        if children is None:
            children = []
        self.board = board
        self.children = children
        self.move = move
        self.score = score
        self.parent = parent
        self.pieceschanged = pieceschanged
        self.maxdirection = maxdirection

    def __lt__(self, other):
        return self.score < other.score

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        z = initial
        positions = {44:WHITE, 45:BLACK, 54:BLACK, 55:WHITE}
        for x in positions:
            z = replace_char(z, positions[x], x)
        return z

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pretty = board.replace(OUTER, "")
        len = 8
        return "\n".join([pretty[i*len:(i+1)*len] for i in range(len)])

    def find_match(self, board, player, direction, index):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        oppo = OTHER[player]
        line = board[index+direction::direction]
        if line[0] == player or player not in line:
            return None
        before, player, after = line.partition(player)
        boolean = all(character == oppo for character in before)
        if boolean == False:
            return None
        return index+(direction*(len(before)+1))

    def is_move_valid(self, board, player, move):
        for direction in DIRECTIONS:
            if self.find_match(board, player, direction, move) != None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        z = board

        global pieces_changed
        pieces_changed = 0

        counter = 0
        for direction in DIRECTIONS:
            other_side = self.find_match(board, player, direction, move)
            if other_side != None:
                for ind in range(move, other_side, direction):
                    z = replace_char(z, player, ind)
                    pieces_changed += 1
        return z

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valid_array = [index for index,ele in enumerate(board) if ele==EMPTY and self.is_move_valid(board, player, index)]
        return valid_array

    def has_any_valid_moves(self, board, player):
        return (self.get_valid_moves(board, player) != [])

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opponent = OTHER[prev_player]
        return opponent if self.has_any_valid_moves(board, opponent) == True else prev_player if self.has_any_valid_moves(board, prev_player) == True else None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        player_score = board.count(player)
        other_score = board.count(OTHER[player])
        return player_score-other_score

    def is_frontier(self, board, index):
        for direction in DIRECTIONS:
            if board[index+direction] == EMPTY:
                return True
        return False
    # def empty_squares_adjacent(self, board, index):
    #     counter = 0
    #     for direction in DIRECTIONS:
    #         if board[index+direction] == EMPTY:
    #             counter += 1
    #     return counter
    def potential_mobility(self, board, player=BLACK):
        #number of frontier disks - negative
        #number of empty squares adjacent to opponents disks - positive
        #sum of empty squares adjacent to each disk - positive
        frontier = 0
        for i, ele in enumerate(board):
            if ele == OUTER or ele == EMPTY: continue
            if self.is_frontier(board, i): frontier += -1 if ele == player else 1 if ele == OTHER[player] else 0
        return frontier

    def weighted_score(self, node, player=BLACK):
        #subtract or add frontiers (iterate in all directions: does one contain an empty space?)
        #minimize number of opponents moves
        board = node.board
        summing = 0
        for i, char in enumerate(board):
            if char == OUTER or char == EMPTY: continue
            summing += weights[i] if char == player else -1* weights[i]
        """
        Scoring function:
        - more pieces changed = good
        - more frontier pieces = bad
        - greater number of valid moves for opponent = lower score
        """
        return ((2*node.pieceschanged*summing) + (5*self.potential_mobility(board)))/(len(self.get_valid_moves(node.board, OTHER[player]))+0.01)

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return not (self.has_any_valid_moves(board, player) or self.has_any_valid_moves(board, OTHER[player]))

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################


    def minmax_search(self, node, player, depth):
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(node)
            return node
        valid_moves = self.get_valid_moves(board, player)
        for move in valid_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                childnode = Node(next_board, move = move, score=1000*self.score(next_board), parent=node)
                node.children.append(childnode)
            elif next_player is not None:
                childnode = Node(next_board, move = move, parent=node)
                childnode.score = self.minmax_search(childnode, next_player, depth-1).score
                node.children.append(childnode)
        winner = best[player](node.children)
        node.score = winner.score
        return winner
        # if player == MAX:
        #     # return max(minmaxscore(c, get_next_player(player)).score for c in nodechilds)
        #     z = max(nodechilds, key=lambda x: self.minmax_search(x, self.opponent(player), depth-1).score)
        #     return z
        # if player == MIN:
        #     # return min(minmaxscore(c, get_next_player(player)).score for c in nodechilds)
        #     a = min(nodechilds, key=lambda x: self.minmax_search(x, self.opponent(player), depth-1).score)
        #     return a
    def alphabeta_pruning(self, node, player, depth, alpha, beta):
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(node)
            return node
        valid_moves = self.get_valid_moves(board, player)
        for move in valid_moves:
            global pieces_changed
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None or move in corners:
                childnode = Node(next_board, move=move, score=1000 * self.score(next_board), pieceschanged=pieces_changed)
                node.children.append(childnode)
                #self.backpropogate(node, player)
            elif next_player is not None:
                childnode = Node(next_board, move=move, pieceschanged=pieces_changed, maxdirection=maxdirection)
                childnode.score = self.alphabeta_pruning(childnode, next_player, depth - 1, alpha, beta).score
                node.children.append(childnode)
                if player == MAX:
                    alpha = max(alpha, childnode.score)
                elif player == MIN:
                    beta = min(beta, childnode.score)
                if alpha >= beta:
                    break

        winner = best[player](node.children)
        node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=3):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node_best = self.minmax_search(Node(board), player, depth)
        move_best = node_best.move
        print("Min Max", node_best.score)
        return move_best

    def alphabeta_strategy(self, board, player, depth=5, alpha=float('-Inf'), beta=float('Inf')):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node_best = self.alphabeta_pruning(Node(board), player, depth, alpha, beta)
        move_best = node_best.move
        print("Alpha Beta", node_best.score)
        return move_best

    def backpropogate(self, gameover_leaf, player):
        pointer = gameover_leaf
        if self.score(gameover_leaf.board, player=player) > 0:
            increment = -1
        else:
            increment = 1
        while pointer != None:
            print("Pointer", pointer, "Pointer move", pointer.move)
            weights[pointer.move] += increment
            pointer = pointer.parent
            print("Pointer", pointer, "Pointer move", pointer.move)


    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            board = list(board)
            board = ''.join(board)
            best_move.value = self.alphabeta_strategy(board, player, depth=depth)
            # FIX THIS LINE
            depth += 1

    standard_strategy = alphabeta_strategy

class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.minmax_strategy}
        #print(ref.get_pretty_board(board))

        while player is not None:
            t1 = time.time()
            move = strategy[player](board, player)
            t2 = time.time()
            print("Time:", t2-t1)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)
            #print(player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))

# class ParallelPlayer():
#      def __init__(self, time_limit = 5):
#         self.black = Strategy()
#         self.white = Strategy()
#         self.time_limit = time_limit
#      def play(self):
#         ref = Strategy()
#         print("play")
#         board = ref.get_starting_board()
#         player = BLACK
#
#         print("Playing Parallel Game")
#         strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
#         while player is not None:
#             best_shared = Value("i", -99)
#             best_shared.value = -99
#             running = Value("i", 1)
#
#             p = Process(target=strategy(player), args=(board, player, best_shared, running))
#             # start the subprocess
#             t1 = time.time()
#             p.start()
#             # run the subprocess for time_limit
#             p.join(self.time_limit)
#             # warn that we're about to stop and wait
#             running.value = 0
#             time.sleep(0.01)
#             # kill the process
#             p.terminate()
#             time.sleep(0.01)
#             # really REALLY kill the process
#             if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
#             # see the best move it found
#             move = best_shared.value
#             if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
#             if not silent:print(board, ref.get_valid_moves(board, player))
#             # make the move
#             board = ref.make_move(board, player, move)
#             if not silent: print(ref.get_pretty_board(board))
#             player = ref.next_player(board, player)
#
#         print("Final Score %i." % ref.score(board), end=" ")
#         print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()
    # with open("weights.pkl", "wb") as f:
    #     pickle.dump(weights, f)
    #(s.find_match("???????????........??........??........??...o@...??...@o...??........??........??........???????????", BLACK, E, 43))
