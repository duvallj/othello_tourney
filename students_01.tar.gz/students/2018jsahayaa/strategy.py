#Jan 12, 0952 version

import random
import math
import re
from time import time

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
outer = 1111111111100000000110000000011000000001100000000110000000011000000001100000000110000000011111111111

class color:
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    DARKCYAN = '\033[36m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'
    BLACK = DARKCYAN
    WHITE = GREEN


############################################################
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################


class Strategy:
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        s = '12345678'.replace('', "\t")[0: -1] + '\n'
        for r in range(1, 9):
            s += str(r) + '\t'
            for c in range(1, 9):
                if board[r * 10 + c] == BLACK:
                    s += color.BLACK + BLACK + color.END + '\t'
                elif board[r * 10 + c] == WHITE:
                    s += color.WHITE + WHITE + color.END + '\t'
                else:
                    s += color.BOLD + board[r * 10 + c] + color.END + '\t'
            s += '\n'
        return s

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        check_square = square + direction

        if board[check_square] == self.opponent(player):
            check_square = check_square + direction

            while board[check_square] != EMPTY and board[check_square] != OUTER:
                if board[check_square] == player:
                    return True
                check_square = check_square + direction
        return False

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if move == EMPTY:
            for d in DIRECTIONS:
                if self.find_match(board, player, move, d):
                    return True
        raise self.IllegalMoveError(board, player, move)

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        for direction in DIRECTIONS:
            toflip = [move]
            check_square = move + direction

            if board[check_square] == self.opponent(player):
                toflip.append(check_square)
                check_square = check_square + direction

                while board[check_square] != EMPTY and board[check_square] != OUTER:
                    if board[check_square] == player:
                        for tile in toflip:     # flip tiles
                            board = board[:tile] + player + board[tile + 1:]
                        break
                    else:
                        toflip.append(check_square)
                    check_square = check_square + direction
        return board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valid = []
        # for i in [m.start() for m in re.finditer(EMPTY, board)]:
        for i in range(len(board)):
            if board[i] == EMPTY:
                for d in DIRECTIONS:
                    if self.find_match(board, player, i, d):
                        valid.append(i)
                        break
        return valid

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        # for i in [m.start() for m in re.finditer('.', board)]:
        for i in range(len(board)):
            if board[i] == EMPTY:
                for d in DIRECTIONS:
                    if self.find_match(board, player, i, d):
                        return True
        return False

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        return BLACK

    def get_next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        if self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        bscore = 0
        wscore = 0
        for each in board:
            if each == BLACK:
                bscore += 1
            elif each == WHITE:
                wscore += 1
        return bscore-wscore

    def find_self_adjacent(self, board, player, square, direction):
        check_square = square + direction
        if board[check_square] == player:
            return True

    # matrix = [
    #     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    #     0, 300, -50, 40, 35, 35, 40, -50, 300, 0,
    #     0, -50, -50, -15, -15, -15, -15, -50, -50, 0,
    #     0, 40, -15, 15, 0, 0, 15, -5, 40, 0,
    #     0, 35, -15, 0, 0, 0, 0, -5, 35, 0,
    #     0, 35, -15, 0, 0, 0, 0, -5, 35, 0,
    #     0, 40, -15, 15, 0, 0, 15, -5, 40, 0,
    #     0, -50, -50, -5, -5, -5, -5, -30, -50, 0,
    #     0, 300, -50, 40, 35, 35, 40, -50, 300, 0,
    #     0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    # ]
    matrix = [
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0, 150, -20,  25,   5,   5,  25, -20, 150,   0,
        0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
        0,  25,  -5,  15,   3,   3,  15,  -5,  25,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,  25,  -5,  15,   3,   3,  15,  -5,  25,   0,
        0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
        0, 150, -20,  25,   5,   5,  25, -20, 150,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    ]
    corners = [11, 18, 81, 88]
    # cardinal = {N, S, E, W}
    # borders = [ ([12,13,14,15,16,17], E), ([28,38,48,58,68,78], S), ([87,86,85,84,83,82], E), ([71,61,51,41,31,21], S) ]
    def weighted_score(self, board):
        bscore = 0
        wscore = 0
        for each in range(len(board)):
            if each == BLACK:
                bscore += self.matrix[each]
            elif each == WHITE:
                wscore += self.matrix[each]
        return bscore - wscore

    def stability_find_match(self, board, opponent, square, direction):
        check_square = square + direction

        while board[check_square] != EMPTY and board[check_square] != OUTER:
            if board[check_square] == opponent:
                return -1, check_square
            check_square = check_square + direction
        return 1, check_square

    DIR_PAIRS = {(N, S), (NE, SW), (E, W), (SE, NW)}

    def stability_score(self, board, player):
        valid_moves = self.get_valid_moves(board, self.opponent(player))
        scores = [0]*100

        for i in self.border:
            if board[i] == player:
                for d1, d2 in self.DIR_PAIRS:
                    score1, end1 = self.stability_find_match(board, self.opponent(player), i, d1)
                    score2, end2 = self.stability_find_match(board, self.opponent(player), i, d2)
                    if score1+score2 <= 0 and (end1 in valid_moves or end2 in valid_moves):
                        scores[i] = -1
                        break
                if scores[i] != -1:
                    scores[i] = 1
        return sum(scores)

    def stability_score_main(self, board, player):
        valid_moves = self.get_valid_moves(board, player)
        opponent_stability = 0
        for move in valid_moves:
            opponent_stability += self.stability_score(self.make_move(board, player, move), self.opponent(player))

        score1 = self.stability_score(board, player)
        score2 = opponent_stability/len(valid_moves)
        if player == BLACK:
            return (score1-score2)/(score1+score2+1.1)
        else:
            return (score2-score1)/(score1+score2+1.1)

    def mobility_score(self, board, player):
        # return len(self.get_valid_moves(board, player))
        valid_moves = self.get_valid_moves(board, player)
        opponent_valid_moves = 0
        length = set()
        for move in self.get_valid_moves(board, player):
            next_board = self.make_move(board, player, move)
            # score = self.alpha_beta_helper(next_board, self.get_next_player(next_board, player), 1, -math.inf, math.inf)
            # scores_length[move] = (score, len(self.get_valid_moves(next_board, self.opponent(player))))
            length.add(len(self.get_valid_moves(next_board, self.opponent(player))))
        # for move in valid_moves:
        #     opponent_valid_moves += len(self.get_valid_moves(self.make_move(board, player, move), self.opponent(player)))
        score1 = len(valid_moves)
        score2 = max(length)
        if player == BLACK:
            return (score1-score2)/(score1+score2+1.1)
        else:
            return (score2-score1)/(score1+score2+1.1)

    def corner_score(self, board, player):
        score = 0
        for square in self.corners:
            if board[square] == player:
                score += 1
        return score

    def corner_score_main(self, board, player):
        score1 = self.corner_score(board, BLACK)
        score2 = self.corner_score(board, WHITE)
        return (score1-score2)/(score1+score2+1.1)    # +1 to avoid dividing by 0 when neither player has corners

    border = [13,14,15,16,38,48,58,68,86,85,84,83,61,51,41,31]
    def border_score(self, board, player):
        score = 0
        for square in self.border:
            if board[square] == player:
                score += 1
        return score

    def border_score_main(self, board, player):
        score1 = self.border_score(board, BLACK)
        score2 = self.border_score(board, WHITE)
        return (score1-score2)/(score1+score2+1.1)    # +1 to avoid dividing by 0 when neither player has corners

    def dynamic_score(self, board, player):
        # bstability = self.stability_score(board, BLACK)
        # wstability = self.stability_score(board, WHITE)
        # bweight = self.corner_score(board, BLACK)
        # wweight = self.corner_score(board, WHITE)
        # bmobility = self.mobility_score(board, BLACK)
        # wmobility = self.mobility_score(board, WHITE)
        # return 50*(bstability-wstability)/(bstability+wstability+.1) + 100*(bweight-wweight)/(bweight+wweight+.1) + 35*(bmobility-wmobility)/(bmobility+wmobility+.1)+20*random.random()

        # return random.random()

        # mobility = self.mobility_score(board, player)
        stability = self.stability_score_main(board, player)
        corners = self.corner_score_main(board, player)
        borders = self.border_score_main(board, player)
        coin_parity = self.score(board, player)
        random_noise = random.random()
        total_score = 25*corners + 15*borders + 15*stability + 10*coin_parity + 10*random_noise+300

        print(self.get_pretty_board(board))
        print('SCORE', total_score)
        print('stable', stability)
        print('corners', corners)
        print('borders', borders)
        print('coin_parity', coin_parity)

        return total_score

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.get_next_player(board, player) is None:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, board, player, move):
            self.board = board
            self.player = player
            self.move = move

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    best = {BLACK: max, WHITE: min}

    def minmax_search(self, board, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if depth == 0:
            if len(self.get_valid_moves(board, player)) == 0:
                return 1000*self.score(board, player)
            else:
                return self.weighted_score(board, player)
        if len(self.get_valid_moves(board, player)) == 0:
            if self.has_any_valid_moves(board, self.opponent(player)):
                return self.minmax_search(board, self.opponent(player), depth-1)
            return 1000 * self.score(board, player)
        moves = self.get_valid_moves(board, player)
        return self.best[player]([self.minmax_search(self.make_move(board, player, c), self.get_next_player(board, player), depth-1) for c in moves])

    def minmax_strategy(self, board, player, depth=3):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        moves = self.get_valid_moves(board, player)     # add random?
        return self.best[player](moves, key=lambda c: self.minmax_search(self.make_move(board, player, c), self.get_next_player(board, player), depth))

    def alpha_beta_helper(self, board, player, depth, alpha, beta):
        valid_moves = self.get_valid_moves(board, player)
        if depth == 0:
            if len(valid_moves) == 0:
                return 1000*self.score(board)
            else:
                return self.weighted_score(board)+len(self.get_valid_moves(board, BLACK))
        if len(valid_moves) == 0:
            if self.has_any_valid_moves(board, self.opponent(player)):
                return self.alpha_beta_helper(board, self.opponent(player), depth, alpha, beta)
            return 1000*self.score(board)

        for move in valid_moves:
            if alpha < beta:
                next_board = self.make_move(board, player, move)
                score = self.alpha_beta_helper(next_board, self.get_next_player(next_board, player), depth - 1, alpha,
                                               beta)
                if player == BLACK:
                    alpha = max([score, alpha])
                else:
                    beta = min([score, beta])
            else:
                break

        if player == BLACK:
            return alpha
        else:
            return beta

    def alpha_beta_pruning(self, board, player, depth=7, alpha=-math.inf, beta=math.inf):
        if not self.has_any_valid_moves(board, player):
            if self.has_any_valid_moves(board, self.opponent(player)):
                return self.alpha_beta_helper(board, self.opponent(player), depth - 1, alpha, beta)
            return 1000 * self.score(board)
        scores = {}
        valid_moves = self.get_valid_moves(board, player)
        corner_moves = set(valid_moves).intersection(set(self.corners))
        if len(corner_moves) > 0:
            if len(valid_moves) == 1:
                return valid_moves[0]
            valid_moves = list(corner_moves)
        for move in valid_moves:
            next_board = self.make_move(board, player, move)
            score = self.alpha_beta_helper(next_board, self.get_next_player(next_board, player), depth-1, alpha, beta)
            scores[score] = move
            if player == BLACK:
                alpha = max([score, alpha])
            else:
                beta = min([score, beta])

        if player == BLACK:
            return scores[alpha]
        else:
            return scores[beta]

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        # if player == BLACK:
        #     best_move.value = self.random_strategy(board, player)
        #     return

        board = ''.join(board)
        # if player == WHITE:
        #     board.replace(BLACK, '-')
        #     board.replace(WHITE, BLACK)
        #     board.replace('-', WHITE)
        depth = 3
        start = time()
        while True:
            # print(depth)
            if depth > 20:
                return
            best_move.value = self.alpha_beta_pruning(board, player, depth)
            # best_move.value = self.alpha_beta_pruning(board, BLACK, depth)
            print(depth, ', ', time()-start)
            depth += 1
            start = time()

        # time_limit = 5
        # depth = 3
        # tic = time()
        # best_move.value = self.alpha_beta_pruning(board, player, depth)
        # total = time() - tic
        # depth_time = {3: total}
        # while depth_time[depth] < time_limit-total and depth < 15:
        #     depth += 1
        #     depth_time[depth] = 3*depth_time[depth-1]
        # print(depth)
        # best_move.value = self.alpha_beta_pruning(board, player, depth-1)
        # print('depth-1')
        # while True:
        #     # print(depth)
        #     if depth > 20:
        #         return
        #     best_move.value = self.alpha_beta_pruning(board, player, depth)
        #     depth += 1

    standard_strategy = alpha_beta_pruning

'''
class Strategy:
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        s = '12345678'.replace('', "\t")[0: -1] + '\n'
        for r in range(1, 9):
            s += str(r) + '\t'
            for c in range(1, 9):
                if board[r * 10 + c] == BLACK:
                    s += color.BLACK + BLACK + color.END + '\t'
                elif board[r * 10 + c] == WHITE:
                    s += color.WHITE + WHITE + color.END + '\t'
                else:
                    s += color.BOLD + board[r * 10 + c] + color.END + '\t'
            s += '\n'
        return s

    def string_to_bit_board(self, str_board):
        b = 0
        w = 0
        for i in range(11, 89):
            if str_board[i] == BLACK:
                b += 10**i
            elif str_board[i] == WHITE:
                w += 10**i
        return b, w

        # print(board)
        # print('b ', b)
        # print('w ', w)
        # for i in range(100):
        #     if b % 10**(i+1)//10**i == 1:
        #         print(i)
        # for i in range(100):
        #     if w % 10**(i+1)//10**i == 1:
        #         print(i)

    def bit_to_string_board(self, b, w):
        board = '???????????'
        for i in range(11, 89):
            if self.index(b, i):
                board += BLACK
            elif self.index(w, i):
                board += WHITE
            elif self.index(outer, i):
                board += OUTER
            else:
                board += EMPTY

    def index(self, board, i):
        if board % 10 ** (i + 1) // 10 ** i == 1:
            return True
        return False

    def opponent(self, player):
        if player == 0:
            return 1
        return 0

    def find_match(self, b, w, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        if player == 0:
            my_board = b
            opp_board = w
        else:
            my_board = w
            opp_board = b

        check_square = square + direction

        if self.index(opp_board, check_square):
            check_square = check_square + direction

            while self.index(my_board, check_square) or self.index(opp_board, check_square):
                if self.index(my_board, check_square):
                    return True
                check_square = check_square + direction
        return False

    def is_move_valid(self, b, w, player, i):
        """Is this a legal move for the player?"""
        if not self.index(b, i) and not self.index(w, i):     # if EMPTY
            for d in DIRECTIONS:
                if self.find_match(b, w, player, i, d):
                    return True
        raise self.IllegalMoveError(board, player, i)

    def make_move(self, b, w, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        if player == 0:
            my_board = b
            opp_board = w
        else:
            my_board = w
            opp_board = b

        for direction in DIRECTIONS:
            toflip = [move]
            check_square = move + direction

            if self.index(opp_board, check_square):
                toflip.append(check_square)
                check_square = check_square + direction

                while self.index(my_board, check_square) or self.index(opp_board, check_square):
                    if self.index(my_board, check_square):
                        for tile in toflip:     # flip tiles
                            my_board += 10**tile
                            if self.index(opp_board, tile):
                                opp_board -= 10**tile
                        break
                    else:
                        toflip.append(check_square)
                    check_square = check_square + direction
        return b, w

    def get_valid_moves(self, b, w, player):
        """Get a list of all legal moves for player."""
        valid = []
        for i in range(11, 89):
            if not self.index(b, i) and not self.index(w, i) and not self.index(outer, i):     # if EMPTY
                for d in DIRECTIONS:
                    if self.find_match(b, w, player, i, d):
                        valid.append(i)
                        break
        return valid

    def has_any_valid_moves(self, b, w, player):
        """Can player make any moves?"""
        for i in range(11, 89):
            if not self.index(b, i) and not self.index(w, i) and not self.index(outer, i):     # if EMPTY
                for d in DIRECTIONS:
                    if self.find_match(b, w, player, i, d):
                        return True
        return False

    def get_next_player(self, b, w, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(b, w, self.opponent(prev_player)):
            return self.opponent(prev_player)
        if self.has_any_valid_moves(b, w, prev_player):
            return prev_player
        return None

    def game_over(self, b, w, player):
        """Return true if player and opponent have no valid moves"""
        if self.get_next_player(b, w, player) is None:
            return True
        return False

    def score(self, b, w):
        """Compute player's score (number of player's pieces minus opponent's)."""
        b_score = 0
        w_score = 0
        for i in range(11, 89):
            if self.index(b, i):
                b_score += 1
            elif self.index(w, i):
                w_score += 1
        return b_score - w_score

    matrix = [
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0, 150, -20,  25,   5,   5,  25, -20, 150,   0,
        0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
        0,  25,  -5,  15,   3,   3,  15,  -5,  25,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
        0,  25,  -5,  15,   3,   3,  15,  -5,  25,   0,
        0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
        0, 150, -20,  25,   5,   5,  25, -20, 150,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    ]
    corners = [11, 18, 81, 88]

    def weighted_score(self, b, w):
        b_score = 0
        w_score = 0
        for i in range(11, 89):
            if self.index(b, i):
                b_score += self.matrix[i]
            elif self.index(w, i):
                w_score += self.matrix[i]
        return b_score - w_score

    def alpha_beta_helper(self, b, w, player, depth, alpha, beta):
        valid_moves = self.get_valid_moves(b, w, player)
        if depth == 0:
            if len(valid_moves) == 0:
                return 1000 * self.score(b, w)
            else:
                return self.weighted_score(b, w)
        if len(valid_moves) == 0:
            if self.has_any_valid_moves(b, w, self.opponent(player)):
                return self.alpha_beta_helper(b, w, self.opponent(player), depth, alpha, beta)
            return 1000 * self.score(b, w)

        for move in valid_moves:
            if alpha < beta:
                next_b, next_w = self.make_move(b, w, player, move)
                score = self.alpha_beta_helper(next_b, next_w, self.get_next_player(next_b, next_w, player), depth - 1,
                                               alpha, beta)
                if player == BLACK:
                    alpha = max([score, alpha])
                else:
                    beta = min([score, beta])
            else:
                break

        if player == BLACK:
            return alpha
        else:
            return beta

    def alpha_beta_pruning(self, b, w, player, depth=7, alpha=-math.inf, beta=math.inf):
        if not self.has_any_valid_moves(b, w, player):
            if self.has_any_valid_moves(b, w, self.opponent(player)):
                return self.alpha_beta_helper(b, w, self.opponent(player), depth - 1, alpha, beta)
            return 1000 * self.score(b, w)
        scores = {}
        valid_moves = self.get_valid_moves(b, w, player)
        corner_moves = set(valid_moves).intersection(set(self.corners))
        if len(corner_moves) > 0:
            if len(valid_moves) == 1:
                return valid_moves[0]
            valid_moves = list(corner_moves)
        for move in valid_moves:
            next_b, next_w = self.make_move(b, w, player, move)
            score = self.alpha_beta_helper(next_b, next_w, self.get_next_player(next_b, next_w, player), depth - 1,
                                           alpha, beta)
            scores[score] = move
            if player == BLACK:
                alpha = max([score, alpha])
            else:
                beta = min([score, beta])

        if player == BLACK:
            return scores[alpha]
        else:
            return scores[beta]

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        # if player == BLACK:
        #     best_move.value = self.random_strategy(board, player)
        #     return

        board = ''.join(board)
        b, w = self.string_to_bit_board(board)
        if player == '@':
            player = 0
        else:
            player = 1
        depth = 3
        start = time()
        while True:
            # print(depth)
            if depth > 20:
                return
            best_move.value = self.alpha_beta_pruning(b, w, player, depth)
            # best_move.value = self.alpha_beta_pruning(board, BLACK, depth)
            print(depth, ', ', time() - start)
            depth += 1
            start = time()

    standard_strategy = alpha_beta_pruning
'''
# bitboard for empty squares? affects get and has valid moves
# clean up alpha beta code
