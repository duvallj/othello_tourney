#edward tong
#edward tong
class Strategy():
    def best_strategy(self, boardS, player, best_move, still_running):
        depth = 1

        edgeList = []
        for x in range (0,8):
            edgeList.append((0,x))
            edgeList.append((x,0))
            edgeList.append((7,x))
            edgeList.append((x,7))
        cornerList = [(0,0),(7,0),(0,7),(7,7)]
        board = ''.join(boardS)
        board=board.replace('?','')


        if player == "@":
            opponent = "o"
        else:
            opponent = "@"
        maxMove2 = None
        boardNode = Node
        neighborDic = {} #creating list of neighbors for each tile on the board
        for x in range(0,8):
            for y in range(0,8):
                neighborDic.update({(x,y):self.getNeighbors(board,x,y)})
        root = Node([],self.netTokens(board,player),board,None)
        allMoves = []
        tempAllMoves = []
        allMoves.append(root)
        root = Node([],self.netTokens(board,player),board,None)
        allMoves.append(root)

        for node in allMoves:
            if node.getChildren() == []:
                children1 = self.findMoves(node.getBoard(),player,opponent,neighborDic)
                if children1 == []:
                    node.children = []
                else:
                    childrenNodes = []
                    for node1 in children1:
                        tempNode = Node([],self.netTokens(self.moveBoard(node.getBoard(),player,opponent,neighborDic,node1[0],node1[1]),player),self.moveBoard(node.getBoard(),player,opponent,neighborDic,node1[0],node1[1]),node1)
                        tempAllMoves.append(tempNode)
                        childrenNodes.append(tempNode)
                    node.children = childrenNodes
        if player == "@":   
            player = "o"
            opponent = "@"
        else:
            player = "@"
            opponent = "o"
        allMoves = tempAllMoves
        tempAllMoves = []

        
        while still_running:  
            depth = depth+ 1
            listTempTemp2 = []
            
            for ch in root.children:    
                hScoreTemp=((ch.move,self.alphaBeta(ch, int(depth)-1,-999999,999999, False)))
                hScore = hScoreTemp[1][0]
                if hScoreTemp[0] == (0,0) or (0,7) or (7,0) or (7,7):
                    hScore = hScore+99999
                listTempTemp2.append((ch.move,(ch.move,hScore)))
            maxMove2 = listTempTemp2[0]    
            for z in range(0,len(listTempTemp2)):
                if listTempTemp2[z][1][1] > maxMove2[1][1]:
                    maxMove2 = listTempTemp2[z]
            maxMoveTemp = (maxMove2[0])
            maxMoveNum = maxMoveTemp[0] + ((maxMoveTemp[1]+1)  * 10) +1 

            best_move.value = maxMoveNum 

            for node in allMoves:
                if node.getChildren() == []:
                    children1 = self.findMoves(node.getBoard(),player,opponent,neighborDic)
                    if children1 == []:
                        node.children = []
                    else:
                        childrenNodes = []
                        for node1 in children1:
                            tempNode = Node([],self.netTokens(self.moveBoard(node.getBoard(),player,opponent,neighborDic,node1[0],node1[1]),player),self.moveBoard(node.getBoard(),player,opponent,neighborDic,node1[0],node1[1]),node1)
                            tempAllMoves.append(tempNode)
                            childrenNodes.append(tempNode)
                        node.children = childrenNodes
            if player == "@":   
                player = "o"
                opponent = "@"
            else:
                player = "@"
                opponent = "o"
            allMoves = tempAllMoves
            tempAllMoves = []

        

    def netTokens(self,board,player):
        if player == "@":
            opponent = "o"
        else:
            opponent = "@" # fix 3

        playerCount = 0
        opponentCount = 0
        for tile in board:
            if tile == player:
                playerCount = playerCount+1
            if tile == opponent:
                opponentCount = opponentCount +1
        return playerCount-opponentCount

    def convertToIndex(self,x,y): #converts xy coordinate into index for the board string
        return ((y*8)+x)

    def tupleToIndex(self,tupleCoord):
        x = tupleCoord[0]
        y = tupleCoord[1]
        return self.convertToIndex(x,y)

    def findMoves(self,board,player,opponent,neighborDic): #returns list of coords of possible moves for the given player
        listMoves = []
        for x in range (0,8):
            for y in range (0,8):
                if self.isValid(board,player,opponent,neighborDic,x,y):
                    listMoves.append((x,y))
        return listMoves

    def isValid(self,board,player,opponent,neighborDic,x,y): #checks if move at specified tile is valid for specified player
        if board[self.convertToIndex(x,y)] != ".": #makes sure tile is empty
            return False
        else:
            nei = neighborDic[(x,y)]

            counter = 0 #counting how many possible directions that the move is valid in. If 0, there are no valid moves
            for dirc in nei:
                listMoves = nei[dirc]

                if len(listMoves) > 0:
                    listMovesCounter = 0
                    opponentCounter = 0

                    tile = board[self.tupleToIndex(listMoves[0])]
                    while (tile != player):
                        if (listMovesCounter >= len(listMoves)):
                            opponentCounter = -2
                            tile = player
                            listMovesCounter = len(listMoves)+1
                        if tile == opponent:
                            opponentCounter = opponentCounter+1
                        else:
                            opponentCounter = -2
                            tile = player
                            listMovesCounter = len(listMoves)+1
                        listMovesCounter = listMovesCounter+1
                        if listMovesCounter < len(listMoves):
                            tile = board[self.tupleToIndex(listMoves[listMovesCounter])]
                    if opponentCounter >0:
                        counter = counter+1
            if counter == 0:
                return False
            else:
                return True

    def moveBoard(self,board,player,opponent,neighborDic,x,y): #similar to isValid, but actually fills in board instead of just finding possible moves. Only works with valid moves
        board = list(board)
        board[self.convertToIndex(x,y)] = player
        nei = neighborDic[(x,y)]
        counter = 0 #counting how many possible directions that the move is valid in. If 0, there are no valid moves
        for dirc in nei:
                listMoves = nei[dirc]
                if len(listMoves) > 0:
                    listMovesCounter = 0
                    opponentCounter = 0
                    tile = board[self.tupleToIndex(listMoves[0])]
                    while (tile != player):
                        if (listMovesCounter >= len(listMoves)):
                            opponentCounter = -2
                            tile = player
                            listMovesCounter = len(listMoves)+1
                        if tile == opponent:
                            opponentCounter = opponentCounter+1
                        else:
                            opponentCounter = -2
                            tile = player
                            listMovesCounter = len(listMoves)+1
                        listMovesCounter = listMovesCounter+1
                        if listMovesCounter < len(listMoves):
                            tile = board[self.tupleToIndex(listMoves[listMovesCounter])]
                    if opponentCounter >0:
                        for x in range(0,opponentCounter):
                            board[self.tupleToIndex(listMoves[x])] = player
        return ''.join(board)

    def alphaBeta(self,node,depth,alpha,beta,player):
        if depth == 0 or node.getChildren() == [] or len(node.children) == 0:
            return (node.getValue(),node)
        if player:
            toCheck = -999999999
            for x in node.getChildren():
                r1,r2=self.alphaBeta(x,depth-1,alpha,beta,False)  
                toCheck = max(toCheck,r1) 
                alpha = max (alpha,toCheck)
                if beta <= alpha:
                    break
            return (toCheck,node)

        else:
            toCheck = 999999999
            for x in node.getChildren():
                r1,r2=self.alphaBeta(x,depth-1,alpha,beta,True)
                toCheck = min(toCheck, r1) 
                beta = min(beta,toCheck)
                if beta <= alpha:
                    break
            return (toCheck,node)


    def getNeighbors(self,board,x,y): #returns dic of indices to check for each of the eight possible directions:N S E W NE SE NW SW
        neighbors = {} #key is direction name (e.g. N for north) and val is list of coordinates

        #making lists for the eight directions and adding to neighbor dic
        nList = []
        nTemp = y-1
        while nTemp > -1: #north
            nList.append((x,nTemp))
            nTemp = nTemp-1
        neighbors.update({"N":nList})
        
        sList = []
        sTemp = y+1
        while sTemp < 8: #south
            sList.append((x,sTemp))
            sTemp = sTemp+1
        neighbors.update({"S":sList})
        
        eList = []
        eTemp = x+1
        while eTemp < 8: #east
            eList.append((eTemp,y))
            eTemp = eTemp+1
        neighbors.update({"E":eList})
        
        wList = []
        wTemp = x-1
        while wTemp > -1:#west
            wList.append((wTemp,y))
            wTemp = wTemp-1
        neighbors.update({"W":wList})
        
        nwList = []
        nwXTemp = x-1
        nwYTemp = y-1
        while nwXTemp > -1 and nwYTemp >-1:#northwest
            nwList.append((nwXTemp,nwYTemp))
            nwXTemp = nwXTemp-1
            nwYTemp = nwYTemp-1
        neighbors.update({"NW":nwList})
        
        seList = []
        seXTemp = x+1
        seYTemp = y+1
        while seXTemp < 8 and seYTemp < 8:#southeast
            seList.append((seXTemp,seYTemp))
            seXTemp = seXTemp+1
            seYTemp = seYTemp+1
        neighbors.update({"SE":seList})
        
        neList = []
        neXTemp = x+1
        neYTemp = y-1
        while neXTemp <8 and neYTemp >-1:#northeast
            neList.append((neXTemp,neYTemp))
            neXTemp = neXTemp+1
            neYTemp = neYTemp-1
        neighbors.update({"NE":neList})
        
        swList = []
        swXTemp = x-1
        swYTemp = y+1
        while swXTemp > -1 and swYTemp < 8:#southwest
            swList.append((swXTemp,swYTemp))
            swXTemp = swXTemp-1
            swYTemp = swYTemp+1
        neighbors.update({"SW":swList})

        return neighbors #return completed dic for the tile

    


class Node:
    def __init__(self,children,value,board,move):
        self.children = children #list of nodes that are the children
        self.value = value #the
        self.board = board
        self.move = move
    def getChildren(self):
        return self.children
    def getValue(self):
        return self.value
    def getBoard(self):
        return self.board
    def getMove(self):
        return self.move





#if __name__ == "__main__": # fix need to remove
    #importStr='???????????........??........??........??...o@...??...@o...??........??........??........???????????'
    #test=Strategy()
    #print(test.best_strategy(importStr, '@', 10, 0))
    #print(test.best_strategy(importStr, 'o', 10, 0))
