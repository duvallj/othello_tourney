#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 21:03:09 2018
@author: nealbayya
"""

import random
from math import sqrt, log

class Strategy():
    def make_move(self, game, _id_, mv, outflank_set):
        return ''.join([self.id_sym(_id_) if game[idx] == self.id_sym(_id_) or idx in outflank_set else self.id_sym(1-_id_) if game[idx] == self.id_sym(1-_id_) else '.' for idx in range(self.size)])
    
    def end_fwd_pass(self, game, idx, poss_idxs, _id_, _next_): #legal moves helper
        capture = set()
        start_idx  = idx
        while idx!=None:
            if game[idx] == self.id_sym(1-_id_): capture.add(idx)
            elif game[idx] == self.id_sym(_id_) and capture: 
                capture.add(start_idx)
                if start_idx not in poss_idxs.keys(): poss_idxs[start_idx] = set()
                poss_idxs[start_idx] = poss_idxs[start_idx] | capture
                break
            elif (game[idx] == '.' and idx != start_idx) or game[idx] == self.id_sym(_id_): break
            idx = _next_(idx)
    def beg_fwd_pass(self, game, idx, poss_idxs, _id_, _next_): #legal moves helper
        capture = set()
        start_idx  = idx
        while idx!=None:
            if game[idx] not in {'.', self.id_sym(_id_)}: capture.add(idx)
            elif game[idx] == '.' and capture: 
                capture.add(idx)
                if idx not in poss_idxs.keys(): poss_idxs[idx] = set()
                poss_idxs[idx] = poss_idxs[idx] | capture
                break
            elif game[idx] == '.' or (game[idx] == self.id_sym(_id_) and idx != start_idx): break
            idx = _next_(idx)     
    def endgame_lm(self, game, _id_):
        poss_idxs = {}
        for idx, sym in enumerate(game):
            if sym == '.':
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-1 if x%self.n>0 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+1 if x%self.n<self.n-1 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-self.n if x//self.n>0 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+self.n if x//self.n<self.n-1 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-self.n-1 if x%self.n>0 and x//self.n>0 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-self.n+1 if x%self.n<self.n-1 and x//self.n>0 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+self.n-1 if x//self.n<self.n-1 and x%self.n>0 else None)
                self.end_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+self.n+1 if x//self.n<self.n-1 and x%self.n<self.n-1 else None)
        return poss_idxs
    def beginning_lm(self, game, _id_):
        poss_idxs = {}
        for idx, sym in enumerate(game):
            if sym == self.id_sym(_id_):
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-1 if x%self.n>0 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+1 if x%self.n<self.n-1 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-self.n if x//self.n>0 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+self.n if x//self.n<self.n-1 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-self.n-1 if x%self.n>0 and x//self.n>0 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x-self.n+1 if x%self.n<self.n-1 and x//self.n>0 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+self.n-1 if x//self.n<self.n-1 and x%self.n>0 else None)
                self.beg_fwd_pass(game, idx, poss_idxs, _id_, lambda x: x+self.n+1 if x//self.n<self.n-1 and x%self.n<self.n-1 else None)
        return poss_idxs   
                
    def legal_moves(self, game, _id_): #returns a dict, where keys are square choices, and values are flipped squares
        #for endgame legal moves only
        game_id = str(_id_) + game
        if game_id in self.lm_lookup: 
            #profiler['cache moves'] += 1
            return self.lm_lookup[game_id]
        
        lm = {}
        if game.count('.') < game.count(self.id_sym(_id_)): lm = self.endgame_lm(game, _id_)
        else: lm = self.beginning_lm(game, _id_)
    
        #profiler['compute moves'] += 1
        self.lm_lookup[game_id] = lm
        return lm
    
    def shallow_eval(self, game, _id_): 
        coin_parity = num_tokens = comp_stability_val = adv_stability_val = comp_corners = adv_corners = 0
        for idx, token in enumerate(game):
            if token == '.': continue
            if idx in self.corners_lookup and token == self.id_sym(self.comp_id): comp_corners += 1
            elif idx in self.corners_lookup and token == self.id_sym(1-self.comp_id): adv_corners += 1
            if token == self.id_sym(self.comp_id): 
                coin_parity += 1
                comp_stability_val += self.stability_lookup[idx]
                num_tokens += 1
            elif token == self.id_sym(1-self.comp_id):
                coin_parity -= 1
                adv_stability_val += self.stability_lookup[idx]
                num_tokens += 1
        comp_lm, adv_lm = len(self.legal_moves(game, self.comp_id)), len(self.legal_moves(game, 1-self.comp_id))
        mobility_h = 0 if comp_lm+adv_lm==0 else 100*(comp_lm-adv_lm)/(comp_lm+adv_lm)
        coin_parity_h = 100 * (coin_parity / num_tokens) 
        stability_h = 0 if comp_stability_val + adv_stability_val == 0 else 100*(comp_stability_val - adv_stability_val)/(comp_stability_val + adv_stability_val)
        corners_h = 0 if comp_corners + adv_corners == 0 else 100*(comp_corners - adv_corners)/(comp_corners + adv_corners)
        tr = (num_tokens/self.size)
        ret_h = 1.5*(1-tr)*mobility_h + \
            1.5*tr*coin_parity_h + 1.5*stability_h + 10*corners_h
        return ret_h if _id_ == self.comp_id else -ret_h
    
    def order_moves(self, game, _id_, lm, cs = set(), ret_heuristics = False):  
        if not cs: cs = {*lm.keys()}
        mv_subgm, move_val = {}, {}
        
        corners_play = cs&self.corners_lookup
        if corners_play: move_val = {corner: 10*self.inf for corner in corners_play}
        
        for mv, outflank in lm.items():
            if mv not in cs or mv in move_val: continue
            sub_game = self.make_move(game, _id_, mv, lm[mv])
            if (outflank & self.x_lookup):
                move_val[mv] = -10*self.inf
            elif mv%self.n in {0,self.n-1}:
                count_down = len([1 for idx in range(mv,self.size,self.n) if sub_game[idx] == self.id_sym(_id_)])
                count_up = len([1 for idx in range(mv,-1,-self.n) if sub_game[idx] == self.id_sym(_id_)])
                if count_down == len(range(mv,self.size,self.n)) or count_up == len(range(mv,-1,-self.n)): move_val[mv] = 5*self.inf
                else: move_val[mv] = self.shallow_eval(sub_game, _id_)
            elif mv//self.n in {0,self.n-1}:
                count_right = len([1 for idx in range(mv,self.n*(1+(mv//self.n)),1) if sub_game[idx] == self.id_sym(_id_)])
                count_left = len([1 for idx in range(mv,mv-(mv%self.n)-1,-1) if sub_game[idx] == self.id_sym(_id_) ])
                if count_right == len(range(mv,self.n*(1+(mv//self.n)),1)) or count_left == len(range(mv,mv-(mv%self.n)-1,-1)): move_val[mv] = 5*self.inf
                else: move_val[mv] = self.shallow_eval(sub_game, _id_)
            else: move_val[mv] = self.shallow_eval(sub_game, _id_)
            mv_subgm[mv]  = sub_game
        if ret_heuristics: return move_val
        return sorted(cs, key = move_val.get, reverse = True)
    
    def board_eval(self, board, _id_): #negamax board evaluator
        diff = board.count(self.id_sym(_id_)) - board.count(self.id_sym(1-_id_))
        return 1 if diff > 0 else 0 if diff == 0 else -1
    
    def ucb1(self, game, _id_, lm, visits, wins, iterations):
        children = {mv: self.make_move(game, _id_, mv, outf) for mv, outf in lm.items()}
        ucb_scores = {ch: wins[ch]/visits[ch] + sqrt( 2 * log(iterations) / visits[ch] ) for mv, ch in children.items()}
        return max(ucb_scores.keys(), key = ucb_scores.get)
    
    def monte_carlo(self, game, _id_, lm_root, iterations, best_move):
        init_id = _id_
        unseen, visits, wins, parent = {}, {}, {}, {}
        unseen[game] = {*lm_root.keys()}
        parent[game] = None
        for i in range(iterations):
            game_iter = game
            lm = lm_root
            _id_ = init_id
            level = 0
            if i % 10 == 0 and i > 0 and not unseen[game_iter]: 
                children_pref = {mv: visits[self.make_move(game, init_id, mv, outflank)] for mv, outflank in lm_root.items()}
                best_move.value = self.convert( max(children_pref.keys(), key = children_pref.get) )
            #Apply UCB1 -> seen all children
            while not unseen[game_iter] and lm:
                ch = self.ucb1(game_iter, _id_, lm, visits, wins, i)
                parent[ch] = game_iter
                game_iter = ch
                _id_ = 1-_id_
                lm = self.legal_moves(game_iter, _id_)
                if game_iter not in unseen.keys(): unseen[game_iter] = {*lm.keys()}
                level += 1
            #Exploration
            if unseen[game]:
                mv = self.order_moves(game_iter, _id_, lm, unseen[game_iter])[0] if level < self.Nd else random.choice([*unseen[game]])
                ch = self.make_move(game, _id_, mv, lm[mv])
                #print(ch)
                parent[ch] = game_iter
                game_iter = ch
                unseen[game].remove(mv) 
                _id_ = 1-_id_
                lm = self.legal_moves(game_iter, _id_)
                if game_iter not in unseen.keys(): unseen[game_iter] = {*lm.keys()}
                level += 1
            #Percolate down randomly if you are exploring
            while lm:
                #play random move until you reach terminating state
                mv = self.order_moves(game_iter, _id_, lm, unseen[game_iter])[0] if level < self.Nd else random.choice([*unseen[game_iter]])
                ch = self.make_move(game_iter, _id_, mv, lm[mv])
                parent[ch] = game_iter
                game_iter = ch
                _id_ = 1-_id_
                lm = self.legal_moves(game_iter, _id_)
                if game_iter not in unseen.keys(): unseen[game_iter] = {*lm.keys()}
                level += 1
            #Backpropogation
            res = self.board_eval(game_iter, 1-_id_)
            while game_iter:
                if game_iter not in visits.keys(): visits[game_iter] = 0
                if game_iter not in wins.keys(): wins[game_iter] = 0
                visits[game_iter] += 1
                wins[game_iter] += res
                game_iter = parent[game_iter]
                res *= -1
        children_pref = {mv: visits[self.make_move(game, init_id, mv, outflank)] for mv, outflank in lm_root.items()}
        return max(children_pref.keys(), key = children_pref.get)
    
    def negamax_terminal (self, game, _id_, improvable, hardBound):
        lm = self.legal_moves(game, _id_)
        if not lm:
            lm = self.legal_moves(game, 1-_id_)
            if not lm: return [self.board_eval(game, _id_), -3] #-3 is game over
            nm = self.negamax_terminal(game, 1-_id_, -hardBound, -improvable) + [-1]
            return [-nm[0]] + nm[1:]
        
        newHB = -improvable
        ord_moves = self.order_moves(game, _id_, lm)
        bm = ord_moves[0]
        nm_best = self.negamax_terminal(self.make_move(game, _id_, bm, lm[bm]), 1-_id_, -hardBound, newHB) + [bm]
        best = nm_best
        if nm_best[0] < newHB:
            newHB = nm_best[0]
            if -newHB >= hardBound: return [-best[0]]+ best[1:]
        
        for mv in ord_moves[1:]:
            nm = self.negamax_terminal(self.make_move(game, _id_, mv, lm[mv]), 1-_id_, newHB-1, newHB) + [mv]
            if -hardBound < nm[0] < newHB:
                nm = self.negamax_terminal(self.make_move(game, _id_, mv, lm[mv]), 1-_id_, -hardBound, newHB) + [mv]
            if nm[0] < newHB:
                best = nm
                newHB = nm[0]
                if -newHB >= hardBound: return [-best[0]] + best[1:]
        return [-best[0]]+ best[1:]
    
    def best_strategy(self, board, player, best_move, still_running):
        self.playerToToken = {'@': 'X', 'O': 'O'}
        board = ((''.join(board)).replace('?','')).replace('@', 'X').upper()
        self.token = self.playerToToken[player.upper()]
        
        self.comp_id = 1 if self.token == 'X' else 0
        self.size = len(board)
        self.n = int(0.5 + self.size**0.5)
        self.id_sym = lambda x: 'X' if x == 1 else 'O'
        self.inf = 10000000
            
        self.stability_lookup = [4, -3, 2, 2, 2, 2, -3, 4,
                           -3, -4, -1, -1, -1, -1, -4, -3,
                            2, -1, 1, 0, 0, 1, -1, 2,
                            2, -1, 0, 1, 1, 0, -1, 2,
                            2, -1, 0, 1, 1, 0, -1, 2,
                            2, -1, 1, 0, 0, 1, -1, 2,
                           -3, -4, -1, -1, -1, -1, -4, -3,
                            4, -3, 2, 2, 2, 2, -3, 4]  
            
        self.corners_lookup = {0,self.n-1,self.size-1,self.size-self.n}
        self.x_lookup = {self.n+1, 2*self.n-2, self.size-self.n-2, self.size-1-2*self.n+2}
        self.Nd = 5
        self.lm_lookup = {}
        
        self.convert = lambda x: 11+(x//8)*10 + (x%8)
        
        lm = self.legal_moves(board, self.comp_id)
        o_m = self.order_moves(board, self.comp_id, lm, ret_heuristics = True)
        bm = max(o_m.keys(), key = o_m.get)
        best_move.value = self.convert(bm)
        
        if o_m[bm] < self.inf and len(lm) > 1:
            if board.count('.') <= 13: best_move.value = self.convert(self.negamax_terminal(board, self.comp_id, -self.inf, self.inf)[-1])
            else:
                pruned_moves = {mv: lm[mv] for mv in lm if o_m[mv] >-self.inf}
                if len(pruned_moves) > 1: self.monte_carlo(board, self.comp_id, pruned_moves, self.inf, best_move)
                else: self.monte_carlo(board, self.comp_id, lm, self.inf, best_move)
    


