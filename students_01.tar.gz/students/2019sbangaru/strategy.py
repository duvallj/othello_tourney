import sys
import time 
class Strategy(): 
	def best_strategy(self, board, player, best_move, still_running): 
		rows=[
			{0, 1, 2, 3, 4, 5, 6, 7}, 
			{8, 9, 10, 11, 12, 13, 14, 15}, 
			{16, 17, 18, 19, 20, 21, 22, 23}, 
			{24, 25, 26, 27, 28, 29, 30, 31}, 
			{32, 33, 34, 35, 36, 37, 38, 39}, 
			{40, 41, 42, 43, 44, 45, 46, 47}, 
			{48, 49, 50, 51, 52, 53, 54, 55}, 
			{56, 57, 58, 59, 60, 61, 62, 63},  		
		]
		
		cols=[
			{0, 8, 16, 24, 32, 40, 48, 56}, 
			{1, 9, 17, 25, 33, 41, 49, 57}, 
			{2, 10, 18, 26, 34, 42, 50, 58}, 
			{3, 11, 19, 27, 35, 43, 51, 59}, 
			{4, 12, 20, 28, 36, 44, 52, 60}, 
			{5, 13, 21, 29, 37, 45, 53, 61}, 
			{6, 14, 22, 30, 38, 46, 54, 62}, 
			{7, 15, 23, 31, 39, 47, 55, 63},  		
		]
		
		diagonals_1=[
			{0}, 
			{8, 1}, 
			{16, 9, 2}, 
			{24, 17, 10, 3}, 
			{32, 25, 18, 11, 4}, 
			{40, 33, 26, 19, 12, 5}, 
			{48, 41, 34, 27, 20, 13, 6}, 
			{56, 49, 42, 35, 28, 21, 14, 7}, 
			{57, 50, 43, 36, 29, 22, 15}, 
			{58, 51, 44, 37, 30, 23}, 
			{59, 52, 45, 38, 31}, 
			{60, 53, 46, 39}, 
			{61, 54, 47}, 
			{62, 58}, 
			{63}, 		
		]
		
		diagonals_2=[
			{7}, 
			{6, 15}, 
			{5, 14, 23}, 
			{4, 13, 22, 31}, 
			{3, 12, 21, 30, 39}, 
			{2, 11, 20, 29, 38, 47}, 
			{1, 10, 19, 28, 37, 46, 55}, 
			{0, 9, 18, 27, 36, 45, 54, 63}, 
			{8, 17, 26, 35, 44, 53, 62}, 
			{16, 25, 34, 43, 52, 61}, 
			{24, 33, 42, 51, 60}, 
			{32, 41, 50, 59}, 
			{40, 49, 58}, 
			{48, 57}, 
			{56}, 		
		]
		lookups=[rows, cols, diagonals_1, diagonals_2]
		
		board=''.join(board).upper().replace("?", "").replace("@", "X")
		player="X" if player=="@" else "O"
		s=legalMoves(board, player, lookups)
		
		temp=getMove(board, player, s)#s.pop()
		tempconvt=11+(temp//8)*10+(temp%8)
		best_move.value=tempconvt
		
		if(board.count(".")<=14):
			nm=negamaxTerminal(board, player, -65, 65, lookups)
			for x in nm: 
				if x in s: 
					temp=x 
			
			tempconvt=11+(temp//8)*10+(temp%8)
			best_move.value=tempconvt
		#print (tempconvt)
def negamaxTerminal(board, token, improvable, hardBound, lookups): 
	lm=legalMoves(board, token, lookups) ##
	if not lm: 
		lm=legalMoves(board, switch(token), lookups) ##
		if not lm: #game over
			return [eval(board, token, lookups), -3]
		nm=negamaxTerminal(board, switch(token), -hardBound, -improvable, lookups)+[-1]
		return [-nm[0]]+nm[1:] #hhhhhhh 
	else: 	########
		best=[] #to return 
		newHB=-improvable
	
		for mv in lm: 
			nm=negamaxTerminal(makeMove(board, token, mv, lookups), switch(token), -hardBound, newHB, lookups)+[mv]
			if not best or nm[0]<newHB: 
				best=nm 
				if nm[0]<newHB: 
					newHB=nm[0] #######
					if -newHB>hardBound: 
						return [-best[0]]+best[1:]
		return [-best[0]]+best[1:]
def eval(board, token, lookups): 
	return board.count(token)-board.count(switch(token))
def getMove(board, player, s): 
	lm=list(s)[::]
	temp=greedyCorners(lm)
	if temp>-1: return temp #because 0 would mean false
	temp2=safeEdges(board, player, lm)
	if temp2>-1: return temp2
	#if not temp and not temp2: 
	#	return avoidEdges(list) 
	return lm.pop()
def greedyCorners(lm): 
	corners=[0, 7, 56, 63] 
	for x in lm: 
		if x in corners: 
			return x 
	return -1	
def safeEdges(board, player, lm): 
	edge1=[0, 1, 2, 3, 4, 5, 6, 7]; edge2=[56, 57, 58, 59, 60, 61, 62, 63]; edge3=[0, 8, 16, 24, 32, 40, 48, 56]; edge4=[7, 15, 23, 31, 39, 47, 55, 63]
	if board[0]==player: 
		for x in edge1: 
			if x in lm and legalHelper(board, x, 0, edge1, player) and cxCheck(board, player, x): 
				return x 
		for x in edge3: 
			if x in lm and legalHelper(board, x, 0, edge3, player) and cxCheck(board, player, x):	
				return x
	if board[7]==player: 
		for x in edge1: 
			if x in lm and legalHelper(board, x, 7, edge1, player) and cxCheck(board, player, x): 
				return x 
		for x in edge4: 
			if x in lm and legalHelper(board, x, 7, edge4, player) and cxCheck(board, player, x):	
				return x
	if board[56]==player: 
		for x in edge2: 
			if x in lm and legalHelper(board, x, 56, edge2, player) and cxCheck(board, player, x): 
				return x 
		for x in edge3: 
			if x in lm and legalHelper(board, x, 56, edge3, player) and cxCheck(board, player, x):	
				return x
	if board[63]==player: 
		for x in edge2: 
			if x in lm and legalHelper(board, x, 63, edge2, player) and cxCheck(board, player, x): 
				return x 
		for x in edge4: 
			if x in lm and legalHelper(board, x, 63, edge4, player) and cxCheck(board, player, x):	
				return x
	return -1
def cxCheck(board, player, move): 
	zero=[1, 8, 9]
	if move in zero: 
		if board[0]!=player: 
			return False 
	seven=[6, 14, 15]
	if move in seven: 
		if board[7]!=player: 
			return False
	s_56=[48, 49, 57]
	if move in s_56: 
		if board[56]!=player: 
			return False 
	s_63=[62, 58, 54]
	if move in s_63: 
		if board[63]!=player: 
			return False 
	return True 
def avoidEdges(lm):
	lm_temp=lm[::]
	edge1=[0, 1, 2, 3, 4, 5, 6, 7]; edge2=[56, 57, 58, 59, 60, 61, 62, 63]; edge3=[0, 8, 16, 24, 32, 40, 48, 56]; edge4=[7, 15, 23, 31, 39, 47, 55, 63]
	for x in set(lm): 
		if (x in edge1) or (x in edge2) or (x in edge3) or (x in edge4): 
			return x 
	return lm_temp.pop()

def legalMoves(board, player, lookups): 
	rows, cols, diagonals_1, diagonals_2=lookups[0], lookups[1], lookups[2], lookups[3]
	candidates={x for x in range(64) if board[x]=="."}
	filled={x for x in range(64) if board[x]==player}
	
	legal=set() 
	#plan: for each empty position, if its in the same row/column/etc. as another filled pos, then check the spaces between them
	
	for pos in candidates:
		bool=False 
		for index in filled: #for each empty pos, go through 
			if not bool: 
				for s in rows: 
					if (not bool) and (pos in s) and (index in s) and legalHelper(board, pos, index, s, player): 
						legal.add(pos)
						bool=True
						break
				for s in cols: 
					if not bool and pos in s and index in s and legalHelper(board, pos, index, s, player): 
						legal.add(pos)
						bool=True
						break
				for s in diagonals_1: 
					if not bool and pos in s and index in s and legalHelper(board, pos, index, s, player): 
						legal.add(pos)
						bool=True
						break
				for s in diagonals_2: 
					if not bool and pos in s and index in s and legalHelper(board, pos, index, s, player): 
						legal.add(pos)
						bool=True
						break
				if bool: break 
			if bool: break 
		bool=False
				
	return legal
def legalHelper(board, pos, index, s, player): #pos and index are the "brackets" 
	oppt=switch(player) 
	count=0 
	
	s1=range(pos+1, index)
	s2=range(index+1, pos)
	
	for i in s: 
		if i in s1 or i in s2: 
			if board[i]!=oppt: return False 
			count+=1 
	if count==0: #it cannot go somewhere if there is nothing in between 
		return False
	return True 
def makeMove(board, player, pos, lookups): 
	rows, cols, diagonals_1, diagonals_2=lookups[0], lookups[1], lookups[2], lookups[3]
	backupboard=board[:]
	#you can end faster if it's surrounded by empty or by its own player colors
	#also only check s if index is in s
	board=replace(board, pos, player)
	
	for index in range(64): 
		if backupboard[index]==player: 
			for s in rows: 
				if index in s and pos in s: 
					board=move_helper(board, s, player, pos, index)
			for s in cols: 
				if index in s and pos in s: 
					board=move_helper(board, s, player, pos, index)
			for s in diagonals_1: 
				if index in s and pos in s: 
					board=move_helper(board, s, player, pos, index)
			for s in diagonals_2: 
				if index in s and pos in s: 
					board=move_helper(board, s, player, pos, index)
	return board
def move_helper(board, s, player, pos, index): 
	board_initial=board[::]
	s1=range(pos+1, index) #why plus 1
	s2=range(index+1, pos)
	for i in s: 
		if i in s1 or i in s2: 
			if board_initial[i]==player or board_initial[i]==".": #check the boundaries 
				return board_initial
			board=replace(board, i, player)
			#print (" another step below ")
			#display(board)
	return board 
def display(b): 
	index=0
	for i in range(8): 
		print (b[i*8:i*8+8])
def switch(currentPlayer): #gives X if O, or give O if X 
	return (currentPlayer=='X' and 'O') or 'X' #this method works 
def replace(board, index, player): #simple helper method replacing player at index in string board 
	board=board[0:index]+player+board[index+1:]
	return board

def main(): 
	'''processing input''' 
	board=sys.argv[1].upper() #'XXXXXXXXXXXXOXXXXXXOXOXXXXOXOOOXXXOOOO.XXXOO.O.XXXO..O..X.......'.upper() #'...........................OX......XO...........................' #sys.argv[1]
	player=sys.argv[2].upper() #'X'.upper() #sys.argv[1]
	
	#sys.argv[1].upper()
	#sys.argv[2].upper()
	
	'''creating lookups''' 
	rows=[
			{0, 1, 2, 3, 4, 5, 6, 7}, 
			{8, 9, 10, 11, 12, 13, 14, 15}, 
			{16, 17, 18, 19, 20, 21, 22, 23}, 
			{24, 25, 26, 27, 28, 29, 30, 31}, 
			{32, 33, 34, 35, 36, 37, 38, 39}, 
			{40, 41, 42, 43, 44, 45, 46, 47}, 
			{48, 49, 50, 51, 52, 53, 54, 55}, 
			{56, 57, 58, 59, 60, 61, 62, 63},  		
	]
		
	cols=[
		{0, 8, 16, 24, 32, 40, 48, 56}, 
		{1, 9, 17, 25, 33, 41, 49, 57}, 
		{2, 10, 18, 26, 34, 42, 50, 58}, 
		{3, 11, 19, 27, 35, 43, 51, 59}, 
		{4, 12, 20, 28, 36, 44, 52, 60}, 
		{5, 13, 21, 29, 37, 45, 53, 61}, 
		{6, 14, 22, 30, 38, 46, 54, 62}, 
		{7, 15, 23, 31, 39, 47, 55, 63},  		
	]
		
	diagonals_1=[
		{0}, 
		{8, 1}, 
		{16, 9, 2}, 
		{24, 17, 10, 3}, 
		{32, 25, 18, 11, 4}, 
		{40, 33, 26, 19, 12, 5}, 
		{48, 41, 34, 27, 20, 13, 6}, 
		{56, 49, 42, 35, 28, 21, 14, 7}, 
		{57, 50, 43, 36, 29, 22, 15}, 
		{58, 51, 44, 37, 30, 23}, 
		{59, 52, 45, 38, 31}, 
		{60, 53, 46, 39}, 
		{61, 54, 47}, 
		{62, 58}, 
		{63}, 		
	]
		
	diagonals_2=[
		{7}, 
		{6, 15}, 
		{5, 14, 23}, 
		{4, 13, 22, 31}, 
		{3, 12, 21, 30, 39}, 
		{2, 11, 20, 29, 38, 47}, 
		{1, 10, 19, 28, 37, 46, 55}, 
		{0, 9, 18, 27, 36, 45, 54, 63}, 
		{8, 17, 26, 35, 44, 53, 62}, 
		{16, 25, 34, 43, 52, 61}, 
		{24, 33, 42, 51, 60}, 
		{32, 41, 50, 59}, 
		{40, 49, 58}, 
		{48, 57}, 
		{56}, 		
	]
	lookups=[rows, cols, diagonals_1, diagonals_2]
	
	
	start=time.clock()
	#PRINTING 2D BOARD
	display(board)
	
	#PRINTING LEGALMOVES
	s=legalMoves(board, player, lookups)
	print ("Legal moves:  "+str(list(s)))
	
	#PRINTING HEURISTIC MOVE
	print ("Heuristic move: "+str(getMove(board, player, s)))
	#print (str(getMove(board, player, s)))
	
	#PRINTING NEGAMAX	
	if(board.count(".")<14):
		#start=time.clock()
		nm=negamaxTerminal(board, player, -65, 65, lookups)
		#lst=list(s)[::]
		
		#print ("Negamax returns: "+str(nm))
		print ("Negamax score "+str(nm[0])+" and move from "+str(nm[-1]))
		#print (str(time.clock()-start))
		#candidateMove=nm[-1] 
		#if candidateMove in s: 
		#	print (candidateMove)
	
	#print ("Time "+str(time.clock()-start))
	
if __name__=="__main__": 
	main() 