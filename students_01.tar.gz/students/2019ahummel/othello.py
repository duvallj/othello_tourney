#!/usr/bin/python3
import random
import math

# Othello Shell
# P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
MAX = BLACK
MIN = WHITE
NODES = 0


class Node:
    def __init__(self, state, player, move):  # N is width of each row
        global NODES
        NODES += 1
        self.state = state
        self.player = player
        self.move = move
        self.score = 0

    def __lt__(self, other):
        if self.score == other.score:
            # return sum([c.score for c in self.children]) < sum(
            #    [c.score for c in other.children])
            return self.score + random.random() < other.score + random.random()
        return self.score < other.score

    def __eq__(self, other):
        if self is None or other is None:
            return False
        return self.state == other.state


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        return

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [EMPTY * 10] * 10
        board[0] = OUTER * 10
        board[9] = OUTER * 10
        for i in range(1, 9):
            board[i] = OUTER + board[i][1:9] + OUTER
        board[4] = board[4][:4] + BLACK + WHITE + board[4][6:]
        board[5] = board[5][:4] + WHITE + BLACK + board[5][6:]
        out = ''.join(board)
        return out

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        rows = [board[i:i + 10] for i in range(0, 100, 10)]
        return '\n'.join(rows)

    def opponent(self, player):
        """Get player's opponent."""
        return BLACK if player == WHITE else WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        if board[square] != OUTER and board[square +
                                            direction] == self.opponent(player):
            i = square + direction
            while board[i] == self.opponent(player):
                i += direction
            if board[i] == EMPTY:
                return i
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if move is None or board[move] != EMPTY:
            return False
        valid = True
        seen_op = False
        # print(move)
        for d in DIRECTIONS:
            i = move
            #match = self.find_match(board, player, move, d)
            #if match is not None:
            #    return True
        #return False
            while board[i] != OUTER and board[i] != player:
                i += d
                # print(i)
                if board[i] == EMPTY:
                    break
                elif board[i] == self.opponent(player):
                    seen_op = True
            if board[i] == player and not seen_op:
                valid = False
            else:
                return valid
            

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        try:
            if self.is_move_valid(board, player, move):
                new_board = list(board)
                for d in DIRECTIONS:
                    i = move
                    while board[i] != OUTER:
                        i += d
                        if board[i] == self.opponent(player):
                            new_board[i] = player
                return ''.join(new_board)
            else:
                raise self.IllegalMoveError(player, move, board)
        except self.IllegalMoveError as e:
            print(e)
            return board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves = set()
        other = set()
        for i in range(100):
            if board[i] == player:
                for d in DIRECTIONS:
                    match = self.find_match(board, player, i, d)
                    if match is not None:
                        moves.add(match)

                    if self.is_move_valid(board, player, match):
                        other.add(match)
        return list(moves)

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player)) != 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        pre = self.has_any_valid_moves(board, prev_player)
        opp = self.has_any_valid_moves(board, self.opponent(prev_player))
        if not opp and not pre:
            return None
        if not opp:
            return prev_player
        return self.opponent(prev_player)

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        return board.count(player) - board.count(self.opponent(player))

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return self.next_player(board, player) is None

    # Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (
                PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if depth == 0 or self.game_over(node.state, node.player):
            node.score = self.score(node.state, node.player)
            return node

        moves = self.get_valid_moves(node.state, node.player)
        corners = set([11, 18, 91, 98])
        corner_moves = set(moves).intersection(corners)
        if len(corner_moves) > 0:
            node.move = random.sample(corner_moves)
            return node

        children = []
        for m in moves:
            new_board = self.make_move(node.state, node.player, m)
            next_player = self.next_player(new_board, node.player)
            new_child = Node(new_board, next_player, m)
            if next_player is None:
                new_child.score = 1000 * \
                    new_child.score(new_board, next_player)
            else:
                new_child.score = self.minmax_search(
                    new_child, depth - 1).score

            children.append(new_child)
        
        if node.player == MAX:
            max_child = max(children)
            node.score = max_child.score
            node.move = max_child.move
        else:
            min_child = min(children)
            node.score = min_child.score
            node.move = min_child.move
        return node

    def minmax_strategy(self, board, player, depth):
        node = Node(board, player, None)
        best = self.minmax_search(node, depth)
        return best.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        # THIS IS the public function you must implement
        # Run your best search in a loop and update best_move.value
        depth = 6
        while(True):
            # doing random in a loop is pointless but it's just an example
            best_move.value = self.minmax_strategy(board, player, depth)
            depth += 1

    standard_strategy = best_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os
import signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        return

    def play(self):
        # create 2 opponent objects and one referee to play the game
        # these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {
            BLACK: black.standard_strategy,
            WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        def strategy(
            who): return self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(
                target=strategy(player),
                args=(
                    board,
                    player,
                    best_shared,
                    running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive():
                os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent:
                print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:
                print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent:
                print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"

        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    game = StandardPlayer()
    game.play()
