#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 13:24:27 2018

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
'''Created on Tue Jan 23 10:07:00 2018
@author: varun
Lab: Othello Minimax
'''


import sys
import random

BLACK = "@"
WHITE = "o"

corners = [0, 7, 56, 63]    #these are the corners
xSquares = {0: {1, 8, 9}, 7: {6, 14, 15}, 56: {48, 49, 57}, 63:{54, 55, 62}} #these are spots next to corners
aSquares = [2, 5, 16, 23, 40, 47, 58, 61] #these are squares that help you get to corners
direction = [-8, 8, -1, 1, -9, -7, 9, 7] #direction is used when flipping items
d2rc = {8:(1, 0), -8:(-1, 0), 1:(0, 1), -1:(0, -1), 9:(1, 1), 7:(1, -1), -9:(-1, -1), -7:(-1, 1)}
border = [0, 1, 2, 3, 4, 5, 6, 7, 8, 16, 24, 32, 40, 48, 56, 57, 58, 59, 60, 61, 62, 63, 55, 47, 39, 31, 23, 15]
switch = {"X":"O","O":"X","@":"o","o":"@"}
rightSide = {7,15,23,31,39,47,55,63}
leftSide = {0,8,16,24,32,40,48,56}
movement = {(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, -1), (-1, 1)}

"Establish whether or not the current position is allowed"
def isValid(r, c):
    return 0 <= r < 8 and 0 <= c < 8

#"Establish whether or not the current position is allowed"
#def isValid(index):
#    return 0 <= index < 64

def legalMoves(board, token):   #all moves for board
    lm = set()
    for ind in range(len(board)):
        if board[ind] == token:
            lm = lm.union(*[moveid(board, token, ind, d) for d in direction])
    if -1 in lm:
        lm.remove(-1)
    return lm

#gets row and column
def gRC(i):
    return divmod(i, 8)

#convert from row, column format to int format
def mti(row, col):
    return (row * 8) + col

def change(row, moveR, col, moveC):
    return (abs(row-moveR) > 1 or abs(col-moveC) > 1)

#find a move in a given direction
def searchD(board, row, col, crow, ccol, token):
    opp = opposite(token)
    moveR = row + crow #original row
    moveC = col + ccol #original col
    #while your moving properly
    while isValid(moveR, moveC) and board[mti(moveR, moveC)] == opp:
        moveR += crow #add change in row
        moveC += ccol #add change in col
    #If we moved a legal amount and we found our new token, return true
    return isValid(moveR, moveC) and board[mti(moveR, moveC)] == token and change(row, moveR, col, moveC)
        #return True
    #IF any of these conditions fail, we did something wrong, so return false
    #return False

#return set of valid moves
def validMoves(board, token):  
    #Will return set of all possible moves
    #Method for how this works, is that it will use divmod function to establish row and col for a given item if the location is some location '.'
    return {mti(row, col) for crow, ccol in movement for row, col in (divmod(k, 8) for k in range(64) if board[k] == ".") if searchD(board, row, col, crow, ccol, token)}
    #return {R*8+C for dr, dc in directions for R, C in (divmod(k, 8) for k in range(64) if board[k] == ".") if checkDirection(R, C, dr, dc)}
    
def moveid(board, token, index, d):     #move in direction
    if (d == -1 or d == 1) and (index in rightSide and (index+d) in leftSide) or (index in leftSide and (index+d) in rightSide):
        #print("Direction: " + str(d))
        #print("MV: " + str(index))
        #print("START: " + str(index+d))
        return {-1}
    #initial row/column
    r,c = divmod(index, 8)
    changeR = d2rc[d][0]
    changeC = d2rc[d][1]
    #div returns the row
    #mod returns the column
    delr = r + changeR #delr is to augment r, figure out if ur moving legally
    delc = c + changeC #delc is to augment c, figure out if ur moving legally
    start = index + d
    while isValid(delr, delc) and board[start] == opposite(token):
        start += d
        delr += changeR
        delc += changeC
    dR = r - delr #change in row, if within 1 is prob a neighbor or u just changed row
    dC = c - delc  #change in column, if within 1 is prob a neighbor or u just changed col
    if isValid(delr, delc) and board[start] == "." and (abs(dR) > 1 or abs(dC) > 1):
        return {start}
    return {-1}

#get movement in row and col directions
def flipid(board, token, index, crow, ccol):     #flip in direction
    toFlip = set()  #define our original set
    startR, startC = divmod(index, 8)   #get our original row and column for moving
    moveR, moveC = startR + crow, startC + ccol #define the row and column tokens to be used for moving
    while isValid(moveR, moveC) and board[mti(moveR, moveC)] == opposite(token): #while still in a valid spot, and moving over opponent tokens
        toFlip.add(mti(moveR, moveC))   #add index to toFlip
        moveR += crow #add change in row
        moveC += ccol #add change in column
    return toFlip if isValid(moveR, moveC) and board[mti(moveR, moveC)] == token and change(startR, moveR, startC, moveC) else set()
    #return to flip if A: valid pos, B: turn token, and C: legal move

def makeMove(board, token, move):
    toFlip = {move}.union(*[flipid(board, token, move, crow, ccol) for crow, ccol in movement])    #get items to flip
    for i in toFlip:
        board = board[0:i] + token + board[i+1:]
    return board

#Find a token, and return the opposite one
def opposite(token):
    return switch[token]

def revEvalBoard(board, token):
    return len(validMoves(board, token)) - len(validMoves(board, opposite(token)))

officialFormat = [11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 31, 32, 33, 34, 35, 36, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 51, 52, 53, 54, 55, 56, 57, 58, 61, 62, 63, 64, 65, 66, 67, 68, 71, 72, 73, 74, 75, 76, 77, 78, 81, 82, 83, 84, 85, 86, 87, 88]
class Strategy():
    def best_strategy(self, board, token, best_move, running):
        c = ''.join(board).replace("?","")
        if c in bOpenings and token == BLACK:
            setOfMoves = bOpenings[c]
            best_move.value = setOfMoves[random.randint(0, len(setOfMoves) - 1)]
        elif c in wOpenings and token == WHITE:
            setOfMoves = wOpenings[c]
            best_move.value = setOfMoves[random.randint(0, len(setOfMoves) - 1)]
        else:
            lm = validMoves(c, token)
            spot = officialFormat[optimize(c, token, lm)] #optimized spot
            rand = list(lm)[0] #random spot
            if spot == -1:
                if rand != -1:
                    best_move.value = rand
            elif spot != -1:
                best_move.value = spot
            if spot not in [11, 18, 81, 88] and board.count(".") > 15:
                if board.count(".") > 30:
                    best_move.value = officialFormat[mid(c, token, -65, 65, 3, "mobile")[-1]]    
                else:
                    best_move.value = officialFormat[mid(c, token, -65, 65, 6, "reg")[-1]]
            elif spot not in [11, 18, 81, 88]:
                #Look for endgame
                best_move.value = officialFormat[negamaxTerminal(c, token, -65, 65)[-1]]

SQUARE_WEIGHTS = [
    120, -40,  20,   5,   5,  20, -40, 120,
    -40, -60,  -5,  -5,  -5,  -5, -60, -40,
     20,  -5,  15,   3,   3,  15,  -5,  20,
      5,  -5,   3,   3,   3,   3,  -5,   5,
      5,  -5,   3,   3,   3,   3,  -5,   5,
     20,  -5,  15,   3,   3,  15,  -5,  20,
    -40, -60,  -5,  -5,  -5,  -5, -60, -40,
    120, -40,  20,   5,   5,  20, -40, 120
]

def mobileWeight(board, player):
    opp = opposite(player)
    total = 0
    for sq in range(64):
        if board[sq] == player:
            total += SQUARE_WEIGHTS[sq]
        elif board[sq] == opp:
            total -= 3 * SQUARE_WEIGHTS[sq] if sq in [0, 8, 56, 63] else SQUARE_WEIGHTS[sq]
    return total - mobilityValue(board, opp)
def evalWithWeight(board, player): #player is token
#
    opp = opposite(player)
    total = 0
    for sq in range(64):
        if board[sq] == player:
            total += SQUARE_WEIGHTS[sq]
        elif board[sq] == opp:
            total -= 2 * SQUARE_WEIGHTS[sq] if sq in [0, 8, 56, 63] else SQUARE_WEIGHTS[sq]
    return total

#principal variation search (fail-soft version)
def pvs(depth, board, token, alpha, beta):
    bM = 0
    current = 0
    lm = validMoves(board, token)
    elm = validMoves(board, opposite(token))
    if depth <= 0 or (len(lm) + len(elm)) == 0:
        #return evaluation
        return evalBoard(board, token)
    if len(lm) == 0:
        return pvs(board, token, beta, alpha)
    for mv in lm:
        cBoard = makeMove(board, token, mv)
        current = -1 * pvs(depth, cBoard, opposite(token), -alpha-1, -alpha)[0]
        if current > alpha and current < beta:
            current = -1 * pvs(depth-1, board, opposite(token), -beta, -alpha)[0]
        if(score >= current):
            current = score
            bM = mv
            if (score >= alpha): alpha = score
            if score >= beta: break
    return (current, bM)     

bOpenings = {'...........................o@......@o...........................':[43, 34, 56, 65], #Depth of 1
             '..................o@.......o@......@o...........................':[43], #Depth of 2
             '...................@.......@@.....ooo...........................':[65,66],
             '....................o.....@@o......@o...........................':[56,66],
             '...........................o@......@o@.......o..................':[65],
             '...........................o@......o@@.....o....................':[33,43],
             '..................o.......@o@......@o...........................':[34],
             '..................o@......o@@.....ooo...........................':[42,64],
             '..................ooo.....@@o......@o...........................':[24,46],
             '...........................ooo.....@@.......@...................':[33,34],
             '....................o....oooo......@@@..........................':[33,36],
             '....................o@...ooooo.....@@@..........................':[33,25,37],
             '............@.......@@...ooo@o.....o@@......o...................':[57],
             '..................ooo.....oo@@....ooo...........................':[25,42,63,65],
             '..................ooo.....ooo.....o@o......@....................':[24,36,52,56],
             '....................@......o@o.....ooo.....ooo..................':[43,47,63,75],
             '...........................ooo....@@oo.....ooo..................':[34,36,57,76],
             '....................@......o@o....oooo....@ooo..................':[75], #Chimney Opening
             '..................ooo.....oo@@....ooo.....@o....................':[42], #||#
             '..................ooo@....oooo....o@o......@....................':[24], #||#
             '....................o@.....ooo....@@oo.....ooo..................':[57], #__#
             '..................ooo....@@oo.....ooo...........................':[25], #Chimney Opening, Mass-Turing
             '...........@......o@o.....ooo.....ooo...........................':[52], #||#
             '...........................ooo.....oo@@....ooo..................':[74],
             '...........................ooo.....ooo.....o@o......@...........':[47],
            }
wOpenings = {
             '...................@.......@@......@o...........................':[33,53], #Depth of 1
             '..........................@@@......@o...........................':[33,35],
             '...........................o@......@@@..........................':[64,66],
             '...........................o@......@@.......@...................':[46,66],
            }
'''
    Diagonal Opening: 26, 18, 19, 34, 25, 11, 43 (Numbers are from 0-63 format, in dictionary they would be in the format 11-88)
'''

def coinParity(board, token):
    a = board.count(token)
    b = board.count(opposite(token))
    if a >= b:
        return 100*(a-b)/(a+b)
    return 100*(a+b)/(a-b)

def mobilityValue(board, token):
    mobT = len(legalMoves(board, token))
    mobO = len(legalMoves(board, opposite(token)))
    if(mobT + mobO) != 0:
        return 100*(max(mobT, mobO) - min(mobT, mobO)/(mobT+mobO))
    return 0


weights = [
           4, -3,  2,  2,  2,  2, -3,  4,
          -3, -4, -1, -1, -1, -1, -4, -3,
           2, -1,  1,  0,  0,  1, -1,  2,
           2, -1,  0,  1,  1,  0, -1,  2,
           2, -1,  0,  1,  1,  0, -1,  2,
           2, -1,  1,  0,  0,  1, -1,  2,
          -3, -4, -1, -1, -1, -1, -4, -3,
           4, -3,  2,  2,  2,  2, -3,  4,
          ]    

###
def getOpening(board, token):
    if(token == "@"):
        return bOpenings[random.choice(board)]
    return wOpenings[random.choice(board)]
###
'''Alpha-Beta Pruning
   Alpha -> improvable (-65)
   Beta -> hardBound (65)
'''
def negamaxTerminal(board, token, improvable=-65, hardBound=65):
    lm = validMoves(board, token)
    if not lm:
        elm = validMoves(board, opposite(token))
        if not elm: return[evalBoard(board, token), -3] #EndGame
        nm = negamaxTerminal(board, opposite(token), -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(board, token, mv), opposite(token), -hardBound, newHB) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound: return [-best[0]] + best[1:] #Prune
    return [-best[0]] + best[1:]
###
def mid(board, token, alpha, beta, depth, form):
    if depth < 1: #If hit levels, evaluate based on weights
        return [evalWithWeight(board, token), -3] 
    mvs = validMoves(board, token)
    emvs = validMoves(board, opposite(token))
    if not mvs:
        if not emvs:
            return [evalWithWeight(board, token), -3] if form == "reg" else [mobileWeight(board, token), -3]
        md = mid(board, opposite(token), -beta, -alpha, depth-1)
        return [-md[0]] + md[1:]
    best = []
    newBeta = -alpha
    for mv in mvs:
        nm = mid(makeMove(board, token, mv), opposite(token), -beta, newBeta, depth-1) + [mv]
        if not best or nm[0] < newBeta:
            best = nm
            if nm[0] < newBeta:
                newHB = nm[0]
                if -newHB > beta: return [-best[0]] + best[1:] #Prune
    return [-best[0]] + best[1:]
    
###
def findBestMove(brd, token,):
    if brd.count('.') <= 8:
        #f = negamax(brd, token, n, enemy, dN)
        #print("Heuristic is negamax of level: " + str(n))
        return negamax(brd, token)[-1]
        #return f
    else:
        f = optimize(brd, token)
        print("Heurisitc is a random search")
        #return optimize(brd, token, enemy, dN)
        return f
        
def optimize(board, t, lm):
   pbs = sorted(lm)
   #display(board)
   #print(pbs)
   if cornerMove(pbs):
       soc = list()
       for i in corners:
           if i in pbs: soc.append(i)
       try:
           return soc[random.randint(0, len(soc)-1)]
       except:
           pbs = pbs   #do nothing
   dup = set(pbs)
   for i in corners:
       if board[i] != t:
           for j in xSquares.get(i):
               if j in dup: dup.remove(j)
               if len(dup) == 0:    #if forced to play something
                   return j
   pbs = dup
   #safe edges
   for move in pbs:
      if move<8: #top edge
         tempboard = makeMove(board,t,move)
         temp = move
         while temp>0 and tempboard[temp-1]==t: temp-=1
         if temp==0: return move
         temp = move
         while temp<7 and tempboard[temp+1]==t: temp+=1
         if temp==7: return move
      elif move>55: #bottom edge
         tempboard = makeMove(board,t,move)
         temp = move
         while temp>56 and tempboard[temp-1]==t: temp-=1
         if temp==56: return move
         temp = move
         while temp<63 and tempboard[temp+1]==t: temp+=1
         if temp==63: return move
      elif move%8==0: #left edge
         tempboard = makeMove(board,t,move)
         temp = move
         while temp>0 and tempboard[temp-8]==t: temp-=8
         if temp==0: return move
         temp = move
         while temp<56 and tempboard[temp+8]==t: temp+=8
         if temp==56: return move
      elif move%8==7: #right edge
         tempboard = makeMove(board,t,move)
         temp = move
         while temp>7 and tempboard[temp-8]==t: temp-=8
         if temp==7: return move
         temp = move
         while temp<63 and tempboard[temp+8]==t: temp+=8
         if temp==63: return move
   for i in pbs:
      if i > 7 and i < 56 and i%8 != 0 and i%8 != 7: return i #this is the avoid edge if you can
   return list(pbs)[random.randint(0, len(pbs) - 1)]   #return a random item in pbs

def display(board):
   for i in range(0, 64, 8): print(board[i] + " " + board[i+1] + " " + board[i+2] + " " + board[i+3] + " " + board[i+4] + " " + board[i+5] + " " + board[i+6] + " " + board[i+7])
def score(board):
   return board.count('X'), board.count('O')

def cornerMove(posibilities):
   for i in corners:
      if i in posibilities:   return True
   return False

def evalBoard(board, token): #return len(legalMoves(board, token, enemy, dN)) - len(legalMoves(board, enemy, token, dN))
    return board.count(token) - board.count(opposite(token))

#NegaMax algorithm
'''def negamax(board, token):
    """ Uses negamax to find the best move, up to a certain level """
    moves = legalMoves(board, token)
    if not moves:
        if not legalMoves(board, opposite(token)): # Endgame
            return [evalBoard(board, token)]
        result = negamax(board[:], opposite(token)) + [-1] #-1 is treated as the pass
        return [-result[0]] + result[1:]
    nm = sorted([negamax(makeMove(board, token, mv), opposite(token)) + [mv] for mv in moves])
    best = nm[0]
    return [-best[0]] + best[1:]'''

def negamax(board, token):
    turnMoves = validMoves(board, token)
    oppoMoves = validMoves(board, opposite(token))
    if board.count('.') == 0 or (len(turnMoves) + len(oppoMoves)) == 0:
        #If can not make a move, return evalBoard within the brackets
        return [evalWithWeight(board, token)]
    if not turnMoves:   #if forced to pass
        nm = negamax(board, opposite(token))
        return [-nm[0]] + nm[1:]
    res_list = sorted(negamax(makeMove(board[:], token, mv), opposite(token)) + [mv] for mv in turnMoves)
    best = res_list[0]
    return [-best[0]] + best[1:]

def nDepth(board, token, depth):
    turnMoves = validMoves(board, token)
    oppoMoves = validMoves(board, opposite(token))
    if depth < 1 or board.count('.') == 0 or (len(turnMoves) + len(oppoMoves)) == 0:
        #If can not make a move, return evalBoard within the brackets
        return [evalWithWeight(board, token)]
    if not turnMoves:   #if forced to pass
        nm = negamax(board, opposite(token))
        return [-nm[0]] + nm[1:]
    res_list = sorted(nDepth(makeMove(board[:], token, mv), opposite(token), depth - 1) + [mv] for mv in turnMoves)
    best = res_list[0]
    return [-best[0]] + best[1:]

def test():
   try:
      board = sys.argv[1].upper()
   except:
      board = '...........................OX......XO...........................'
   try:
      turn = sys.argv[2].upper()
   except:
      turn = 'X' if board.count('.') % 2 == 0 else 'O'
   mvSet = sys.argv[3:]
   print(mvSet)
   display(board)
   #other = 'X' if turn == 'O' else 'O'
   #dN = directNeighbors(len(board)) 
   #nm = negamax(board, turn)
   nB = board
   print(legalMoves(nB, turn))
   for i in mvSet:
       print()
       nB = makeMove(nB, turn, int(i))
       display(nB)
       turn = opposite(turn)
   print()
   #display(nB)
   print(nB.count('X'))
   print(nB.count('O'))

def main():
   try:
      board = sys.argv[1].upper()
   except:
       #board = "O.X.O.XOXO..O.OXXOOOOOXXXOXOOXXXXOOXXXXXXOOXXXXXXXXXXXXXXXXXXXXX"
       board = '...........................OX......XO...........................'
   try:
      turn = sys.argv[2].upper()
   except:
      turn = 'X' if board.count('.') % 2 == 0 else 'O'
   if '.' in board:
      #1
      display(board)
      #2
      print("Legal or possible moves: " + str(validMoves(board, turn)))
      #3
      print("My Heuristic move is: " + str(optimize(board, turn, legalMoves(board, turn))))
      #4
      if board.count('.') <= 14:
          nm = negamaxTerminal(board, turn)
          print("Negamax returns {}, and I choose {}".format(nm, nm[-1]))
      #toRet = findBestMove(board, turn, other, dN)
      #toRet = negamax(board, turn, 5, other, dN)
      #if type(toRet) is list:
      #    print("Once move is made, score is: " + str(playMove(board, turn, other, toRet[-1]).count('X')) + "/" + str(playMove(board, turn, other, toRet[-1]).count('O')))
      #else:
      #    print("Once move is made, score is: " + str(playMove(board, turn, other, toRet).count('X')) + "/" + str(playMove(board, turn, other, toRet).count('O')))
      #print(toRet)
      #print(toRet)'''
main()
#test()

def mainTwo():
   try:
      board = sys.argv[1].upper()
   except:
       #board = "O.X.O.XOXO..O.OXXOOOOOXXXOXOOXXXXOOXXXXXXOOXXXXXXXXXXXXXXXXXXXXX"
       board = '...........................OX......XO...........................'
   try:
      turn = sys.argv[2].upper()
   except:
      turn = '@' if board.count('.') % 2 == 0 else 'o'
   display(board)
   print(legalMoves(board, turn))

#mainTwo()
#test()

'''
import numpy as np
import sys

def printBoard(brd):
    toPrint = ""
    for i in range(0, 8):
        for j in range(0, 8):
            toPrint += str(brd[i,j]) + " "
        toPrint += "\n"
    print(toPrint)

def avoidCX(posibilities):
    

def cornerMove(posibilities):
    toRet = set()
    for i in [0, 7, 56, 63]:
        if i in posibilities:
            toRet.add(i)
    return toRet

def makeRow(brd, s, e): #make a row for the matrix
    return [brd[i] for i in range(s,e)]

def getMoves(brd, turn):
    other = 'X' if turn == 'O' else 'O'
    counts = np.count_nonzero(brd == '.')   #To count periods in the matrix, use count_nonzero, and set parameter of brd to '.'
    if counts < 8:
        print("Negamax Search")
        #run negaMax
    else:
        print("Random Search")
        #run random search from before
    return(counts)

def main():
    try:
        if len(sys.argv[1] == 64):
            inputS = sys.argv[1].upper() #input is reading sys.argv IFF length is 64
    except:
        inputS = '...........................OX......XO...........................' #make a default board
    #Define board system as following: columns are numbers, rows are letters
    brd = np.matrix([makeRow(inputS, 0, 8), makeRow(inputS, 8, 16), makeRow(inputS, 16, 24), makeRow(inputS, 24, 32), 
                     makeRow(inputS, 32, 40), makeRow(inputS, 40, 48), makeRow(inputS, 48, 56), makeRow(inputS, 56, 64)])   #Make a matrix from the string
    printBoard(brd) #Show 2D Board
    try:
        if len(sys.argv[1]) == 1:   #if the input wasn't a board, rather a move
            turn = sys.argv[1].upper()
        elif len(sys.argv[2]) == 2: #if we had a board input, potential move input
            turn = sys.argv[2].upper()
    except:
        turn = 'X' if inputS.count('.') % 2 == 0 else 'O'
    mvs = getMoves(brd, turn)    #Show possible moves for whoever's turn it is
    print(mvs)
    
    
if __name__ == '__main__':
    main()'''