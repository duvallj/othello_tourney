import sys
othello1='...........................ox......xo...........................'
othChar=''
oppChar=''
pos=-1
#Universal Input Fix:
moves=['x','o']
for i in sys.argv[1:4]:
	if len(i)==64:
		othello1=i.lower()
	elif i in moves:
		othChar=i
		oppChar=moves[1-moves.index(i)]
	else:
		try:
			pos=int(i)
		except ValueError:
			continue
defaultLevel=5
for i in sys.argv[5:]:
	defaultLevel=int(i)
rowDict=[[],[],[],[],[],[],[],[]]
colDict=[[],[],[],[],[],[],[],[]]
count=0
for i in range(0,8):
	for j in range(0,8):
		rowDict[i].append(count)
		colDict[j].append(count)
		count+=1
def validMoves(board,token):
	return [board[:i]+token+board[i+1:] for i in getValidMoves(board,token)]
def evalBoard(board,token):
	return len([x for x in board if x==token])-len([o for o in board if o==findOpp(token)])
letterToCol=['a','b','c','d','e','f','g','h']
def negaMax(board,token,level):
	if level==0:
		return [evalBoard(board,token)]
	if len(getValidMoves(board,token))==0:
		nm= negaMax(board,findOpp(token),level-1) + [-1]
		return [-1*nm[0]]+nm[1:]
	nmList=sorted([negaMax(flip(board,token,mv),findOpp(token),level-1) +[mv] for mv in getValidMoves(board,token)])
	best=nmList[0]
	return [-1*best[0]]+[best[1:]]
def othNotationToInt(notation):
	nCache=[notation[0],notation[1]]
	nCache[0]=letterToCol.index(nCache[0])
	return (8*(int(nCache[1])-1)+(nCache[0]))
corners=[0,63,7,56]
cornerNeighbors=[[1,8],[6,15],[48,57],[55,62]]
edges=[[1,2,3,4,5,6],[8,16,24,32,40,48],[15,23,31,39,47,55],[57,58,59,60,61,62]]
sides=[[0,1,2,3,4,5,6,7],[0,8,16,24,32,40,48,56],[56,57,58,59,60,61,62,63],[7,15,22,31,39,47,55,63]]
def playMove(pzl,char):
	for i in getValidMoves(pzl,char):
		if i in corners:
			if validCapture(pzl[:i]+'*'+pzl[i+1:],i,char):
				return i
		for z in cornerNeighbors:
			if i in z:
				if corners[cornerNeighbors.index(z)]==char:
					return i
			continue
		for x in edges:
			if i in x:
				cache=sides[edges.index(x)]
				startend=cache.index(1)+1
				if char in set([pzl[s] for s in cache[startend:]]) or char in set([pzl[s] for s in cache[:startend]]) and len(set(filter('.',[pzl[s] for s in cache])))==1:
					return i
	return getValidMoves(pzl,char)[0]
	pass
urDict=[[0],[1,8],[2,9,16],[3,10,17,24],[4,11,18,25,32],[5,12,19,26,33,40],[6,13,20,27,34,41,48],[7,14,21,28,35,42,49,56],[15,22,29,36,43,50,57],[23,30,37,44,51,58],[31,38,45,52,59],[39,46,53,60],[47,54,61],[55,62],[63]]
ulDict = urDict[::-1]
drDict=[[56],[48,57],[40,49,58],[32,41,50,59],[24,33,42,51,60],[16,25,34,43,52,61],[8,17,26,35,44,53,62],[0,9,18,27,36,45,54,63],[1,10,19,28,37,46,55],[2,11,20,29,38,47],[3,12,21,30,39],[4,13,22,31],[5,14,23],[6,15],[7]]
dlDict=drDict[::-1]
def findOpp(char):
	if char=='x':return 'o'
	else: return 'x'
def flip(pzl,char,pos):
	pCache=pzl[:pos]+'*'+pzl[pos+1:]
	rowCache,colCache,urCache,drCache,ulCache,dlCache=None,None,None,None,None,None
	for i in rowDict:
		for j in i:
			if pos==j:
				rowCache=i[:]
	for i in colDict:
		for j in i:
			if pos==j:
				colCache=i[:]
	for i in urDict:
		for j in i:
			if pos==j:
				urCache=i[:]
	for i in drDict:
		for j in i:
			if pos==j:
				drCache=i[:]
	for i in filter(None,[rowCache,colCache,urCache,drCache]):
		tempRow=[pCache[j] for j in i]
		if len(i)>3:
			if 'x' in tempRow and 'o' in tempRow and '*' in tempRow:
				tempRow=generateCapturedSegment(tempRow,char)
				ec=0
				for j in i:
					pCache=pCache[:j]+tempRow[ec]+pCache[j+1:]
					ec+=1
	pCache=pCache[:pCache.index('*')]+char+pCache[pCache.index('*')+1:]
	# printPuzzle(pCache)
	# print()
	return pCache
def generateCapturedSegment(row,char):
	startend=row.index('*')
	if startend+1>len(row)-1 or row[startend+1]=='.':
		for i in range(0,startend+1)[::-1]:
			if row[i]==findOpp(char):
				row[i]=char
			elif row[i]=='*':
				continue
			else: break
	elif startend-1<0 or row[startend-1]=='.':
		for i in range(startend,len(row)):
			if row[i]==findOpp(char):
				row[i]=char
			elif row[i]=='*':
				continue
			else: break
	return row
	pass
def validCapture(pzl,count,char):
	rowCache,colCache,urCache,drCache=None,None,None,None
	for i in rowDict:
		for j in i:
			if count==j:
				rowCache=i[:]
	for i in colDict:
		for j in i:
			if count==j:
				colCache=i[:]
	for i in urDict:
		for j in i:
			if count==j:
				urCache=i[:]
	for i in drDict:
		for j in i:
			if count==j:
				drCache=i[:]
	validCount=0
	for i in filter(None,[colCache,rowCache,urCache,drCache]):
		row=[pzl[e] for e in i]
		if 'x' in row and 'o' in row:
			startend=row.index('*')
			if startend+1>len(row)-1 or row[startend+1]=='.':
				count=0
				if char in row[:startend]:
					for i in range(0,startend)[::-1]:
						if row[i]==findOpp(char):
							count+=1
						elif row[i]==char: break
						else:
							count=0
							break
					if count>=1:
						validCount+=1
			elif startend-1<0 or row[startend-1]=='.':
				count=0
				if char in row[startend:]:
					for i in range(startend+1,len(row)):
						if row[i]==findOpp(char):
							count+=1
						elif row[i]==char:
							break
						else:
							count=0
							break
					if count>=1:
						validCount+=1
	if validCount>0:
		return True
	return False
	pass
def printPuzzle(pzl):
	print('\n'.join([pzl[start:start+8] for start in range(0,64)[::8]]))
def getValidMoves(pzl,char):
	array=[i for i in range(len(pzl)) if pzl[i]=='.']
	toReturn =[]
	for i in array:
		if validCapture(pzl[:i]+'*'+pzl[i+1:],i,char):
			toReturn.append(i)
	return toReturn
print()
pCache=othello1[:]

class Strategy():
	def best_strategy(self, board, player, best_move, still_running):
		othBoard=''.join(board).replace('?','').replace('@','x')
		othToken='x' if player=='@' else 'o'
		move = playMove(othBoard,othToken)
		toReturn=11+(move//8)*10 + (move%8)
		best_move.value=toReturn
# depth = 1
# while(True):
# 	best_move.value = self.my_search_strategy(board, player, depth)
# 	depth += 1
def main():
	print(playMove(othello1,othChar))
if __name__=="__main__":
	main()
