import sys
import random

corners = {0, 7, 56, 63}
cx = {1, 8, 9, 6, 15, 14, 48, 49, 57, 55, 54, 62}
topbot = {x for x in range(64)if x in {*range(8)}|{*range(56,64)}}
sides = {x for x in range(64) if x%8 in {0, 7}}
edges = topbot|sides

def findMoves(board, token):
    opponent = 'o'
    if token == 'o':
        opponent = 'x'
    side = int(len(board)**0.5)
    answers = set()
    for i in range(len(board)):
        if board[i] == '.':
            for dx, dy in ([0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]):
                x = i//side
                y = i%side
                x += dx
                y += dy
                if x > 7 or x < 0 or y <0 or y > 7:
                    continue
                if board[x*8+y] == token or board[x*8+y] == '.':
                    continue
                while board[x*8+y] == opponent:
                    x += dx
                    y += dy
                    if x > 7 or x < 0 or y <0 or y > 7:
                        break
                    if board[x*8+y] == '.':
                        break
                    elif board[x*8+y] == token:
                        x = i//side
                        y = i%side
                        answers.add(x*8+y)
    return answers

def move(board, token, position):
    side = int(len(board)**0.5)
    opponent = 'o'
    if token == 'o':
        opponent = 'x'
    newBoard = list(board)
    newBoard[position] = token
    for dx, dy in ([0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]):
        toChange = set()
        x = position//side
        y = position%side
        x += dx
        y += dy
        if x > 7 or x < 0 or y <0 or y > 7:
            continue
        if board[x*8+y] == token or board[x*8+y] == '.':
            continue
        while board[x*8+y] == opponent:
            toChange.add(x*8+y)
            x += dx
            y += dy
            if x > 7 or x < 0 or y <0 or y > 7:
                break
            if board[x*8+y] == '.':
                toChange = set()
            elif board[x*8+y] == token:
                for i in toChange:
                    newBoard[i] = token
                break
    return ''.join(newBoard)

def safeEdge(board, token, index, di, edges):
    newBoard = move(board, token, index)
    while newBoard[index] == token:
        if index in edges or index not in {*range(64)}:
            return True
        index += di
    return False

def bestMove(board, token):
    moves = findMoves(board, token)
    numMoves = len(moves)
    safeEdgem = set()
    if numMoves == 1:
        return list(moves)[0]
    for i in moves:
        if i in corners:
            return i
        elif i in topbot:
            if safeEdge(board, token, i , -1, sides) or safeEdge(board, token, i, 1, sides):
                safeEdgem.add(i)
        elif i in sides:
            if safeEdge(board,token, i, 8, topbot) or safeEdge(board,token, i, -8, topbot):
                safeEdgem.add(i)
    if safeEdgem:
        return random.choice(list(safeEdgem))
    if moves - cx - edges:
        return random.choice(list(moves - cx - edges))
    elif moves - cx:
        return random.choice(list(moves - cx))
    else:
        return random.choice(list(moves))

def display(board):
    for i in range(8):
        for j in range(8):
            print(board[i*8+j], end = '')
        print()

def evaluate(board, token):
    opponent = 64 - board.count(token) - board.count('.')
    return board.count(token) - opponent

def negamax(board, token):
    enemy = 'x'
    if token == 'x':
        enemy = 'o'
    lm = findMoves(board, token)
    if not lm:
        if not findMoves(board, enemy):
            return [evaluate(board, token)]
        nm = negamax(board, enemy) + [-1]
        return[-nm[0]] + nm[1:]
    nmList = sorted([negamax(move(board, token, m), enemy) + [m] for m in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]

def negamaxTerminal (board, token, improvable, hardBound):
    lm = findMoves(board, token)
    enemy = 'o'
    if token == 'o':
        enemy = 'x'
    score = evaluate(board, token)
    if not lm:
        lm = findMoves(board, enemy)
        if not lm: return [score, -3]
        nm = negamaxTerminal(board, enemy, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    best =[]
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(move(board, token, mv), enemy, -hardBound, newHB) + [mv]
        if not best or nm[0]<newHB:
            best = nm
            if nm[0]<newHB:
                newHB = nm[0]
                if -newHB >= hardBound: return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]

def main():
    board = "...........................ox......xo..........................."
    token = None
    args = sys.argv
    for i in range(1, len(args)):
        if len(args[i]) == 64:
            board = args[i].lower()
        elif args[i].lower() == 'x' or args[i].lower() == 'o':
            token = args[i].lower()
    openSpots = board.count('.')
    if not token:
        if not openSpots%2:
            token = 'x'
        else:
            token = 'o'

    display(board)
    print("Possible Moves:", end = '' )
    print(findMoves(board, token))
    print("My Heuristic Move: ")
    print(bestMove(board, token))

    if openSpots <= 15:
            print("Negamax score is ", end = '')
            nm = negamax(board, token)
            print(nm[0], end = '')
            print(" and my move is:", end = "")
            print(nm[-1])


class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        translate = {'@' : "x", 'o':'o'}
        board = ''.join(board)
        board = board.replace("?", "")
        board = board.replace("@", 'x')
        token = translate[player]
        myM = bestMove(board, token)
        best_move.value = 11 + (myM//8)*10 + myM%8
        if board.count('.') <= 15:
            myM = negamaxTerminal(board, token, -65, 65)[-1]
            best_move.value = 11+ (myM//8)*10 + myM%8


if __name__ == '__main__':
    main()
