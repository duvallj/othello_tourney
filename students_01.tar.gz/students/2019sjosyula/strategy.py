from multiprocessing import Value
import time
import math
import random
##Sriram Josyula
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]
UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)

class Strategy():
  def squares(self):
        """List all the valid squares on the board."""
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]
  def initial_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [OUTER] * 100
        for i in self.squares():
            board[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        return board
  def print_board(self,board):
        """Get a string representation of the board."""
        rep = ''
        rep += '  %s\n' % ' '.join(map(str, list(range(1, 9))))
        for row in range(1, 9):
            begin, end = 10 * row + 1, 10 * row + 9
            rep += '%d %s\n' % (row, ' '.join(board[begin:end]))
        return rep
  def is_valid(self, move):
        """Is move a square on the board?"""
        x1 = int(move/10)
        y1 = int(move%10)
        return (1<=x1<=8) and (1<=y1<=8)
  def opponent(self, player):
        """Get player's opponent piece."""
        if player == WHITE:
          return BLACK
        if player == BLACK:
          return WHITE
  def find_bracket(self, square, player, board, direction):
        """
        Find a square that forms a bracket with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        Returns the index of the bracketing square if found
        """
        bracket = square + direction
        if board[bracket] == player:
            return None
        opp = self.opponent(player)
        while board[bracket] == opp:
            bracket += direction
        return None if board[bracket] in (OUTER, EMPTY) else bracket
  def is_legal(self, move, player, board):
      """Is this a legal move for the player?"""
      for d in DIRECTIONS:
        if self.find_bracket(move, player, board, d) is not None:
          return True
      return False
  def make_move(self, move, player, board):
        """Update the board to reflect the move by the specified player."""
        if not self.is_legal(move, player, board):
            raise self.IllegalMoveError(player, move, board)
        board[move] = player
        for d in DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board
  def make_flips(self, move, player, board, direction):
        """Flip pieces in the given direction as a result of the move by player."""
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction
  def legal_moves(self, player, board):
        """Get a list of all legal moves for player, as a list of integers"""
        legalmoves = []
        for i in range(11,89):
          if board[i] == EMPTY:
            if self.is_legal(i, player, board) ==  True:
              legalmoves.append(i)
        return legalmoves
  def next_player(self,board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.any_legal_move(self.opponent(prev_player), board):
          return self.opponent(prev_player)
        else:
          return None
  def any_legal_move(self, player, board):
        """Can player make any moves? Returns a boolean"""
        moves = self.legal_moves(player, board)
        if len(moves) == 0:
          return False
        return True
  def score(self,player, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        pscore = 0
        oscore = 0
        for i in range(0,100):
          if board[i] == player:
            pscore = pscore + 1
          if board[i] == self.opponent(player):
            oscore = oscore + 1
        return (pscore - oscore)
  def weightedScore(self, player, board,weights):
    pscore = 0
    value = 0
    oscore = 0
    for i in self.squares():
      if board[i] == player:
        pscore += weights[i]
      if board[i] == self.opponent(player):
        pscore -= weights[i]
    return pscore
  def mobility(self, player, board):
    return len(self.legal_moves(player, board)) - len(self.legal_moves(self.opponent(player), board))
  def nextToEmpty(self,board,player, coordinate):
    count = 0
    for d in DIRECTIONS:
      coordinate = coordinate + d
      if board[coordinate] == EMPTY:
        count = count + 1
      coordinate = coordinate - d
    return count
  def potentialMobility(self, board, player):
    count = 0
    for i in range(11,89):
      if board[i] == self.opponent(player):
        count = count + self.nextToEmpty(board, self.opponent(player), i)
      if board[i] == player:
        count = count - self.nextToEmpty(board, player, i)
    return count
  def numCoins(self, board):
    total = 0
    for i in self.squares():
      if board[i] == BLACK or board[i] == WHITE:
        total = total + 1
    return total
  def sortNodes(self, player, board):
    sortedMoves = []
    nodes = self.legal_moves(player, board)
    for node in nodes:
      tempBoard = self.make_move(node, player, self.deepcopy(board))
      temp = (node, tempBoard, self.h(player, tempBoard))
      sortedMoves.append(temp)
    sortedMoves = sorted(sortedMoves, key=lambda move: move[2], reverse = True)
    return sortedMoves
  def scorePlayer(self,player, board):
    total = 0
    for s in self.squares():
      if board[s] == player:
        total = total + 1
    return total
  def h(self, player, board):
    weights = self.deepcopy(SQUARE_WEIGHTS)
    if board[11] == player:
      # weights[31] = weights[31]*2
      # weights[41] = weights[31]*2
      # weights[51] = weights[31]*2
      # weights[61] = weights[31]*2
      # weights[13] = weights[31]*2
      # weights[14] = weights[31]*2
      # weights[15] = weights[31]*2
      # weights[16] = weights[31]*2
      weights[21] = 60
      weights[12] = 60
      weights[22] = 60
    if board[18] == player:
      # weights[31] = weights[31]*2
      # weights[41] = weights[31]*2
      # weights[51] = weights[31]*2
      # weights[61] = weights[31]*2
      # weights[83] = weights[31]*2
      # weights[84] = weights[31]*2
      # weights[85] = weights[31]*2
      # weights[86] = weights[31]*2
      weights[17] = 60
      weights[27] = 60
      weights[28] = 60
    if board[81] == player:
      weights[71] = 60
      weights[82] = 60
      weights[72] = 60
    if board[88] == player:
      weights[87] = 60
      weights[78] = 60
      weights[77] = 60
    if self.numCoins(board) > 54:
      return self.weightedScore(player, board, weights)
    return self.weightedScore(player, board, weights) + 5*self.potentialMobility(board, player)
    #return self.scorePlayer(self.opponent(player), board)
  def finalEval(self,player, board):
    if self.scorePlayer(player, board)> self.scorePlayer(self.opponent(player), board):
      return 10000
    if self.scorePlayer(player, board)<self.scorePlayer(self.opponent(player),board):
      return -10000
    return 0
  def deepcopy(self, board):
    newBoard = []
    for a in board:
      newBoard.append(a)
    return newBoard
  def alphabeta(self, board, depth,player,a, b,maximizingPlayer):
    myMoves = self.legal_moves(player, board)
    oppMoves = self.legal_moves(self.opponent(player), board)
    if len(myMoves)==0 and len(oppMoves)==0:
      return self.finalEval(player, board)
    if depth == 0 or len(myMoves)==0:
        return self.h(player, board)
    if maximizingPlayer:
      v = float("-inf")
      for move in myMoves:
        tempBoard = self.make_move(move, player, self.deepcopy(board))
        v = max(v, self.alphabeta(tempBoard, depth -1, player, a,b,False))
        a = max(a, v)
        if b <= a:
          break
      return v
    else:
      v = float("inf")
      for move in oppMoves:
        tempBoard = self.make_move(move, self.opponent(player), self.deepcopy(board))
        v = min(v, self.alphabeta(tempBoard, depth -1, player, a, b, True))
        b = min(b, v)
        if b <= a:
          break
      return v
  def minimaxSearch(self, board, player, depth):
    bestMove = float("-inf")
    best = 0
    for move in self.legal_moves(player, board):
      tempBoard = self.make_move(move, player, self.deepcopy(board))
      v = self.alphabeta(tempBoard, depth, player, float("-inf"), float("inf"),False)
      if (v > bestMove):
        bestMove = v
        best = move
    return best
  def best_strategy(self, board, player, best_move, still_running):
        """
        :param board: a length 100 list representing the board state
        :param player: WHITE or BLACK
        :param best_move: shared multiptocessing.Value containing an int of
                the current best move
        :param still_running: shared multiprocessing.Value containing an int
                that is 0 iff the parent process intends to kill this process
        :return: best move as an int in [11,88] or possibly 0 for 'unknown'
        """
        for depth in range(2,64):
          if (still_running):
            best_move.value = self.minimaxSearch(board, player, depth)
  def randomMove(self,player, board):
    return random.choice(self.legal_moves(player, board))
  class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)
