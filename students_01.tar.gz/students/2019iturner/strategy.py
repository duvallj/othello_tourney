
#Isaiah Turner Period 3
import sys, random, time
pmDict = {}
scoreDict = {}

def findAdjacent(position, max):
    ret = []
    rowLen = 8
    if (position + 1) < max and position // rowLen == (position + 1) // rowLen:  # right
        ret.append(position + 1)
    if (position - 1) >= 0 and position // rowLen == (position - 1) // rowLen:  # left
        ret.append(position - 1)
    if (position + rowLen) < max:  # below
        ret.append(position + rowLen)
    if position - rowLen >= 0:  # above
        ret.append(position - rowLen)
    if position + rowLen + 1 < max and abs(
            (position // rowLen) - ((position + rowLen + 1) // rowLen)) == 1:  # bottom right
        ret.append(position + rowLen + 1)
    if position + rowLen - 1 < max and abs(
            (position // rowLen) - ((position + rowLen - 1) // rowLen)) == 1:  # bottom left
        ret.append(position + rowLen - 1)
    if position - rowLen + 1 >= 0 and abs((position // rowLen) - ((position - rowLen + 1) // rowLen)) == 1:  # top right
        ret.append(position - rowLen + 1)
    if position - rowLen - 1 >= 0 and abs((position // rowLen) - ((position - rowLen - 1) // rowLen)) == 1:  # top left
        ret.append(position - rowLen - 1)
    return ret


def makeReadable(pzl):
    return "\n".join([pzl[8 * n:8 * n + 8] for n in range(8)])


def findMoves(board, turn, adj):
    if (board,turn) in pmDict:
        return pmDict[(board, turn)][0], pmDict[(board, turn)][1]
    max, rowLen = 64, 8
    ret = []
    opponentChar = ({"X", "O"} - {turn}).pop()
    possibleIndices = [i for i, v in enumerate(board) if v == turn and opponentChar in [board[k] for k in adj[i]]]
    swaps = {}
    for i in possibleIndices:
        currentAdjacent = [j for j in adj[i] if board[j] == opponentChar]
        for otherPiece in currentAdjacent:
            finalSpot = -1
            tempChar = i
            tryList = []
            if i - otherPiece == 1:  # piece is to the left of the opponent, keep going left
                tempChar -= 1
                while tempChar >= 0 and (tempChar // rowLen == i // rowLen):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar -= 1
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            elif i - otherPiece == -1:  # piece is to the right of the opponent, keep right
                tempChar += 1
                while tempChar < max and (tempChar // rowLen == i // rowLen):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += 1
                    elif board[tempChar] == ".":
                        finalSpot = tempChar
                        ret.append(tempChar)
                        break
                    else:
                        break
            elif i - otherPiece == rowLen:  # piece is above of the opponent, go up
                tempChar -= rowLen
                while tempChar >= 0:
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar -= rowLen
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            elif i - otherPiece == -rowLen:  # piece is below the opponent, go down
                tempChar += rowLen
                while tempChar < max:
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += rowLen
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            elif i - otherPiece == rowLen - 1:  # piece is daig right and up
                tempChar += -rowLen + 1
                while tempChar >= 0 and (
                        (tempChar - rowLen + 1) // rowLen - tempChar // rowLen == -1 or board[tempChar] == "."):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += -rowLen + 1
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            elif i - otherPiece == -rowLen + 1:  # piece is diag left and down
                tempChar += rowLen - 1
                while tempChar < max and (
                        (tempChar + rowLen - 1) // rowLen - tempChar // rowLen == 1 or board[tempChar] == "."):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += rowLen - 1
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            elif i - otherPiece == (rowLen + 1):  # piece is diag left and up
                tempChar += -rowLen - 1
                while tempChar >= 0 and (
                        (tempChar - rowLen - 1) // rowLen - tempChar // rowLen == -1 or board[tempChar] == "."):
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += -rowLen - 1
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            elif i - otherPiece == (-rowLen - 1):  # piece is diag right and down
                # print("here")
                tempChar += rowLen + 1
                while tempChar < max and (
                        (tempChar + rowLen + 1) // rowLen - tempChar // rowLen == 1 or board[tempChar] == "."):
                    # print(tempChar)
                    if board[tempChar] == opponentChar:
                        tryList.append(tempChar)
                        tempChar += rowLen + 1
                    elif board[tempChar] == ".":
                        ret.append(tempChar)
                        finalSpot = tempChar
                        break
                    else:
                        break
            if finalSpot >= 0 and finalSpot in swaps.keys():
                swaps[finalSpot] += tryList
            elif finalSpot >= 0:
                swaps[finalSpot] = tryList
    pmDict[(board, turn)] = (list(set(ret)),swaps)
    return list(set(ret)), swaps


def negamax(board, token, levels, lm, places, adjacent):  # will guarantee best result for given number of levels, recursive; lm list of possiblemoves
    if not levels or "." not in board:  # at end of evaluation
        return [evalBoard(board, token)]  # evalBoard yourTokens-theirTokens
    lm, places = findMoves(board, token, adjacent)
    #if levels == -1 and len(lm) ==0 and len(findMoves(board, "XO".replace(token,""))) == 0:
    #    return [evalBoard(board, token)]
    if not lm:  # passing
        nm = negamax(board, "".join({"X", "O"} - {token}), levels - 1, lm, places, adjacent) + [-1]  # -1 indicates a pass
        return [-nm[0]] + nm[1:]  # flips score and adds move
    nmList = sorted([negamax(makeMove(board, token, mv, places), "".join({"X", "O"} - {token}), levels - 1, lm, places, adjacent) + [mv] for mv in lm])
    # returns[score, lastmove,secondtolastmove,etc..., first move] want the lowest score because negamax returns from enemy's POV
    best = nmList[0]
    return [-best[0]] + best[1:]
    #return nmList


def evalBoard(b, t):
    return b.count(t) - b.count("".join({"X", "O"} - {t}))


def bestMove(game, possibleMoves, places, turnChar, adj):
    edges = list({*range(0, 8), *range(0, 56, 8), *range(7, 63, 8), *range(56, 63)})
    corners = {0, 7, 56, 63}
    opponentChar = "XO".replace(turnChar, "")
    finalMove = -1
    if len(possibleMoves) > 0:
        goodMoves = possibleMoves
        safeEdges = []
        edgeCanBeGood = False
        if [i for i in possibleMoves if i in corners]:  # corner
            finalMove = random.choice([i for i in possibleMoves if i in corners])
            safeEdges += [i for i in possibleMoves if i in corners]
        temp = []
        if [i for i in possibleMoves if i in edges]:
            edgeMoves = [i for i in possibleMoves if i in edges]
            for move in edgeMoves:
                for j in [0, 56]:  # go right from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    #print([v for v in list(places.values())])
                    while tempIndex // 8 == j // 8 and game[j] == turnChar and tempIndex < 64:
                        if game[tempIndex] == turnChar:
                            tempIndex += 1
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex += 1
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
                for j in [7, 63]:  # go left from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    while tempIndex // 8 == j // 8 and game[j] == turnChar and tempIndex >= 0:
                        if game[tempIndex] == turnChar:
                            tempIndex -= 1
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex -= 1
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
                for j in [0, 7]:  # go down from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    while tempIndex % 8 == j % 8 and tempIndex < 64 and game[j] == turnChar:
                        if game[tempIndex] == turnChar:
                            tempIndex += 8
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex += 8
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
                for j in [56, 63]:  # go up from two corners
                    tempIndex = j
                    needToBeFlipped = []
                    while tempIndex % 8 == j % 8 and tempIndex >= 0 and game[j] == turnChar:
                        if game[tempIndex] == turnChar:
                            tempIndex -= 8
                            # print([j for j in i for i in list(places.values())])
                        elif game[tempIndex] == opponentChar and tempIndex in [v for v in list(places.values())]:
                            needToBeFlipped.append(tempIndex)
                            tempIndex -= 8
                        elif game[tempIndex] == "." and tempIndex in goodMoves and places[tempIndex] == needToBeFlipped:
                            temp.append(tempIndex)
                        else:
                            break
        if temp:
            goodMoves = temp
            safeEdges += temp
        for pos in corners:
            if game[pos] == turnChar:
                safeEdges += adj[pos]
        goodMoves = [i for i in goodMoves if i not in edges or i in safeEdges]
        if goodMoves and finalMove < 0:
            finalMove = random.choice(goodMoves)
        elif finalMove < 0:
            finalMove = random.choice(possibleMoves)
    return finalMove


def makeMove(b, t, m, places):
    b = list(b)
    for spot in [*places[m],m]:
        b[spot] = t
    return "".join(b)

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        adj = {i: findAdjacent(i, 64) for i in range(64)}
        fixedBoard = "".join(board).replace("?", "").replace("@", "X").replace("o","O")
        token = "X" if player == "@" else "O"
        possiblemoves, places = findMoves(fixedBoard, token, adj)
        mv = -1
        mv = bestMove(fixedBoard, possiblemoves, places, token, adj)
        mv1 = 11 + (mv // 8) * 10 + mv % 8
        best_move.value = mv1
        if fixedBoard.count(".") <=14:
            mv = negamaxTerminal(fixedBoard, token, -65, 65, adj)[-1]
            mv1 = 11 + (mv // 8) * 10 + mv % 8
            best_move.value = mv1


def negamaxTerminal(brd, token, improvable, hardBound, adjacent):
    enemy = "XO".replace(token, "")
    lm, places = findMoves(brd, token, adjacent)
    if not lm:  #we have to pass
        lm, places = findMoves(brd, enemy, adjacent)
        if not lm:
            try:
                storedScore = scoreDict[(brd,token)]
                return [storedScore, -3]  #end of game signifier
            except KeyError:
                storedScore = evalBoard(brd,token)
                scoreDict[(brd,token)] = storedScore
                scoreDict[(brd,enemy)] = -storedScore
                return [storedScore, -3]
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable, adjacent) + [-1]  #reflect across y axis, hardBound becomes improvable, improvable becomes hardBouund
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    #print(lm)
    #print("Improve: %s  Hard %s"%(improvable, hardBound))
    for mv in sorted(lm, key=lambda x: places[x]):  #80 sec
        nm = negamaxTerminal(makeMove(brd, token, mv, places), enemy, -hardBound, newHB, adjacent) + [mv]
        #print("NM for %s, %s"%(mv,nm))
        if not best or nm[0] < newHB:  #if this is the first call or there is an improvement in score but negated
            best = nm
        if nm[0] < newHB:
            newHB = nm[0]
            if -newHB > hardBound: return [-best[0]] + best[1:]  #stops and returns, pruning out branch
    return [-best[0]] + best[1:]


def main():
    game = "...........................OX......XO..........................."
    turnChar = ""
    adj = {i: findAdjacent(i, len(game)) for i in range(64)}
    if len(sys.argv) > 1:
        if len(sys.argv[1]) >= 64:
            game = "".join(i.upper() for i in sys.argv[1] if i in "xoXO.")
        elif not sys.argv[1].isdigit():
            turnChar = sys.argv[1].upper()
    if len(sys.argv) > 2 and sys.argv[2] in ("x", "o", "X", "O"):
        turnChar = sys.argv[2].upper()
    if not turnChar:
        turnChar = "X" if not game.count(".") % 2 else "O"
    possiblemoves, places = findMoves(game, turnChar, adj)
    pmDict[(game,turnChar)] = (possiblemoves, places)
    n = 14
    #print(game.count("."))
    print(makeReadable(game))
    print("Possible  moves: " + " ".join(str(i) for i in set(possiblemoves)))
    move = bestMove(game, possiblemoves, places, turnChar, adj)
    print("My heuristic choice is %d" % move)
    if game.count(".") <= n:
        start = time.time()
        print("Negamax: ", end="")
        print(negamaxTerminal(game, turnChar, -65, 65, adj))
        print("Time elapsed: %f" % (time.time()-start))
    #print(score)


if __name__ == "__main__":
    main()
