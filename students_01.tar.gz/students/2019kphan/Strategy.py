EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        import math
        import time
        depth = 3
        string = ""
        for st in board:
            string += st
        s = string.replace(OUTER,'')
        arr = [s[0:8], s[8:16], s[16:24], s[24:32], s[32:40], s[40:48], s[48:56], s[56:64]]
        matrix = []
        for x in arr:
            temp = []
            for y in x:
                temp.append(y)
            matrix.append(temp)
        p = self.getPoints(matrix, player)
        #print(matrix)
        node = (p[0], matrix)
        #start = time.time()
        #while((time.time()-start) < 30):
        while(True):
            #print("depth:", depth)
            temp = self.alphabeta(node, self.getPossibleMoves(matrix, player), depth, -math.inf, math.inf, player, True)
            x,y = temp[1]
            #print('best move:', ((y+1)*10)+x+1)
            #print(time.time()-start)
            best_move.value = ((y+1)*10)+x+1
            depth += 1

    def isPossibleMove(self, gameboard, turn, r1, c1):
        moves = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]
            #up, upper right, right, lower right, down, lower left, left, upper left
        if turn == BLACK:
            other = WHITE
        else:
            other = BLACK
        #print(gameboard)
        if gameboard[r1][c1] != EMPTY:
            return False

        posMove = ([], 0) #(list of x and y coordinates, score)

        for x, y in moves:
            flipped = []
            r, c = r1, c1
            r += x
            c += y
            count = 0
            while self.onBoard(r, c) and gameboard[r][c] == other: # if a direction possible can generate score, move to that direction to calculate score
                flipped.append((r,c))
                count+=1
                r += x
                c += y
            if self.onBoard(r,c):
                if gameboard[r][c] == turn and count > 0: # the other end has yours
                    #if posMove[1] < count: # record the move from x1, y1 (directions shown by xdirection, ydirection)
                    flipped.append((r1, c1))
                    if len(posMove[0]):
                        temp1 = flipped
                    else:
                        temp1 = posMove[0].extend(flipped)
                    temp2 = posMove[1] + count
                    posMove = (flipped, temp2)
            count = 0
        return posMove

    def onBoard(self, x, y):
        if x>=0 and x<=7 and y>=0 and y<=7:
            return True
        return False

    def getPossibleMoves(self, gameboard, turn):
        import heapq
        posMoves = []
        for x in range(0,8):
            for y in range(0,8):
                aMove = self.isPossibleMove(gameboard, turn, x, y)
                if aMove != False and aMove[1] > 0:
                    heapq.heappush(posMoves, (aMove[1], x, y, aMove[0]))
        return posMoves

    def alphabeta(self, node, posMoves, depth, a, b, turn, maximizingPlayer):
        #node is a tuple: points, gameboard
        import math
        import heapq
        #print("DEPTH:", depth, maximizingPlayer)
        if turn == BLACK:
            notTurn = WHITE
        else:
            notTurn = BLACK
        if depth == 0 or self.gameOver(node):
            return (self.heuristic(node[1], turn), node[1])
        if maximizingPlayer == True:
            bestValue = -math.inf
            bestMove = 0
            posMoves = self.getPossibleMoves(node[1], turn)
            children = self.generateChildren(node, posMoves, turn)
            #print("children", children)
            while len(children) > 0:
            #for child in children:
                child = heapq.heappop(children);
                childMoves = self.getPossibleMoves(child[1], turn)
                #print("next gameboard")
                #formatBoard(child[1])
                #print("next move")
                #print(childMoves)
                temp = self.alphabeta(child, childMoves, depth-1, a, b, notTurn, False)
                if temp[0] > bestValue:
                    bestValue = temp[0]
                    bestMove = (child[2], child[3])
                if temp[0] > a:
                    a = temp[0]
                if b <= a:
                    break
            return bestValue, bestMove
        else:
            bestValue = math.inf
            bestMove = 0
            posMoves = self.getPossibleMoves(node[1], turn)
            children = self.generateChildren(node, posMoves, turn)
            while len(children) > 0:
            #for child in children:
                child = heapq.heappop(children);
                childMoves = self.getPossibleMoves(child[1], turn)
                #print("next gameboard")
                #formatBoard(child[1])
                #print("next move")
                #print(childMoves)
                temp = self.alphabeta(child, childMoves, depth-1, a, b, notTurn, False)
                if temp[0] < bestValue:
                    bestValue = temp[0]
                    bestMove = (child[2], child[3])
                if temp[0] < b:
                    b = temp[0]
                if b <= a:
                    break
            return bestValue, bestMove

    def heuristic(self, gameboard, turn):
        if turn == BLACK:
            notTurn = WHITE
        else:
            notTurn = BLACK
        """Compares the difference in tiles."""
        mine, other = self.getPoints(gameboard, turn)
        if mine > other:
            p = (100.0 * mine)/(mine + other)
        elif mine < other:
            p = -(100.0 * other)/(mine + other)
        else:
            p = 0
        """Accounts for the mobility."""
        myMoves = len(self.getPossibleMoves(gameboard, turn))
        otherMoves = len(self.getPossibleMoves(gameboard, notTurn))
        if myMoves > otherMoves:
            m = (100.0 * myMoves)/(myMoves + otherMoves)
        elif myMoves < otherMoves:
            m = -(100.0 * otherMoves)/(myMoves + otherMoves)
        else:
            m = 0
        """Checks for corners and deducts near corners since it gives the other player more chance to flip your tiles."""
        mine = 0
        other = 0
        corners = [[0,0], [0,7], [7,0], [7,7]]
        for x,y in corners:
            if gameboard[x][y] == turn:
                mine+=1
            elif gameboard[x][y] == notTurn:
                other+=1
        c = 25 * (mine - other)

        mine = 0
        other = 0
        nearCorner = [[0,1], [1,1], [1,0], [0,7], [0,6], [1,6], [7,1], [6,1], [6,0], [6,7], [6,6], [7,6]]
        for x,y in nearCorner:
            if gameboard[x][y] == turn:
                mine+=1
            elif gameboard[x][y] == notTurn:
                other+=1
        nc = -12.5 * (mine - other)

        h = (p*10) + (m*19) + (c*800) + (nc*400)
        return h

    def gameOver(self, node):
        gameboard = node[1]
        if len(self.getPossibleMoves(gameboard, BLACK))== 0 and len(self.getPossibleMoves(gameboard, WHITE)) == 0:
            return True
        return False

    def copyBoard(self, orgBoard):
        newBoard = []
        for item in orgBoard:
            temp = []
            for sub in item:
                temp.append(sub)
            newBoard.append(temp)
        return newBoard

    def generateChildren(self, node, posMoves, turn):
        import heapq
        children = []
        for t in posMoves:
            gameboard = self.copyBoard(node[1])
            flipped = t[3]
            gameboard[t[1]][t[2]] = turn
            for x,y in flipped:
                gameboard[x][y] = turn
            points = node[0] + t[0]
            #print("move:")
            #formatBoard(gameboard)
            heapq.heappush(children, (-points, gameboard, t[1], t[2]))
        return children

    def getPoints(self, gameboard, turn):
        total1 = 0
        total2 = 0
        if turn == BLACK:
            other = WHITE
        else:
            other = BLACK
        for x in range(0, 8):
            for y in range(0, 8):
                if gameboard[x][y] == turn:
                    total1+=1
                elif gameboard[x][y] == other:
                    total2+=1
        return total1, total2

def main():
    string = '...ooo.o....o..o..@@@o@o..@@o@oooo@o@.....@@@...................'
    obj = Strategy()
    obj.best_strategy(string, BLACK, 0, None)

if  __name__ =='__main__':
    main()
    

