import time
s = time.time()
import sys
import random

leafnodes = 0
inputturn = None
def sprint(pzl):
    for x in range(8): print(*pzl[8*x:8*(x+1)])
def whoturn(q):
    if sum([1 for x in q if x == '.']) % 2 == 0:
        z = 'x'
    else:
        z = 'o'
    return z
if 'x' in sys.argv or 'X' in sys.argv:
    #print('gotem')
    inputturn = 'x'
elif 'o' in sys.argv or 'O' in sys.argv:
    inputturn = 'o'
inputpzl = [x.lower() for x in sys.argv if len(x) == 64]
if len(inputpzl)== 1:
    inputpzl = [*inputpzl[0]]
else:
    inputpzl = ['.']*64
    inputpzl[35],inputpzl[36] = 'x','o'
    inputpzl[27],inputpzl[28] = 'o','x'
if inputturn == None:
    if sum([1 for x in inputpzl if x == '.']) % 2 == 0:
        inputturn = 'x'
    else:
        inputturn = 'o'

rows = [[8*x+y for y in range(8)]for x in range(8)]
cols = [[8*y + x for y in range(8)]for x in range(8)]
#print(cols)
lddiag = [[tl+9*x for x in range(0,8-(tl%8+tl//8))] for tl in [*range(8,48,8)]+[*range(0,6)]]
#print(lddiag)
rudiag = [[tr+7*x for x in range(0,(tr%8-tr//8)+1)] for tr in [*range(2,8)]+[*range(15,48,8)]]
#print(rudiag)
nbrset = rows+cols+lddiag+rudiag
other = {'o':'x','x':'o'}
bset = {}
for p in range(0,64):
    #right
    #print(p)
    bset.update({p:[]})
    cc = p % 8
    for thing in nbrset:
        if p in thing:
            minip = thing.index(p)
            if minip != 0:
                left = thing[minip-1::-1]

                if len(left) > 1:
                    bset[p] += [left]
            right = thing[minip+1:len(thing)]

            if len(right) > 1:
                bset[p] += [right]
#print(bset)
#print(bset[16])
#for x in bset:
#    if len(bset[x]) < 2:
#        print('FAIL')
def propmove(pzl,move,turn):
    #subsets = [(nbrs,[pzl[x] for x in nbrs]) for nbrs in nbrset]
    #subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]

    #if pzl[move] == '.':
    pset = bset[move]
    approve = {move}
    #print('move' + str(move))
    for subp in pset:

        if pzl[subp[0]] == other[turn]:
            miniapprove = {subp[0]}
            check = False
            #state = True
            y = 0
            #print(subp)
            while True:
                y += 1
                #print(y)
                if y == len(subp):
                    break
                elif pzl[subp[y]] == turn:
                    check = True
                    miniapprove = miniapprove | {subp[y]}
                    break
                elif pzl[subp[y]] == other[turn]:
                    miniapprove = miniapprove | {subp[y]}
                else:
                    break

            if check == True:
                #print(miniapprove)
                approve = approve | miniapprove
    #approve = approve | {move}
    npzl = pzl[:]
    #print(approve)
    for checked in approve:

        npzl[checked] = turn
    return npzl
globallegal = {}
def legalmove(pzl,turn):
    #subsets = [(nbrs,[pzl[x] for x in nbrs]) for nbrs in nbrset]
    #subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]
    '''opzl = ''.join(pzl)
    spzl = opzl+turn
    if spzl in globallegal:
        return(globallegal[spzl])'''
    bettervalid = set()
    for x in range(0,64):
        if pzl[x] == '.':
            pset = bset[x]
            for subp in pset:
                if pzl[subp[0]] == other[turn]:
                    for y in range(1,len(subp)):
                        if pzl[subp[y]] == turn:
                            bettervalid = bettervalid | {x}
                        if pzl[subp[y]] == other[turn]:
                            continue
                        else:
                            break

    '''if spzl not in globallegal:
        globallegal.update({spzl:bettervalid})
        for xl in totalxlate:
            globallegal.update({nprint(opzl,xl):nlm(bettervalid,xl)})'''
    return bettervalid
xlate2 = [x % 64 for x in range(63,64+63)]
#p = [game[xlate[x]] for x in range(0,64)]
#nprint(game,xlate)
xlate1 = [63-x for x in range(0,64)]
totalxlate = [xlate2,xlate1]

def nprint(pzl,xlate):
    #npzl = pzl[:]
    npzl = [pzl[xlate[x]] for x in range(0,64)]
    #sprint(npzl)
    return ''.join(npzl)
def nlm(lm,xlate):
    new = {xlate[x] for x in lm}
    return new
def evalBoard(board,token):
    goodscore = sum([1 for x in board if x == token])
    badscore = sum([1 for x in board if x == other[token]])
    return goodscore - badscore

def negamaxTerm(board,token,improv,hrdb,levels,prev):
    #subsets = [(nbrs,[board[x] for x in nbrs]) for nbrs in nbrset]
    #subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]
    lm = legalmove(board,token)
    #print('legal: '+str(lm))
    #sprint(board)
    if levels == 0:
        return [evalBoard(board,token)]
    if not lm:
        if prev == 1:
            return [evalBoard(board,token)]#
        #prev = 1
        nm = negamaxTerm(board,other[token],-hrdb,-improv,levels-1,1)+[-1]
        return [-nm[0]] + nm[1:] #modify in place?
    best = []
    newhb = -improv
    for mv in lm:
        newboard = propmove(board,mv,token)
        nm = negamaxTerm(newboard,other[token],-hrdb,newhb,levels-1,0)+[mv]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0]<newhb:
                newhb = nm[0]
                if -newhb>=hrdb: return[-best[0]]+best[1:]
    return [-best[0]]+best[1:]
    #newboard = propmove()
def heuristic(pzl, turn, tvalid):
    holymoves = {*tvalid}
    corners = {0,7,56,63}

    donezo = False
    if holymoves & corners:
        holymoves = holymoves & corners
        donezo = True


    edges = [[*range(8)],[8*x+7 for x in range(8)],[8*x for x in range(8)],[56+x for x in range(8)]]
    edgemoves = {x for subedge in edges for x in subedge}
    inring = [[x+8 for x in range(8)],[8*x+6 for x in range(8)],[8*x+1 for x in range(8)],[48+x for x in range(8)]]
    inring = {x for subedge in edges for x in subedge}
    edgemovesv2 = edgemoves|inring
    #edgemovesv2 = [*edgemovesv2]
    #print(edges)
    #print(edgemoves)
    edgedict = {c:[edge for edge in edges if c in edge]for c in corners}
    edgedict = {c:edge for c, edge in edgedict.items() if sum([1 for x in tvalid if x in edge]) > 0}
    edges1 = [edge for edge in edges if sum([1 for x in tvalid if x in edge]) > 0]
    if not donezo:
        safemoves = set()
        for edge in edges1:
            pzledge = [pzl[x] for x in edge]
            lindex = 0
            rindex = 7
            if pzledge[lindex] == turn:
                while(pzledge[lindex] == turn):
                    lindex = lindex + 1
                    #if edge[lindex] in mymoves:
                        #holy = edge[lindex]
                while(pzledge[lindex] == other[turn]):
                    lindex = lindex + 1
                if pzledge[lindex] == '.':
                    #holy = edge[lindex]
                    safemoves = safemoves | {edge[lindex]}
            if pzledge[rindex] == turn:
                while(pzledge[rindex] == turn):
                    rindex = rindex - 1
                while(pzledge[rindex] == other[turn]):
                    rindex = rindex - 1
                    #if edge[rindex] in mymoves:
                        #holy = edge[lindex]
                if pzledge[rindex] == '.':
                    safemoves = safemoves | {edge[rindex]}
                    #print(type(safemoves))


        if holymoves & safemoves:
            holymoves = safemoves & holymoves
            donezo = True
    #print(edgedict)
    if not donezo:
        badmoves = set()
        cxdict = {0:{1,8,9},7:{6,14,15},56:{48,49,57},63:{54,55,62}}
        for x in corners:
            if pzl[x] != turn:
                badmoves = badmoves | cxdict[x]
        if holymoves - badmoves:
            holymoves = holymoves - badmoves
            #donezo = True

    #try not to play in the inner circle?
    if not donezo:
        if holymoves - edgemoves:
            holymoves = holymoves - edgemoves

    return random.choice([*holymoves])
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):

        inputpzl = ''.join(board).replace('?','').replace('@','x')
        inputpzl = [*inputpzl]
        inputturn = 'x' if player == '@' else 'o'

        mylegalmoves = legalmove(inputpzl,inputturn)
        if sum([1 for x in inputpzl if x == '.'])>15:
            makemove(heuristic(inputpzl,inputturn,mylegalmoves),best_move)
            #for level in range(1,15):
            #    nmreturn = negamaxTerm(inputpzl,inputturn,-65,65,level,0)
        else:
            for level in range(20,30,2):
                makemove(heuristic(inputpzl,inputturn,mylegalmoves),best_move)
                nmreturn = negamaxTerm(inputpzl,inputturn,-65,65,level,0)
                makemove(nmreturn[-1],best_move)
            #print(nmreturn)
                #print(nmreturn[-1])

            #depth += 1

#def my_search_strategy()
def makemove(mv,target):
    mv1 = 11 + (mv//8)*10+(mv%8)
    target.value = mv1

def main():
    sprint(inputpzl)
    subsets = [(nbrs,[inputpzl[x] for x in nbrs]) for nbrs in nbrset]
    subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]
    mylegalmoves = legalmove(inputpzl,inputturn)
    print("Legal Moves: "+str(mylegalmoves))
    #print(random.choice([*mylegalmoves]))
    #mine = random.choice([*mylegalmoves])
    #print(mine)
    #zboard = propmove(inputpzl,mine,inputturn)
    #sprint(zboard)
    #print(random.choice([*mylegalmoves]))
    print("Heuristic Choice: "+str(heuristic(inputpzl,inputturn,mylegalmoves)))
    n = 16
    nmreturn = None
    level = n
    if inputpzl.count('.') < n:
        for q in range(29,30,1):
            #print("Heuristic Choice: "+str(heuristic(inputpzl,inputturn,mylegalmoves)))
            nmreturn = negamaxTerm(inputpzl,inputturn,-65,65,q,0)
            goldenmove = nmreturn[-1]
        #etime = time.time()
        #dtime = etime-stime
            print("NegamaxTerm return: "+str(nmreturn))
        #print("Negamax return: "+str([50,5]))
        #print("Best Score: "+str(nmreturn[0]))
        #print("Best Move Sequence"+str(nmreturn[-1:1:-1]))
        #print("Negamax Time: "+str(dtime))
        #print("I choose move: "+str(goldenmove))
    #debug'''

if __name__ == "__main__":
    main()

#endtime = time.time();
#print('Elapsed Time: '+str(endtime-s))
