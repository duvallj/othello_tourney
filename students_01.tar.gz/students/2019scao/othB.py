import time
s = time.time()
import sys
import random


def sprint(pzl):
    for x in range(8): print(*pzl[8*x:8*(x+1)])
def whoturn(q):
    if sum([1 for x in q if x == '.']) % 2 == 0:
        z = 'x'
    else:
        z = 'o'
    return z
if len(sys.argv) == 3:

    inputpzl = [x.lower() for x in sys.argv[1]]
    inputturn = sys.argv[2].lower()
elif len(sys.argv) == 2:
#print(pzl)
    inputpzl = [x.lower() for x in sys.argv[1]]
    if sum([1 for x in inputpzl if x == '.']) % 2 == 0:

        inputturn = 'x'
    else:
        inputturn = 'o'
else:
    inputpzl = ['.']*64
    inputpzl[35],inputpzl[36] = 'x','o'
    inputpzl[27],inputpzl[28] = 'o','x'
    if sum([1 for x in inputpzl if x == '.']) % 2 == 0:
        inputturn = 'x'
    else:
        inputturn = 'o'
#print('Initial Board: ')
#print(''.join(pzl))

#('It\'s '+turn+'\'s turn')

rows = [[8*x+y for y in range(8)]for x in range(8)]
cols = [[8*y + x for y in range(8)]for x in range(8)]
#print(cols)
lddiag = [[tl+9*x for x in range(0,8-(tl%8+tl//8))] for tl in [*range(8,48,8)]+[*range(0,6)]]
#print(lddiag)
rudiag = [[tr+7*x for x in range(0,(tr%8-tr//8)+1)] for tr in [*range(2,8)]+[*range(15,48,8)]]
#print(rudiag)
nbrset = rows+cols+lddiag+rudiag
other = {'o':'x','x':'o'}

#subsets = [(nbrs,[pzl[x] for x in nbrs]) for nbrs in nbrset]
#subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]
#print(subsets)
holy = None

def propmove(pzl,move,turn,subsets):
    newpzl = pzl[:]
    approved = []
    for idxs,items in subsets:

        if move in idxs:
            #print("move found")
            #sprint(['#' if x in idxs else pzl[x] for x in range(64)])
            pos = idxs.index(move)
            items[pos] = turn
            #pzl[idxs[pos]] = turn
            rgo, lgo = [],[]
            leftcheck, rightcheck = False, False
            if pos!=len(items)-1:
                if items[pos+1]==other[turn]:
                    state = True
                    temp = pos
                    while state:
                        temp = temp+1
                        if items[temp] == turn:
                            rightcheck = True
                            state = False
                        if items[temp] == '.':
                            #rightcheck = False
                            state = False
                        if temp == len(items) -1:
                            state = False
                        if items[temp] == other[turn]:
                            rgo = rgo + [idxs[temp]]
                            #print('rgo' + str(rgo))
                            #print(type(pzl))
                            #pzl[idxs[temp]] = turn
                    if rightcheck:
                        approved = approved + rgo
            if pos!=0:
                if items[pos-1]==other[turn]:
                    state = True
                    temp = pos
                    while state:
                        temp = temp-1
                        #print(temp)
                        #print(idxs[temp])
                        if items[temp] == turn:
                            #print('lcheck')
                            leftcheck = True
                            state = False
                        if items[temp] == '.':
                            state = False
                        if temp == 0:
                            state = False
                        if items[temp] == other[turn]:
                            lgo = lgo + [idxs[temp]]
                            #print('lgo'+str(lgo))
                    if leftcheck:

                        approved = approved + lgo
            #print(approved)
    if approved:
        #print(approved)

        for x in approved:

            newpzl[x] = turn
        newpzl[move] = turn
        return newpzl
    else:
        print('bad move')
        print(move)
        return newpzl
def adjcheck(idxs,items,turn):
    valid = []

    for pos in range(len(items)):
        leftcheck, rightcheck = False, False
        if items[pos] =='.':
            if pos!=len(items)-1:
                if items[pos+1]==other[turn]:
                    state = True
                    temp = pos
                    while state:
                        temp = temp+1
                        if items[temp] == turn:
                            rightcheck = True
                            state = False
                        if items[temp] == '.':
                            rightcheck = False
                            state = False
                        if temp == len(items)-1:
                            state = False
            if pos!=0:
                if items[pos-1]==other[turn]:
                    state = True
                    temp = pos
                    while state:
                        temp = temp-1
                        if items[temp] == turn:
                            leftcheck = True
                            state = False
                        if items[temp] == '.':
                            state = False
                        if temp == 0:
                            state = False
        if leftcheck or rightcheck:
            valid = valid + [idxs[pos]]
    return valid

def legalmove1(pzl,token):
    subsets = [(nbrs,[pzl[x] for x in nbrs]) for nbrs in nbrset]
    subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]

    tvalid = []
    for idxs,items in subsets:
        tvalid = tvalid + adjcheck(idxs,items,token)
    #print(tvalid)
#tvalid = []
    holymoves = {*tvalid}
    return holymoves
def legalmove(pzl,token,subsets):
    #subsets = [(nbrs,[pzl[x] for x in nbrs]) for nbrs in nbrset]
    #subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]

    tvalid = []
    for idxs,items in subsets:
        tvalid = tvalid + adjcheck(idxs,items,token)
    #print(tvalid)
#tvalid = []
    holymoves = {*tvalid}
    return holymoves
def evalBoard(board,token):
    goodscore = sum([1 for x in board if x == token])
    badscore = sum([1 for x in board if x == other[token]])
    return goodscore - badscore
def negamax(board,token,levels,prev):
    #print(str(board)+token+str(levels))
    #print(token+'---'+whoturn(board))
    #print('board: '+''.join(board))
    #sprint(board)
    #print('l:  '+str(levels))
#if levels == -1:
        #print("last level reached")
    #    return [evalBoard(board,token)]

    subsets = [(nbrs,[board[x] for x in nbrs]) for nbrs in nbrset]
    subsets = [x for x in subsets if 'x' in {*x[1]} and 'o' in {*x[1]}]
    lm = legalmove(board,token,subsets)
    #print(lm)
    if not lm:
        #print("no legal moves")
        if prev == 1:
            return [evalBoard(board,token)]
        #prev = 1
        nm = negamax(board,other[token],levels-1,1)+[-1]
        return [-nm[0]] + nm[1:] #modify in place?

    #newboard =
    #print("newboard"+''.join(newboard))
    newboard = board[:]
    nmList = sorted([negamax(propmove(newboard,move,token,subsets),other[token],levels-1,0)+[move] for move in lm])
    #print(nmList)
    best = nmList[0]
    return [-best[0]]+best[1:]
    #return [score,last move...]
def heuristic(pzl, turn, tvalid):
    holymoves = {*tvalid}
    corners = {0,7,56,63}

    donezo = False
    if holymoves & corners:
        holymoves = holymoves & corners
        donezo = True


    edges = [[*range(8)],[8*x+7 for x in range(8)],[8*x for x in range(8)],[56+x for x in range(8)]]
    edgemoves = {x for subedge in edges for x in subedge}
    inring = [[x+8 for x in range(8)],[8*x+6 for x in range(8)],[8*x+1 for x in range(8)],[48+x for x in range(8)]]
    inring = {x for subedge in edges for x in subedge}
    edgemovesv2 = edgemoves|inring
    #edgemovesv2 = [*edgemovesv2]
    #print(edges)
    #print(edgemoves)
    edgedict = {c:[edge for edge in edges if c in edge]for c in corners}
    edgedict = {c:edge for c, edge in edgedict.items() if sum([1 for x in tvalid if x in edge]) > 0}
    edges1 = [edge for edge in edges if sum([1 for x in tvalid if x in edge]) > 0]
    if not donezo:
        safemoves = set()
        for edge in edges1:
            pzledge = [pzl[x] for x in edge]
            lindex = 0
            rindex = 7
            if pzledge[lindex] == turn:
                while(pzledge[lindex] == turn):
                    lindex = lindex + 1
                    #if edge[lindex] in mymoves:
                        #holy = edge[lindex]
                while(pzledge[lindex] == other[turn]):
                    lindex = lindex + 1
                if pzledge[lindex] == '.':
                    #holy = edge[lindex]
                    safemoves = safemoves | {edge[lindex]}
                    #print(type(safemoves))
                    #print('lms')
                    #print(holy)
            if pzledge[rindex] == turn:
                while(pzledge[rindex] == turn):
                    rindex = rindex - 1
                while(pzledge[rindex] == other[turn]):
                    rindex = rindex - 1
                    #if edge[rindex] in mymoves:
                        #holy = edge[lindex]
                if pzledge[rindex] == '.':
                    safemoves = safemoves | {edge[rindex]}
                    #print(type(safemoves))


        if holymoves & safemoves:
            holymoves = safemoves & holymoves
            donezo = True
    #print(edgedict)
    if not donezo:
        badmoves = set()
        cxdict = {0:{1,8,9},7:{6,14,15},56:{48,49,57},63:{54,55,62}}
        for x in corners:
            if pzl[x] != turn:
                badmoves = badmoves | cxdict[x]
        if holymoves - badmoves:
            holymoves = holymoves - badmoves
            donezo = True

    #try not to play in the inner circle?
    if not donezo:
        if holymoves - edgemoves:
            holymoves = holymoves - edgemoves

    return random.choice([*holymoves])
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):

        inputpzl = ''.join(board).replace('?','').replace('@','x')
        inputturn = 'x' if player == '@' else 'o'
        mylegalmoves = legalmove1(inputpzl,inputturn)
        if sum([1 for x in inputpzl if x == '.'])>8:
            makemove(heuristic(inputpzl,inputturn,mylegalmoves),best_move)
        else:
            for level in range(1,10):
                nmreturn = negamax(inputpzl,inputturn,level,0)
                makemove(nmreturn[-1],best_move)
            #print(nmreturn)
                #print(nmreturn[-1])

            #depth += 1

#def my_search_strategy()
def makemove(mv,target):
    mv1 = 11 + (mv//8)*10+(mv%8)
    target.value = mv1

def main():
    sprint(inputpzl)

    mylegalmoves = legalmove1(inputpzl,inputturn)
    print("Legal Moves: "+str(mylegalmoves))
    #print(random.choice([*mylegalmoves]))

    print("Heuristic Choice: "+str(heuristic(inputpzl,inputturn,mylegalmoves)))
    #print(random.choice([*mylegalmoves]))
    #nmreturn = negamax(inputpzl,inputturn,3)
    #if sum([1 for x in inputpzl if x == '.'])>4:
    #    print(heuristic(inputpzl,inputturn,mylegalmoves))
    #holyN = 0
    #for n in range(10):
        #print("Current N: "+str(n))
    #if no legalmoves
    #level = 8
    n = 8

    level = n
    if inputpzl.count('.') <= n:
        stime = time.time()
        nmreturn = negamax(inputpzl,inputturn,level,0)
        goldenmove = nmreturn[-1]
        etime = time.time()
        dtime = etime-stime
        print("Negamax return: "+str(nmreturn))
        #print("Best Score: "+str(nmreturn[0]))
        #print("Best Move Sequence"+str(nmreturn[-1:1:-1]))
        #print("Negamax Time: "+str(dtime))
        #print("I choose move: "+str(goldenmove))


    #print('My Move')
    #print()
    #holy = random.choice([*tvalid])
    #print(holy)
    #npzl = pzl
    #for x in tvalid: npzl[x] = '*'
    #sprint(npzl)
#else:
#    print('No Valid Moves')

if __name__ == "__main__":
    main()

#endtime = time.time();
#print('Elapsed Time: '+str(endtime-s))
