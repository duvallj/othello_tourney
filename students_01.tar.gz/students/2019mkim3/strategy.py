import Othello_Core

from multiprocessing import Value
import Othello_Core as core
import random
import math

#Mina Kim

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

# To refer to neighbor squares we can add a direction to a square.
UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)

class Strategy(core.OthelloCore):

    def squares(self):
        """List all the valid squares on the board."""
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]

    def legal_moves(self, player, board):
        """Returns list of legal moves"""
        moves = []
        for sq in self.squares():
            if self.move_is_possible(sq, player, board) and board[sq] == '.':
                moves.append(sq)
        return moves

    def move_is_possible(self, square, player, board):
        """Checks if a specific move (square) is possible"""
        opp = self.opponent(player)
        for direction in DIRECTIONS:
            pos = square + direction
            if pos not in self.squares():
                continue
            while pos in self.squares() and board[pos] == opp:
                pos += direction
                if pos not in self.squares():
                    break
                if board[pos] == player:
                    return True

    def opponent(self, player):
        """Get player's opponent piece."""
        opponent = BLACK if player == WHITE else WHITE
        return opponent

    def weighted_score(self, player, board):
        """
        Compute the difference between the sum of the weights of player's
        squares and the sum of the weights of opponent's squares.
        """
        opp = self.opponent(player)
        total = 0
        for sq in self.squares():
            if board[sq] == player:
                total += self.SQUARE_WEIGHTS[sq]
            elif board[sq] == opp:
                total -= self.SQUARE_WEIGHTS[sq]
        return total

    def make_move(self, move, player, board):
    #     """Update the board to reflect the move by the specified player."""
        board[move] = player
        for d in DIRECTIONS:
            self.flip(move, player, board, d)
        return board

    def find_bracket(self, square, player, board, direction):
        """
        Find a square that forms a bracket with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        opp = self.opponent(player)
        pos = square + direction
        if pos not in self.squares():
            return None
        while board[pos] == opp and pos in self.squares():
            pos += direction
            if pos not in self.squares():
                break
            if board[pos] == player:
                return True

    def flip(self, move, player, board, direction):
        """Flip pieces in the given direction as a result of the move by player."""
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket and square in self.squares():
            board[square] = player
            square += direction

    def score(self,player, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        minplayer = WHITE if player == BLACK else BLACK
        mincount, maxcount = 0, 0
        for square in self.squares(): #for every valid square (represented as index)
            piece = board[square]
            if piece == minplayer:
                mincount += 1
            elif piece == player:
                maxcount += 1
        count_score = maxcount- mincount

        return count_score

    def is_legal(self, move, player, board):
        """Is this a legal move for the player?"""
        moves = self.legal_moves(player, board)
        if move in moves:
            return True
        return False

    SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    # def minimax(self, player, board, depth, evaluate):
    #     """
    #     Find the best legal move for player, searching to the specified depth.
    #     Returns a tuple (move, min_score), where min_score is the guaranteed minimum
    #     score achievable for player if the move is made.
    #     """
    #     def value(board):
    #         return -self.minimax(self.opponent(player), board, depth - 1, evaluate)[0]
    #     if depth == 0:
    #         return self.weighted_score(player, board), None
    #     moves = self.legal_moves(player, board)
    #     if not moves:
    #         if len(self.legal_moves(self.opponent(player), board)) == 0:
    #             return self.final_value(player, board), None
    #         return value(board), None
    #
    #     # When there are multiple legal moves available, choose the best one by
    #     # maximizing the value of the resulting boards.
    #     return max((value(self.make_move(m, player, list(board))), m) for m in moves)


    # Values for endgame boards are big constants.
    MAX_VALUE = sum(map(abs, SQUARE_WEIGHTS))
    MIN_VALUE = -MAX_VALUE

    def final_value(self, player, board):
        """The game is over--find the value of this board to player."""
        diff = self.score(player, board)
        if diff < 0:
            return self.MIN_VALUE
        elif diff > 0:
            return self.MAX_VALUE
        return diff


    def is_terminal(self, player, board):
        """Checks if there are any legal moves left, returns boolean"""
        for sq in self.squares():
            if self.is_legal(sq, player, board):
                return False
        return True

    def weighted_moves(self, board, player):
        """returns the highest weighted move if there are possible moves"""
        moves = self.legal_moves(player, board)
        moves.sort(key = lambda val: self.SQUARE_WEIGHTS[val])
        if len(moves) == 0:
            return False
        return moves[0]

    def random_strategy(self, board, player):
        return random.choice(self.legal_moves(player, board))

    def parallel_random_strategy(self, board, player, best_move, still_running):
        best_move.value = random.choice(self.legal_moves(player, board))

    #beta is opponent's best score, alpha is my best score
    def alphabeta(self, player, board, alpha, beta, depth, evaluate):
        if depth == 0:
            return self.score(player, board), None

        #sort legal moves by weight
        moves = self.legal_moves(player, board)
        moves.sort(key=lambda x: self.SQUARE_WEIGHTS[x], reverse=True)

        #no moves left, terminate
        if not moves:
            if len(self.legal_moves(self.opponent(player), board)) == 0:
                return self.final_value(player, board), None
            return self.score(player, board), None

        best_move = moves[0]
        for move in moves:
            if alpha >= beta: #my max score, this is the best move
                break
            new_board = self.make_move(move, player, board)
            val = self.alphabeta(player, new_board, alpha, beta, depth-1, evaluate)[0]
            if val > alpha: #find move that maximizes alpha
                alpha = val
                best_move = move
        return alpha, best_move

    def best_strategy(self, board, player, best_move, still_running):
        """
        :param board: a length 100 list representing the board state
        :param player: WHITE or BLACK
        :param best_move: shared multiprocessing.Value containing an int of
                the current best move
        :param still_running: shared multiprocessing.Value containing an int
                that is 0 if the parent process intends tso kill this process
        :return: best move as an int in [11,88] or possibly 0 for 'unknown'
        """

        depth = 2
        evaluate = self.weighted_score(player, board)
        while still_running != 0:
            #best_move.value= self.weighted_moves(board, player)
            #self.parallel_random_strategy(board, player, best_move, still_running)
            #best_move.value = self.alphabeta(player, board, self.MIN_VALUE, self.MAX_VALUE, depth, evaluate)[1] #ad ab

            best_move.value = self.alphabeta(player, board, depth, self.MIN_VALUE, self.MAX_VALUE, True)[1]
            #best_move.value = self.minimax(player, board, depth, evaluate)[1]
            depth += 1

