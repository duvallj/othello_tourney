#!/usr/bin/env python3
#Sylesh Suresh
import os, sys
import urllib.request
from subprocess import call
import random
import requests
import time
import tensorflow as tf
import numpy as np
cache = {}
cacheheur = {}
xsquares = {9 : 0, 14 : 7, 49 : 56, 54 : 63}
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
origout = sys.stdout
origerr = sys.stderr
sys.stderr=open("errors.txt", "w")
positionweights = [10000, -3000, 1000, 800, 800, 1000, -3000, 10000,
-3000, -5000, -450, -500, -500, -450, -5000, -3000,
1000, -450, 30, 10, 10, 30, -450, 1000,
800, -500, 10, 50, 50, 10, -500, 800,
800, -500, 10, 50, 50, 10, -500, 800,
1000, -450, 30, 10, 10, 30, -450, 1000,
-3000, -5000, -450, -500, -500, -450, -5000, -3000,
10000, -3000, 1000, 800, 800, 1000, -3000, 10000]

class Strategy():
    def __init__(self):
        os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'
        response = requests.get('https://raw.github.com/csabadavid/asdoifj/master/simplemodel.txt', stream=True)
        handle = open("/tmp/simplemodel.txt", "wb")
        for chunk in response.iter_content(chunk_size=512):
            if chunk:
                handle.write(chunk)

    def best_strategy(self, b, token, best_move, running):
        start = time.time()
        actualboard = ''.join(b).replace("?", "").replace("@", "x")
        actualtoken = token if token == 'o' else 'x'
        legals = getLegalMoves(actualboard, actualtoken)
        mv = negamaxTerminal(actualboard, actualtoken, 3, combheuristic, -65, 65, -1, ohyes=True)[-1]
        if mv in xsquares and actualboard[xsquares[mv]] == ".":
            for i in legals:
                if i not in xsquares and not OHNO(actualboard, actualtoken, i, legals):
                    mv = i
                    break
        print("START")
        best_move.value  = 11 + (mv // 8)*10 + (mv%8)
        """
        if actualboard.count('.') in (60, 59):
            response = requests.get('https://raw.github.com/csabadavid/asdoifj/master/simplemodel.txt', stream=True)
            handle = open("simplemodel.txt", "wb")
            for chunk in response.iter_content(chunk_size=512):
                if chunk:
                    handle.write(chunk)
        """
        move = getmove(actualboard.lower(),actualtoken.lower(), legals, start)
        depth = 4
        if move == -1:
            while True: 
                move = negamaxTerminal(actualboard, actualtoken, depth, combheuristic, -65, 65, -1, ohyes=True)[-1]
                print(move)
                if not (move in xsquares and actualboard[xsquares[move]] == "."):
                    best_move.value = 11+ (move // 8)*10 + (move%8) 
                depth += 1
        best_move.value = 11+ (move // 8)*10 + (move%8) 
        print("FINISH")
        sys.stdout.close()
        sys.stdout=origout
def cornerheuristic(gameboard, token):
    me = 0
    opp = 0
    for i in [0, 7, 56, 63]:
        if gameboard[i] == token:
            me += 1
        elif gameboard[i] != ".":
            opp += 1
    return me - opp
def edgestableheuristic(gameboard, token):
    return edgestable(gameboard, token) - edgestable(gameboard, ({'x','o'}-{token}).pop())
def edgestable(gameboard, token):
    stables = 0
    if gameboard[0] == token:
        stables += 1
        for i in range(1, 8):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(7, 63, 8):
            if gameboard[i] != token:
                break
            stables += 1
    if gameboard[7] == token:
        stables += 1
        for i in range(6, -1, -1):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(15, 64, 8):
            if gameboard[i] != token:
                break
            stables += 1
    if gameboard[56] == token:
        stables += 1
        for i in range(63, 6, -8):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(57, 64):
            if gameboard[i] != token:
                break
            stables += 1
    if gameboard[63] == token:
        stables += 1
        for i in range(62, 55, -1):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(55, 6, -8):
            if gameboard[i] != token:
                break
            stables += 1
    enemy = ({'x','o'}-{token}).pop()
    if (gameboard[0] == enemy and gameboard[7] == enemy) and all([gameboard[i] != "." for i in range(0, 8)]):
        for i in range(0, 8):
            if gameboard[i] == token:
                stables += 1
    if (gameboard[0] == enemy and gameboard[56] == enemy) and all([gameboard[i] != "." for i in range(0, 57, 8)]):
        for i in range(0, 57, 8):
            if gameboard[i] == token:
                stables += 1
    if (gameboard[63] == enemy and gameboard[7] == enemy) and all([gameboard[i] != "." for i in range(7, 64, 8)]):
        for i in range(7, 64, 8):
            if gameboard[i] == token:
                stables += 1
    if (gameboard[63] == enemy and gameboard[56] == enemy) and all([gameboard[i] != "." for i in range(56, 64)]):
        for i in range(56, 64):
            if gameboard[i] == token:
                stables += 1

    return stables
def combheuristic(gameboard, token):
    if gameboard.count(token) == 0:
        return -10000
    if gameboard.count(({'x','o'}-{token}).pop()) == 0:
        return 10000
    return 0.000001*posheuristic(gameboard, token) + 1.3*frontierheuristic(gameboard, token) + 5*heuristic(gameboard, token) + 50*edgestableheuristic(gameboard, token) 
def negamax(gameboard, token, levels, heuristic, start):
    lm = getLegalMoves(gameboard, token)
    if (time.time() - start) >= 4.85 or not levels or gameboard.count('.') == 0 or gameboard.count('x') == 0 or gameboard.count('o') == 0: return [heuristic(gameboard, token)]
    if not lm:
        nm = negamax(gameboard, ({'x', 'o'}-{token}).pop(), levels-1, heuristic, start) + [-1]
        return [-1*nm[0]] + nm[1:]
    best = min([negamax(makeMove(gameboard, token, mv), ({'x','o'}-{token}).pop(), levels-1, heuristic, start) + [mv] for mv in lm])
    best[0] = -1*best[0]
    return best
def OHNO(gameboard, token, move, legals):
    lm = legals
    makemove = makeMove(gameboard, token, move)
    lm = getLegalMoves(makemove, ({'x','o'}-{token}).pop())
    if {0, 7, 56, 63} & lm:
        return True
    return False
def antitoken(board, token):
    oppval = board.count(({'x','o'}-{token}).pop())
    meval = board.count(token)
    if meval == 0:
        return -100
    if oppval == 0:
        return 100
    return 0.8*heuristic(board,token)+0.2*(oppval-meval)
def heuristic(board, token):
    if board.count(token) == 0:
        return -1000
    if board.count( ({'x','o'}-{token}).pop()) == 0:
        return 1000
    return len(getLegalMoves(board, token)) - len(getLegalMoves(board, ({'x', 'o'}-{token}).pop()))

def load():
    TFGRAPH = tf.GraphDef()
    TFGRAPH.ParseFromString(tf.gfile.GFile("/tmp/simplemodel.txt", "rb").read())
    with tf.Graph().as_default() as graph:
        tf.import_graph_def(TFGRAPH, input_map=None, return_elements=None, name="prefix", op_dict=None, producer_op_list=None)
    graphop = graph.get_operations()
    input_name, output_name = graphop[0].name+':0', graphop[-1].name+':0'
    return graph, input_name, output_name
def predict(input_data):
    tgraph,tinput,toutput = load()
    return tf.Session(graph=tgraph).run(tgraph.get_tensor_by_name(toutput) , feed_dict={tgraph.get_tensor_by_name(tinput): np.array([input_data])})
def toMatrix(binstring):
    mat = []
    for i in range(10):
        row = []
        for j in range(10):
            row.append(int(binstring[10*i + j]))
        mat.append(row)
    return mat
def combMat(a, b, c):
    finalmat = []
    for i in range(10):
        row = []
        for j in range(10):
            subrow = [a[i][j], b[i][j], c[i][j]]
            row.append(subrow)
        finalmat.append(row)
    return finalmat
def preprocess(prevboard, token, legal):
    xboard, oboard, legalboard = binify(prevboard, legal)
    if token == 'o':
        xboard, oboard= oboard, xboard
    return np.array([combMat(toMatrix(pad(xboard)), toMatrix(pad(oboard)), toMatrix(pad(legalboard)))])
def pad(binaryboardgame):
    matrix = ['0'*10] + [binaryboardgame[8*i:8*i+8] for i in range(8)] + ['0'*10]
    for i in range(1, 9):
        matrix[i] = '0' + matrix[i] + '0'
    return ''.join(matrix)
def sixtyto64():
    j = 0
    six64 = []
    for i in range(60):
        if i == 27: j += 2
        if i == 33: j += 2
        six64.append(j)
        j += 1
    return six64
def predictMain(board, token, legal, start):
    X = preprocess(board, token, legal)
    probs = predict(X[0])
    six64 = sixtyto64()
    n = np.argmax(probs)
    bestmove = six64[n]
    if probs[0][n] > 0.6:
        return bestmove
    return -1
    print(bestmove)
    if probs[0][n] < 0.2 or OHNO(board, token, bestmove, legal):
        return -1
    if probs[0][n] < 0.7 and bestmove % 8 not in (0, 7) and bestmove // 8 not in (0, 7):
        cutoff = 0.1
        okmoves = set()
        goodmoves = set()
        for i in range(60):
            if probs[0][i] > cutoff:
                mv = six64[i]
                if mv in legal:
                    if not OHNO(board, token, mv, legal):
                        if mv % 8 in (0, 7) or mv // 8 in (0, 7): 
                            goodmoves.add(mv)
                        else:
                            okmoves.add(mv)
        maxval = -1
        if len(goodmoves) == 1:
            return goodmoves.pop()
        else:
            okmoves = goodmoves
        if not okmoves:
            return -1 
        if len(okmoves) == 1 and probs[0][n] < 0.6:
            return -1
        bestmove = random.choice([*okmoves])
        if (bestmove in xsquares and board[xsquares[move]] == ".") or OHNO(board, token, bestmove, legal):
            return -1
        return bestmove
    if ((bestmove in xsquares and board[xsquares[move]] == ".") or OHNO(board, token, bestmove, legal)) and probs[0][n] < 0.9:
        return -1
    return bestmove
def binify(boardgame, legal):
    return (''.join(['1' if i in ('X', 'x') else '0' for i in boardgame]), ''.join(['1' if i in ('o', 'O') else '0' for i in boardgame]), ''.join(['1' if i in legal else '0' for i in range(len(boardgame))]))

def posheuristic(board, token):
    val = 0
    if board.count(token) == 0:
        return -100000
    enemy = ({'x','o'}-{token}).pop()
    for idx, who in enumerate(board):
        if who == token:
            val += positionweights[idx]
        elif who == enemy:
            val -= positionweights[idx]
    return val
def getmove(board, token, legals, start):
    if board.count('.') <= 8:
        return negamaxTerminal(board, token, 8, tokenheuristic, -65, 65, start)[-1]
    """
    for i in random.sample([0, 7, 56, 63], 4):
        if i in legals:
            return i
    """
    if board.count('.') >= 54:
        return -1
    csquares = {1, 6, 8, 15, 48, 57, 62, 55, 9, 14, 49, 54}
        #if move not in xsquares:
        #    return move
    move = -1
    #move = predictMain(board, token, legals, start)
    if move in legals:
        return move
    else:
        return -1
        """
        if mv in xsquares:
            for m in legals:
                if m not in xsquares:
                    return m
        """
def sortedmoves(gameboard, legals, token):
    orderedlegals = []
    corners = {0, 7, 56, 63}
    for move in legals:
        if move in corners:
            orderedlegals = [move] + orderedlegals
        else:
            orderedlegals.append(move)
    return orderedlegals
def negamaxTerminal(gameboard, token, levels, heuristic, improvable, hardBound, start, ohyes=False):
    if (start != -1 and (time.time() - start) >= 4.9) or not levels: 
        val = heuristic(gameboard, token)
        if ohyes:
            if (gameboard, token) in cacheheur:
                return cacheheur[(gameboard,token)]
            cacheheur[(gameboard,token)] = val
        return [val]
    cachereadygameboard = ''.join(gameboard)+token
    if cachereadygameboard not in cache:
        lm = getLegalMoves(gameboard, token)
        cache[cachereadygameboard] = lm
    else:
        lm = cache[cachereadygameboard]
    enemy = ({'x', 'o'} - {token}).pop()
    if not lm:
        cachereadygameboard = ''.join(gameboard)+enemy
        if cachereadygameboard not in cache:
            lm = getLegalMoves(gameboard, enemy)
            cache[cachereadygameboard] = lm
        else:
            lm = cache[cachereadygameboard]
        if not lm:
            val = heuristic(gameboard, token)
            if ohyes:
                if (gameboard, token) in cacheheur:
                    return cacheheur[(gameboard,token)]
                cacheheur[(gameboard, token)] = val
            return [val]
        nm = negamaxTerminal(gameboard, enemy, levels-1, heuristic, -hardBound, -improvable, start) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in sortedmoves(gameboard, lm, token):
        nm = negamaxTerminal(makeMove(gameboard, token, mv), enemy, levels-1, heuristic, -hardBound, newHB, start) + [mv]
        if not best or nm[0] < newHB:
            best=nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardBound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]

def mobilityheuristic(gameboard, token):
    return len(actuallegal(gameboard, token)) - len(actuallegal(gameboard, ({'x', 'o'}-{token}).pop()))
def getAdjacent(index):
    location = 1 << index
    maskedloc = mask(location)
    return shift(maskedloc, -1) | shift(maskedloc, 1) | shift(maskedloc, 7) | shift(maskedloc, -7) | shift(maskedloc, 9) | shift(maskedloc, -9) | shift(location, 8) | shift(location, -8)
    """
    locset = set()
    locstring = bitToString(final_locs)
    for idx, char in enumerate(locstring):
        if char == "1":
            locset.add(idx)
    return locset 
    """

def frontierheuristic(gameboard, token):
    if gameboard.count(token) == 0:
        return -1000
    enemy = ({'x','o'}-{token})
    me, opp = stringToBit(gameboard)
    if token == "o":
        opp, me = me, opp
    oppval = 0
    meval = 0
    for i in range(64):
        if gameboard[i] == ".":
            if me & getAdjacent(i):
                meval += 1
            if opp & getAdjacent(i):
                oppval += 1
    return oppval - meval
def tokenheuristic(gameboard, token):
    me = gameboard.count(token)
    opp = gameboard.count(({'x', 'o'}-{token.lower()}).pop())
    if gameboard.count('.') == 0 or (len(getLegalMoves(gameboard, me)) == 0 and len(getLegalMoves(gameboard, opp))) == 0:
        return 1000*(me-opp)
    return me-opp
def stringToBit(string):
    bitboardx = 0
    bitboardo = 0
    for i in string.lower():
        bitboardx = bitboardx << 1
        bitboardo = bitboardo << 1
        if i == "x":
            bitboardx += 1
        elif i == "o":
            bitboardo += 1
    return (bitboardx, bitboardo)
def bitToString(bits):
    string = str(bin(bits)[2:])
    if len(string) < 64:
        string = "0"*(64-len(string)) + string
    return string
def shift(singleboard, direction):
    #side TRUE = right: up, upright, right, downright
    #side FALSE = left: upleft, left, downleft, down
    #direction -1: left 1 right
    #direction -7: / downleft 7 upright 
    #direction -8: down 8 up
    #direction -9: \ upleft 9 downright
    return 0xFFFFFFFFFFFFFFFF & (((singleboard) >> direction) if direction > 0 else (singleboard) << -1*direction)

def shiftrep(me, opp, direction, empty):
    shifted = (shift(me, direction) & opp)
    shifted |= (shift(shifted, direction) & opp)
    shifted |= (shift(shifted, direction) & opp)
    shifted |= (shift(shifted, direction) & opp )
    shifted |= (shift(shifted, direction) & opp )
    shifted |= (shift(shifted, direction) & opp) 
    shifted |= (shift(shifted, direction) )
    return shifted & empty
def mask(board):
    return board & 0x7E7E7E7E7E7E7E7E
def boardToString(bits):
    xstring = bitToString(bits[0])
    ostring = bitToString(bits[1])
    return ''.join(["x" if xstring[i] == "1" else "o" if ostring[i] == "1" else "." for i in range(64)])
def makeMove(board, token, move):   
    boardpair = stringToBit(board)
    move = 1 << (63-move) #move - 0 topleft 63 botright
    captured = 0 
    if token == 'x':
        me, opp = boardpair
    else:
        opp, me = boardpair
    me |= move
    
    for direc in [1, -1, 7, -7, 9, -9]:
        x = shift(mask(move), direc) & opp
        x |= shift(mask(x), direc) & opp
        x |= shift(mask(x), direc) & opp
        x |= shift(mask(x), direc) & opp
        x |= shift(mask(x), direc) & opp
        x |= shift(mask(x), direc) & opp
        captured |= x if (shift(mask(x), direc) & me) else 0
    x = shift(move, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    captured |= (x if (shift(x, 8) & me) else 0)
    x = shift(move, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    captured |= (x if (shift(x, -8) & me) else 0)
    me ^= captured
    opp ^= captured
    if token == 'o':
        return boardToString((opp,me))
    return boardToString((me, opp))

def binLegalMoves(boardpair, token):
    if token == "x":
        me, opp = boardpair
    else:
        opp, me = boardpair
    mestring = bitToString(me)
    empty = ~(me | opp) 
    upright = shiftrep(me, opp, 7, empty)
    finalstring = bitToString(upright)
    maskedopp = opp & 0x7E7E7E7E7E7E7E7E
    return shiftrep(me, maskedopp, 1, empty) | shiftrep(me, maskedopp, 7, empty) | shiftrep(me, opp, 8, empty) | shiftrep(me, maskedopp, 9, empty) | shiftrep(me, maskedopp, -1, empty) | shiftrep(me, maskedopp, -7, empty) | shiftrep(me, opp, -8, empty) | shiftrep(me, maskedopp, -9, empty)
def getLegalMoves(board, token):
    legals = binLegalMoves(stringToBit(board),token)
    legalset = set()
    legalstring = bitToString(legals)
    for idx, char in enumerate(legalstring):
        if char == "1":
            legalset.add(idx)
    return legalset
"""
boardf = "x..............x.......x.......x.......x.......x.......x.......o" 
boardf = "???????????........??........??o.ooo@..??@oo@@...??.@oooo..??..@o@...??........??........???????????".replace("?","").replace("@","x")
print(boardf)
print(getLegalMoves(boardf, "x"))
print(negamaxTerminal(boardf, 'x', 3, combheuristic, -65, 65, -1))
print(getmove(boardf, "x", getLegalMoves(boardf, "x"), -1))
"""
