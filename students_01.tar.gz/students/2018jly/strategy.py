#minimax  alpha  beta
#negamax  improvable  hardBound
import sys, random, time
playerToToken = {'@': 'x', 'o': 'o'}
# board = '...........................ox......xo...........................'
# token = -1
# if len(sys.argv)==3:
#     if len(sys.argv[1])>2:
#         board = sys.argv[1]
#     elif sys.argv[1].isalpha():
#         token = sys.argv[1]
#     if len(sys.argv[2])>2:
#         board = sys.argv[2]
#     elif sys.argv[2].isalpha():
#         token = sys.argv[2]
# elif len(sys.argv)==2:
#     if len(sys.argv[1])>2:
#         board = sys.argv[1]
#     elif sys.argv[1].isalpha():
#         token = sys.argv[1]
# if token == -1:
#     if (board.count('.'))%2==0:
#        token = 'x'
#     else:
#        token = 'o'
# board = board.lower()
# token = token.lower()
corners = [0, 7, 56, 63]
cornerNbrs = {0: [1, 8, 9], 7: [6, 15, 14], 56: [48, 57, 49], 63: [62, 55, 54]}
top2, bottom2, left2, right2 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15], [63,62,61,60,59,58,57,56,55,54,53,52,51,50,49,48], [0,8,16,24,32,40,48,56,1,9,17,25,33,41,49,57], [7,15,23,31,39,47,55,63,6,14,22,30,38,46,54,62]
top, bottom, left, right = [0,1,2,3,4,5,6,7], [63,62,61,60,59,58,57,56], [0,8,16,24,32,40,48,56], [7,15,23,31,39,47,55,63]
edges = top + bottom + left + right
def opptoken(token):
    return 'o' if token=='x' else 'x'
def displayBoard(board):
    for x in range(0,64,8):
        print(board[x:x+8])
    print('\n')
def isNotLegal(board, token, pos):
    if pos in legalMoves(board, token):
        return False
    return True
def legalMoves(board,token):
    legal = set()
    opp = opptoken(token)
    opptokenPos = [x for x in range(64) if board[x] == opp]
    for pos in opptokenPos:
        if pos not in top:
            if board[pos-8]=='.':
                for move in range(pos,64,8):
                    if board[move] == '.':
                        break
                    if board[move] ==token:
                        legal.add(pos-8)
                        break
            if pos not in left and board[pos-9]=='.':
                for move in range(pos,64,9):
                    if board[move]=='.':
                        break
                    if move in right:
                        if board[move]==token:
                            legal.add(pos-9)
                        break
                    if board[move]==token:
                        legal.add(pos-9)
                        break
            if pos not in right and board[pos-7]=='.':
                for move in range(pos,64,7):
                    if board[move]=='.':
                        break
                    if move in left:
                        if board[move]==token:
                            legal.add(pos-7)
                        break
                    if board[move]==token:
                        legal.add(pos-7)
                        break
        if pos not in right:
            if board[pos+1]=='.':
                for move in range(pos,-1,-1):
                    if board[move]=='.':
                        break
                    if move in left:
                        if board[move]==token:
                            legal.add(pos+1)
                        break
                    if board[move]==token:
                        legal.add(pos+1)
                        break
        if pos not in left:
            if board[pos-1]=='.':
                for move in range(pos,64):
                    if board[move]=='.':
                        break
                    if move in right:
                        if board[move]==token:
                            legal.add(pos-1)
                        break
                    if board[move]==token:
                        legal.add(pos-1)
                        break
        if pos not in bottom:
            if board[pos+8]=='.':
                for move in range(pos,-1,-8):
                    if board[move] == '.':
                        break
                    if board[move] ==token:
                        legal.add(pos+8)
                        break
            if pos not in left and board[pos+7]=='.':
                for move in range(pos,-1,-7):
                    if board[move]=='.':
                        break
                    if move in right:
                        if board[move]==token:
                            legal.add(pos+7)
                        break
                    if board[move]==token:
                        legal.add(pos+7)
                        break
            if pos not in right and board[pos+9]=='.':
                for move in range(pos,-1,-9):
                    if board[move]=='.':
                        break
                    if move in left:
                        if board[move]==token:
                            legal.add(pos+9)
                        break
                    if board[move]==token:
                        legal.add(pos+9)
                        break
    if len(legal)==0:
        return []
    return list(legal)
def playMove(board, token, pos):
    board = board[:pos]+'*'+board[pos+1:]
    switch = []
    if pos not in top2:
        if board[pos-8]!='.'and board[pos-8]!=token: #top
            for spot in range(pos,-1,-8):
                if board[spot] == '.':
                    break
                switch.append(spot)
                if board[spot] == token and spot!=pos:
                    for x in switch:
                        board = board[:x]+token+board[x+1:]
                    break
            switch = []
        if pos not in right2:
            if board[pos-7]!='.' and board[pos-7]!=token: #top right
                for spot in range(pos,-1,-7):
                    if board[spot] == '.':
                        break
                    switch.append(spot)
                    if board[spot] == token and spot!=pos:
                        for x in switch:
                            board = board[:x]+token+board[x+1:]
                        break
            switch = []
        if pos not in left2:
            if board[pos-9]!='.' and board[pos-9]!=token: #top left
                for spot in range(pos,-1,-9):
                    if board[spot] == '.':
                        break
                    switch.append(spot)
                    if board[spot] == token and spot!=pos:
                        for x in switch:
                            board = board[:x]+token+board[x+1:]
                        break
            switch = []
    if pos not in bottom2:
        if board[pos+8]!='.'and board[pos+8]!=token: #bottom
            for spot in range(pos, 64, 8):
                if board[spot] == '.':
                    break
                switch.append(spot)
                if board[spot] == token and spot!=pos:
                    for x in switch:
                        board = board[:x]+token+board[x+1:]
                    break
            switch = []
        if pos not in left2:
            if board[pos+7]!='.' and board[pos+7]!=token: #bottom left
                for spot in range(pos, 64, 7):
                    if board[spot] == '.':
                        break
                    switch.append(spot)
                    if board[spot] == token and spot!=pos:
                        for x in switch:
                            board = board[:x]+token+board[x+1:]
                        break
                    if spot in left:
                        break
            switch = []
        if pos not in right2:
            if board[pos+9]!='.' and board[pos+9]!=token: #bottom right
                for spot in range(pos,64,9):
                    if board[spot] == '.':
                        break
                    switch.append(spot)
                    if board[spot] == token and spot!=pos:
                        for x in switch:
                            board = board[:x]+token+board[x+1:]
                        break
                    if spot in right:
                        break
            switch = []
    if pos not in right2:
        for spot in range(pos,64):
            if board[spot] == '.':
                break
            switch.append(spot)
            if board[spot] == token and spot!=pos:
                for x in switch:
                    board = board[:x]+token+board[x+1:]
                break
            if spot in right:
                break
        switch=[]
    if pos not in left2:
        for spot in range(pos,-1,-1):
            if board[spot] == '.':
                break
            switch.append(spot)
            if board[spot] == token and spot!=pos:
                for x in switch:
                    board = board[:x]+token+board[x+1:]
                break
            if spot in left:
                break
        switch=[]
    return board
def bestMove(board,token, legalMoves):
    for corner in corners:
        if corner in legalMoves:
            return corner
    for move in legalMoves:
        if move in edges:
            temp = playMove(board,token,move)
            if move in top:
                for spot in range(move, 8):
                    if temp[spot]!=token:
                        break
                    if spot==7:
                        return move
                for spot in range(move, -1, -1):
                    if temp[spot]!=token:
                        break
                    if spot==0:
                        return move
            if move in bottom:
                for spot in range(move, 64):
                    if temp[spot]!=token:
                        break
                    if spot==63:
                        return move
                for spot in range(move, 55, -1):
                    if temp[spot]!=token:
                        break
                    if spot==56:
                        return move
            if move in right:
                for spot in range(move, 6, -8):
                    if temp[spot]!=token:
                        break
                    if spot==7:
                        return move
                for spot in range(move, 64, 8):
                    if temp[spot]!=token:
                        break
                    if spot==63:
                        return move
            if move in left:
                for spot in range(move, -1, -8):
                    if temp[spot]!=token:
                        break
                    if spot==0:
                        return move
                for spot in range(move, 57, 8):
                    if temp[spot]!=token:
                        break
                    if spot==56:
                        return move
    for move in legalMoves:
        for key in cornerNbrs:
            if move in cornerNbrs[key]:
                if board[key]==token:
                    return move
    for move in legalMoves:
        if move not in edges:
            return move
    return random.choice(legalMoves)
def boardEval(board, token):
    return board.count(token)-board.count(opptoken(token))
#negamax: assumes the two sides are negatives of each other
def negamax(board, token, levels):
    enemy = opptoken(token)
    if not levels: #levels has gone down to zero
        return [boardEval(board, token)] #[score, last move, penultimate move, move before that... first move]
    lm = legalMoves(board, token)
    if not lm:
        nm = negamax(board, enemy, levels-1)+[-1]
        return [-nm[0]]+nm[1:]
    nmList = sorted([negamax(playMove(board, token, mv), enemy, levels-1)+[mv] for mv in lm])
    print(nmList)
    best = nmList[0]
    return [-best[0]] + best[1:]
def negamaxTerminal(brd, token, improvable, hardBound):
    lm = legalMoves(brd, token)
    enemy = opptoken(token)
    if not lm:
        lm = legalMoves(brd, enemy)
        if not lm: return [boardEval(brd, token), -3] #-3 indicates game over
        nm = negamaxTerminal(brd, enemy, -hardBound, -improvable)+[-1]
        return [-nm[0]]+nm[1:]
    best = [] #what gets returned
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(playMove(brd, token, mv), enemy, -hardBound, newHB)+[mv]
        if not best or nm[0]<newHB:
            best = nm
            if nm[0]<newHB:
                newHB=nm[0]
                if -newHB>=hardBound: return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]
class Strategy():
    def best_strategy(self, board, player, best_move, running):
        #print('BOARD',board)
        # myMove = 11 + (mv//8)*10 + (mv%8)
        # best_move.value = myMove
        board = ''.join(board)
        board = ''.join([board[i:i+8]for i in range(11,91,10)])
        board.replace('?','')
        board = board.replace('@', 'x')
        token = playerToToken[player]
        print("board:",board)
        #print("board len: {}".format(len(board)))
        print("legal moves {}".format(legalMoves(board, token)))
        print('token:', token)
        if board.count('.')>9:
            move=bestMove(board, token, legalMoves(board, token))
            best_move.value=11+(move//8)*10+(move%8)
        else:
            #move=negamax(board, token, 9)[9]
            boop = negamaxTerminal(board, token, -65, 65)
            move=boop[-1]
            best_move.value=11+(move//8)*10+(move%8)
        #if running.value:
            # myMove = 11 + (mv//8)*10 + (mv%8)
            # best_move.value = myMove
            # best_move.value = random.choice(legalMoves(board, player))
def main():
    board,tok=sys.argv[1],sys.argv[2]
    board = board.lower()
    tok = tok.lower()
    n=10
    displayBoard(board)
    legal = legalMoves(board,tok)
    print("Legal moves:",legal)
    if len(legal)>0:
        #if board.count('.')>n:
        print("My heuristic choice is {}".format(bestMove(board, tok, legalMoves(board, tok))))
        if board.count('.')<=n:
            boop = negamaxTerminal(board, tok, -65, 65)
            #print(boop[len(boop)-1])
            #beep = negamax(board, token, 9)
            print(boop)
            print("Negamax returns", boop[0], "and I choose move", boop[-1])
    else:
        print(-1)
if __name__=='__main__':
    main()
