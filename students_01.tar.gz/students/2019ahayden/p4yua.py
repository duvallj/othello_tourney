import sys, time
from sys import stdin
start = time.time()
#x is dark, o is light
codeIndex = [a + b for b in "12345678" for a in "abcdefgh" ]
c2i = {codeIndex[i]:i for i in range(64)}
i2c = {i:codeIndex[i] for i in range(64)}
corners = {0, 7, 56, 63}
#edges plus X pieces
xtiles = {9, 14, 49, 54}
edges = {*range(8), *range(56, 64), *range(0, 57, 8), *range(5, 64, 8)}
cornerEdges = {1: 0, 8: 0, 9: 0, 6: 7, 14: 7, 15: 7, 48: 56, 49: 56, 57: 56, 54: 63, 55:  63, 62: 63}
dir = {"N": -8, "S": 8, "E": 1, "W": -1, "NE": -7, "SE": 9, "SW": 7, "NW": -9}
stableDiscDir = {frozenset(["N", "NW", "W", "SW"]), frozenset(["N", "NW", "W", "NE"]), frozenset(["N", "NE", "E", "NW"]), frozenset(["N", "NE", "E", "SE"]), frozenset(["S", "SW", "W", "NW"]), frozenset(["S", "SW", "W", "SE"]), frozenset(["S", "SE", "E", "SW"]), frozenset(["S", "SE", "E", "NE"])}

class Strategy():

    def best_strategy(self, board, player, best_move, skill_running):
        brd = ''.join(board).replace('?', '').replace('@', 'x')
        token = 'x' if player == '@' else 'o'
        mv = findBestMove(brd, token)
        mv1 = 11 + (mv//8)*10 + (mv%8)
        best_move.value = mv1


def reverse(token):
    return 'o' if token == 'x' else 'x'

def conditional(direction, tile):
    return (tile + dir[direction]) >= 0 if direction == "N" else ((tile + dir[direction])
        <= 63 if direction == "S" else ((tile + dir[direction]) // 8 == tile // 8 if direction in ("W", "E") else (
        ((tile + dir[direction]) // 8 + 1 == tile // 8 and direction in ("NE", "NW"))
        or ((tile + dir[direction]) // 8 - 1 == tile // 8 and direction in ("SE", "SW"))
        if direction in ("NE", "NW", "SW", "SE") else False)))

def adjacent(board, index, player):
    return {direction for direction in dir if (index + dir[direction]) in range(64) and board[index + dir[direction]] == player}

def possibleMoves(board, player, end):
    opponent = 'x' if player == 'o' else 'o'
    possMoves = {}

    for tileIndex in range(64):
        if board[tileIndex] == player:
            for facing in dir:
                if (tileIndex + dir[facing]) in range(0, 64) and board[
                    tileIndex + dir[facing]] == opponent and conditional(
                        facing, tileIndex):
                    temp = tileIndex + dir[facing]
                    tiles = []
                    while board[temp] == opponent:
                        tiles.append(temp)
                        if conditional(facing, temp):
                            if temp + dir[facing] in range(64):
                                temp += dir[facing]
                            else:
                                break
                        else:
                            break
                    if board[temp] == end and temp in range(64):
                        possMoves[temp] = tiles
    for key in possMoves:
        moreTiles = check(board, key, opponent, player)
        totalTiles = {j for i in moreTiles.values() for j in i}
        possMoves[key] = totalTiles
    #print(possMoves)
    return possMoves

def check(board, tileIndex, opponent, end):
    totalTiles = {}
    for facing in dir:
        if (tileIndex + dir[facing]) in range(0, 64) and board[tileIndex + dir[facing]] == opponent and conditional(
                facing, tileIndex):
            temp = tileIndex + dir[facing]
            tiles = set()
            while board[temp] == opponent:
                tiles.add(temp)
                if conditional(facing, temp):
                    if temp + dir[facing] in range(64):
                        temp += dir[facing]
                    else:
                        break
                else:
                    break
            if board[temp] == end:
                totalTiles[temp] = tiles
    return totalTiles

def stableDisc(board, tileIndex, player):
    totalDir = set()
    for facing in dir:
        if (tileIndex + dir[facing]) in range(0, 64) and board[tileIndex + dir[facing]] == player and conditional(
                facing, tileIndex):
            temp = tileIndex + dir[facing]
            tiles = set()
            while board[temp] == player:
                tiles.add(temp)
                if conditional(facing, temp):
                    if temp + dir[facing] in range(64):
                        temp += dir[facing]
                    else:
                        break
                else:
                    break
            if board[temp] == player:
                if temp in edges:
                    totalDir.add(facing)
                    if totalDir in stableDiscDir:
                        return True
    return False

def makeMove(board, token, changeTiles, mv):
    changeTiles.add(mv)
    return "".join([token if index in changeTiles else str(board[index]) for index in range(64)])

def negamax(board, token, levels):
    if not levels: return [h_Fork(board, token)]
    lm = possibleMoves(board, token, '.')
    if not lm:
        nm = negamax(board, reverse(token), levels - 1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makeMove(board, token, lm[mv], mv), reverse(token), levels - 1) + [mv] for mv in lm.keys()])
    best = nmList[0]
    return [-best[0]] + best[1:]

def h_default(board, token):
    return len(possibleMoves(board, token, '.'))**2 - len(possibleMoves(board, reverse(token), '.'))

def h_moveAvg(board, token):
    #return len(possibleMoves(board, token, '.'))**2 - len(possibleMoves(board, reverse(token), '.'))
    p = possibleMoves(board, token, '.')
    if len(p):
        possum = 0
        for k in p:
            possum += len(p[k])
        return possum/len(p)**2
    else:
        return len(p) - len(possibleMoves(board, reverse(token), '.'))

def h_stableDiscs(board, token):
    p = possibleMoves(board, token, '.')
    if len(p):
        count = 0
        for k in p:
            if stableDisc(board, k, token):
                count += 1
        return count
    else:
        return len(p) - len(possibleMoves(board, reverse(token), '.'))

def h_Fork(board, token):
    h = 70*h_default(board, token) + 50*h_stableDiscs(board, token) + 20*h_moveAvg(board, token)
    if len([1 for x in corners if board[x] == reverse(token)]):
        h *= 0.75
    return h

def findBestMove(brd, token):
    start = time.time()
    moveTime = 2
    opponent = 'x' if token == 'o' else 'o'
    possMoves = possibleMoves(brd, token, '.')
    level = 1
    while (time.time() - start < moveTime):
        inverseCorners = {len(possMoves[key]): key for key in corners if key in possMoves}
        if len(inverseCorners):
            return (inverseCorners[max(inverseCorners.keys())])
            #break
        else:
            nm = negamax(brd, token, level)
            # print(nm)
            return (nm[-1])
            #level += 2


def main():
    start = time.time()
    moveTime = 2
    board = sys.argv[1].lower()
    humanToken = sys.argv[2].lower()
    opponent = 'x' if humanToken == 'o' else 'o'
    possMoves = possibleMoves(board, humanToken, '.')
    level = 1
    while(time.time() - start < moveTime):
        inverseCorners = {len(possMoves[key]): key for key in corners if key in possMoves}
        if len(inverseCorners):
            print(inverseCorners[max(inverseCorners.keys())])
            break
        else:
            nm = negamax(board, humanToken, level)
            #print(nm)
            print(nm[-1])
            level += 2

if __name__ == "__main__":
    main()

#num cornes/opp corners #1
#numm stable - num other stable#3
#unsafe x's - unsafe x's I have -->maximiaze 2rd most
#moves#4

