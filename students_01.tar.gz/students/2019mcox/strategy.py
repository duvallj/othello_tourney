#2/18/2018
from random import random, choice
import dbm
import json
import pickle
import math
import time
from multiprocessing import Value, Process,Manager,Queue
import os, signal
from collections import deque
silent = False
sqs=[i for i in range(100) if i%10 in range(1,9) and i//10 in range(1,9)]
sqset=set(sqs)
borders=[i for i in range(100) if i not in sqset]
borderset=set(borders)
E,W,S,N,SW,NE,SE,NW=1,-1,10,-10,9,-9,11,-11#E,W,S,N,SW,NE,SE,NW
dirs=[E,W,S,N,SW,NE,SE,NW]
dir2=[(N,S),(E,W),(NE,SW),(NW,SE)]
coorddirs=dirs[:4]
WHITE,BLACK,EMPTY,BORDER,REF='o','@','.','?','-'
startboard = [EMPTY if i in sqs else BORDER for i in range(100)]
startboard[45],startboard[54],startboard[44],startboard[55]=BLACK,BLACK,WHITE,WHITE
startboard="".join(startboard)
scoremult={BLACK:1,WHITE:-1,EMPTY:0,BORDER:0}
corners=[11,18,81,88]
csqs=[12,21,78,87,17,28,71,82]
opp={WHITE:BLACK,BLACK:WHITE}
rows=[{i for i in range(j*10+1,j*10+9)}for j in range(1,9)]
cols=[{i for i in range(j+10,j+90,10)}for j in range(1,9)]
levels=[rows[i].union(cols[i]).union(rows[7-i]).union(cols[7-i]) for i in range(4)]
wts0=[
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,#change corners to 120 to revert to original
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0
]

wts1=[
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 5000, -200,  20,   0,   0,  20, -200, 5000,   0,
    0, -200, -500,  -2,  -2,  -2,  -2, -500, -200,   0,
    0,  20,  -2,  15,   0,   0,  15,  -2,  20,   0,
    0,   0,  -2,   0,   0,   0,   0,  -2,   0,   0,
    0,   0,  -2,   0,   0,   0,   0,  -2,   0,   0,
    0,  20,  -2,  15,   0,   0,  15,  -2,  20,   0,
    0, -200, -500,  -2,  -2,  -2,  -2, -500, -200,   0,
    0, 5000, -200,  20,   0,   0,  20, -200, 5000,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0
]
wts2=[
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   0,   0,  20, -20, 120,   0,
    0, -20, -80,  -2,  -2,  -2,  -2, -80, -20,   0,
    0,  20,  -2,  15,   0,   0,  15,  -2,  20,   0,
    0,   0,  -2,   0,   0,   0,   0,  -2,   0,   0,
    0,   0,  -2,   0,   0,   0,   0,  -2,   0,   0,
    0,  20,  -2,  15,   0,   0,  15,  -2,  20,   0,
    0, -80, -40,  -2,  -2,  -2,  -2, -80, -20,   0,
    0, 120, -20,  20,   0,   0,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0
]
wts=wts1
for i in range(4):
    for j in range(i+1,4):
        levels[j]-=levels[i]
lvl2corners=[22,27,72,77]
matchcorner={lvl2corners[i]:corners[i] for i in range(4)}
Sc='score'
Ha='has'
Ne='next'
Ge='get'
Mo='move'
Mi='minmax'
fileext='.pk'
storage=pickle
binwrite='b'
filename='/tmp/othello2019mcox'
USEFILE=0
dontdelete={Sc,Ha,Ne,Ge,Mo}
class Strategy():
    def __init__(self):
        # mgr=Manager()
        # self.d = mgr.dict()
        # self.d[0] = {}
        self.ttbl = {}
        self.ttbl[Sc] = 0
        self.ttbl[Ha] = 0
        self.ttbl[Ge] = 0
        self.ttbl[Ne] = 0
        self.ttbl[Mo] = 0
        if USEFILE:
            fh = open(filename+'0'+fileext, 'w'+binwrite)
            storage.dump(self.ttbl, fh)
            fh.close()
            fh = open(filename + '.txt', 'w')
            fh.write('0')
            fh.close()
        self.n=0
        # self.d.update(self.ttbl)

    def get_valid_moves2(self,board,player):
        ind=(board,player,Ge)
        if ind not in self.ttbl:
            moves=set()
            op=opp[player]
            for i in sqs:
                if board[i]==EMPTY:
                    for j in dirs:
                        k = i+j
                        if board[k]==op:
                            while board[k]==op:
                                k+=j
                            if board[k]==player:
                                moves.add(i)
                                break
            self.ttbl[ind]=list(moves)#sorted(list(moves),key=lambda x:wts[x])
        return self.ttbl[ind]

    get_valid_moves = get_valid_moves2

    @staticmethod
    def has_valid_move(board, player):
        op = opp[player]
        for i in sqs:
            if board[i] == EMPTY:
                for j in dirs:
                    k = i + j
                    if board[k] == op:
                        while board[k] == op:
                            k += j
                        if board[k] == player:
                            return True
        return False

    def best_strategy(self,board,player,best_move,still_running):
        #best_move.value = Strategy.random_strategy(board, player)
        # self.ttbl=self.d[0]
        # self.ttbl=dict(self.d)
        if USEFILE:
            fh=open(filename + '.txt', 'r')
            n=fh.read()
            fh.close()
            self.ttbl=storage.load(open(filename+n+fileext, 'r'+binwrite))
            e=board.count('.')
            s=set()
            for i in self.ttbl:
                if isinstance(i,tuple) and i[0].count('.')>=e:
                    s.add(i)
            for i in s:
                del self.ttbl[i]
        self.n=0
        self.abstrategy(''.join(board), player, best_move,self.score_wts,verbose=0,MYPLAYER=player,sr=still_running)

    @staticmethod
    def trim(board):
        return board[11:19]+board[21:29]+board[31:33]+board[41:43]+board[51:53]+board[61:63]+board[37:39]+board[47:49]+board[57:59]+board[67:69]+board[71:79]+board[81:89]

    def score_wts(self,board,player,nPlayer):#player is who I am; nPlayer is next to move
        self.n+=1
        ind=(board,Sc)
        if ind not in self.ttbl:
            if self.game_over(board):
                return 1000000000*Strategy.score(board)
            s = 0
            ss=Strategy.safesqs(board,BLACK)|Strategy.safesqs(board,WHITE)
            E=board.count(EMPTY)
            if E not in self.ttbl:
                self.ttbl[E]=(E ** .4/2,E**1.5/11)
            e = self.ttbl[E][0]
            ee=self.ttbl[E][1]
            for i in sqs:
                if i in ss:
                    s+=(abs(wts[i] * e) +1)* scoremult[board[i]]*20###############################################Change factor
                else:
                    s += (wts[i] * e) * scoremult[board[i]]
            #nVM=(len(Strategy.get_valid_moves(board, BLACK)),len(Strategy.get_valid_moves(board, WHITE)))#number of valid moves
            #s += e * (nVM[0]/(nVM[1]+.01)-nVM[1]/(nVM[0]+.01))
            s += 10 * e * (len(self.get_valid_moves(board, BLACK)) - len(self.get_valid_moves(board, WHITE)))
            #s+=10*e*(len(Strategy.get_valid_moves(board,player))-len(Strategy.get_valid_moves(board,opp[player])))
            s += Strategy.score(board) * 5 * (1 - ee)
            self.ttbl[ind]=s
        # else:
        #     self.ttbl[Sc]+=1
            #print(len(self.ttbl))
        return self.ttbl[ind]


    @staticmethod
    def score(board):
        return board.count(BLACK)-board.count(WHITE)

    @staticmethod
    def safesqs1(board,player):
        s=set()
        for i in corners:
            if board[i]==player:
                s.add(i)
                for j in coorddirs:
                    k = i+j
                    while board[k]==player:
                        s.add(k)
                        k+=j
        for i in lvl2corners:
            if board[i]==player and (i+N in s or i//10==7) and (i+S in s or i//10==2)and (i+E in s or i%10==2) and (i+W in s or i%10==7):
                s.add(i)
                for j in coorddirs:
                    k = i + j
                    while board[k] == player:
                        s.add(k)
                        k += j
        return s

    safesqs=safesqs1


    def game_over(self,board):
        return self.next_player(board,BLACK) is None


    def make_move(self,board,player,sq):
        ind=(board,player,sq,Mo)
        if ind not in self.ttbl:
            assert board[sq]==EMPTY
            b=list(board)
            b[sq]=player
            op=opp[player]
            for i in dirs:
                k=sq+i
                while b[k]==op:
                    k+=i
                if b[k]==player:
                    k = sq + i
                    while b[k] == op:
                        b[k]=player
                        k += i
            self.ttbl[ind]="".join(b)
        return self.ttbl[ind]


    def abstrategy(self,board,player,best_move,scorefunc,maxd=10000,verbose=2,MYPLAYER=None,sr=None):
        i=1
        print(len(self.ttbl))
        while i<=board.count(EMPTY) and i<maxd:
            s=self.minmaxab(board,player,i,scorefunc,MYPLAYER=MYPLAYER,sr=sr)
            if verbose == 1: print(i)
            if verbose>1:
                print(str(i)+" "+str(s))
                print(self.n)
            assert abs(s[0]) < 64000000001
            best_move.value=s[-1]
            i+=1
            if USEFILE:
                fh = open(filename+str(i)+fileext, 'w'+binwrite)
                storage.dump(self.ttbl, fh)
                fh.close()
                fh = open(filename + '.txt', 'w')
                fh.write(str(i))
                fh.close()


    #@staticmethod
    # def abhelper(board, player,depth,scorefunc):
    #     a = {}
    #     s = Strategy.get_valid_moves(board,player)
    #     op = opp[player]
    #     if not s:
    #         return None
    #     for i in s:
    #         a[i] = Strategy.minmaxab(Strategy.make_move(board, player, i), op,depth,scorefunc)
    #     if player==WHITE:
    #         return min(s, key=lambda x: (a[x],random.random()))
    #     return max(s, key=lambda x: (a[x],random.random()))


    def minmaxab(self,board, player,depth,scorefunc, a=-1000000000000000000, b=1000000000000000000,MYPLAYER=None,sr=None):
        if player==None or depth==0:
            return (scorefunc(board,MYPLAYER,player),)
        # if sr.value==0:
        #     json.dump(self.ttbl,open("othello2019mcox.json", 'w'))
        #     sr.value=1
        #op=Strategy.next_player(board,player)
        if player == BLACK:
            mx=(-1000000000000000,0,0)
            for i in self.get_valid_moves(board,player):
                bb=self.make_move(board, player, i)
                mx = max(mx, (self.minmaxab(bb, self.next_player(bb,player),depth-1,scorefunc, a, b,MYPLAYER=MYPLAYER,sr=sr)[0],random(),i))
                a = max(a, mx[0])
                if b <= a:
                    break
            return mx
        else:
            mn = (1000000000000000,0,0)
            for i in self.get_valid_moves(board,player):
                bb = self.make_move(board, player, i)
                mn = min(mn, (self.minmaxab(bb, self.next_player(bb,player),depth-1,scorefunc, a, b,MYPLAYER=MYPLAYER,sr=sr)[0],random(),i))
                b = min(b, mn[0])
                if b <= a:
                    break
            return mn

    @staticmethod
    def get_starting_board():
        return startboard

    @staticmethod
    def printB(board):
        for i in sqs:
            if i % 10 == 1:
                print()
            print(board[i], end=" ")
        print("\n")

    def next_player(self,board,player):
        ind=(board,player,Ne)
        if ind not in self.ttbl:
            if self.has_valid_move(board,opp[player]):
                self.ttbl[ind]=opp[player]
            elif self.has_valid_move(board,player):
                self.ttbl[ind] = player
            else:
                self.ttbl[ind] = None
        return self.ttbl[ind]




