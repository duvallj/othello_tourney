
#Noah Holloway, Period 1
from Othello_Core import OthelloCore
import multiprocessing
from heapq import *
import math

indices = None
edge_size = 10
row = None
col = None
up = None
down = None
min_inf = -1000000000000000
inf = 1000000000000000

class Thing():
    value = 3


#class Strategy(OthelloCore):

class Strategy(OthelloCore):
    directions = [-11, -10, -9,
                   -1,       1,
                   9,   10,  11] #(0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1)}

    rows = [
        [11, 12, 13, 14, 15, 16, 17, 18],
        [21, 22, 23, 24, 25, 26, 27, 28],
        [31, 32, 33, 34, 35, 36, 37, 38],
        [41, 42, 43, 44, 45, 46, 47, 48],
        [51, 52, 53, 54, 55, 56, 57, 58],
        [61, 62, 63, 64, 65, 66, 67, 68],
        [71, 72, 73, 74, 75, 76, 77, 78],
        [81, 82, 83, 84, 85, 86, 87, 88]
    ]

    cols = [
        [11, 21, 31, 41, 51, 61, 71, 81],
        [12, 22, 32, 42, 52, 62, 72, 82],
        [13, 23, 33, 43, 53, 63, 73, 83],
        [14, 24, 34, 44, 54, 64, 74, 84],
        [15, 25, 35, 45, 55, 65, 75, 85],
        [16, 26, 36, 46, 56, 66, 76, 86],
        [17, 27, 37, 47, 57, 67, 77, 87],
        [18, 28, 38, 48, 58, 68, 78, 88],
    ]

    ups = [
        [11],
        [21, 12],
        [31, 22, 13],
        [41, 32, 23, 14],
        [51, 42, 33, 24, 15],
        [61, 52, 43, 34, 25, 16],
        [71, 62, 53, 44, 35, 26, 17],
        [81, 72, 63, 54, 45, 36, 27, 18],
        [82, 73, 64, 55, 46, 37, 28],
        [83, 74, 65, 56, 47, 38],
        [84, 75, 66, 57, 48],
        [85, 76, 67, 58],
        [86, 77, 68],
        [87, 78],
        [88]
    ]

    downs = [
        [18],
        [17, 28],
        [16, 27, 38],
        [15, 26, 37, 48],
        [14, 25, 36, 47, 58],
        [13, 24, 35, 46, 57, 68],
        [12, 23, 34, 45, 56, 67, 78],
        [11, 22, 33, 44, 55, 66, 77, 88],
        [21, 32, 43, 54, 65, 76, 87],
        [31, 42, 53, 64, 75, 86],
        [41, 52, 63, 74, 85],
        [51, 62, 73, 84],
        [61, 72, 83],
        [71, 82],
        [81],
    ]

    adj_mat = {
         11: [],  12: [11],         13: [12],         14: [13],           15: [16],         16: [17],         17: [18],         18: [],
        21: [11], 22: [11, 12, 21], 23: [12, 13, 22], 24: [13, 14, 23],   25: [15, 16, 26], 26: [16, 17, 27], 27: [17, 18, 28], 28: [18],
        31: [21], 32: [21, 22, 31], 33: [22, 23, 32], 34: [23, 24, 33],   35: [25, 26, 36], 36: [26, 27, 37], 37: [27, 28, 38], 38: [28],
        41: [31], 42: [31, 32, 41], 43: [32, 33, 42], 44: [33, 34, 43],   45: [35, 36, 46], 46: [36, 37, 47], 47: [37, 38, 48], 48: [38],

        51: [61], 52: [51, 61, 62], 53: [52, 62, 63], 54: [53, 63, 64],   55: [56, 65, 66], 56: [57, 66, 67], 57: [58, 67, 68], 58: [68],
        61: [71], 62: [61, 71, 72], 63: [62, 72, 73], 64: [63, 73, 74],   65: [66, 75, 76], 66: [67, 76, 77], 67: [68, 77, 78], 68: [78],
        71: [81], 72: [71, 81, 82], 73: [72, 82, 83], 74: [73, 83, 84],   75: [76, 85, 86], 76: [77, 86, 87], 77: [78, 87, 88], 78: [88],
        81: [],   82: [81],         83: [82],         84: [83],           85: [86],         86: [87],         87: [88],         88: []
    }

    top_left = [11, 12, 13, 14,
                21, 22, 23, 24,
                31, 32, 33, 34,
                41, 42, 43, 44]
    top_right = [15, 16, 17, 18,
                 25, 26, 27, 28,
                 35, 36, 37, 38,
                 45, 46, 47, 48]
    bottom_left = []

    bottom_right = [55, 56, 57, 58,
                    65, 66, 67, 68,
                    75, 76, 77, 78,
                    85, 86, 87, 88]


    spiral_board = [11, 18, 88, 81,
                    12, 17, 28, 78, 87, 82, 71, 21,
                    13, 16, 27, 38, 68, 77, 86, 83, 72, 61, 31, 22,
                    14, 15, 26, 37, 48, 58, 67, 76, 85, 84, 73, 62, 51, 41, 32, 23,
                    24, 25, 36, 47, 57, 66, 75, 74, 63, 52, 42, 33,
                    34, 35, 46, 56, 65, 64, 53, 43,
                    44, 45, 55, 54
                    ]

    spiral_bitboard = [0, 7, 63, 56,
                       1, 6, 15, 55, 63, 57, 48, 8,
                       2, 5, 14, 23, 47, 54, 61, 58, 49, 40, 16, 9,
                       3, 4, 13, 22, 31, 39, 46, 53, 60, 59, 50, 41, 32, 24, 17, 10,
                       11, 12, 21, 30, 38, 45, 52, 51, 42, 33, 25, 18,
                       19, 20, 29, 37, 44, 42, 34, 26,
                       27, 28, 36, 35
                       ]




    def best_strategy(self,
                      board, player, move, flag):

        Strategy.me = player
        for x in board:
            if x != player and x != "." and x != "?":
                Strategy.them = x
                break

        #Strategy.table = {}

        boards = self.get_bitboards(self.eightify(''.join(board)))

        #if (boards[0] & 0x810000000000000081):
        #    add_one = 1
        #else:
        #    add_one = 0

        #board = ''.join(board)

        #all_moves = self.get_moves(boards[0], boards[1])

        #a = self.all_moves_2(board_list, player)
        #print(a)
        #display(''.join(board_list))

        #Strategy.rebuild(boards[0], boards[1], 0)

        expected = -1*float('inf')

        Strategy.master_depth = bin(boards[0] & boards[1]).count("1")

        scores = {}

        #for depth in range(0):
        #for depth in range(32):
        for depth in range(32):
        #for depth in [3]:
        #for depth in [2]:
        #for depth in [3]:
            #print("[NEW] DEPTH " + str(2*depth))
            Strategy.table = {}

            temp_expect = -1*float('inf')
            temp_move = -1

            for mv in self.get_moves_pretty(boards[0], boards[1]):
                #if self.convert(mv) != 18:
                #    continue

                #Strategy.ttable = []

                #print("Looking at move: " + str(self.convert(mv)))
                new_boards = self.new_bitboard(boards[0], boards[1], mv)

                #Strategy.rebuild(new_boards[0], new_boards[1], 0)
                #display(new_board)

                Strategy.current_depth = depth * 2

                new = self.alpha_beta(new_boards[0], new_boards[1], -1*float('inf'), float('inf'), depth*2, False) #want to end on opponent's move, actually no, actually yes, actually no (mobility), actually yes (screw mobility), actually no (mobility is really important)

                #if mv in scores:
                #    new = self.mtdf(new_boards[0], new_boards[1], scores[mv], depth)
                #else:
                #    new = self.mtdf(new_boards[0], new_boards[1], 0, depth)

                #scores[mv] = new


                #new = -1*self.pvs(new_boards[1], new_boards[0], 2*depth+1, -1*float('inf'), float('inf')) #starts FALSE

                #print("Got value: " + str(new))

                if new > temp_expect:
                    temp_expect = new
                    temp_move = mv
            #print(str(temp_move) + "-> ")


            move.value = self.convert(temp_move)
            #print(move.value)

    def convert(self, num):
        d = {1: 88,
        2: 87,
        4: 86,
        8: 85,
        16: 84,
        32: 83,
        64: 82,
        128: 81,
        256: 78,
        512: 77,
        1024: 76,
        2048: 75,
        4096: 74,
        8192: 73,
        16384: 72,
        32768: 71,
        65536: 68,
        131072: 67,
        262144: 66,
        524288: 65,
        1048576: 64,
        2097152: 63,
        4194304: 62,
        8388608: 61,
        16777216: 58,
        33554432: 57,
        67108864: 56,
        134217728: 55,
        268435456: 54,
        536870912: 53,
        1073741824: 52,
        2147483648: 51,
        4294967296: 48,
        8589934592: 47,
        17179869184: 46,
        34359738368: 45,
        68719476736: 44,
        137438953472: 43,
        274877906944: 42,
        549755813888: 41,
        1099511627776: 38,
        2199023255552: 37,
        4398046511104: 36,
        8796093022208: 35,
        17592186044416: 34,
        35184372088832: 33,
        70368744177664: 32,
        140737488355328: 31,
        281474976710656: 28,
        562949953421312: 27,
        1125899906842624: 26,
        2251799813685248: 25,
        4503599627370496: 24,
        9007199254740992: 23,
        18014398509481984: 22,
        36028797018963968: 21,
        72057594037927936: 18,
        144115188075855872: 17,
        288230376151711744: 16,
        576460752303423488: 15,
        1152921504606846976: 14,
        2305843009213693952: 13,
        4611686018427387904: 12,
        9223372036854775808: 11
             }
        return d[num]

    def pvs(self, my_board, their_board, depth, alp, bet):   #my_board is NOT ALWAYS MY BOARD (switches)
        #possible_moves = self.get_moves_pretty(my_board, their_board)
        id = self.id(my_board, their_board)

        #self.rebuild(my_board,their_board, 0)

        if id in Strategy.table:
            # print("        " * (6 - depth) + "from table: " + str(Strategy.table[id]))
            return Strategy.table[id]

        if (self.game_is_done(my_board, their_board)):
            return (len(self.component_split(my_board)) - len(self.component_split(their_board))) * 2 ** 20

        if depth == 0:
            ret = self.evaluate4(my_board, their_board, depth)
            return ret

        possible_moves = self.get_moves_pretty(my_board, their_board)

        if len(possible_moves) == 0:
            return -1*self.pvs(their_board, my_board, depth - 1, -bet, -alp)
        for pos in range(len(possible_moves)):
            mov = possible_moves[pos]
            new_board = self.new_bitboard(my_board, their_board, mov)
            #b = self.new_bitboard(my_board, their_board, possible_moves[pos])
            #b = self.new_board(, children[pos], player, other)
            if pos == 0:
                score = -1*self.pvs(new_board[1], new_board[0], depth - 1, -bet, -alp)
            else:
                score = -1*self.pvs(new_board[1], new_board[0], depth - 1, -alp - 1, -alp)
                if alp < score < bet:
                    score = -1*self.pvs(new_board[1], new_board[0], depth - 1, -bet, -1*score)
            alp = max(alp, score)
            if alp > bet:
                break
        return alp

    def mtdf(self, my_board, their_board, first_guess, depth):
        g = first_guess
        epsilon = float('1000')
        delta = -1*float('1000')
        while delta < epsilon:
            temp_beta = max(g, delta+1)
            g = self.alpha_beta(my_board, their_board, temp_beta-1, temp_beta, depth, True)
            if g < temp_beta:
                epsilon = g
            else:
                delta = g
        return g

    def bns(self, my_board, their_board, depth):
        subs = self.get_moves_pretty(my_board, their_board)
        #for x in subs:
        #    print(self.convert(x))

        big = 10
        small = -10

        while True:
            test = (big+small)/2
            better = 0
            for move in subs:
                new_ = self.new_bitboard(my_board, their_board, move)

                best_val = self.alpha_beta(new_[0], new_[1], -1*test, -1*test+1, depth*2+1, False)
                if best_val >= test:
                    better += 1
                    best_move = move
            if better > 1:
                small = test
            elif better < 1:
                big = test
            if (big - small < 2) or (better == 1):
                return best_move
        #return best_move


    def alpha_beta(self, my_board, their_board, alpha, beta, depth, MAX):
        id = self.id(my_board, their_board)
        if id in Strategy.table:
            #print("        " * (6 - depth) + "from table: " + str(Strategy.table[id]))
            return Strategy.table[id]

        #print("ALPHA BETA")
        #print(board)
        #if depth < 100:
        #display_with_pad(board, 8*depth)


        #if (their_board & (1 << 0 | 1 << 7 | 1 << 56 | 1 << 63)):

        #if depth > 0:
        #Strategy.rebuild(my_board, their_board, 8 * (6 - depth))
        #print(depth)

        if (self.game_is_done(my_board, their_board)):
            return (len(self.component_split(my_board)) - len(self.component_split(their_board))) * 2 ** 20



        if depth == 0:
            #ret = self.evaluate3(my_board, their_board)
            ret = self.evaluate4(my_board, their_board, depth)
            #print("        " * (8 - depth) + "eval: " + str(ret))
            return ret

        if MAX:
            current_max = -1*float('inf')
            #for move in Strategy.all_moves_2(board, Strategy.me):
            #CHANGE: a = self.get_moves_pretty(my_board, their_board)
            #a = self.get_moves_order(my_board, their_board)
            a = self.get_moves_pretty(my_board, their_board)
            if len(a) == 0:
                return self.alpha_beta(my_board, their_board, alpha, beta, depth - 1, False)
            for move in a:
                #print(my_board)
                #print(their_board)
                #print(move)
                #current_max = max(current_max, self.alpha_beta(self.new_board(board, move, Strategy.me, Strategy.them), Strategy.them, alpha, beta, depth-1))

                next_board = self.new_bitboard(my_board, their_board, move)
                current_max = max(current_max, self.alpha_beta(next_board[0], next_board[1], alpha, beta, depth-1, False))
                alpha = max(alpha, current_max)
                if alpha >= beta:
                    break

            #if (depth >0):
            #print("        "*(6-depth)+"max: "+str(current_max))
            Strategy.table[id] = current_max
            return current_max
        else:
            current_min = 1*float('inf')
            #CHANGE: a = self.get_moves_pretty(their_board, my_board)
            #a = self.get_moves_order(their_board, my_board)
            a = self.get_moves_pretty(their_board, my_board)

            if len(a) == 0:
                return self.alpha_beta(my_board, their_board, alpha, beta, depth - 1, True)
            #for move in self.all_moves_2(board, Strategy.them):
            for move in a:
                next_board = self.new_bitboard(their_board, my_board, move)
                current_min = min(current_min, self.alpha_beta(next_board[1], next_board[0], alpha, beta, depth-1, True))
                beta = min(current_min, beta)
                if beta <= alpha:
                    break


            #if (depth > 0):
            #print("        "*(6-depth)+"min: "+str(current_min))
            Strategy.table[id] = current_min
            return current_min

    def evaluate(self, my_board, their_board):
        if my_board & 0x8100000000000081:
            # print("        " * (6 - depth) + "stable: " + str(self.stable(my_board, their_board)))
            return self.stable_2(my_board, their_board)

        # return self.spread(my_board, their_board) - self.spread(their_board, my_board)
        # return self.spread(my_board, their_board)
        # print("        " * (6 - depth) + "final: " + str(self.mobility(my_board, their_board)))
        return self.mobility(my_board, their_board)


    def evaluate2(self, my_board, their_board):
        if my_board == 0:
            return -(2**30)
        elif their_board == 0:
            return 2**30

        depth = self.num_ones(my_board | their_board)

        if (my_board & 0x8100000000000081) or depth > 50:
            return self.stable_2(my_board, their_board)


        #if depth < 30:
        #    a = self.num_ones(their_board) - self.num_ones(my_board)
        #else:
        a = self.mobility(my_board, their_board)

        return a + self.corners(my_board, their_board)
        #return self.num_ones(their_board) - self.num_ones(my_board) + self.corners(my_board, their_board)

    def evaluate3(self, my_board, their_board):
        if my_board == 0:
            return -(2**30)
        elif their_board == 0:
            return 2**30

        return self.spread(my_board, their_board)

    def evaluate4(self, my_board, their_board, now_depth):
        if my_board == 0:
            return -(2**30)
        elif their_board == 0:
            return 2**30

        actual_depth = Strategy.master_depth + Strategy.current_depth - now_depth
        if my_board & 0x8100000000000081:
            return self.stable_2(my_board, their_board)
        if actual_depth < 30:
            return self.spread(my_board, their_board) - self.spread(their_board, my_board) + self.corners(my_board, their_board) + self.mobility(my_board, their_board) / 5
            #return self.num_ones(their_board) - self.num_ones(my_board) + self.corners(my_board, their_board) + self.mobility(my_board, their_board) / 3
            #return self.mobility(my_board, their_board) + self.corners(my_board, their_board)
        elif 30 < actual_depth < 45:
            return self.mobility(my_board, their_board) + self.corners(my_board, their_board) + self.corner_spinoffs(my_board, their_board)
        else:
            return self.stable_2(my_board, their_board)


    def corners(self, my_board, their_board):
        total = 0

        for x in [1 << 0, 1 << 7, 1 << 56, 1 << 63]:
            if my_board & x:
                total += 70
            elif their_board & x:
                total -= 150

        for x in [1 << 9, 1 << 14, 1 << 49, 1 << 54]:
            if my_board & x:
                total -= 30
            elif their_board & x:
                total += 20

        for x in [1 << 1, 1 << 6, 1 << 8, 1 << 15, 1 << 48, 1 << 55, 1 << 57, 1 << 62]:
        #for x in [1 << ]
            if my_board & x:
                total -= 10
            elif their_board & x:
                total += 5


        return total

    def corner_spinoffs(self, my_board, their_board):
        mask = 0x2424E70000E72424
        union = my_board & mask

        return (self.num_ones(union)**0.5) * 5

        #total = 0
        #for x in [1 << 2, 1 << 10, 1 << 18, 1 << 17, 1 << 16, 1 << 5, 1 << 13, 1 << 21, 1 << 22, 1 << 23, 1 << 40, 1 << 41, 1 << 42, 1 << 50,
        #          1 << 58, 1 << 47, 1 << 46, 1 << 45, 1 << 53, 1 << 61, 1 <<36, 1 << 27, 1 << 28, 1 << 35]:
        #    if my_board && x:
        #        total += 1



    def stable(self, my_board, their_board):
        edge = 0xFF818181818181FF

        score = 0
        score += 16 * len(self.component_split(my_board & edge))

        b = my_board

        for i in range(5):
            b |= (b >> 1 | b << 1 | b >> 8 | b << 8 | b >> 7 | b << 7 | b >> 9 | b << 9)
            score += (2**(3-i))*self.num_ones(my_board & b)
            score -= (2**(3-i))*self.num_ones(their_board & b)

        return score


    def mobility(self, my_board, their_board):
        #self.rebuild(my_board, their_board, 0)

        mask = 0xBD3CFFFFFFFF3CBD # all except c- and x- squares
        #self.rep(mask)

        my_good = self.get_moves(my_board, their_board)
        #self.rep(my_good)

        their_good = self.get_moves(their_board, my_board)
        #self.rep(their_board)

        score = 0

        if self.num_ones(my_good) == 0:
            score += -1000
        if self.num_ones(their_good) == 0:
            score += 1000

        my_good &= mask
        their_good &= mask

        a = self.num_ones(my_good)
        b = self.num_ones(their_good)

        if a == 0:
            score += -50
        if b == 0:
            score += 50

        return score + a

    def num_ones(self, binary_string):
        c = 0
        b2 = binary_string
        while b2:
            c += (b2 & 1)
            b2 >>= 1
        return c

    def id(self, my_board, their_board):
        return my_board << 64 | their_board


    def has_corner(self, my_board, their_board):
        total = 0
        for num in [0, 7, 56, 63]:
            if my_board & 1 << num:
                total += 50
            elif their_board & 1 << num:
                total -= 99
        return total

    def game_is_done(self, my_board, their_board):
        return not ((self.get_moves(my_board, their_board) | self.get_moves(their_board, my_board)))


    def spread(self, my_board, their_board):

        total = 0

            #or board[18]==player or board[81]==player or board[88] == player):
            #return

        rows = []
        cols = []

        m = self.component_split(my_board)

        for pos in m:
            rows.append(pos//8)
            cols.append(pos%8)

        x = self.stdev(rows) if len(rows) > 2 else 0
        y = self.stdev(cols) if len(cols) > 2 else 0

        return total + 2-((x*y)**0.5)


    def stdev(self, li):
        sum = 0
        for l in li:
            sum += l
        sum = sum/len(li)


        total = 0
        for l in li:
            total += (l-sum)**2
        return (total/len(li)) ** 0.5




    def sub_new(self, board, their_board, binary_pos, direction, mask):
        new_me = board
        new_them = their_board
        #mask = 0x7E7E7E7E7E7E7E7E

        pos1 = binary_pos >> direction

        temp = 0
        if new_them & pos1:
            while new_them & pos1:
                temp |= pos1
                if pos1 & mask:
                    pos1 >>= direction
                else:
                    break
            else:
                if board & pos1:
                    new_me |= temp
                    new_them ^= temp

        pos2 = binary_pos << direction
        temp = 0
        if new_them & pos2:
            while new_them & pos2:
                temp |= pos2
                if pos2 & mask:
                    pos2 <<= direction
                else:
                    break
            else:
                if board & pos2:
                    new_me |= temp
                    new_them ^= temp

        return (new_me, new_them)




    def new_bitboard(self, my_board, their_board, binary_pos):
        #self.rep(my_board)
        #self.rep(binary_pos)
        my_board |= binary_pos
        #self.rep(my_board)
        #self.rep(their_board)
        mask = 0x7E7E7E7E7E7E7E7E
        x = self.sub_new(my_board, their_board, binary_pos, 1, mask)
        x = self.sub_new(x[0], x[1], binary_pos, 7, mask)
        x = self.sub_new(x[0], x[1], binary_pos, 8, 0xFFFFFFFFFFFFFFFF)
        x = self.sub_new(x[0], x[1], binary_pos, 9, mask)
        #for direction in [1, 7, 8, 9]:
        ##for direction in [1]:
        #    x = self.sub_new(my_board, their_board, binary_pos, direction)
        #    my_board = x[0]
        #    their_board = x[1]
        #    self.rep(my_board)
        #    self.rep(their_board)
        return x[0], x[1]

    def eightify(self, board):
        return board.replace("?","")

    def get_bitboards(self, board):
        my_board = 0
        their_board = 0

        for tile in board:
            my_board <<= 1
            their_board <<= 1
            if tile == Strategy.me:
                my_board += 1
            elif tile == Strategy.them:
                their_board += 1

        return (my_board, their_board)

    def component_split(self, b):
        a = []
        num = 0
        while b:
            if b & (1 << num):
                a.append(num)
                b ^= (1 << num)
            num += 1
        return a

    def get_moves_order(self, my_board, their_board): #looks one move ahead, sorts boards by this metric
        l = []

        for x in self.get_moves_pretty(my_board, their_board):
            temp_board = self.new_bitboard(my_board, their_board, x)
            t = self.id(temp_board[0], temp_board[1])
            if Strategy.table is not None and t in Strategy.table:
                l.append((*temp_board, Strategy.table[t]))
            else:
                y = (*temp_board, self.evaluate(temp_board[0], temp_board[1]))#)self.num_ones(self.get_moves(temp_board[0], temp_board[1]))-self.num_ones(self.get_moves(temp_board[0], temp_board[0])))
                l.append(y)


        #l.sort(key=lambda temp_thing:temp_thing[2], reverse=True)

        try:
            return sorted(l, key=lambda element:element[2], reverse=True)
        except:
            print("BADDD")
            print(my_board)
            print(their_board)
            print(l)
            return 0

    def get_moves_pretty(self, my_board, their_board):
        a = self.get_moves(my_board, their_board)
        num = 1
        ret = []
        while a:
            if a & num:
                ret.append(num)
                a ^= num
            num <<= 1
        return ret
        #return self.component_split(self.get_moves(my_board, their_board))

    @classmethod
    def rebuild(self, my_board, their_board, pad):
        st = ""

        for i in range(63, -1, -1):
            j = 1 << i
            if my_board & j:
                st += Strategy.me
            elif their_board & j:
                st += Strategy.them
            else:
                st += "."

        st2 = "?"*10
        while len(st) > 0:
            st2 += "?"+st[:8]+"?"
            st = st[8:]

        st2 += "?"*10

        display_with_pad(st2, pad)

    def get_moves(self, my_board, their_board):
        edge = 0x7E7E7E7E7E7E7E7E & their_board  # all but left- and right-most columns filled in
        edge2 = 0x00FFFFFFFFFFFF00 & their_board  # all but top and bottom rows filled in

        return self.get_sub_moves(my_board, their_board, 1, edge) | self.get_sub_moves(my_board, their_board, 8, edge2) | self.get_sub_moves(my_board, their_board, 7, edge) | self.get_sub_moves(my_board, their_board, 9, edge) # 1->left/right, 8->up/down, 7->down/right diagonal, 9->up/right diagonal

    def get_sub_moves(self, my_board, their_board, direction, valid):
        ret = ((my_board << direction | my_board >> direction) & valid)

        ret = ret | ((ret << direction | ret >> direction) & valid)
        ret = ret | ((ret << direction | ret >> direction) & valid)
        ret = ret | ((ret << direction | ret >> direction) & valid)
        ret = ret | ((ret << direction | ret >> direction) & valid)
        ret = ret | ((ret << direction | ret >> direction) & valid)

        return (ret << direction | ret >> direction) & 0xFFFFFFFFFFFFFFFF & ~(my_board|their_board)

    def stable_2(self, my_board, their_board):
        #self.rebuild(my_board, their_board, 0)
        #a = self.num_ones(self.get_stable(my_board, their_board))
        #print(a)
        #b = self.num_ones(self.get_stable(their_board, my_board))
        #print(b)

        #c = self.corners(my_board, their_board)
        #print(c)

        #print(50*a-100*b+c)

        #self.get_stable(their_board, my_board)
        return self.num_ones(self.get_stable(my_board, their_board)) * 50 - self.num_ones(self.get_stable(their_board, my_board)) * 100 + self.corners(my_board, their_board)

    def get_stable(self, my_board, their_board):
        edge = 0x7E7E7E7E7E7E7E7E
        edge2 = 0xFFFFFFFFFFFFFFFF

        #print("_"*100)
        #self.rebuild(my_board, their_board, 0)

        #return self.get_sub_stable(my_board, their_board, 1, edge)

        #r = self.get_sub_stable(my_board, their_board, 1, edge)


        #return 0
        #c = self.get_sub_stable(my_board, their_board, 8, edge2)
        #d1 = self.get_sub_stable(my_board, their_board, 7, edge)
        #d2 = self.get_sub_stable(my_board, their_board, 9, edge)

        #self.rep(r)
        #self.rep(c)
        #self.rep(d1)
        #self.rep(d2)

        return self.get_sub_stable(my_board, their_board, 1, edge) & self.get_sub_stable(my_board, their_board, 8, edge2) & self.get_sub_stable(my_board, their_board, 7, edge) & self.get_sub_stable(my_board, their_board, 9, edge)

    def get_sub_stable(self, my_board, their_board, direction, valid):


        empty = 0xFFFFFFFFFFFFFFFF & ~(my_board | their_board)

        unstable_tokens = their_board | empty

        #self.rep(unstable_tokens)
        #self.rep(empty)

        ret_bad = 0

        empty_forward = (empty & valid) >> direction

        empty_backward = (empty & valid) << direction

        #self.rep(empty_forward)
        #self.rep(empty_backward)

        # 6 times


        empty_forward = (empty_forward & valid) >> direction
        empty_backward = (empty_backward & valid) << direction
        temp_f = empty_forward & unstable_tokens
        temp_b = empty_backward & unstable_tokens
        ret_bad |= (temp_f << direction) | (temp_b >> direction)
        #print("rep")
        #self.rep(empty_forward)
        #self.rep(empty_backward)
        #self.rep(ret_bad)


        empty_forward = (empty_forward & valid) >> direction
        empty_backward = (empty_backward & valid) << direction
        temp_f = empty_forward & unstable_tokens
        temp_b = empty_backward & unstable_tokens
        ret_bad |= (temp_f << direction) | (temp_f << (direction*2)) | (temp_b >> direction) | (temp_b >> (direction*2))
        #print("rep")
        #self.rep(empty_forward)
        #self.rep(empty_backward)
        #self.rep(ret_bad)


        empty_forward = (empty_forward & valid) >> direction
        empty_backward = (empty_backward & valid) << direction
        temp_f = empty_forward & unstable_tokens
        temp_b = empty_backward & unstable_tokens
        ret_bad |= (temp_f << direction) | (temp_f << (direction*2)) | (temp_f << (direction*3)) | (temp_b >> direction) | (temp_b >> (direction*2)) | (temp_b >> (direction*3))
        #print("rep")
        #self.rep(empty_forward)
        #self.rep(empty_backward)
        #self.rep(ret_bad)



        empty_forward = (empty_forward & valid) >> direction
        empty_backward = (empty_backward & valid) << direction
        temp_f = empty_forward & unstable_tokens
        temp_b = empty_backward & unstable_tokens
        ret_bad |= (temp_f << direction) | (
                temp_f << (direction * 2)) | (
                temp_f << (direction * 3)) | (
                temp_f << (direction * 4)) | (
                temp_b >> direction) | (
                temp_b >> (direction * 2)) | (
                temp_b >> (direction * 3)) | (
                temp_b >> (direction * 4))

        #ret_bad |= ((empty_forward & unstable_tokens) << direction) | ((empty_backward & unstable_tokens) >> direction)
        #print("rep")
        #self.rep(empty_forward)
        #self.rep(empty_backward)
        #self.rep(ret_bad)


        empty_forward = (empty_forward & valid) >> direction
        empty_backward = (empty_backward & valid) << direction
        temp_f = empty_forward & unstable_tokens
        temp_b = empty_backward & unstable_tokens
        #ret_bad |= ((empty_forward & unstable_tokens) << direction) | ((empty_backward & unstable_tokens) >> direction)
        ret_bad |= (temp_f << direction) | (
                temp_f << (direction * 2)) | (
                temp_f << (direction * 3)) | (
                temp_f << (direction * 4)) | (
                temp_f << (direction * 5)) | (
                temp_b >> direction) | (
                temp_b >> (direction * 2)) | (
                temp_b >> (direction * 3)) | (
                temp_b >> (direction * 4)) | (
                temp_b >> (direction * 5))
        #print("rep")
        #self.rep(empty_forward)
        #self.rep(empty_backward)
        #self.rep(ret_bad)

        temp_f = empty_forward & unstable_tokens
        temp_b = empty_backward & unstable_tokens
        empty_forward = (empty_forward & valid) >> direction
        empty_backward = (empty_backward & valid) << direction
        #ret_bad |= ((empty_forward & unstable_tokens) << direction) | ((empty_backward & unstable_tokens) >> direction)
        ret_bad |= (temp_f << direction) | (
                temp_f << (direction * 2)) | (
                           temp_f << (direction * 3)) | (
                           temp_f << (direction * 4)) | (
                           temp_f << (direction * 5)) | (
                           temp_f << (direction * 6)) | (
                           temp_b >> direction) | (
                           temp_b >> (direction * 2)) | (
                           temp_b >> (direction * 3)) | (
                           temp_b >> (direction * 4)) | (
                           temp_b >> (direction * 5)) | (
                           temp_b >> (direction * 6))
        #print("rep")
        #self.rep(empty_forward)
        #self.rep(empty_backward)
        #self.rep(ret_bad)

        #print("FINAL")
        #self.rep(my_board & ~ret_bad)

        return my_board & ~ret_bad

    @classmethod
    def rep_pad(self, bboard, pad_num):
        y = str(bin(bboard))
        y = y.lstrip("0b")
        y = y.lstrip("-0b")
        #print(y)
        #print(len(y))
        temp = "0" * (64 - len(y))

        y = temp + y
        pad = " "*pad_num

        ret = pad + "?" * 10 + "\n"
        while len(y) > 0:
            ret = ret + pad + "?" + y[:8] + "?" + "\n"
            y = y[8:]

        ret += pad + "?"*10+"\n"

        print(ret)

    @classmethod
    def rep(self, bboard):
        Strategy.rep_pad(bboard, 0)




    def get_adj(self, pos):
        a = []
        for d in Strategy.directions:
            temp_ = pos+d
            if 0 <= temp_ < 100 and 1 <= temp_%10 < 9 and 1 <= temp_//10 < 9:
                a.append(temp_)
        return a

    @classmethod
    def combine(self, scores, board, player):
        score = 0
        for pos in range(len(board)):
            if board[pos] == player:
                score += scores[pos]
        return score


def main():
    s = Strategy()

    Strategy.table = {}

    #board = "???????????........??@.ooo..o??@@oooooo??@@@@@@@o??@@@@@o@o??@@o@@@oo??@@@@@@@o??@@@@@@@@???????????"
    #board = "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
    #board = "???????????.....@..??..o.o@.o??...o@@o@??..oooo@@??...ooo.@??..oooo..??........??........???????????"
    #board = "???????????.....@.@??..o.o@.@??...o@@o@??..ooooo@??...oooo@??..oooo..??........??........???????????"
    board = "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
    #board = "???????????........??........??........??...o@...??...@o...??....@o@.??......o.??........???????????"
    #board = "???????????........??@.ooo..o??@@oooooo??@@@@@@@o??@@@@@o@o??@@o@@@oo??@@@@@@@o??@@@@@@@@???????????"
    #board = "???????????@@@@@@@.??@@@oooo.??@@@@@o..??@@@@ooo.??@@@o@oo.??@@ooo@oo??@@@@@o..??..oooo..???????????"
    #board = "???????????@@@@@@@.??@@@oooo.??@@@@@o..??@@@@@oo.??@@@@@@o.??@@oo@@@o??@@@@@@@@??@@@@@@@.???????????"

    display(board)

    Strategy.me = "@"
    Strategy.them = "o"


    board = s.eightify(board)

    bit_boards = s.get_bitboards(board)

    #y = s.get_stable(bit_boards[0], bit_boards[1])

    #s.rep(y)

    print(s.stable_2(bit_boards[0], bit_boards[1]))

    #print(s.stable_2(bit))

    #print(s.get_moves_order(bit_boards[0], bit_boards[1]))

    move = multiprocessing.Value("i", 11)

    s.best_strategy(board, "@", move, None)
    #print(s.convert(s.bns(boards[0], boards[1], 3)))


    #print(move.value)








































def display_with_pad(board, padding):
    print("")
    temp2 = " "*padding
    c = 0
    while len(board) > 0:
        temp = board[:10]
        board = board[10:]
        print(temp2 + str(c) + " | " + ' '.join(temp))
        c += 1
    print(temp2+"   " + " _" * 10)
    print(temp2+"    0 1 2 3 4 5 6 7 8 9\n")

def display(board):
    print("")
    c = 0
    while len(board) > 0:
        temp = board[:10]
        board = board[10:]
        print(str(c) + " | " + ' '.join(temp))
        c+=1
    print("   "+" _"*10)
    print("    0 1 2 3 4 5 6 7 8 9\n")



if __name__ == '__main__':
    main()


class Deprecated:

    def minimax(self, board, player, depth, max_depth):
        # try catch terminal node
        if depth == max_depth:
            # return self.naive_heuristic(board, Strategy.them if player == Strategy.me else Strategy.me)
            return self.better_score(board, Strategy.me, Strategy.them)
        elif player == Strategy.me:
            current_max = -1 * float('inf')
            for move in self.all_moves(board, Strategy.me):
                new_max = self.minimax(self.new_board(board, move, Strategy.me, Strategy.them), Strategy.them,
                                       depth + 1, max_depth)
                if new_max > current_max:
                    current_max = new_max
            return current_max
        else:
            current_min = float('inf')
            for move in self.all_moves(board, Strategy.them):
                new_min = self.minimax(self.new_board(board, move, Strategy.them, Strategy.me), Strategy.me, depth + 1,
                                       max_depth)
                if new_min < current_min:
                    current_min = new_min
            return current_min


    def naive_heuristic(self, board, player):
        if self.game_over(board):
            p = board.count(player)
            q = (64 - board.count(".")) / 2

            # print("ayy: " + str((p-q)*10000))
            return (p - q) * 10000

        # print("byy: " + str(board.count(player)))
        return board.count(player)


    @classmethod
    def better_score(self, board, player, other_player):
        if Strategy.game_over(board):
            p = board.count(player)
            q = (64 - board.count(".")) / 2

            # print("ayy: " + str((p-q)*10000))
            return (p - q) * 10000

        if board.count(".") > 10:
            matrix = [
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 1000, -50, 40, 10, 10, 40, -50, 1000, 0,
                0, -50, -50, 20, 1, 1, 20, -50, -50, 0,
                0, 40, 20, 40, 1, 1, 40, 20, 40, 0,
                0, 10, 1, 1, 1, 1, 1, 1, 10, 0,
                0, 10, 1, 1, 1, 1, 1, 1, 10, 0,
                0, 40, 20, 40, 1, 1, 40, 20, 40, 0,
                0, -50, -50, 20, 1, 1, 20, -50, -50, 0,
                0, 1000, -50, 40, 10, 10, 40, -50, 1000, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0
            ]

            # print(len(matrix))
        else:
            matrix = [
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0
            ]
        return Strategy.combine(matrix, board, player)


    # BAAAAD TAKES C/X SQUARES
    def frontiers(self, board, player, other):
        if self.game_over(board):
            p = board.count(player)
            q = (64 - board.count(".")) / 2

            # print("ayy: " + str((p-q)*10000))
            # print("BAAAAD")
            return int(p - q) * 100000000

        matrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, -2000, 500, 500, 500, 500, -2000, 0, 0,
            0, -2000, -2000, 50, 0, 0, 50, -2000, -2000, 0,
            0, 500, 50, 50, 0, 0, 50, 50, 500, 0,
            0, 500, 0, 0, 0, 0, 0, 0, 500, 0,
            0, 500, 0, 0, 0, 0, 0, 0, 500, 0,
            0, 500, 50, 50, 0, 0, 50, 50, 500, 0,
            0, -2000, -2000, 50, 0, 0, 50, -2000, -2000, 0,
            0, 0, -2000, 500, 500, 500, 500, -2000, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        ]
        """matrix = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 100, -50, 40, 10, 10, 40, -50, 100, 0,
            0, -50, -50, 20, 1, 1, 20, -50, -50, 0,
            0, 40, 20, 40, 1, 1, 40, 20, 40, 0,
            0, 10, 1, 1, 1, 1, 1, 1, 10, 0,
            0, 10, 1, 1, 1, 1, 1, 1, 10, 0,
            0, 40, 20, 40, 1, 1, 40, 20, 40, 0,
            0, -50, -50, 20, 1, 1, 20, -50, -50, 0,
            0, 100, -50, 40, 10, 10, 40, -50, 100, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        ]"""

        if board.count(player) == 0:
            return -100000000

        # good = {}

        total = 0
        # start = [11, 18, 88, 81]
        # c = deque([11, 18, 88, 81])
        # searched = {}
        current = {11, 18, 81, 88}
        current_opp = {11, 18, 81, 88}
        for pos in Strategy.spiral_board:
            if board[pos] == player:

                good = True
                bad = True
                for adj in Strategy.adj_mat[pos]:
                    if adj in current:
                        bad = False
                    if adj not in current:
                        good = False
                        # total += matrix[pos]
                        # break
                # if bad and pos in [12, 21, 22, 17, 27, 28, 77, 78, 87, ]:
                # if bad:
                #    total += matrix[pos]*20
                if good:
                    total += 1000 + self.frontier_improved(board, pos, player, other)
                    current.add(pos)
                else:
                    total += matrix[pos]
                # else:
                #    total += 1000 + self.frontier_improved(board, pos, player, other)

            elif board[pos] == other:
                good_for_them = True
                bad_for_them = True
                for adj in Strategy.adj_mat[pos]:
                    if adj in current_opp:
                        bad_for_them = False
                    if adj not in current_opp:
                        good_for_them = False
                        # total += matrix[pos]
                        # break
                if good_for_them:
                    total -= 3000
                    current_opp.add(pos)

                if bad_for_them:
                    total -= matrix[pos]
                """if good:
                    total += 1000 + self.frontier_improved(board, pos, player, other)
                    current.add(pos)

                for adj in Strategy.adj_mat[pos]:
                    if adj not in current_opp:
                        break
                else:
                    total -= 3000
                    current_opp.add(pos)"""

        opp_moves = Strategy.all_moves(board, other)

        if len(opp_moves) == 0:
            return 100000000
        elif len(opp_moves) < 12:
            for x in opp_moves:
                if x not in [12, 22, 21, 17, 27, 28, 71, 72, 82, 77, 78, 87]:
                    break
            else:
                total += 100000

        return total
        """for pos in range(len(board)):
            if board[pos] == player:
                total += matrix[pos] + self.frontier_improved(board, pos, player, other)
            elif board[pos] == other:
                total -= matrix[pos]
        return total"""


    def frontier_wrapper(self, board, player, other):
        total = 0
        for pos in range(len(board)):
            total += self.frontier_improved(board, pos, player, other)
        return total


    def frontier_score(self, board, pos, player, other):
        return self.frontier_2(board, pos, player, other)


    def frontier_improved(self, board, pos, player, other):
        c = 0
        for direction in Strategy.directions:
            if board[pos + direction] == "?" or board[pos + direction] == player or board[pos + direction] == other:
                c += 1
        return 2 ** c


    def frontier_2(self, board, pos, player, other):
        total = 0
        for direction in Strategy.directions[:4]:
            next = pos + direction
            prev = pos - direction
            c = 0
            while board[next] == player:
                next += direction
                c += 1
            while board[prev] == player:
                prev -= direction
                c += 1

            sandwich = 0
            sandwich_good = True

            if board[prev] == ".":
                if board[next] == ".":
                    total += -1
                elif board[next] == other:
                    total += -15
                    sandwich_good = False
                elif board[next] == "?":
                    total += 30
            elif board[prev] == other:
                if board[next] == ".":
                    total += -15
                    sandwich_good = False
                elif board[next] == "?":
                    total += 15 - 2 * c
                elif board[next] == other:
                    sandwich += 1
            elif board[prev] == "?":
                if board[next] == ".":
                    total += 30
                elif board[next] == other:
                    total += 15 - 2 * c
                elif board[next] == "?":
                    total += 30

            if sandwich_good:
                if sandwich == 0:
                    total += -10
                elif sandwich == 1:
                    total += 0
                elif sandwich == 2:
                    total += 5
                elif sandwich == 3:
                    total += 40
                elif sandwich == 4:
                    total += 140

        return total

        # if board[pos2] == ".":


    def fourth_3_heuristic(self, board, player, other):
        total = 0
        for pos in range(len(board)):
            if board[pos] == player:
                for d in Strategy.directions:
                    if board[pos + d] == ".":
                        total -= 1
                    else:
                        total += 1

            elif board[pos] == other:
                for d in Strategy.directions:
                    if board[pos + d] == ".":
                        total += 1
                    else:
                        total -= 1
        return total

    # def mobility(self, my_board, their_board):
    #    return str(self.get_moves(my_board, their_board)).count("1") - str(self.get_moves(their_board, my_board)).count("1") + self.corners(my_board, their_board)
    @classmethod
    def all_moves_2(self, board, player):
        r = set()
        for s in [Strategy.rows, Strategy.cols, Strategy.ups, Strategy.downs]:
            for sub_ in s:
                # ind = [index for index, value in enumerate(sub_) if value == "."]

                segment = ''.join([board[x] for x in sub_])

                if player == "@":
                    good = Const.dict_black[segment]
                else:
                    good = Const.dict_white[segment]

                for g in good:
                    r.add(sub_[g])

                # if player in set(segment)
        return list(r)

    def alpha_star(self, board, player, other_player, move):
        # q = []
        Node.me = player
        Node.them = other_player

        a = Node(board, player, other_player, True)
        # a = self.all_moves(board, player)

        mov = a.all_moves()

        penalty = 100

        q = []
        for m in mov:
            print(m)
            # print(self.new_board(list(board), m, player, other_player))
            heappush(q, m)
            # heappush(q, (-1*self.better_wrapper(board, player, other_player), mov))

        # while not len(q) == 0:
        #    node = heappop(q)
        #    moves = self.all_moves(node, )

        print(q)
        # heapify(q)"""

