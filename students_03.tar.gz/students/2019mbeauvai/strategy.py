import sys
playertot = {'@':'x', 'o':'o'}

if len(sys.argv) == 1:
    board = '...........................ox......xo...........................'
else:
    board = sys.argv[1].lower().replace('?', '').replace('@','x')
if len(sys.argv) == 3:
    play = sys.argv[2].lower()
else:
    if board.count('.') % 2:
        play = 'o'
    else:
        play = 'x'

if play == 'x':
    play = 'x'
    opp = 'o'
else:
    opp = 'x'
    play = 'o'

ns = board.count('.')
n = 8

# 20 games run negamax with n = 1 empty position
# 20 run with n = 2 empty positions
# find until negamax cannot be run under 5 seconds; make graph and turn in monday 02/05

def matrixprint(s):
    print('\n'.join(s[i:i+8] for i in range(64) if not i % 8))

matrixprint(board)
moves = [[0,-1],[0,1],[-1,0],[1,0],[-1,1],[-1,-1],[1,-1],[1,1]]

def valid(bread, r,c,o):
    if r > 7 or c > 7 or c < 0 or r < 0:
        return False
    pos = r * 8 + c
    if bread[pos] is o:
        return True
    return False

def findmvs(boas, pl, op):
    oves = [[0, -1], [0, 1], [-1, 0], [1, 0], [-1, 1], [-1, -1], [1, -1], [1, 1]]
    succ = []
    for i in range(64):
        if boas[i] != '.':
            continue
        row = i // 8
        col = i % 8
        for k,j in oves:
            r = row + k
            c = col + j
            gin = False
            while valid(boas, r,c,op):
                gin = True
                r = r + k
                c = c + j
            if gin and r*8+c < 64 and r*8+c >= 0 and boas[r*8 + c] is pl and r <= 7 and c <= 7 and r >= 0 and c >= 0:
                succ.append(i)
    return succ

def flip(b, token, m, t, k, j):
    bo = list(b)
    i = m
    while i != t:
        bo[i] = token
        i = (i // 8 + k)*8 + i%8 + j
    return ''.join(bo)

def makemove(boar, token, o, mv):
    moves = [(0,1),(-1,0),(1,0),(0,-1),(-1,1),(-1,-1),(1,-1),(1,1)]
    for k, j in moves:
        r = mv //8 + k
        c = mv % 8 + j
        gin = False
        while valid(boar,r,c,o):
            gin = True
            r = r + k
            c = c + j
        if gin and r * 8 + c < 64 and boar[r*8+c] is token and r <= 7 and r >=0 and c <= 7 and c >= 0:
            boar = flip(boar, token, mv, r*8+c, k, j)
    return boar


def evalu(board, token, o):
    return board.count(token) - board.count(o)

def negamax(rum, token, lev):
    o = 'x'
    if token == 'x':
        token = 'x'
        o = 'o'
    if lev == 0:
        return [evalu(rum, token, o)]
    lm = set(findmvs(rum, token, o))
    if not lm:
        nm = negamax(rum, o, lev-1) + [-1]
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(makemove(rum,token,o,mv), o, lev-1) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]

def validgen(brie, r,c,token):
    if r < 0 or c < 0 or r > 7 or c > 7:
        return False
    if brie[r*8+c] == token:
        return True
    return False

def generate(bobs, c, p):
    gos = [[0,1],[0,-1],[1,0],[-1,0]]
    gen = []
    row = c // 8
    col = c % 8
    for k, j in gos:
        r = row + k
        co = col + j
        while validgen(bobs, r, co, p):
            r = r + k
            co = co + j
        if r*8+co < 64 and r*8+co >= 0 and bobs[r*8+co] == '.':
            gen.append(r*8+co)
    return gen

def heuristic(breads, play, opp):
    succ = set(findmvs(breads, play, opp))
    cx = {1, 8, 9, 6, 15, 7, 48, 49, 57, 62, 54, 55}
    corners = {0, 7, 56, 63}
    findmvs(breads, play, opp)

    for i in succ:
        if i in corners:
            return i

    for k in corners:
        if breads[k] == play:
            ls = generate(breads, k, play)
            for j in ls:
                if j in succ:
                    return j

    tor = []
    for h in succ:
        if h in cx and len(succ) > 1:
            tor += [h]
    for l in tor:
        if len(succ) > 1:
            succ.remove(l)
        if len(succ) == 1:
            return succ.pop()

    tore = []
    for j in succ:
        r = j // 8
        c = j % 8
        if r == 0 or c == 0 or r == 7 or c == 7:
            tore += [j]
    for r in tore:
        if len(succ) > 1:
            succ.remove(r)
        if len(succ) == 1:
            return succ.pop()

    return succ.pop()

def main():
    boars = board[:]
    f = set(findmvs(board,play,opp))
    print("Legal moves: ", end='')
    print(set(f))
    m = heuristic(boars, play, opp)
    print("Heuristic: ", end='')
    print(m)
    if ns <=n:
        print("Negamax: ", end='')
        if len(f) == 1:
            print(f.pop())
        else:
            nmx = negamax(board,play,board.count('.')+2)
            print(nmx)
            print(nmx[-1])

class Strategy():
    def best_strategy(self, breee, playe, best_move, still_running):
        player = playe.lower().replace('@', 'x')
        bees = ''.join(breee).replace('?', '').replace('@', 'x').lower()

        if player == 'x':
            player = 'x'
            oppon = 'o'
        else:
            oppon = 'x'
            player = 'o'
        f = set(findmvs(bees,player,oppon))

        ns = bees.count('.')
        n = 8

        if len(f) == 1:
            mre = f.pop()
            best_move.value = 11 + (mre//8)*10+(mre%8)
        else:
            moos = heuristic(bees, player, oppon)
            best_move.value = 11+ (moos//8)*10 + (moos%8)

            if ns <= n:
                nmx = negamax(bees, player, bees.count('.') + 2)
                best_move.value = 11+ (nmx[-1]//8)*10 + (nmx[-1]%8)

if __name__ == '__main__':
    main()