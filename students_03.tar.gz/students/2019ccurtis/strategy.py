import random
from random import shuffle
import math
import sys
from time import time

EMPTY, BLACK, WHITE, OUTER = '.', 'X', 'O', '?'
MOVES={}
PREPOST={}
COUNT=0
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
MIMA = {BLACK: max, WHITE: min}
WEIGHT = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
    0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
    0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
    0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
    0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
    0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
    0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def parseIn(self, l):
        board = ''
        token = ''
        for i in l[1:]:
            if len(i) == 1:
                token = i
            else:
                board = i
                for i in range(8):
                    print(board[i * 8:8 * i + 8])
        self.labc(board.upper(), token.upper())

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = ['?'] * 10 + (['?'] + ['.'] * 8 + ['?']) * 8 + ['?'] * 10
        board[44] = board[55] = BLACK
        board[45] = board[54] = WHITE
        return ''.join(board)

    def get_nice_board(self, board):
        nboard = []
        board = list(board)
        for i in range(1, 9):
            nboard += board[i * 10 + 1:i * 10 + 9] + ['\n']
        return ''.join(nboard)

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        elif player == WHITE:
            return BLACK
        elif player=='@':
          return 'o'
        elif player =='o':
          return '@'
        return None
    def isFrontier(self,board,move):
        for d in DIRECTIONS:
            if board[move+d]=='.':
                return True
        return False
    def find_match(self, board, player, square, direction):
        if board[square] != '.' or board[square + direction] != self.opponent(player):
            return False
        square += direction
        while board[square] == self.opponent(player):
            square += direction
        if board[square] == player:
            return True
        return False

    def is_move_valid(self, board, player, move):
        for d in DIRECTIONS:
            if self.find_match(board, player, move, d):
                return True
        return False

    def make_move(self, board, player, move):
        global PREPOST
        if (board,move) in PREPOST:
          return PREPOST[(board,move)]
        nboard=board
        for d in DIRECTIONS:
            nboard = self.make_match(nboard, player, move, d)
        PREPOST[(board,move)]=nboard
        return nboard
    def make_match(self, board, player, square, direction):
        nboard = list(board)
        nboard[square] = player
        square += direction
        while nboard[square] == self.opponent(player):
            nboard[square] = player
            square += direction
        if nboard[square] == player:
            return ''.join(nboard)
        return board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        global MOVES
        if board+player in MOVES:
            return MOVES[board+player]
        m=[move for move in range(len(board)) if self.is_move_valid(board, player, move)]
        MOVES[board+player]=m
        return m

    def laba(self, board, player, n=8):
        if len(board) == 64:
            board = self.padboard(board)
        mvs = self.get_valid_moves(board, player)
        print('Possible moves: ' + str([self.unpadi(i) for i in mvs]))
        mm = self.random_strategy(board, player)
        print('My heuristic: ' + str(self.unpadi(mm)))
        if len([a for a in board if a == '.']) <= n:
            bm = self.minmax_search(board, player, -1)
            print('Negamax : ' + str([bm[0]]+[self.unpadi(i) if i>-1 else i for i in bm[1:]]) + ' and my move is ' + str(self.unpadi(bm[-1])))
            return bm
        return mm
    def labc(self,board,player,n=14):
        if len(board) == 64:
            board = self.padboard(board)
        mvs = self.get_valid_moves(board, player)
        print('Possible moves: ' + str([self.unpadi(i) for i in mvs]))
        mm = self.random_strategy(board, player)
        print('My heuristic: ' + str(self.unpadi(mm)))
        if len([a for a in board if a == '.']) <= n:
            bm = self.alphabeta_search(player,board, -1,-65,65)
            print('Negamax: ' + str([bm[0]]+[self.unpadi(i) if i>-1 else i for i in bm[1:]]) + ' and my move is ' + str(self.unpadi(bm[-1])))
            return bm
        return mm
    def has_any_valid_moves(self, board, player):
        for move in range(11, 89):
            if self.is_move_valid(board, player, move):
                return True
        return False

    def next_player(self, board, prev_player):
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        p = 0
        for i in range(0, 100):
            if board[i] == player:
                p += WEIGHT[i]
            elif board[i] == self.opponent(player):
                p -= WEIGHT[i]
        return p

    def unweightedscore(self, board, player=BLACK):
        return sum([1 for move in board if move == player]) - sum(
            [1 for move in board if move == self.opponent(player)])

    def board_print(self, board):
        nboard = ''
        for i in range(1, 9):
            nboard += board[i * 10 + 1:i * 10 + 9] + '\n'
        print(nboard)

    def padboard(self, board):
        return '?' * 11 + '??'.join([board[i:i + 8] for i in range(0, len(board), 8)]) + '?' * 11

    def unpadi(self, index):
        return index - 11 - (index // 10 - 1) * 2

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if not self.has_any_valid_moves(board, player) and not self.has_any_valid_moves(board, self.opponent(player)):
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    def pvs(self,board,player,a,b,depth=-1):
        pass

    def alphabeta_strategy(self,board,player,depth=5):
        return self.alphabeta_search(player,board,depth,-65,65)[-1]
    def alphabeta_search(self,player,board,depth,alpha,beta):
        if depth==0 or self.game_over(board,player):
          return (self.unweightedscore(board,player),)
        vms=self.get_valid_moves(board,player)
        if len(vms)==0:
          mm=self.alphabeta_search(self.opponent(player),board,depth,-beta,-alpha)
          return (-mm[0],)+mm[1:]
        best=(-float('inf'),)
        vms.sort(key=lambda x:WEIGHT[x])
        for m in vms:
            next_board=self.make_move(board,player,m)
            mm=self.alphabeta_search(self.opponent(player),next_board,depth-1,-beta,-alpha)+(m,)
            mm=(-mm[0],)+mm[1:]
            best=max(best,mm)
            alpha=max(alpha,best[0])
            if alpha>=beta:
              break
        return best
    def minmax_search(self, board, player, depth):
        vms=self.get_valid_moves(board,player)
        if len(vms)==0:
            vms=self.get_valid_moves(board,self.opponent(player))
            if len(vms)==0:
                return (self.unweightedscore(board,player),)
            mm=self.minmax_search(board,self.opponent(player), depth-1)
            mm=(-mm[0],)+(-1,)+mm[1:]
            return mm
        if depth==0:
            mm=(self.score(board,player),)
            mm=(-mm[0],)+mm[1:]
            return mm
        c=[]
        for m in vms:
            next_board=self.make_move(board,player,m)
            mm=self.minmax_search(next_board,self.opponent(player),depth-1)
            mm=(-mm[0],)+mm[1:]+(m,)
            c.append(mm)
        mm=max(c)
        return mm
    def bns_strategy(self,board,player,a,b):
        stc=len(self.get_valid_moves(board,player))
        while(True):
            test=a+(b-a)*(stc-1)/stc
            bc=0
            for m in self.get_valid_moves(board,player):
                bv=-self.alphabeta_search(player,board,-1,-test,-(test-1))
                if bv >= test:
                    bc+=1
                    best=m
            #adjust a and b
            #adjust stc
            if (b-a<2) or (bc==1):
                break
        return best
    def mtd(self,board,player,f=48):
        g=board.count(player)+.75*board.count('.')
        ub=65
        lb=-65
        while lb<ub:
            b=max(g,lb+1)
            g=self.alphabeta_search(player,board, -1,b-1,b)[-1]
            if g<b:
                ub=g
            else:
                lb=g
        return g

    def minmax_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(board, player, depth)[-1]

    def laba_strategy(self, board, player, n=8):
        #mvs = self.get_valid_moves(board, player)
        mm = self.random_strategy(board, player)
        if len([a for a in board if a == '.']) <= n:
            bm = self.minmax_strategy(board, player, -1)
            return bm
        return mm
    def labc_strategy(self,board,player,n=10):
            if len([a for a in board if a == '.']) <= n:
                bm = self.alphabeta_search(player, board, -1, -65, 65)[-1]
                return bm
            mm = self.quick_strategy(board, player)
            return mm
    def random_strategy(self, board, player): 
        return random.choice(self.get_valid_moves(board, player))

    def quick_strategy(self, board, player):
        vms = self.get_valid_moves(board, player)
        return max(vms,key=lambda x: WEIGHT[x]-(20 if self.isFrontier(board,x) else 0))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board=''.join(board)
        best_move.value=self.quick_strategy(board,player)
        '''best_move.value=self.alphabeta_strategy(board,player,100)'''
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board,player,depth)
            depth += 1
    def new_strategy(self,board,player,best_move,still_running):
        board=''.join(board)
        best_move.value=self.quick_strategy(board,player)
        best_move.value=self.alphabeta_strategy(board,player,100)
    def exp_strategy(self,board,player,best_move,still_running):
        board=''.join(board)
        best_move.value=self.quick_strategy(board,player)
        best_move.value=self.mtd(board,player)

    def worst_strategy(self, board, player, best_move, still_running):
        board=''.join(board)
        best_move.value=self.random_strategy(board,player)

    standard_strategy = random_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()
        ref.board_print(ref.get_starting_board())
        # print(ref.get_valid_moves(ref.get_starting_board(),BLACK))
        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.minmax_strategy, WHITE: white.alphabeta_strategy}
        print(ref.get_nice_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_nice_board(board))
            player = ref.next_player(board, player)

        # print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.unweightedscore(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        #print("play")
        board = ref.get_starting_board()
        player = BLACK
        #print("Playing Parallel Game")
        strategy = lambda who: self.black.new_strategy if who == BLACK else self.white.worst_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_nice_board(board)+'\n'+player +'   ' +str(ref.unweightedscore(board,player)))
            player = ref.next_player(board, player)

        # print("Final Score %i." % ref.score(board), end=" ")
        #print("%s wins" % ("Black" if ref.unweightedscore(board) > 0 else "White"))
        return sum([1 for i in board if i==BLACK])/sum([1 for i in board if i==BLACK or i==WHITE])

if __name__ == "__main__":
    r=Strategy()
    #r.parseIn(sys.argv)
    print(r.alphabeta_strategy(r.get_starting_board(),'X'))
