import random
#Sheral Patel
import sys
ranges = {0:[[*range(1,8)],[*range(8,57,8)],[*range(9,64,9)]],1:[[*range(2,8)],[*range(9,58,8)],[*range(10,56,9)]],2:[[1,0],[9,16],[*range(3,8)],[*range(10,59,8)],[*range(11,48,9)]],3:[[*range(2,-1,-1)],[*range(4,8)],[*range(10,25,7)],[*range(11,60,8)],[*range(12,40,9)]],4:[[*range(5,8)],[*range(3,-1,-1)],[*range(11,33,7)],[*range(12,61,8)],[*range(13,32,9)]],5:[[*range(4,-1,-1)],[*range(6,8)],[*range(12,41,7)],[*range(13,62,8)],[14,23]],6:[[*range(5,-1,-1)],[*range(13,49,7)],[*range(14,63,8)]],
7:[[*range(6,-1,-1)],[*range(14,57,7)],[*range(15,64,8)]],8:[[*range(17,63,9)],[*range(9,16)],[*range(16,57,8)]],9:[[*range(18,64,9)],[*range(10,16)],[*range(17,58,8)]],10:[[*range(11,16)],[*range(18,59,8)],[9,8],[17,24],[*range(19,56,9)]],11:[[*range(18,33,7)],[*range(20,48,9)],[*range(12,16)],[*range(10,7,-1)],[*range(19,60,8)]],12:[[*range(19,41,7)],[*range(21,40,9)],[*range(20,61,8)],[*range(13,16)],[*range(11,7,-1)]],
13:[[*range(21,62,8)],[*range(14,16)],[*range(12,7,-1)],[*range(20,49,7)],[22,31]],14:[[*range(22,63,8)],[*range(13,7,-1)],[*range(21,57,7)]],15:[[*range(23,64,8)],[*range(15,7,-1)],[*range(22,58,7)]],16:[[8,0],[*range(17,24)],[9,2],[*range(25,62,9)],[*range(24,57,8)]],17:[[9,1],[10,3],[*range(18,24)],[*range(26,63,9)],[*range(25,58,8)]],18:[[9,0],[10,2],[11,4],[*range(19,24)],[*range(27,64,9)],[*range(26,59,8)],[25,32],[17,16]],
19:[[11,3],[12,5],[*range(20,24)],[*range(28,56,9)],[*range(27,60,8)],[*range(26,41,7)],[*range(18,15,-1)],[10,1]],20:[[12,4],[13,6],[*range(21,24)],[*range(29,48,9)],[*range(28,61,8)],[*range(27,49,7)],[*range(19,15,-1)],[11,2]],21:[[*range(20,15,-1)],[12,3],[13,5],[14,7],[22,23],[30,39],[*range(29,62,8)],[*range(28,57,7)]],22:[[13,4],[14,6],[*range(30,63,8)],[*range(29,58,7)],[*range(21,15,-1)]],23:[[14,5],[15,7],[*range(31,64,8)],[*range(30,59,7)],[*range(22,15,-1)]],
24:[[*range(16,-1,-8)],[*range(17,2,-7)],[*range(25,32)],[*range(33,61,9)],[*range(32,57,8)]],25:[[*range(17,0,-8)],[*range(26,32)],[*range(34,61,9)],[*range(33,58,8)]],26:[[18,10,2],[*range(27,32)],[19,12,5],[*range(35,63,9)],[*range(34,59,8)],[33,40],[25,24],[17,8]],27:[[*range(26,23,-1)],[*range(18,-1,-9)],[*range(19,2,-8)],[*range(20,5,-7)],[*range(28,32)],[*range(36,64,9)],[*range(35,60,8)],[*range(34,49,7)]],
28:[[*range(19,0,-9)],[*range(20,3,-8)],[*range(21,6,-7)],[*range(29,32)],[*range(37,56,9)],[*range(36,61,8)],[*range(35,57,7)],[*range(27,23,-1)]],29:[[*range(21,4,-8)],[22,15],[30,31],[38,47],[*range(37,62,8)],[*range(36,58,7)],[*range(28,23,-1)],[*range(20,1,-9)]],30:[[*range(22,5,-8)],[*range(38,63,8)],[*range(37,59,7)],[*range(29,23,-1)],[*range(21,2,-9)]],31:[[*range(23,6,-8)],[*range(39,64,8)],[*range(38,60,7)],[*range(30,23,-1)],[*range(22,3,-9)]],
32:[[*range(24,-1,-8)],[*range(33,40)],[*range(41,60,9)],[*range(40,57,8)],[*range(25,3,-7)]],33:[[*range(25,0,-8)],[*range(34,40)],[*range(42,61,9)],[*range(41,58,8)],[*range(26,4,-7)]],34:[[33,32],[25,16],[*range(26,1,-8)],[*range(35,40)],[*range(43,62,9)],[*range(27,5,-7)],[*range(42,59,8)],[41,48]],35:[[*range(34,31,-1)],[*range(26,7,-9)],[*range(27,2,-8)],[*range(28,6,-7)],[*range(36,40)],[*range(44,63,9)],[*range(43,60,8)],[*range(42,57,7)]],
36:[[*range(35,31,-1)],[*range(27,-1,-9)],[*range(28,3,-8)],[*range(29,14,-7)],[*range(37,40)],[*range(45,64,9)],[*range(44,61,8)],[*range(43,58,7)]],37:[[*range(36,31,-1)],[*range(28,0,-9)],[*range(29,4,-8)],[30,23],[38,39],[46,55],[*range(45,62,8)],[*range(44,59,7)]],38:[[*range(37,31,-1)],[*range(29,1,-9)],[*range(30,5,-8)],[*range(46,63,8)],[*range(45,50,7)]],39:[[*range(31,6,-8)],[*range(30,2,-9)],[*range(38,31,-1)],[*range(46,61,7)],[*range(47,64,8)]],
40:[[*range(32,-1,-8)],[*range(33,4,-7)],[*range(41,48)],[49,58],[48,56]],41:[[33,0,-8],[*range(34,5,-7)],[*range(42,48)],[50,59],[49,57]],42:[[41,40],[33,24],[*range(35,6,-7)],[*range(34,1,-8)],[*range(43,48)],[51,60],[50,58],[49,56]],43:[[*range(42,39,-1)],[*range(34,15,-9)],[*range(35,2,-8)],[*range(36,14,-7)],[*range(44,48)],[52,61],[51,59],[50,57]],44:[[*range(43,39,-1)],[*range(35,7,-9)],[*range(36,3,-8)],[*range(37,22,-7)],[*range(45,48)],[53,62],[52,60],[51,58]],
45:[[*range(44,39,-1)],[*range(36,-1,-9)],[*range(37,4,-8)],[38,31],[46,47],[54,63],[53,61],[52,59]],46:[[*range(45,39,-1)],[*range(37,0,-9)],[*range(38,5,-8)],[53,60],[54,62]],47:[[*range(46,39,-1)],[*range(38,1,-9)],[*range(39,6,-8)],[55,63],[54,61]],48:[[*range(40,-1,-8)],[*range(41,5,-7)],[*range(49,56)]],49:[[*range(41,0,-8)],[*range(42,6,-7)],[*range(50,56)]],50:[[49,48],[41,32],[*range(42,1,-8)],[*range(43,14,-7)],[*range(51,56)]],
51:[[*range(50,47,-1)],[*range(42,23,-9)],[*range(43,2,-8)],[*range(44,22,-7)],[*range(52,56)]],52:[[*range(51,47,-1)],[*range(43,15,-9)],[*range(44,3,-8)],[*range(45,30,-7)],[*range(53,56)]],53:[[*range(52,47,-1)],[*range(44,7,-9)],[*range(45,4,-8)],[46,39],[54,55]],54:[[*range(53,47,-1)],[*range(45,-1,-9)],[*range(46,5,-8)]],55:[[*range(54,47,-1)],[*range(46,0,-9)],[*range(47,6,-8)]],56:[[*range(48,-1,-8)],[*range(49,6,-7)],[*range(57,64)]],
57:[[*range(49,0,-8)],[*range(50,14,-7)],[*range(58,64)]],58:[[57,56],[49,40],[*range(50,1,-8)],[*range(51,22,-7)],[*range(59,64)]],59:[[*range(58,55,-1)],[*range(50,31,-9)],[*range(51,2,-8)],[*range(52,30,-7)],[*range(60,64)]],60:[[*range(59,55,-1)],[*range(51,23,-9)],[*range(52,3,-8)],[*range(53,38,-7)],[*range(61,64)]],61:[[*range(60,55,-1)],[*range(52,15,-9)],[*range(53,4,-8)],[54,47],[62,63]],62:[[*range(61,55,-1)],[*range(53,7,-9)],[*range(54,5,-8)]],
63:[[*range(62,55,-1)],[*range(54,-1,-9)],[*range(55,6,-8)]]}

rowLookUp = [[*range(0,8)],[*range(8,16)],[*range(16,24)],[*range(24,32)],[*range(32,40)],[*range(40,48)],[*range(48,56)],[*range(56,64)]]
colLookUp = [[*range(0,57,8)],[*range(1,58,8)],[*range(2,59,8)],[*range(3,60,8)],[*range(4,61,8)],[*range(5,62,8)],[*range(6,63,8)],[*range(7,64,8)]]
diagLeftLookUp = [[*range(1,9,7)],[*range(2,17,7)],[*range(3,25,7)],[*range(4,33,7)],[*range(5,41,7)],[*range(6,49,7)],[*range(7,57,7)],[*range(15,58,7)],
[*range(23,59,7)],[*range(31,60,7)],[*range(39,61,7)],[*range(47,62,7)],[*range(55,63,7)]]
diagRightLookUp = [[*range(0,64,9)],[*range(1,56,9)],[*range(2,48,9)],[*range(3,40,9)],[*range(4,32,9)],[*range(5,24,9)],[*range(6,16,9)],[*range(8,63,9)]
,[*range(16,62,9)],[*range(24,61,9)],[*range(32,60,9)],[*range(40,59,9)],[*range(48,58,9)]]
weighting = {0:10,1:0,2:9,3:9,4:9,5:9,6:0,7:10,8:0,9:0,10:5,11:5,12:5,13:5,14:0,15:0,16:9,17:5,18:5,19:5,20:5,21:5,22:5,23:9,24:9,25:5,26:5,27:5,28:5,29:5,30:5,31:9,32:9,33:5,34:5,35:5,36:5,37:5,38:5,39:9,40:9,41:5,42:5,43:5,44:5,45:5,46:5,47:9,48:0,49:0,50:5,51:5,52:5,53:5,54:0,55:0,56:10,57:0,58:9,59:9,60:9,61:9,62:0,63:10}
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = ''.join(board).replace('?','').replace('@','X').replace('o','O')
        brd = brd.upper()
        #f.write(str(brd))
        if player == "@": player = "X"
        player=player.upper()
        #call your best Strategy
        periodNum = brd.count('.')
        ans= movesPossible(brd,player)
        mv = heuristic(brd,player, ans)
        mv1 = 11+(mv//8)*10+(mv%8)
        best_move.value = mv1
        if periodNum <= 8:
            #negamaxTerminal
            #mv = negamax(brd,player)[-1]
            mv = negamaxTerminal(brd, player,-65,65)[-1]
            mv1 = 11+(mv//8)*10+(mv%8)
            best_move.value = mv1
    #use lab6 to estimate move, last 8 dots use negamax with level of 1
def heuristic(brd, player, possible):
    #f = open('bestStrategy.txt','a')
    ans = possible
    #f.write("\n"+"ANS: "+player+" "+str(ans))
    corner = set([0, 7, 56, 63])
    safeEdge = set([2,3,4,5,23,31,39,47,58,59,60,61,16,24,32,40])
    CX = set([1,8,9,6,14,15,54,55,62,48,49,57])
    edgeToCorner = {1:0,8:0,9:0,6:7,14:7,15:7,54:63,55:63,62:63,48:56,49:56,57:56}
    edge = set([0,1,2,3,4,5,6,7,15,23,31,39,47,55,63,56,57,58,59,60,61,62,8,16,24,32,40,48])
    edgeHORZ = [[*range(0,8)],[*range(56,64)],[*range(0,57,8)]]
    edgeVERT= [[*range(7,64,8)],[*range(0,57,8)]]
    edge1 = [1,2,3,4,5,6]
    edge2 = [15,23,31,39,47,55]
    edge3 = [57,58,59,60,61,62]
    edge4 = [8,16,24,32,40,48]
    gotIn = False
    if corner.intersection(ans):
        ans = corner.intersection(ans)
        gotIn = True
    elif safeEdge.intersection(ans):
        n = safeEdge.intersection(ans)
        newans = set()
        for pos in n:
            if pos in edge1:
                yes1 = True
                yes2 = True
                for x in [*range(1,pos)]:
                    if brd[x] == '.':
                        yes1 = False
                for x in [*range(pos+1,7)]:
                    if brd[x] == '.':
                        yes2 = False
                if yes1  == True or yes2 == True:
                    newans.add(pos)
            if pos in edge2:
                yes1 = True
                yes2 = True
                for x in [*range(15,pos-7,8)]:
                    if brd[x] == '.':
                        yes1 = False
                for x in [*range(pos+8,56,8)]:
                    if brd[x] == '.':
                        yes2 = False
                if yes1  == True or yes2 == True:
                    newans.add(pos)
            if pos in edge3:
                yes1 = True
                yes2 = True
                for x in [*range(57,pos)]:
                    if brd[x] == '.':
                        yes1 = False
                for x in [*range(pos+1,63)]:
                    if brd[x] == '.':
                        yes2 = False
                if yes1  == True or yes2 == True:
                    newans.add(pos)
            if pos in edge4:
                yes1 = True
                yes2 = True
                for x in [*range(8,pos-7,8)]:
                    if brd[x] == '.':
                        yes1 = False
                for x in [*range(pos+8,49)]:
                    if brd[x] == '.':
                        yes2 = False
                if yes1  == True or yes2 == True:
                    newans.add(pos)
        if newans:
            ans = newans
    elif CX.intersection(ans) and len(ans)>1 and gotIn == False:
        newSet = CX.intersection(ans)
        newAns = set()
        for x in newSet:
            if brd[edgeToCorner[int(x)]] == player:
                newAns.add(int(x))
        if len(newAns)>0:
            ans = newAns
        elif ans.difference(CX):
            ans = ans.difference(CX)
    '''
    elif edge.intersection(ans):
        new = edge.intersection(ans)
        newSet = set()
        for pos in new:
            valid = True
            if pos<8:
                temp = pos
                while temp<56:
                    temp+=6
                    if brd[temp] == ".":
                        valid = False
            if pos in edge4:
                temp = pos
                while temp<pos+6:
                    pos+=1
                    if brd[temp] == ".":
                        valid = False
            if pos in edge2:
                temp = pos
                while temp>pos-5:
                    pos-=1
                    if brd[temp] == ".":
                        valid = False
            if pos in edge3:
                temp = pos
                while temp>pos-40:
                    pos-=8
                    if brd[temp] == ".":
                        valid = False
            if valid == True:
                newSet.add(pos)
        if newSet:
            ans = newSet
    '''
    ans = list(ans)
    largeX = random.choice(ans)
    return largeX
def displayBoard(pzl):
    print(pzl[:8])
    print(pzl[8:16])
    print(pzl[16:24])
    print(pzl[24:32])
    print(pzl[32:40])
    print(pzl[40:48])
    print(pzl[48:56])
    print(pzl[56:64])
def movesPossible(pzl, symb):
    possible = set()
    oppSymb = ""
    if symb == "X": oppSymb = "O"
    else: oppSymb = "X"
    holeIndex = [i for i in range(len(pzl)) if pzl[i] == "."]
    for hole in holeIndex:
        for seq in ranges[hole]:
            if pzl[seq[0]] != oppSymb: continue
            for pos in seq[1:]:
                if pzl[pos] == '.': break
                if pzl[pos] == symb:
                    possible.add(hole)
    return possible
def makeMove(board,token,mv):
    if token == "X": oppSymb = "O"
    else: oppSymb = "X"
    symbIndex = [i for i, x in enumerate(list(board)) if x == token]
    incr = []
    for pos in symbIndex:
        for row in rowLookUp:
            if mv in row and pos in row:
                valid = True
                if mv < pos:
                    temp = mv+1
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp+=1
                else:
                    temp = mv-1
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp-=1
                if valid == True:
                    incr.append([pos,1])
        for col in colLookUp:
            if mv in col and pos in col:
                valid = True
                if mv < pos:
                    temp = mv+8
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp+=8
                else:
                    temp = mv-8
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp-=8
                if valid == True:
                    incr.append([pos,8])
        for diagLeft in diagLeftLookUp:
            if mv in diagLeft and pos in diagLeft:
                valid = True
                if mv < pos:
                    temp = mv+7
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp+=7
                else:
                    temp = mv-7
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp-=7
                if valid == True:
                    incr.append([pos,7])
        for diagRight in diagRightLookUp:
            if mv in diagRight and pos in diagRight:
                valid = True
                if mv < pos:
                    temp = mv+9
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp+=9
                else:
                    temp = mv-9
                    while temp != pos:
                        if board[temp]!=oppSymb:
                            valid = False
                        temp-=9
                if valid == True:
                    incr.append([pos,9])
    for change in incr:
        fr = change[0]
        incr = change[1]
        if fr < mv:
            while fr != mv:
                fr+=incr
                board = board[:fr]+token+board[fr+1:]
        else:
            while fr != mv:
                fr-=incr
                board = board[:fr]+token+board[fr+1:]
    return board
def evalBoard(board, token):
    if token == "X": opp = "O"
    else: opp = "X"
    return board.count(token)-board.count(opp)
def negamax(board, token):
    if token == "X": enemy = "O"
    else: enemy = "X"
    lm = movesPossible(board, token)
    if not lm:
        lm2 = movesPossible(board, enemy)
        if not lm2:
            return [evalBoard(board, token)]
        nm = negamax(board, enemy)+[-1]
        return[-nm[0]]+nm[1:]
    nmList = sorted([negamax(makeMove(board,token,mv),enemy)+[mv] for mv in lm])
    best = nmList[0]
    return [-best[0]]+best[1:]
def takenOver(board, to, d):#incr, from
    orig = to
    taken = 0
    if len(d[to])==2:
        fr = d[to][1]
        incr = d[to][0]
        if fr>to:
            while to!=fr:
                to+=incr
                taken+=1
        else:
            while fr!=to:
                fr+=incr
                taken+=1
        return taken
    else:
        taken = 0
        it = 0
        while it < len(d[orig]):
            fr = d[orig][it+1]
            incr = d[orig][it]
            if fr>to:
                while to!=fr:
                    to+=incr
                    taken+=1
                to=orig
            else:
                while to!=fr:
                    to-=incr
                    taken+=1
                to=orig
            it+=2
        return taken
def negamaxTerminal(brd, token, improvable, hardBound):
    if token == "X": enemy = "O"
    else: enemy = "X"
    lm = movesPossible(brd,token)
    if not lm:
         lm = movesPossible(brd,enemy)
         if not lm: return [evalBoard(brd,token), -3]
         nm = negamaxTerminal(brd,enemy,-hardBound,-improvable)+[-1]
         return [-nm[0]]+nm[1:]
    best  = [] #what gets returned
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(brd,token,mv),enemy,-hardBound,newHB)+[mv]
        if not best or nm[0]<newHB:
            best = nm
            if nm[0]<newHB:
                newHB = nm[0]
                if -newHB>hardBound: return [-best[0]]+best[1:] #pruning
    return [-best[0]]+best[1:]
def main():
    board = sys.argv[1].upper()
    token = sys.argv[2].upper()
    n = 8
    ans = movesPossible(board.upper(), token.upper())
    print("legal Moves: ", ans)
    #heuristic to pick best move
    periodNum = board.count(".")
    if True:
        move = heuristic(board,token,ans)
        print("My heuristic move is: ", move)
    if periodNum <= n:
        score = negamaxTerminal(board,token,-65,65)
        print("Negamax score is "+str(score)+" and my move is "+str(score[-1]))
if __name__ == "__main__":
    main()
