import sys, random

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        playerToToken = {'@':'x', 'o':'o'}
        board = ((''.join(board)).replace('?', '')).replace('@', 'x').lower()
        token = playerToToken[player].lower()
        mv = getMove(board, token)
        best_move.value = 11+(mv//8)*10+(mv%8)

opp = {'x':'o', 'o':'x'}

corners = {0, 7, 56, 63}

c = {1:0, 6:7, 8:0, 15:7, 48:56, 55:63, 57:56, 62:63}

x = {9:0, 14:7, 49:56, 54:63}

edges = {1:{0,7}, 2:{0,7}, 3:{0,7}, 4:{0,7}, 5:{0,7}, 6:{0,7}, 8:{0,56}, 16:{0,56}, 24:{0,56}, 32:{0,56},
40:{0,56}, 48:{0,56}, 57:{56,63}, 58:{56,63}, 59:{56,63}, 60:{56,63}, 61:{56,63}, 62:{56,63}, 15:{7,63}, 23:{7,63},
31:{7,63}, 39:{7,63}, 47:{7,63}, 55:{7,63}}

directs = [(-1, 1), (1, -1), (1, 1), (-1, -1), (1, 0), (-1, 0), (0, 1), (0, -1)]

def getPoss(game, turn):
    idxs = [i for i,j in enumerate(game) if j==turn]
    finPoss = set()
    for idx in idxs:
        for i in directs:
            tmpx, tmpy, between, poss = idx%8, idx//8, 0, set()
            while True:
                tmpx += i[0]
                tmpy += i[1]
                index = 8*tmpy+tmpx
                if tmpx < 0 or tmpx > 7 or tmpy < 0 or tmpy > 7: break
                if game[index] == opp[turn]: between += 1
                elif game[index] == turn: break
                elif game[index] == '.' and between > 0:
                    poss.add(index)
                    break
                else: break
            finPoss = finPoss|poss
    return finPoss

def toFlip(game, turn, moveIndex):
    flip = set()
    valid = False
    for i in directs:
        tmpx, tmpy, tmpInd = moveIndex%8, moveIndex//8, set()
        while True:
            tmpx += i[0]
            tmpy += i[1]
            if tmpx < 0 or tmpx > 7 or tmpy < 0 or tmpy > 7: break
            index = 8 * tmpy + tmpx
            if game[index] == opp[turn]: tmpInd.add(index)
            elif game[index] == turn and tmpInd:
                valid = True
                tmpInd.add(index)
                break
            elif game[index] == '.': break
            else: break
        if valid: flip = flip|tmpInd
        valid = False
    flip = flip|{moveIndex}
    return flip

def display(game):
    print(''.join([game[index] + '\n' if index - 7 == i and index != 0 else game[index] for i in range(0,57,8) for index in range(i, i + 8)]))

def findMove(game, turn):
    index = -1
    safeEdges = set()
    poss = getPoss(game, turn)
    if poss & corners: index = random.sample(poss&corners, 1)[0]
    elif poss & edges.keys():
        possEdges = poss&edges.keys()
        while possEdges:
            possEdge = possEdges.pop()
            for corner in edges[possEdge]:
                if game[corner] == turn and corner in toFlip(game, turn, possEdge):
                    safeEdges.add(possEdge)
        if safeEdges:
            index = random.sample(safeEdges, 1)[0]
    if index == -1:
        while index == -1:
            index = poss.pop()
            if not poss: break
            if index in c:
                if game[c[index]] != turn:
                    index = -1
            elif index in x:
                if game[x[index]] != turn:
                    index = -1
            elif index in edges and not (poss&c.keys() or poss&x.keys()):
                index = -1
    return index

def boardEval(game, turn):
    return game.count(turn) - game.count(opp[turn])

def makeMove(game, turn, idx):
    temp = game
    flip = toFlip(game, turn, idx)
    for index in flip: temp = ''.join([temp[:index], turn, temp[index+1:]])
    return temp

def Negamax(game, turn, level):
    if not game.count('.') or not getPoss(game, turn)|getPoss(game, opp[turn]): return [boardEval(game, turn)]
    lm = getPoss(game, turn)
    if not lm: best = Negamax(game, opp[turn], level-1) + [-1]
    else: best = sorted([Negamax(makeMove(game, turn, mv), opp[turn], level-1)+[mv] for mv in lm])[0]
    return [-best[0]] + best[1:]

def getMove(board, token):
    index = findMove(board, token)
    if board.count('.') > 8: return index
    else:
        nm = Negamax(board, token, -1)
        return nm[-1]

def main():
    board = sys.argv[1].lower()
    token = sys.argv[2].lower()
    index = findMove(board, token)
    display(board)
    print("Possible moves: " + str(getPoss(board, token)))
    print("My heuristic choice is {}".format(findMove(board, token)))
    if board.count('.') <= 8:
        nm = Negamax(board, token, -1)
        print("Negamax returns {} and I choose move {}".format(nm, nm[-1]))

if __name__ == "__main__":
    main()
