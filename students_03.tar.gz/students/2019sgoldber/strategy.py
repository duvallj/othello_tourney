#Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018
REFUTES={}
scorer=[
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 200, -20, 20, 5, 5, 20, -20, 200, 0,
 0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
 0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
 0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
 0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
 0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
 0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
 0, 200, -20, 20, 5, 5, 20, -20, 200, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.

N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
class Node:
	def __init__(self,board, player, score=None,move=None, top_move=None, parent=None):
		strat=Strategy()
		self.move=move
		self.board=board
		self.score=score
		self.filled=strat.num_filled(board)
		if score is None:
			self.score = strat.scorenorm(board,player)
		self.is_leaf=True if strat.next_player(board,player) is None else False
		self.children=[]
		self.parent=parent
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        tempB = ""
        for x in range(10): #top outer
            tempB=tempB+OUTER
        for x in range(3): #top block of empties
            tempB=tempB+OUTER
            for y in range(8):
                tempB=tempB+EMPTY
            tempB=tempB+OUTER
        tempB=tempB+OUTER #first row with pieces
        for x in range(3):
            tempB=tempB+EMPTY
        tempB=tempB+WHITE+BLACK
        for x in range(3):
            tempB=tempB+EMPTY
        tempB=tempB+OUTER
        tempB=tempB+OUTER #second row with pieces
        for x in range(3):
            tempB=tempB+EMPTY
        tempB=tempB+BLACK+WHITE
        for x in range(3):
            tempB=tempB+EMPTY
        tempB=tempB+OUTER
        for x in range(3): #bottom block of empties
            tempB=tempB+OUTER
            for y in range(8):
                tempB=tempB+EMPTY
            tempB=tempB+OUTER
        for x in range(10): #bottom outer
            tempB=tempB+OUTER
        return tempB
        """Create a new board with the initial black and white positions filled."""
        pass

    def get_pretty_board(self, board):
        tempP=""
        for x in range(10):
            tempP=tempP+board[((x)*10):(x*10)+10]+"\n"
        return tempP
        """Get a string representation of the board."""
        pass
    def num_filled(self,board):
        a=0
        for x in board:
            if (x is BLACK) or (x is WHITE):
                a+=1
        return a
    def opponent(self, player):
        if player==BLACK:
            return WHITE
        if player==WHITE:
            return BLACK
        """Get player's opponent."""
        pass
 
    def find_match(self, board, player, square, direction):
        tempS=square+direction
        while board[tempS]!=OUTER and board[tempS]!=EMPTY:
            if board[tempS]==player:
                return tempS
            tempS=tempS+direction
        return None
        
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        pass

    def is_move_valid(self, board, player, move):
        a=""
        tempS=move
        count=0
        for x in DIRECTIONS:
            count=0
            tempS=move+x
            if not (board[tempS]==player and count==0):
#               print(x)
                while board[tempS]!= EMPTY and board[tempS]!=OUTER and board[tempS]!=player:
                    count+=1
                    tempS=tempS+x
 #              print("tempS is " +str(tempS))
 #              print("count is "+str(count))
 #              input()
                if board[tempS]==player and count>0:
 #              print("returning true")
                    a=a+'T'
#       print("returning false")
#       print(a)
        if "T" in a:
            return True
        return False
        """Is this a legal move for the player?"""
        pass
    def is_kill(self,board,depth):
        if not depth in REFUTES:
            return 0
        if REFUTES[depth].contains(board):
            return 1
        return 0		
    def make_move(self, board, player, move):
        board=board[:move]+player+board[move+1:]
#       print(self.get_pretty_board(board))
#       print("move is"+str(move))
        for d in DIRECTIONS:
            a=self.find_match(board,player,move,d)
#           print("move is "+str(move))
#           print("a is "+str(a))
            if a is None:
                continue
            for x in range(move,a,d):
#               print(x)
                board=board[:x]+player+board[x+1:]
#       input()
        return board
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        pass

    def get_valid_moves(self, board, player):
        moves=[]
        for x in range(8):
            for y in range(8):
                if board[((x+1)*10)+(y+1)]==EMPTY:
 #                   print(((x+1)*10)+(y+1))
                    if self.is_move_valid(board,player,(((x+1)*10)+(y+1))):
                        moves.append((((x+1)*10)+(y+1)))
        return moves
        """Get a list of all legal moves for player."""
        pass
    def has_any_valid_moves(self, board, player):
        if len(self.get_valid_moves(board,player)) is not 0:
            return True
        return False
        """Can player make any moves?"""
        pass

    def next_player(self, board, prev_player):
        if self.has_any_valid_moves(board,self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board,prev_player):
            return prev_player
        return None
        """Which player should move next?  Returns None if no legal moves exist."""
        pass

    def scorenorm(self, board, depth, player=BLACK):
        pps=0 #player pieces
        ops=0 #opponent pieces
        for x in range(100):
            if (x==BLACK and player==BLACK) or (x==WHITE and player==WHITE):
                pps+=scorer[x]
            elif (x==BLACK and player==WHITE) or (x==WHITE and player==BLACK):
                ops+=scorer[x]
        return ((pps-ops)+random.random()) 
        """Compute player's score (number of player's pieces minus opponent's)."""
        pass
    def scoremix(self,board,depth,player=BLACK):
        return self.scorenorm(self,board,depth)+(self.score(board)/6)
    def compscore(self,board,player=BLACK):
        pps=0
        ops=0
        boarda=board.board
        k=2
#       print("board is: "+self.get_pretty_board(boarda))
        if board.parent is not None:
            boardb=board.parent
#           print("parent is: "+self.get_pretty_board(boardb))
        else:
            return self.score(board.board)
        for x in range(100):
             if (boarda[x]==BLACK and player==BLACK and boardb[x]!=BLACK) or (boarda[x]==WHITE and player==WHITE and boardb[x]!=WHITE):
                 pps+=1
             elif (boarda[x]==WHITE and player==BLACK and boardb[x]!=WHITE) or (boarda[x]==BLACK and player==WHITE and boardb[x]!=BLACK):
                 ops+=k
                 k+=(k/2)
        a=((pps-ops)+(random.random())/3)
#       print("score is"+str(a))
#       input()
        return a
    def comprscore(self,board,player=BLACK):
        pps=0
        ops=0
        boarda=board.board
        k=2
#       print("board is: "+self.get_pretty_board(boarda))
        if board.parent is not None:
            boardb=board.parent
#           print("parent is: "+self.get_pretty_board(boardb))
        else:
            return self.score(board.board)
        for x in range(100):
             if (boarda[x]==BLACK and player==BLACK and boardb[x]!=BLACK) or (boarda[x]==WHITE and player==WHITE and boardb[x]!=WHITE):
                 pps+=k
                 k+=(k/2)
             elif (boarda[x]==WHITE and player==BLACK and boardb[x]!=WHITE) or (boarda[x]==BLACK and player==WHITE and boardb[x]!=BLACK):
                 ops+=1
        a=((pps-ops)+(random.random())/3)
#       print("score is"+str(a))
#       input()
        return a
    def score(self,board,player=BLACK):
        pps=0
        ops=0
        for x in board:
            if (x==BLACK and player==BLACK) or (x==WHITE and player==WHITE):
                pps+=1
            elif (x==BLACK and player==WHITE) or (x==WHITE and player==BLACK):
                ops+=1
        return ((pps-ops)+random.random())
    def game_over(self, board, player):
        if next_player is None:
            
            return True
        return False
        """Return true if player and opponent have no valid moves"""
        pass

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth):
        best={BLACK:max,WHITE:min}
        b=board
        if depth is 0:
            return board
        my_moves = self.get_valid_moves(board.board,player)
        children = []
        for a in my_moves:
            next_board=self.make_move(board.board,player,a)
            next_player=self.next_player(next_board,player)
            if next_player is None:
                c=Node(next_board, player, score=1000*self.score(next_board),move=a,parent=b.board)
                b.children.append(c)
            else:
                c=Node(next_board, player, move=a, parent=b.board)
                r=self.minmax_search(c,next_player,depth-1)
                c.score=r.score
                b.children.append(c)
        winner= best[player](b.children,key=lambda x:x.score)
        b.score=winner.score
        return winner
        pass

    def minmax_strategy(self, board, player, depth=3):
        c=Node(board,player)
        a=self.minmax_search(c,player,depth)
        return a.move
        pass
    def alphabeta_search(self,board,player,depth,alpha,beta):
        best={BLACK:max,WHITE:min}
        b=board
        if depth is 0:
             board.score=self.scorenorm(board,depth)
             return board
        my_moves=self.get_valid_moves(board.board,player)
        for a in my_moves:
            next_board=self.make_move(board.board,player,a)
            next_player=self.next_player(next_board,player)
            if next_player is None:
                c=Node(next_board,player,score=1000*self.scorenorm(next_board,depth+1),move=a,parent=b.board)
                b.children.append(c)
            else:
                c=Node(next_board,player,move=a,parent=b.board)
                r=self.alphabeta_search(c,next_player,depth-1,alpha,beta)
                c.score=r.score
                b.children.append(c)
            if player==BLACK:
                alpha=max(alpha,c.score)
            if player==WHITE:
                beta=min(alpha,c.score)
            if alpha>=beta:
                break
        winner=best[player](b.children,key=lambda x:x.score)
        b.score=winner.score
        return winner
        pass
    def alphabeta_strategy(self,board,player,depth=6):
        c=Node(board,player)
        a=self.alphabeta_search(c,player,depth,-math.inf,math.inf)
        print(a.move)
        return a.move
        pass
    def alphabeta_search_killer(self,board,player,curdepth,depth,alpha,beta):
        global REFUTES
        best={BLACK:max,WHITE:min}
        b=board
        if curdepth is depth:
            if board.filled > 54 and self.score(board.board)>0:
                board.score=self.compscore(board,player)
                if player is WHITE:
                    board.score=-board.score
#            elif board.filled>30:
#                board.score=self.scoremix(board,curdepth)
            elif board.filled>54 and self.score(board.board)<0:
                board.score=self.comprscore(board,player)
                if player is WHITE:
                    board.score=-board.score
            elif board.filled>54:
                board.score=self.score(board.board)
            else:
                board.score=self.scorenorm(board,curdepth)
            return board
        my_moves=self.get_valid_moves(board.board,player)
        r=[]
        for a in my_moves:
            nb=self.make_move(board.board,player,a)
            np=self.next_player(nb,player)
            if np is None:
                c=Node(nb,player,score=1000*self.score(nb),move=a,parent=b.board)
                b.children.append(c)
                if player==BLACK:
                    alpha=max(alpha,c.score)
                if player==WHITE:
                    beta=min(alpha,c.score)
                if alpha>=beta:
                    break
            else:
                c=Node(nb,player,move=a,parent=b.board)
                r.append(c)
        l=[]
        if best[player]==max:
            l=sorted(r,key=lambda x: x.score+10*self.is_kill(x.board,curdepth))
        if best[player]==min:
            l=sorted(r,key=lambda x:-x.score-10*self.is_kill(x.board,curdepth))
        for x in l:
            np=self.next_player(x.board,player)
            n=self.alphabeta_search_killer(x,np,curdepth+1,depth,alpha,beta)
            x.score=n.score
            if np is player:
                if player is BLACK:
                    x.score=x.score*100
                if player is WHITE:
                    x.score=abs(x.score)*-100
            b.children.append(x)
            if player==BLACK:
                alpha=max(alpha,x.score)
            if player==WHITE:
                beta=min(alpha,c.score)
            if alpha>=beta:
                if not depth in REFUTES:
                    REFUTES[depth]=[x.board]
                elif len(REFUTES[depth]) is 1:
                    REFUTES[depth].append(x.board)
                elif not self.is_kill(x.board,curdepth):
                    REFUTES[depth].remove(random.choice(REFUTES[depth]))
                    REFUTES[depth].append(x.board)
                break
        winner=best[player](b.children,key=lambda x:x.score)
        b.score=winner.score
        return winner
        pass
    def alphabeta_strategy_killer(self,board,player,depth=6):
        c=Node(board,player)
        a=self.alphabeta_search_killer(c,player,0,depth,-math.inf,math.inf)
        print(a.move)
        return a.move
        pass
    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = ''.join(board)
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy_killer(board, player, depth)
            depth += 1

    standard_strategy = alphabeta_strategy_killer


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()
