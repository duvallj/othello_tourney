# Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class node:
    # a class that holds board, player, move, score info for minmax tree
    # FILL THIS IN
    def __init__(self, board, score):
        self.board = board
        self.score = None
        self.last_move = None

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return "???????????........??........??........??...o@...??...@o...??........??........??........???????????"

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        str = ""
        for i in range(0, len(board), 10):
            str += board[i: min(i + 10, len(board))]
        return str

    def opponent(self, player):
        """Get player's opponent."""
        return BLACK if player == WHITE else WHITE

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        middle = False
        current = square + direction
        while True:
            if board[current] == player or board[current] == OUTER:
                return None
            elif board[current] == self.opponent(player):
                current += direction
                middle = True
            elif board[current] == EMPTY:
                return current if middle else None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        moves = []
        for d in DIRECTIONS:
            middle = False
            current = move + d
            while True:
                if board[current] == EMPTY or board[current] == OUTER:
                    break
                elif board[current] == self.opponent(player):
                    current += d
                    middle = True
                elif board[current] == player:
                    if middle:
                        moves.append((current, d))
                    break
        new_board = list(board)
        for move2, d in moves:
            for i in range(move, move2, d):
                new_board[i] = player
        return ''.join(new_board)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves = set()
        for i in range(0, len(board)):
            if board[i] == player:
                for d in DIRECTIONS:
                    move = self.find_match(board, player, i, d)
                    if move is not None:
                        moves.add(move)
        return list(moves)

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player)) > 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opp = self.opponent(prev_player)
        has_moves = self.has_any_valid_moves(board, prev_player)
        opp_has_moves = self.has_any_valid_moves(board, opp)
        if not has_moves and not opp_has_moves:
            return None
        elif not opp_has_moves:
            return prev_player
        else:
            return opp

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        return board.count(BLACK) - board.count(WHITE)

    def weighted_score(self, board, player=BLACK):
        scoring_matrix = [  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
                            0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
                            0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
                            0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
                            0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
                            0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
                            0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
                            0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
                            0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,   0,   0]
        sum = 0
        for i in range(len(board)):
            sum += (1 if board[i] == player else -1) * scoring_matrix[i]
        opponent = self.opponent(player)
        actual_mobility = len(self.get_valid_moves(board, player)) - len(self.get_valid_moves(board, opponent))
        relative_mobility = 0
        for i in range(len(board)):
            if board[i] == '.':
                for d in DIRECTIONS:
                    if i + d >= 0 and i + d < len(board) and board[i + d] == opponent:
                       relative_mobility += 1
        return sum + .75 * actual_mobility + .25 * relative_mobility

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return not self.has_any_valid_moves(player) and not self.has_any_valid_moves(self.opponent(player))

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, cur_node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if depth == 0:
            cur_node.score = self.score(cur_node.board)
            return cur_node
        children = []
        for move in self.get_valid_moves(cur_node.board, player):
            next_board = self.make_move(cur_node.board, player, move)
            next_player = self.next_player(next_board, player)
            c = node(next_board, move)
            c.score = 1000 * self.score(next_board) if next_player is None else self.minmax_search(c, next_player, depth - 1).score
            c.last_move = move
            children.append(c)
        winner = max(children, key = lambda x: x.score) if player == BLACK else min(children, key = lambda x: x.score)
        cur_node.score = winner.score
        return winner

    def minmax_strategy(self, board, player):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(node(board, -1), player, 3).last_move

    def alpha_beta_search(self, cur_node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if depth == 0:
            cur_node.score = self.weighted_score(cur_node.board)
            return cur_node
        children = []
        for move in self.get_valid_moves(cur_node.board, player):
            next_board = self.make_move(cur_node.board, player, move)
            next_player = self.next_player(next_board, player)
            c = node(next_board, move)
            c.score = 1000 * self.weighted_score(next_board) if next_player is None else self.alpha_beta_search(c, next_player, depth - 1, alpha, beta).score
            c.last_move = move
            children.append(c)
            if player == BLACK:
                alpha = max(alpha, c.score)
            if player == WHITE:
                beta = min(beta, c.score)
            if alpha >= beta:
                break
        winner = max(children, key = lambda x: x.score) if player == BLACK else min(children, key = lambda x: x.score)
        cur_node.score = winner.score
        return winner

    def alpha_beta_strategy(self, board, player):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.alpha_beta_search(node(board, -1), player, 3, -math.inf, math.inf).last_move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = ''.join(board)
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alpha_beta_strategy(board, player)
            depth += 1

    standard_strategy = alpha_beta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    # game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()