import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
weighting_array=[
            10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
            10, 180, -20, 20, 5, 5, 20, -40, 180, 10,
            10, -20, -80, -5, -5, -5, -5, -80, -40, 10,
            10, 20, -5, 15, 3, 3, 15, -5, 20, 10,
            10, 5, -5, 3, 3, 3, 3, -5, 5, 10,
            10, 5, -5, 3, 3, 3, 3, -5, 5, 10,
            10, 20, -5, 15, 3, 3, 15, -5, 20, 10,
            10, -40, -80, -5, -5, -5, -5, -80, -40, 10,
            10, 180, -40, 20, 5, 5, 20, -40, 180, 10,
            10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
        ]
class Node:
    #For parents/roots
    def __init__(self,state,parent,depth=0):
        self.state=state
        self.parent=parent
        self.depth=depth
        self.children=set()
        self.iternode=self
        self.ancestors={self,parent}
    def __iter__(self):
        self.iternode=self
        return self
    def __next__(self): #iterate up the tree, not down it
        if self.iternode is None:
            raise StopIteration
        n=self.iternode
        self.iternode=self.iternode.parent
        return n
        #return self.parent
    def __str__(self):
        return str(self.state)
    def __repr__(self): #State,children,parent,depth
        childstrings=[c.__str__() for c in self.children]
        return "%s,[%s],%s,%i"%(str(self.state),",".join(childstrings),str(self.parent),self.depth)
    def __eq__(self,other):
        #assert type(self)==type(other)
        return type(self)==type(other) and self.state==other.state
    def __ne__(self,other):
        #assert type(self)==type(other)
        return type(self)!=type(other) or self.state!=other.state
    def __hash__(self):
        return hash(self.__str__())
    def __lt__(self,other):
        if type(self)!=type(other):
            return NotImplemented
        return self.depth<other.depth
    def __gt__(self,other):
        if type(self)!=type(other):
            return NotImplemented
        return self.depth>other.depth
    def __le__(self,other):
        if type(self)!=type(other):
            return NotImplemented
        return self.depth<=other.depth
    def __ge__(self,other):
        if type(self)!=type(other):
            return NotImplemented
        return self.depth>=other.depth
    # Returns a copy of the node with the same parent, state, and ancestors but different children.
    def clone(self):
        return Node(self.state,self.parent)

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        self.board='???????????........??........??........??...o@...??...@o...??........??........??........???????????'
        return self.board
    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        return board.strip("?").replace("??","\n")

    def opponent(self, player):
        """Get player's opponent."""
        return (BLACK+WHITE).strip(player)

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        pass

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        pass

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board_list=list(board)
        opponent=self.opponent(player)
        board_list[move]=player
        for dir in DIRECTIONS:
            pos=move+dir
            n=0
            while board_list[pos]==opponent:
                n+=1
                pos+=dir
            if board_list[pos]==player:
                while n>0:
                    pos-=dir
                    board_list[pos]=player
                    n-=1
        return "".join(board_list)
        #return board[:move]+player+board[move+1:]

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        moves=set()
        for p in range(len(board)):
            if board[p]==player:
                moves |= self.get_moves_coord(board,player,p)
        return moves

    def get_moves_coord(self,board,player,pos):
        #~~If given an empty coordinate, determines whether or not the space is a valid move and returns the space if it is.~~
        #Disregard, it doesn't do that any more. That functionality has been moved to check_move_coord

        #If given a coordinate containing a player's piece, returns all valid moves from that space
        #adj = board[pos+NW:pos+NE] + board[pos+W] + board[pos+E] + board[pos+SW:pos+SE]
        opponent=self.opponent(player)
        coords=set()
        for dir in DIRECTIONS:
            npos=pos+dir
            while board[npos]==opponent:
                npos+=dir
            if npos==pos+dir:
                continue
            #elif board[npos]==player and board[pos]==EMPTY:
            #    return pos
            elif board[npos]==EMPTY and board[pos]==player:
                coords.add(npos)
        return coords

    def check_move_coord(self,board,player,pos):
        opponent = self.opponent(player)
        for dir in DIRECTIONS:
            npos = pos + dir
            while board[npos] == opponent:
                npos += dir
            if npos==pos+dir:
                continue
            elif board[npos]==player and board[pos]==EMPTY:
                return True
            elif board[npos]==EMPTY and board[pos]==player:
                return True
        return False
    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        for c in range(len(board)):
            if board[c]==player and self.check_move_coord(board,player,c):
                return True
        return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opponent=self.opponent(prev_player)
        if self.has_any_valid_moves(board, opponent):
            return opponent
        elif self.has_any_valid_moves(board,prev_player):
            return prev_player
        else:
            return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        opponent=self.opponent(player)
        return board.count(player)-board.count(opponent)+(random.random()/2)
    def weighted_score(self,board,player=BLACK,weighting=weighting_array):
        # Computes a useful weighted score for the algorithm to use.
        opponent=self.opponent(player)
        score=0
        score_dict={player:1,opponent:-1, "?":0,".":0}
        for n in range(len(board)):
            #if board[n]==player:
            #    score+=weighting_array[n]
            #elif board[n]==opponent:
            #    score-=weighting_array[n]
            score+=weighting[n]*score_dict[board[n]]
        return score+(random.random()/2)

    def altered_scoring_array(self,move,weighting=weighting_array):
        cop=weighting.copy()
        if move==11:
            cop[12]=20
            cop[21]=20
            cop[22]=10
        elif move==19:
            cop[18] = 20
            cop[29] = 20
            cop[28] = 10
        elif move==81:
            cop[82]=20
            cop[71]=20
            cop[72]=10
        elif move==89:
            cop[88] = 20
            cop[79] = 20
            cop[78] = 10
        return cop
    def neighboring_score(self,board,player,pos):
        opponent = self.opponent(player)
        score = 0
        score_dict = {player: 1, opponent: -1, "?":0,".":0}
        if pos-11>0:
            score+=weighting_array[pos-11] * score_dict[board[pos-11]]
            score+=weighting_array[pos-10] *score_dict[board[pos-10]]
            score+=weighting_array[pos-9] * score_dict[board[pos-9]]
            score += weighting_array[pos - 1] * score_dict[board[pos - 1]]
            score += weighting_array[pos + 1] * score_dict[board[pos + 1]]
        else:
            for n in range(0, pos-9):
                score += weighting_array[n] * score_dict[board[n]]
            score += weighting_array[pos-1] * score_dict[board[pos-1]]
            score += weighting_array[pos+1] * score_dict[board[pos+1]]
            for n in range(pos+9, pos+11):
                score += weighting_array[n] * score_dict[board[n]]
            return score
        if pos+11>len(board):
            for n in range(pos+9, len(board)):
                score += weighting_array[n] * score_dict[board[n]]
        else:
            for n in range(pos+9, pos+11):
                score += weighting_array[n] * score_dict[board[n]]
        return score
    def sum_neighbors(self,array,pos):
        #opponent = self.opponent(player)
        sum = 0
        #score_dict = {player: 1, opponent: -1, "?": 0, ".": 0}
        if pos - 11 > 0:
            sum += array[pos-11]
            sum += array[pos-10]
            sum += array[pos - 9]
            sum += array[pos - 1]
        else:
            for n in range(0, pos - 9):
                sum += array[n]
            sum += array[pos - 1]
            sum += array[pos + 1]
            for n in range(pos + 9, pos + 11):
                sum += array[n]
            return sum
        if pos + 11 > len(array):
            for n in range(pos + 9, len(array)):
                sum += array[n]
        else:
            for n in range(pos + 9, pos + 11):
                sum += array[n]
        return sum
    def scored_board(self,board,player):
        opponent = self.opponent(player)
        scores = []
        score_dict = {player: 1, opponent: 0, "?": 10, ".": -10}
        for n in range(len(board)):
            # if board[n]==player:
            #    score+=weighting_array[n]
            # elif board[n]==opponent:
            #    score-=weighting_array[n]
            scores.append( weighting_array[n] * score_dict[board[n]])
        return scores
    def dynamic_weighted_score(self,board,player):
        opponent = self.opponent(player)
        score = 0
        score_dict = {player: 1, opponent: -1, "?":10,".":0}
        scored=self.scored_board(board,player)
        for n in range(len(scored)):
            # if board[n]==player:
            #    score+=weighting_array[n]
            # elif board[n]==opponent:
            #    score-=weighting_array[n]
            #score += weighting_array[n] * score_dict[board[n]]+0.5*self.neighboring_score(board,player,n)
            score+=score_dict[board[n]]*(weighting_array[n]+0.5*self.sum_neighbors(scored,n))
            #score+=score_dict[board[n]]*(weighting_array[n]+0.5*self.sum_neighbors(weighting_array,n))
        return score + (random.random() / 2)
    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return (not self.has_any_valid_moves(board,player)) and (not self.has_any_valid_moves(board,self.opponent(player)))

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    default_scoring= weighted_score
    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best={BLACK:max,WHITE:min}
        board=node.state[0]
        if depth==0:
            node.depth=self.default_scoring(board,player)
            return node
        my_moves=self.get_valid_moves(board,player)
        children=[]
        for move in my_moves:
            next_board=self.make_move(board,player,move)
            next_player=self.next_player(next_board,player)
            if next_player is None:
                c = Node((next_board,move),node,int(1000*self.score(next_board,player)))
            else:
                c=Node((next_board,move),node)
                c.depth=self.minmax_search(c,next_player,depth=depth-1).depth
            children.append(c)
        winner=best[player](children,key=lambda x:x.depth)
        node.depth=winner.depth
        return winner
    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node((board,0),None),player,depth).state[1]
    def alphabeta_search(self, node, player, depth, alpha, beta, weighting=weighting_array):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best={BLACK:max,WHITE:min}
        board=node.state[0]
        if depth==0:
            node.depth=self.default_scoring(board,player,weighting)
            return node
        my_moves=self.get_valid_moves(board,player)
        children=[]
        for move in my_moves:
            next_board=self.make_move(board,player,move)
            next_player=self.next_player(next_board,player)
            if next_player is None:
                c = Node((next_board,move),node,int(1000*self.score(next_board,player)))
            else:
                c=Node((next_board,move),node)
                c.depth=self.alphabeta_search(c,next_player,depth=depth-1,alpha=alpha,beta=beta).depth
            children.append(c)
            if player==BLACK:
                alpha=max(alpha,c.depth)
            if player==WHITE:
                beta=min(beta,c.depth)
            if alpha >= beta:
                break
        winner=best[player](children,key=lambda x:x.depth)
        node.depth=winner.depth
        return winner
    def alphabeta_strategy(self, board, player, depth=4):
        # calls alphabeta_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.alphabeta_search(Node((board,0),None),player,depth,-math.inf,math.inf).state[1]
    def human_strategy(self,board,player):
        print(self.get_pretty_board(board))
        coord_x=input("Enter coordinates: X=")
        coord_y=input("Y=")


    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running=True):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while(still_running):
            ## doing random in a loop is pointless but it's just an example
            #best_move.value = self.random_strategy(board, player)
            #best_move.value=self.minmax_strategy(board,player,depth)
            best_move.value=self.alphabeta_strategy("".join(board),player,depth)
            weighting_array=self.altered_scoring_array(best_move.value)
            depth += 1
    def scattershot_strategy(self,board,player):
        ## This strategy calls several types of search, in an attempt to determine what search the opponent is using.
        opp=self.opponent(player)
        minimax=self.minmax_search(board,opp,depth=2)
        random=self.random_strategy(board,opp)


    standard_strategy = best_strategy