import sys

corners = {0, 7, 63, 56}
corx = {1: 0, 8: 0, 9: 0, 6: 7, 15: 7, 14: 7, 57: 56, 48: 56, 49: 56, 62: 63, 55: 63, 54: 63}
x = {9:0,14:7,49:56,54:63}
edges = {2, 3, 4, 5, 58, 59, 60, 61, 16, 23, 24, 31, 32, 39, 40}
edgecorners = {1: [0, 7, 1, -1], 2: [0, 7, 1, -1], 3: [0, 7, 1, -1], 4: [0, 7, 1, -1], 5: [0, 7, 1, -1],
               6: [0, 7, 1, -1], 8: [0, 56, 8, -8], 16: [0, 56, 8, -8], 24: [0, 56, 8, -8], 32: [0, 56, 8, -8],
               40: [0, 56, 8, -8], 48: [0, 56, 8, -8], 57: [56, 63, 1, -1], 58: [56, 63, 1, -1], 59: [56, 63, 1, -1],
               60: [56, 63, 1, -1], 61: [56, 63, 1, -1], 62: [56, 63, 1, -1], 23: [7, 63, 8, -8], 31: [7, 63, 8, -8],
               39: [7, 63, 8, -8], 47: [7, 63, 8, -8], 55: [7, 63, 8, -8]}
adjacents = {}
frontiers = {0: [1, 8, 9], 1: [0, 2, 9, 10, 8], 2: [1, 3, 10, 11, 9], 3: [2, 4, 11, 12, 10], 4: [3, 5, 12, 13, 11], 5: [4, 6, 13, 14, 12], 6: [5, 7, 14, 15, 13], 7: [6, 15, 14], 8: [9, 0, 16, 17, 1], 9: [8, 10, 1, 17, 18, 0, 16, 2], 10: [9, 11, 2, 18, 19, 1, 17, 3], 11: [10, 12, 3, 19, 20, 2, 18, 4], 12: [11, 13, 4, 20, 21, 3, 19, 5], 13: [12, 14, 5, 21, 22, 4, 20, 6], 14: [13, 15, 6, 22, 23, 5, 21, 7], 15: [14, 7, 23, 6, 22], 16: [17, 8, 24, 25, 9], 17: [16, 18, 9, 25, 26, 8, 24, 10], 18: [17, 19, 10, 26, 27, 9, 25, 11], 19: [18, 20, 11, 27, 28, 10, 26, 12], 20: [19, 21, 12, 28, 29, 11, 27, 13], 21: [20, 22, 13, 29, 30, 12, 28, 14], 22: [21, 23, 14, 30, 31, 13, 29, 15], 23: [22, 15, 31, 14, 30], 24: [25, 16, 32, 33, 17], 25: [24, 26, 17, 33, 34, 16, 32, 18], 26: [25, 27, 18, 34, 35, 17, 33, 19], 27: [26, 28, 19, 35, 36, 18, 34, 20], 28: [27, 29, 20, 36, 37, 19, 35, 21], 29: [28, 30, 21, 37, 38, 20, 36, 22], 30: [29, 31, 22, 38, 39, 21, 37, 23], 31: [30, 23, 39, 22, 38], 32: [33, 24, 40, 41, 25], 33: [32, 34, 25, 41, 42, 24, 40, 26], 34: [33, 35, 26, 42, 43, 25, 41, 27], 35: [34, 36, 27, 43, 44, 26, 42, 28], 36: [35, 37, 28, 44, 45, 27, 43, 29], 37: [36, 38, 29, 45, 46, 28, 44, 30], 38: [37, 39, 30, 46, 47, 29, 45, 31], 39: [38, 31, 47, 30, 46], 40: [41, 32, 48, 49, 33], 41: [40, 42, 33, 49, 50, 32, 48, 34], 42: [41, 43, 34, 50, 51, 33, 49, 35], 43: [42, 44, 35, 51, 52, 34, 50, 36], 44: [43, 45, 36, 52, 53, 35, 51, 37], 45: [44, 46, 37, 53, 54, 36, 52, 38], 46: [45, 47, 38, 54, 55, 37, 53, 39], 47: [46, 39, 55, 38, 54], 48: [49, 40, 56, 57, 41], 49: [48, 50, 41, 57, 58, 40, 56, 42], 50: [49, 51, 42, 58, 59, 41, 57, 43], 51: [50, 52, 43, 59, 60, 42, 58, 44], 52: [51, 53, 44, 60, 61, 43, 59, 45], 53: [52, 54, 45, 61, 62, 44, 60, 46], 54: [53, 55, 46, 62, 63, 45, 61, 47], 55: [54, 47, 63, 46, 62], 56: [57, 48, 49], 57: [56, 58, 49, 48], 58: [57, 59, 50, 49], 59: [58, 60, 51, 50], 60: [59, 61, 52, 51], 61: [60, 62, 53, 52], 62: [61, 63, 54, 53], 63: [62, 55, 54],64:[]}
adjacents = {16:[0,8],2:[0,1],23:[7,15],5:[7,6],40:[56,48],58:[56,57],61:[63,62],47:[63,55]}

def numtokens(board,tokenlist):
    i = 0
    for item in board:
      if item in tokenlist:
        i+=1
      elif item!='.':
        i-=1
    return i
def numfrontiers(board,item,token):
    weight = 0
    for thing in frontiers[item]:
        if board[thing] not in ['x','X','o','O']:
            weight +=.75
    return weight
def findweight(board,item,token):
    weight = 0
    #newgame = board[:]
    #weight -= len(legalmoves(newgame,determineturnopposite(token)[1]))
    #weight = 0
    if numleft(board)>33:
        weight-=numfrontiers(board,item,token)
    else:
        weight+= numtokens(board,makelist(token))
    if item in corners:
        return 1000000
    newboard = board[:]
    if item in corx:
        if board[corx[item]] in token:
            return 100000
        else:
            return -10000 + weight
    if item in adjacents:
        if board[adjacents[item][0]] in token and board[adjacents[item][1]] != ".":
            weight += 100
    if item in edges and (board[edgecorners[item][0]] not in token and board[edgecorners[item][1]] not in token) and numleft(game)<20:
        weight-=40

    #if numleft(board) > 30:
    #    return -.5 + weight
    #else:
    return weight
def determine(game):
    l1 = 0
    l2 = 0
    for thing in game:
        if thing not in ['x','X','o','O']:
          l1 +=1
    if l1%2 == 0:
        return ['x','X']
    else:
        return ['o','O']
def determineturn(game):
    if len(game)>64:
      if game[64] in ['X', 'x']:
        return ['x', 'X']
      else:
        return ['o', 'O']
    else:
        l1 = 0
        l2 = 0
        for thing in game:
            if thing not in ['x', 'X', 'o', 'O']:
                l1 += 1
        if l1 % 2 == 0:
            return ['x', 'X']
        else:
            return ['o', 'O']

def determineturnopposite(token):
    if token in ['O', 'o']:
        return ['x', 'X']
    else:
        return ['o', 'O']

def determinetoken(token):
    if token in ['x','X']:
        return ['x','X']
    else:
        return ['o','O']
def givescore(game, token, place):
    list = alllegalmoves(game, token)
    bool = 0
    listt = []
    for i in list:
        if i[0] == place:
            bool = 1
            listt += [i]
    game2 = game[0:]
    for answer in listt:
        if bool == 1:
            while answer[1] + answer[2] != answer[0]:
                game2[answer[1] + answer[2]] = token
                answer[1] += answer[2]
            game2[answer[0]] = token
    return game2
def alllegalmoves(game, turn):
    notturn = ''
    possiblemoves = []
    if turn == 'x' or turn == 'X':
        notturn = ['o', 'O']
        turn = ['x', 'X']
    else:
        notturn = ['x', 'X']
        turn = ['o', 'O']
    poslist = [index for index, item in enumerate(game) if item in turn and index < 64]
    for index in poslist:
        count = 1
        helpcount = int(index / 8)
        while (index + count) < 64 and game[index + count] in notturn: count += 1
        if count != 1 and (index + count) < len(game) and game[index + count] == '.' and (
        int((index + count) / 8)) == helpcount: possiblemoves.append([index + count, index, 1])
        count = 1
        helpcount = int(index / 8)
        while (index - count) > -1 and game[index - count] in notturn: count += 1
        if count != 1 and (index - count) >= 0 and game[index - count] == '.' and (
        int((index - count) / 8)) == helpcount:            possiblemoves.append([index - count, index, -1])
        count = 8
        helpcount = int(index / 8)
        while (index + count) < 64 and game[index + count] in notturn: count += 8
        if count != 8 and (index + count) < len(game) and game[index + count] == '.':
            possiblemoves.append([index + count, index, 8])
        count = 8
        helpcount = int(index / 8)
        while (index - count) > -1 and game[index - count] in notturn: count += 8
        if count != 8 and (index - count) > -1 and game[index - count] == '.':
            possiblemoves.append([index - count, index, -8])
        count = 9
        helpcount = int(index / 8) + 1
        while (index + count) < 64 and game[index + count] in notturn:
            count += 9
            helpcount += 1
        if (index + count) < len(game) and count != 9 and game[index + count] == '.' and (
        int((index + count) / 8)) == helpcount:
            possiblemoves.append([index + count, index, 9])
        count = 9
        helpcount = int(index / 8) - 1
        while (index - count) > -1 and game[index - count] in notturn:
            count += 9
            helpcount -= 1
        if count != 9 and (index - count) > -1 and game[index - count] == '.' and (
        int((index - count) / 8)) == helpcount:
            possiblemoves.append([index - count, index, -9])
        count = 7
        helpcount = int(index / 8) + 1
        while (index + count) < 64 and game[index + count] in notturn:
            count += 7
            helpcount += 1
        if count != 7 and (index + count) < len(game) and game[index + count] == '.' and (
        int((index + count) / 8)) == helpcount:
            possiblemoves.append([index + count, index, 7])
        count = 7
        helpcount = int(index / 8) - 1
        while (index - count) > -1 and game[index - count] in notturn:
            count += 7
            helpcount -= 1
        if (index - count) > -1 and count != 7 and game[index - count] == '.' and (
        int((index - count) / 8)) == helpcount:
            possiblemoves.append([index - count, index, -7])
    return possiblemoves
def makelist(toke):
    if toke in ['x','X']:
        return['x','X']
    else:
        return ['o','O']
def makelistopposite(toke):
    if toke in ['x','X']:
        return['o','O']
    else:
        return ['x','X']
def evaluateboard(game, token):
    sum1 = 0
    sum2 = 0
    b = 0
    for index,item in enumerate(game):
        if item in makelist(token):
            b = 1
            sum1 += findweight(game,index,token)
        elif item in makelistopposite(token):
            sum2 += findweight(game,index,determineturnopposite(token))
    if b !=0:
      return (sum1 - sum2)
    else:
        return -100000
thing = '...................x.......xx......xo...........................o'
if sys.argv[1:] == []:
    game = ['.'] * 64 + ['x']
    game[27], game[28], game[35], game[36] = 'O', 'X', 'X', 'O'
else:
    list = []
    for char in sys.argv[1]:
        list += char
    if len(sys.argv[1:]) == 2:
        game = list + [sys.argv[2]]
    else:
        if len(sys.argv[1]) == 64:
            count = 0
            for char in list:
                if char == '.': count += 1
            if count % 2 == 0:
                game = list + ['x']
            else:
                game = list + ['o']
        else:
            for char in sys.argv[1]:
                list += char
                game = list
def printgame(game):
    print(''.join([''.join([game[i + z] for i in range(8)]) + '\n' for z in range(0, 64, 8)]))
def legalmoves(game, turn):
    notturn = ''
    possiblemoves = []
    if turn == 'x' or turn == 'X':
        notturn = ['o', 'O']
        turn = ['x', 'X']
    else:
        notturn = ['x', 'X']
        turn = ['o', 'O']
    poslist = [index for index, item in enumerate(game) if item in turn and index < 64]
    for index in poslist:
        count = 1
        helpcount = int(index / 8)
        while (index + count) < len(game) and game[index + count] in notturn: count += 1
        if count != 1 and (index + count) < len(game) and game[index + count] == '.' and (
        int((index + count) / 8)) == helpcount:
            possiblemoves.append(index + count)
        count = 1
        helpcount = int(index / 8)
        while (index - count) > -1 and game[index - count] in notturn: count += 1
        if count != 1 and (index - count) > -1 and game[index - count] == '.' and (
        int((index - count) / 8)) == helpcount: possiblemoves.append(index - count)
        count = 8
        helpcount = int(index / 8)
        while (index + count) < len(game) and game[index + count] in notturn: count += 8
        if count != 8 and (index + count) < len(game) and game[index + count] == '.':
            possiblemoves.append(index + count)
        count = 8
        helpcount = int(index / 8)
        while (index - count) > -1 and game[index - count] in notturn: count += 8
        if count != 8 and (index - count) > -1 and game[index - count] == '.':
            possiblemoves.append(index - count)
        count = 9
        if index == 25:
            adf = 'adf'
        helpcount = int(index / 8) + 1
        while (index + count) < len(game) and game[index + count] in notturn:
            count += 9
            helpcount += 1
        if (index + count) < len(game) and count != 9 and game[index + count] == '.' and (
        int((index + count) / 8)) == helpcount:
            possiblemoves.append(index + count)
        count = 9
        helpcount = int(index / 8) - 1
        while (index - count) > -1 and game[index - count] in notturn:
            count += 9
            helpcount -= 1
        if count != 9 and (index - count) > -1 and game[index - count] == '.' and (
        int((index - count) / 8)) == helpcount:
            possiblemoves.append(index - count)
        count = 7
        helpcount = int(index / 8) + 1
        while (index + count) < len(game) and game[index + count] in notturn:
            count += 7
            helpcount += 1
        if count != 7 and (index + count) < len(game) and game[index + count] == '.' and (
        int((index + count) / 8)) == helpcount:
            possiblemoves.append(index + count)
        count = 7
        helpcount = int(index / 8) - 1
        while (index - count) > -1 and game[index - count] in notturn:
            count += 7
            helpcount -= 1
        if (index - count) > -1 and count != 7 and game[index - count] == '.' and (
        int((index - count) / 8)) == helpcount:
            possiblemoves.append(index - count)
    helper = set()
    for item in possiblemoves:
        helper.add(item)
    actuallist = []
    for item in helper:
        actuallist.append(item)
    return actuallist
def negamax(game, token, level):
    if level == 0:
        return [evaluateboard(game,token)]
    lm = legalmoves(game,token)
    if len(lm) ==0:
        lmop = legalmoves(game,determineturnopposite(token)[1])
        if len(lmop) == 0:
            return [evaluateboard(game,token)]
        best = negamax(game,determineturnopposite(token)[1],level) + [-1]
        return [-best[0]] + best[1:]
    nmlist = sorted([negamax(givescore(game,token,move),determineturnopposite(token)[1],level-1)+ [move] for move in lm])
    best = nmlist[0]
    return [-best[0]] + best[1:]
def numleft(game):
  i = 0
  for item in game:
    if item == '.':
      i+=1
  return i
def heuristic(game,list):
    listnew = list[0:]
    for item in list:
      if item in corners:
        return item
    for item in listnew:
      if item in corx:
        if game[corx[item]] not in determineturn(game):
            listnew.remove(item)
        else:
            return item
    if len(listnew) != 0:
      list = listnew
    list2 = list[0:]
    if len(list2) !=0:
      list = list2
    return list.pop()
def pickamove(game, list,num,token):
  listnew = list[0:]
  if numleft(game)>6:
    return negamax(game, token, num)
  else:
    return negamax(game,token,1000)
string = '..OOOOOX..OOOOXX.OOOXXOOXOOXXXOO.OOXXOXX..OXOOXX.OOOOOOX.XXXX..X'
gametest = []
# for thing in string:gametest.append(thing)
# printgame(gametest)
# print(negamax(gametest, 'X', 3)[-1])
class Strategy():
  def best_strategy(self,board,player,best_move,still_running):
    broad = ''.join(board).replace('?','').replace('@','X')
    board = []
    for thing in broad:
      board.append(thing)
    token = "X" if player == '@' else 'O'
    list2 = legalmoves(board, token)
    if len(list2)!=0:
      help = list2[0]
      mv1 = 11+(help//8)*10 + (help%8)
      best_move.value = mv1

    # mv = pickamove(board,list2,1)[-1]
    # mv1 = 11+(mv//8)*10 + (mv%8)
    # best_move.value = mv1
    mv = pickamove(board,list2,3,token)[-1]
    mv1 = 11+(mv//8)*10 + (mv%8)
    best_move.value = mv1
    mv = pickamove(board, list2, 5,token)[-1]
    mv1 = 11 + (mv // 8) * 10 + (mv % 8)
    best_move.value = mv1
if __name__ == "___main__":
  main()

