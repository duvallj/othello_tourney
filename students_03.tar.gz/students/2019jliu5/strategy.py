#!/usr/bin/python3

from random import shuffle
from multiprocessing import Process, Value, Array

# Constants that we will use
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
BOARD_SIZE = 8

#To refer to neighbor squares we can add a direction to a square.

UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)
COLS = ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H')

SQUARE_WEIGHTS = [
	0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
	0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
	0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
	0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
	0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
	0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
	0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
	0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
	0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
	0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

MAX_VALUE = sum(map(abs, SQUARE_WEIGHTS))
MIN_VALUE = -MAX_VALUE

''' Function: Used to read the file and get all the boards. '''
def fetchBoards(filename):

	# Open the words file and read
	file = open(filename, 'r')

	# Create a list of all the boards
	boardList = []

	lines = file.readlines()
	numlines = len(lines)

	# Read each line
	for i in range(0, numlines):

		# Fetch the line
		line = lines[i]

		# First remove unnecessary characters
		line = line.strip()

		if len(line) > 0:
			
			#print('Line no: %d is %s' % (i+1, line))
			
			# Split the line to get the board and the player
			board, player = line.split(' ')

			# Add outer edges
			boardLine = OUTER * 10

			for j in range(0, BOARD_SIZE):
				boardLine += OUTER
				for k in range(0, BOARD_SIZE):
					boardLine += board[j * BOARD_SIZE + k]
				boardLine += OUTER

			# Append to the list
			boardList.append([boardLine, player])

	# Close the file
	file.close()

	# Return the list
	return boardList

''' Function: Print the board. '''
def printBoard(boardLine):

	#print(boardLine)

	print(' ', end = ' ')
	for i in range(0, BOARD_SIZE):
		print('%s' % (COLS[i]), end = ' ')
	print()

	for i in range (0, BOARD_SIZE):
		print('%d' % (i + 1), end = ' ')

		for j in range(0, BOARD_SIZE):
			print(boardLine[(i+1)*(BOARD_SIZE+2) + j + 1], end = ' ')
		
		print('%d' % (i+1))

	print(' ', end = ' ')
	for i in range(0, BOARD_SIZE):
		print('%s' % (COLS[i]), end = ' ')
	print()

class Strategy():

	''' Function: List all the valid squares on the board. '''
	def squares(self):
		return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]

	''' Function: Checks whether move is a valid square on the board. '''
	def is_valid(self, move):
		return isinstance(move, int) and move in self.squares()

	''' Function: Get the opponent player. '''
	def opponent(self, player):
		return BLACK if player is WHITE else WHITE

	''' Function: Finds a square that forms a bracket with square for player in the given direction. 
		Returns None if no such square exists.
	'''
	def find_bracket(self, square, player, board, direction):

		# First square in given direction
		bracket = square + direction

		#print('Checking for this square: %d with player: %s in direction: %d' % (square, player, direction))

		# If this does not contain opposite in between
		if self.is_valid(bracket) and board[bracket] == player:
			return None
		
		# Get the opponent
		opp = self.opponent(player)

		while self.is_valid(bracket) and board[bracket] == opp:
			bracket += direction

		result = None if (self.is_valid(bracket) == False or board[bracket] in (OUTER, EMPTY)) else bracket
		#print('Found result: %s' % (result))
		return result

	''' Function: Checks if the move is legal for the player. '''
	def is_legal(self, move, player, board):

		hasbracket = lambda direction: self.find_bracket(move, player, board, direction)
		return board[move] == EMPTY and any(map(hasbracket, DIRECTIONS))

	''' Function: Get a list of all legal moves for a player. '''
	def legal_moves(self, player, board):
		return [sq for sq in self.squares() if self.is_legal(sq, player, board)]

	''' Function: Check if a player can player make any moves? '''
	def any_legal_move(self, player, board):
		return any(self.is_legal(sq, player, board) for sq in self.squares())

	''' Function: Flips the pieces in given direction as a result of move by player. '''
	def make_flips(self, move, player, board, direction):
		bracket = self.find_bracket(move, player, board, direction)
		if not bracket:
			return
		square = move + direction
		while square != bracket:
			board[square] = player
			square += direction

	''' Function: Updates the board to reflect the move by the specified player. '''
	def make_move(self, move, player, board):
		board[move] = player
		for d in DIRECTIONS:
			self.make_flips(move, player, board, d)
		return board

	''' Function: Get the weighted score of the board. '''
	def weighted_score(self, player, board):
		opp = self.opponent(player)
		total = 0
		for sq in self.squares():
			if board[sq] == player:
				total += SQUARE_WEIGHTS[sq]
			elif board[sq] == opp:
				total -= SQUARE_WEIGHTS[sq]
		return total

	def minimax(self, player, board, depth):

		# We define the value of a board to be the opposite of its value to our opponent, computed by recursively applying minimax for our opponent.

		def value(board):
			return -self.minimax(self.opponent(player), board, depth-1)[0]

		# When depth is zero, don't examine possible moves--just determine the value of this board to the player.

		if depth == 0:
			return self.weighted_score(player, board), None

		# We want to evaluate all the legal moves by considering their implications depth turns in advance. 
		# First, find all the legal moves.
		moves = self.legal_moves(player, board)

		# If player has no legal moves, then either:
		if not moves:
			# the game is over, so the best achievable score is victory or defeat;

			if not self.any_legal_move(self.opponent(player), board):
				return self.final_value(player, board), None
			
			# or we have to pass this turn, so just find the value of this board.
			return value(board), None
		# When there are multiple legal moves available, choose the best one by maximizing the value of the resulting boards.
		return max((value(self.make_move(m, player, list(board))), m) for m in moves)

	def final_value(self, player, board):
		diff = self.weighted_score(player, board)
		return diff

	''' Function: To get the best strategy. '''
	def best_strategy(self, board, player, best_move, still_running):

		# We will only move till next three moves
		depth = 3

		best_move.value = self.minimax(player, board, depth)[1]
'''
def main():
	# Read the file name
	filename  = input('Please enter the file name: ')

	# Fetch all the boards
	boardList = fetchBoards(filename)
	strategy  = Strategy()

	for i in range(0, len(boardList)):

		print('Board looks like this: ')
		printBoard(boardList[i][0])

		possibleMoves = strategy.legal_moves(boardList[i][1], boardList[i][0])
		bestMove      = strategy.best_strategy(boardList[i][0], boardList[i][1], 0, 0)



		print('It\'s %s\'s chance.' % (PLAYERS[boardList[i][1]]))

		if possibleMoves != None and len(possibleMoves) > 0:
			print('%s can place his move on following squares:' % (boardList[i][1]))
			for j in range(0, len(possibleMoves)):
				move = possibleMoves[j]
				row  = int(move / 10)
				col  = (move % 10) - 1

				print('%s%d' % (COLS[col], row), end = ' ')

				''
				hasbracket = lambda direction: find_bracket(move, boardList[i][1], boardList[i][0], direction)
				for direction in DIRECTIONS:
					val = hasbracket(direction)
					if val != None:
						vrow = int(val/10)
						vcol = (val % 10) - 1
						print('%s : %s%d' % (direction, COLS[vcol], vrow), end = ' ')

				print()
				''

			print()
			brow  = int(bestMove / 10)
			bcol  = (bestMove % 10) - 1

			print('Best chance to play on: %s%d' % (COLS[col], row), end = ' ')
			print()
		else:
			print('%s has to pass his chance' % (boardList[i][1]))

if __name__ == '__main__':
	main()
'''