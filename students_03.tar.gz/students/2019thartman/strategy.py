import functools
import cProfile
class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        brd = ''.join(board).replace('?','').replace('@','X').replace('o','O')
        token = 'X' if player == '@' else 'O'
        x = 1
        if brd.count(".") >= 14:
            while(True):
                mv = negamaxD(brd,token,-float("inf"),float("inf"),x)[-1]
                mv1 = 11+(mv//8)*10+(mv%8)
                best_move.value = mv1
                x +=1
        else:
            while(True):
                mv = negamaxE(brd,token,-65,65,x)[-1]
                mv1 = 11+(mv//8)*10+(mv%8)
                best_move.value = mv1
                x +=1


from collections import defaultdict
import sys
import random
flip = {"X":"O","O":"X"}
dumb = [-1,0,1]
corners = {0,7,56,63}
xs = {9,14,49,54}
cs = {1,8,6,15,48,57,62,55}
sur = {0:{1,8},7:{6,15},56:{48,57},63:{62,55}}
cdict = {1:0,8:0,6:7,15:7,48:56,57:56,62:63,55:63}
edges = {*range(0,8),*range(56,64),*range(0,56,8),*range(7,63,8)}
neigh = defaultdict(set)
axis = [(-1,1),(-8,8),(-9,9),(-7,7)]
#value = [99,-8,8,6,6,8,-8,99,-8,-24,-4,-3,-3,-4,-24,-8,8,-4,7,4,4,7,-4,8,6,-3,4,0,0,4,-3,6,6,-3,4,0,0,4,-3,6,8,-4,7,4,4,7,-4,8,-8,-24,-4,-3,-3,-4,-24,-8,99,-8,8,6,6,8,-8,99]
conversion = {"abcdefgh"[n]:n for n in range(8)}
[neigh[i].add(i + ro + 8*co) for co in dumb for ro in dumb for i in range(0,64) if (i + ro + 8*co) != i and (i + ro + 8*co) > -1 and (i + ro + 8*co) < 64]
[neigh[p].discard(p+7) for p in range(0,64,8)]
[neigh[p].discard(p-9) for p in range(16,64,8)]
[neigh[p].discard(p-1) for p in range(8,64,8)]
[neigh[p].discard(p-7) for p in range(7,64,8)]
[neigh[p].discard(p+9) for p in range(7,55,8)]
[neigh[p].discard(p+1) for p in range(7,64,8)]
def othprint(board):
   [print(board[x*8:(x*8)+8]) for x in range(0,8)]
def convert(s):
    if s[0].lower() in "abcdefgh":
        return conversion[s[0].lower()]+8*(int(s[1])-1)
    else:
        return int(s)
def isStable(board,idx,who):
    if board[idx] != who:
        return False
    if idx in corners:
        return True
    elif idx in edges:
        if idx % 8 != 0:
            if not stab(board,idx,idx+1,who) and not stab(board,idx,idx-1,who):
                return False
            return True
        else:
            if not stab(board,idx,idx+8,who) and not stab(board,idx,idx-8,who):
                return False
            return True
    else:
        for pair in axis:
            if not stab(board,idx,idx+pair[0],who) and not stab(board,idx,idx+pair[1],who):
                return False
        return True
def stab(board,idx,idx2,who):
    xmove,ymove = idx2%8 - idx%8, idx2//8 - idx//8
    next = idx2 + (8*ymove) + xmove
    if board[idx2] != who:
        return False
    if -1 < next < 64 and next in neigh[idx2]:
        if board[next] == who:
            return stab(board,idx2,next,who)
        else:
            return False
    return True
def turn(board):
   dotn = sum([1 for r in board if r == "."])
   if dotn%2 == 0:
       return "X"
   else:
       return "O"
def insert(board,idx,who):
    if idx != 63:
        return board[:idx] + who + board[idx + 1:]
    else:
        return board[:idx] + who
        
@functools.lru_cache(maxsize=2**14, typed=False)
def posset(board,who):
    realpos,pos = set(),set()
    [pos.add(neighbor) for spot in range(64) if board[spot] != "." for neighbor in neigh[spot] if board[neighbor] == "."]
    [realpos.add(idx) for idx in pos for idx2 in neigh[idx] if board[idx2] == flip[who] and makeline(board,idx,idx2,who)[0]]
    return realpos
    
def makeline(board,idx,idx2,who):
    xmove,ymove = idx2%8 - idx%8, idx2//8 - idx//8
    next = idx2 + (8*ymove) + xmove
    if -1 < next < 64 and next in neigh[idx2]:
        if board[next] == who:
            return (True,next)
        elif board[next] == flip[who]:
            return makeline(board,idx2,next,who)
    return (False,-1)
def npo(a):
    if a == 0:
        return 0
    elif a > 0:
        return 1
    elif a < 0:
        return -1
def fate(board):
    xsum = sum([1 for x in board if x == "X"])
    osum = sum([1 for o in board if o == "O"])
    print("X score: " + str(xsum) + " O score: " + str(osum))
    if not posset(board,"X") and not posset(board,"O"):
        if xsum > osum:
            return "X"
        elif osum > xsum:
            return "O"
        else:
            return "tie"
    else:
        return "playable"
def bestmove(board,who):
    pos = posset(board,who)
    p = set()
    for spot in pos:
        if spot in corners:
            return spot
        elif gedge(board,spot,who):
            return spot
        elif spot not in cs and spot not in xs:
            p.add(spot)
        for corner in sur:
            if board[corner] == who:
                un = pos & sur[corner]
                if un:
                    return un.pop()
    if p:
        temp = set()
        for idx in p:
            if idx not in edges:
                temp.add(idx)
            if temp:
                return random.choice([*temp])
                #return max([(value[idx],idx) for idx in temp])[1]
        #return max([(value[idx], idx) for idx in p])[1]
        return random.choice([*p])
    return random.choice([*pos])
    #return max([(value[idx], idx) for idx in pos])[1]
def gedge(board,spot,who):
    if spot in edges:
        if spot // 8 == 0 or spot // 8 == 0:
            if board[makeline(board,spot,spot+1,who)[1]] == who or board[makeline(board,spot,spot-1,who)[1]] == who:
                return True
        if spot % 8 == 0 or spot % 8 == 0:
            if board[makeline(board, spot, spot + 8, who)[1]] == who or board[makeline(board, spot, spot - 8, who)[1]] == who:
                return True
    return False

def play(board,who,idx):
    friends = {makeline(board,idx,n,who)[1] for n in neigh[idx] if board[n] == flip[who]}
    friends.discard(-1)
    for friend in friends:
        xmove, ymove = npo(friend % 8 - idx % 8), npo(friend // 8 - idx // 8)
        tempidx = idx + xmove + 8*(ymove)
        while(tempidx != friend):
            board = insert(board,tempidx,who)
            tempidx += xmove + 8*(ymove)
    board = insert(board,idx,who)
    #othprint(board)
    #print(board)
    #fate(board)
    return board
    
def hcorners(board,who):
    return sum([1 for idx in corners if board[idx] == who]) - sum([1 for idx in corners if board[idx] == flip[who]])

def ccount(board,who):
    return sum([1 for idx in cs if board[idx] == who and not board[cdict[idx]] == who]) - sum([1 for idx in cs if board[idx] == flip[who] and not board[cdict[idx]] == flip[who]])
    
def xcount(board,who):
    return sum([1 for idx in xs if board[idx] == who]) - sum([1 for idx in xs if board[idx] == flip[who]])
    
def hmoves(board,who):
    return len(posset(board,who)) - len(posset(board,flip[who]))
    
def htoks(board,who):
    return sum([1 for x in board if x == who]) - sum([1 for o in board if o == flip[who]])

def stabs(board,who):
    return sum([1 for x in range(len(board)) if isStable(board,x,who)]) - sum([1 for x in range(len(board)) if isStable(board,x,flip[who])])

def eboard(board,who):
    return 9999999999*hcorners(board,who) + htoks(board,who)- 6*ccount(board,who) - 15*xcount(board,who) + 10*hmoves(board,who)

def negamax(board,who,depth,passes):
    if not depth:
        return [eboard(board,who)]
    if passes == 2:
        return [htoks(board,who)]
    moves = posset(board,who)
    if not moves:
        nm = negamax(board,flip[who],depth-1,passes+1)+[-1]
        return [-nm[0]] + nm[1:]
    nm = sorted([negamax(play(board,who,move),flip[who],depth-1,0)+[move] for move in moves])
    best = nm[0]
    return [-best[0]]+best[1:]

def negamaxT(board,token,im,hb):
    if not posset(board,token):
        lm2 = posset(board,flip[token])
        if not lm2:
            return[htoks(board,token),-3]
        nm = negamaxT(board,flip[token],-hb,-im)+[-1]
        return [-nm[0]]+nm[1:]
    best = []
    newhb = -im
    #l = [(mv, play(board,token,mv)) for mv in posset(board,token)]
    #sl = sorted(l, key=lamba mv: eboard(mv[1]),reversed=True)
    for move in posset(board,token):
    #for move in sl:
        nm = negamaxT(play(board,token,move),flip[token],-hb,newhb)+[move]
        #nm = negamaxT(move[1],flip[token],-hb,newhb)+[move[0]]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0] < newhb:
                newhb = nm[0]
                if -newhb >= hb:
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]
    
def negamaxD(board,token,im,hb,depth):
    if not depth:
        return [eboard(board,token)]
    if not posset(board,token):
        lm2 = posset(board,flip[token])
        if not lm2:
            return[eboard(board,token),-3]
        nm = negamaxD(board,flip[token],-hb,-im,depth-1)+[-1]
        return [-nm[0]]+nm[1:]
    best = []
    newhb = -im
    for move in posset(board,token):
        nm = negamaxD(play(board,token,move),flip[token],-hb,newhb,depth-1)+[move]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0] < newhb:
                newhb = nm[0]
                if -newhb >= hb:
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]

def negamaxE(board,token,im,hb,depth):
    if not depth:
        return [eboard(board,token)]
    if not posset(board,token):
        lm2 = posset(board,flip[token])
        if not lm2:
            return[htoks(board,token),-3]
        nm = negamaxD(board,flip[token],-hb,-im,depth-1)+[-1]
        return [-nm[0]]+nm[1:]
    best = []
    newhb = -im
    for move in posset(board,token):
        nm = negamaxD(play(board,token,move),flip[token],-hb,newhb,depth-1)+[move]
        if not best or nm[0] < newhb:
            best = nm
            if nm[0] < newhb:
                newhb = nm[0]
                if -newhb >= hb:
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]

def main():
    board = "...........................OX......XO..........................."
    who = None
    moves = []
    for item in sys.argv[1:]:
        try:
            if len(item) != 64:
                if item.upper() == "X" or item.upper() == "O":
                    who = item.upper()
                else:
                    moves.append(item)
            else:
                board = item.upper()
        except:
            no = ""
    if who == None:
        who = turn(board)
    #othprint(board)
    othprint(board)
    print("Legal moves: " + str([*posset(board,who)])[1:-1])
    if board.count(".") <= 14:
        print("My heuristic move is: " + str(bestmove(board,who)))
        l = negamaxT(board,who,-65,65)
        print("My negamax score is: "+str(l[0])+" and my move is: " + str(l[-1]))
    else:
        print("My heuristic move is: " + str(bestmove(board,who)))
if __name__=="__main__":
    main()
  
