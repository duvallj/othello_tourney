#!/where python3 lives
# Isaac David Othello
# v. 0.4.5.9
import sys
import random
from time import perf_counter, time
# from datetime import date
from collections import namedtuple
from functools import reduce
# import os
import multiprocessing

# //TRY TO CUT DOWN ON CALLS TO getPossibleMoves()
# //and _evalDiscLocations
# Maybe make Board a class to implement a delayed calculation of get possible moves/maybe a faster instantiation,
# is eval disc locations a problem because of
# try memos
# try different keygens, symmetries
# coroutines
# opening book
# I give away corners way too easily something's up in the code
# consider dynamic evaluation function
maxEval = 1 << 80
minEval = -maxEval
WIN = maxEval // 100
TIE = 0
LOSS = -WIN
defaultDepth = 6
maxDepth = 7
startFullSearch = 13
assert maxDepth is None or maxDepth >= defaultDepth
FULL, TOKEN, HEUR = (1, 2, 4)
evalType = HEUR
tiles = {'X', 'O'}
stableDepth = 2
evalRounder = 0
# double check evalRound not too large, not too small
# maybe upgrade mobility heuristic
#
openingBook = {4740831241376492421120: 137438953472, 4740831241445346115584: 17179869184,
               4722366482973127606272: 17179869184, 4778013805424236560384: 137438953472,
               4852376396946936430592: 524288, 4722366482973194190848: 1048576, 313131912750030967541858304: 536870912,
               79197655380716611809837056: 67108864, 14494547170316058099712: 17592186044416,
               57978188681263292874752: 8796093022208, 14462247353788691644416: 35184372088832,
               57848989415153557569536: 4398046511104, 4833695465762263138304: 4398046511104,
               4759476707883204214784: 35184372088832, 313122412604793109155414016: 262144,
               79195266509353567286984704: 2097152, 311917065525568729140690944: 2097152,
               77979266381392375793582080: 262144, 4740867340610975563776: 67108864, 4740975639207913455616: 536870912,
               4815050563304950857728: 1048576, 4740867340611042148352: 524288,
               1242789928128063499566841856: 137438953472, 78587280289446970664157184: 17179869184,
               19648604862401630103928832: 8796093022208, 1242789928128046044819750912: 17592186044416,
               4759476707883137630208: 536870912, 4759476707952126590976: 67108864,
               57848989415154093391872: 17592186044416, 14462247353788758228992: 8796093022208,
               311917065525595169227800576: 17179869184, 311917065525577508053843968: 137438953472,
               14462247353909017313280: 524288, 57848989415394611560448: 1048576,
               1242808891597548967168049152: 137438953472, 19649804063741652376748032: 17179869184,
               20267383022070809707937792: 8796093022208, 1245218428172809678347042816: 17592186044416,
               313127171936874462321836032: 67108864, 79200081615081362258132992: 536870912,
               311907583827074909569286144: 1048576, 77976895956773336193957888: 524288,
               1237968410540353156591124480: 17592186044416, 19346364275048023059333120: 8796093022208,
               77979275640938483178012672: 17179869184, 1240373252491322191632138240: 137438953472,
               313122421882208410325483520: 524288, 79195303835191677519134720: 1048576,
               311917102563736114102796288: 536870912, 77979275640934222033846272: 67108864,
               2792665977889696389225512960: 1048576, 175003873880689896683732992: 524288,
               77373622880118465072988160: 137438953472, 1254937113734805221511528448: 17179869184,
               313127190491846214399557632: 8796093022208, 79200100278566666129899520: 17592186044416,
               311907620864679345113792512: 67108864, 77976905216174445013237760: 536870912,
               2792651792253343822226391040: 8796093022208, 174996771739556609380581376: 17592186044416,
               79815197320729568538001408: 67108864, 1254927604402241869490159616: 536870912,
               310699875564847243486560256: 1048576, 310721140521726821056643072: 524288,
               313124824737381287337132032: 137438953472, 79204831543027015996407808: 17179869184,
               3803945449434678495470944256: 9007199254740992, 954180268832568235912593408: 1125899906842624,
               79808002927997956764729344: 2199023255552, 1254994170487002741578137600: 70368744177664,
               313136727820098474426236928: 1024, 309506260835336044313837568: 8192,
               309487407902737938487705600: 4194304, 77380706700476699107917824: 131072,
               81926653329453575497943771250688: 70368744177664, 1318006768082067318752140066816: 2199023255552,
               241201691250720945133846528: 1125899906842624, 15169129520050532618264903680: 9007199254740992,
               313136681431981384640758784: 131072, 309506353360452600277762048: 4194304,
               314342242473292996846551040: 8192, 77683258699497800086847488: 1024,
               81288481917332047705996218859520: 4503599627370496, 1307888507296932289823636979712: 2251799813685248,
               1297811374404684237253575704576: 8589934592, 82087528477586724740064668024832: 274877906944,
               313139070425373194327163904: 2048, 309487389744162797199564800: 4096,
               314342130927696659484778496: 1073741824, 77683244836581711287288832: 33554432,
               183257769211347618149991354728448: 536870912, 11588985691622199650924874432512: 67108864,
               1297537386902595242449462362112: 17592186044416, 82083170241932061032325435097088: 8796093022208,
               311919449862106326377565184: 17179869184, 311919491964229084457730048: 137438953472,
               314413524167588325692022784: 524288, 77692117361442222414496768: 1048576,
               183257769211347631687264684736512: 536870912, 11588985691622203055184807460864: 67108864,
               1297537386902594103354476462080: 17592186044416, 82083170241932051972349152460800: 8796093022208,
               311919449862088665136106496: 17179869184, 311919491964246745700380672: 137438953472,
               314413524167606057401589760: 524288, 77692117361451036727706624: 1048576,
               4759585218754468904960: 536870912, 4833695465762266284032: 67108864,
               58108543125076034191360: 17592186044416, 14478455844100689625088: 8796093022208,
               3795440328795825696950714368: 17179869184, 952050370561239181615431680: 137438953472,
               79195266509357982513364992: 524288, 1247696707576129216074219520: 1048576,
               79197688041317058568257536: 17592186044416, 313132042635828015365357568: 8796093022208,
               311907620864679465439985664: 17179869184, 77976905216174325291024384: 137438953472,
               3799708343037863722198499328: 524288, 949939495928349990915670016: 1048576,
               77373622880118602042179584: 536870912, 1256187904849922700604342272: 67108864,
               313143788134289023516278784: 2097152, 310104078231980975050457088: 262144,
               311305828103352710050349056: 35184372088832, 311327113786114002626543616: 4398046511104,
               3803904124066447121806000128: 4398046511104, 954188528379959338666557440: 35184372088832,
               78599188366152947081936896: 262144, 1253763020822705638816612352: 2097152}
bitscan = {0: -1}
for i in range(64):
  bitscan[1 << i] = i
reverseLook = {0b1: (7, 7, 14, 7), 0b10: (7, 6, 13, 8), 0b100: (7, 5, 12, 9), 0b1000: (7, 4, 11, 10),
               0b10000: (7, 3, 10, 11), 0b100000: (7, 2, 9, 12), 0b1000000: (7, 1, 8, 13), 0b10000000: (7, 0, 7, 14),
               0b100000000: (6, 7, 13, 6), 0b1000000000: (6, 6, 12, 7), 0b10000000000: (6, 5, 11, 8),
               0b100000000000: (6, 4, 10, 9), 0b1000000000000: (6, 3, 9, 10), 0b10000000000000: (6, 2, 8, 11),
               0b100000000000000: (6, 1, 7, 12), 0b1000000000000000: (6, 0, 6, 13), 0b10000000000000000: (5, 7, 12, 5),
               0b100000000000000000: (5, 6, 11, 6), 0b1000000000000000000: (5, 5, 10, 7),
               0b10000000000000000000: (5, 4, 9, 8), 0b100000000000000000000: (5, 3, 8, 9),
               0b1000000000000000000000: (5, 2, 7, 10), 0b10000000000000000000000: (5, 1, 6, 11),
               0b100000000000000000000000: (5, 0, 5, 12), 0b1000000000000000000000000: (4, 7, 11, 4),
               0b10000000000000000000000000: (4, 6, 10, 5), 0b100000000000000000000000000: (4, 5, 9, 6),
               0b1000000000000000000000000000: (4, 4, 8, 7), 0b10000000000000000000000000000: (4, 3, 7, 8),
               0b100000000000000000000000000000: (4, 2, 6, 9), 0b1000000000000000000000000000000: (4, 1, 5, 10),
               0b10000000000000000000000000000000: (4, 0, 4, 11), 0b100000000000000000000000000000000: (3, 7, 10, 3),
               0b1000000000000000000000000000000000: (3, 6, 9, 4), 0b10000000000000000000000000000000000: (3, 5, 8, 5),
               0b100000000000000000000000000000000000: (3, 4, 7, 6),
               0b1000000000000000000000000000000000000: (3, 3, 6, 7),
               0b10000000000000000000000000000000000000: (3, 2, 5, 8),
               0b100000000000000000000000000000000000000: (3, 1, 4, 9),
               0b1000000000000000000000000000000000000000: (3, 0, 3, 10),
               0b10000000000000000000000000000000000000000: (2, 7, 9, 2),
               0b100000000000000000000000000000000000000000: (2, 6, 8, 3),
               0b1000000000000000000000000000000000000000000: (2, 5, 7, 4),
               0b10000000000000000000000000000000000000000000: (2, 4, 6, 5),
               0b100000000000000000000000000000000000000000000: (2, 3, 5, 6),
               0b1000000000000000000000000000000000000000000000: (2, 2, 4, 7),
               0b10000000000000000000000000000000000000000000000: (2, 1, 3, 8),
               0b100000000000000000000000000000000000000000000000: (2, 0, 2, 9),
               0b1000000000000000000000000000000000000000000000000: (1, 7, 8, 1),
               0b10000000000000000000000000000000000000000000000000: (1, 6, 7, 2),
               0b100000000000000000000000000000000000000000000000000: (1, 5, 6, 3),
               0b1000000000000000000000000000000000000000000000000000: (1, 4, 5, 4),
               0b10000000000000000000000000000000000000000000000000000: (1, 3, 4, 5),
               0b100000000000000000000000000000000000000000000000000000: (1, 2, 3, 6),
               0b1000000000000000000000000000000000000000000000000000000: (1, 1, 2, 7),
               0b10000000000000000000000000000000000000000000000000000000: (1, 0, 1, 8),
               0b100000000000000000000000000000000000000000000000000000000: (0, 7, 7, 0),
               0b1000000000000000000000000000000000000000000000000000000000: (0, 6, 6, 1),
               0b10000000000000000000000000000000000000000000000000000000000: (0, 5, 5, 2),
               0b100000000000000000000000000000000000000000000000000000000000: (0, 4, 4, 3),
               0b1000000000000000000000000000000000000000000000000000000000000: (0, 3, 3, 4),
               0b10000000000000000000000000000000000000000000000000000000000000: (0, 2, 2, 5),
               0b100000000000000000000000000000000000000000000000000000000000000: (0, 1, 1, 6),
               0b1000000000000000000000000000000000000000000000000000000000000000: (0, 0, 0, 7)}

Board = namedtuple('Board', ['myBoard', 'otherBoard', 'empties', 'myPossibleMoves', 'otherPossibleMoves', 'myStables',
                             'otherStables', 'myDirectionStables', 'otherDirectionStables'])
#                        0            1           2             3                    4                 5             6                  7                       8
# dirStables:[H, V, NE, NW]

coord = []
app = coord.append
for i in range(64):
  app(1 << i)

leftMask = [
  0x0000000000000000, 0x0000000000000001, 0x0000000000000003, 0x0000000000000007, 0x000000000000000F,
  0x000000000000001F, 0x000000000000003F, 0x000000000000007F,
  0x0000000000000000, 0x0000000000000100, 0x0000000000000300, 0x0000000000000700, 0x0000000000000F00,
  0x0000000000001F00, 0x0000000000003F00, 0x0000000000007F00,
  0x0000000000000000, 0x0000000000010000, 0x0000000000030000, 0x0000000000070000, 0x00000000000F0000,
  0x00000000001F0000, 0x00000000003F0000, 0x00000000007F0000,
  0x0000000000000000, 0x0000000001000000, 0x0000000003000000, 0x0000000007000000, 0x000000000F000000,
  0x000000001F000000, 0x000000003F000000, 0x000000007F000000,
  0x0000000000000000, 0x0000000100000000, 0x0000000300000000, 0x0000000700000000, 0x0000000F00000000,
  0x0000001F00000000, 0x0000003F00000000, 0x0000007F00000000,
  0x0000000000000000, 0x0000010000000000, 0x0000030000000000, 0x0000070000000000, 0x00000F0000000000,
  0x00001F0000000000, 0x00003F0000000000, 0x00007F0000000000,
  0x0000000000000000, 0x0001000000000000, 0x0003000000000000, 0x0007000000000000, 0x000F000000000000,
  0x001F000000000000, 0x003F000000000000, 0x007F000000000000,
  0x0000000000000000, 0x0100000000000000, 0x0300000000000000, 0x0700000000000000, 0x0F00000000000000,
  0x1F00000000000000, 0x3F00000000000000, 0x7F00000000000000]

downLeftMask = [
  0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFEFF, 0xFFFFFFFFFFFEFDFF, 0xFFFFFFFFFEFDFBFF, 0xFFFFFFFEFDFBF7FF,
  0xFFFFFEFDFBF7EFFF, 0xFFFEFDFBF7EFDFFF, 0xFEFDFBF7EFDFBFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFEFFFF, 0xFFFFFFFFFEFDFFFF, 0xFFFFFFFEFDFBFFFF, 0xFFFFFEFDFBF7FFFF,
  0xFFFEFDFBF7EFFFFF, 0xFEFDFBF7EFDFFFFF, 0xFDFBF7EFDFBFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFEFFFFFF, 0xFFFFFFFEFDFFFFFF, 0xFFFFFEFDFBFFFFFF, 0xFFFEFDFBF7FFFFFF,
  0xFEFDFBF7EFFFFFFF, 0xFDFBF7EFDFFFFFFF, 0xFBF7EFDFBFFFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFFFFFEFFFFFFFF, 0xFFFFFEFDFFFFFFFF, 0xFFFEFDFBFFFFFFFF, 0xFEFDFBF7FFFFFFFF,
  0xFDFBF7EFFFFFFFFF, 0xFBF7EFDFFFFFFFFF, 0xF7EFDFBFFFFFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFFFEFFFFFFFFFF, 0xFFFEFDFFFFFFFFFF, 0xFEFDFBFFFFFFFFFF, 0xFDFBF7FFFFFFFFFF,
  0xFBF7EFFFFFFFFFFF, 0xF7EFDFFFFFFFFFFF, 0xEFDFBFFFFFFFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFEFFFFFFFFFFFF, 0xFEFDFFFFFFFFFFFF, 0xFDFBFFFFFFFFFFFF, 0xFBF7FFFFFFFFFFFF,
  0xF7EFFFFFFFFFFFFF, 0xEFDFFFFFFFFFFFFF, 0xDFBFFFFFFFFFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFEFFFFFFFFFFFFFF, 0xFDFFFFFFFFFFFFFF, 0xFBFFFFFFFFFFFFFF, 0xF7FFFFFFFFFFFFFF,
  0xEFFFFFFFFFFFFFFF, 0xDFFFFFFFFFFFFFFF, 0xBFFFFFFFFFFFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF,
  0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF]
downMask = [
  0XFEFEFEFEFEFEFEFF, 0XFDFDFDFDFDFDFDFF, 0XFBFBFBFBFBFBFBFF, 0XF7F7F7F7F7F7F7FF, 0XEFEFEFEFEFEFEFFF,
  0XDFDFDFDFDFDFDFFF, 0XBFBFBFBFBFBFBFFF, 0X7F7F7F7F7F7F7FFF,
  0XFEFEFEFEFEFEFFFF, 0XFDFDFDFDFDFDFFFF, 0XFBFBFBFBFBFBFFFF, 0XF7F7F7F7F7F7FFFF, 0XEFEFEFEFEFEFFFFF,
  0XDFDFDFDFDFDFFFFF, 0XBFBFBFBFBFBFFFFF, 0X7F7F7F7F7F7FFFFF,
  0XFEFEFEFEFEFFFFFF, 0XFDFDFDFDFDFFFFFF, 0XFBFBFBFBFBFFFFFF, 0XF7F7F7F7F7FFFFFF, 0XEFEFEFEFEFFFFFFF,
  0XDFDFDFDFDFFFFFFF, 0XBFBFBFBFBFFFFFFF, 0X7F7F7F7F7FFFFFFF,
  0XFEFEFEFEFFFFFFFF, 0XFDFDFDFDFFFFFFFF, 0XFBFBFBFBFFFFFFFF, 0XF7F7F7F7FFFFFFFF, 0XEFEFEFEFFFFFFFFF,
  0XDFDFDFDFFFFFFFFF, 0XBFBFBFBFFFFFFFFF, 0X7F7F7F7FFFFFFFFF,
  0XFEFEFEFFFFFFFFFF, 0XFDFDFDFFFFFFFFFF, 0XFBFBFBFFFFFFFFFF, 0XF7F7F7FFFFFFFFFF, 0XEFEFEFFFFFFFFFFF,
  0XDFDFDFFFFFFFFFFF, 0XBFBFBFFFFFFFFFFF, 0X7F7F7FFFFFFFFFFF,
  0XFEFEFFFFFFFFFFFF, 0XFDFDFFFFFFFFFFFF, 0XFBFBFFFFFFFFFFFF, 0XF7F7FFFFFFFFFFFF, 0XEFEFFFFFFFFFFFFF,
  0XDFDFFFFFFFFFFFFF, 0XBFBFFFFFFFFFFFFF, 0X7F7FFFFFFFFFFFFF,
  0XFEFFFFFFFFFFFFFF, 0XFDFFFFFFFFFFFFFF, 0XFBFFFFFFFFFFFFFF, 0XF7FFFFFFFFFFFFFF, 0XEFFFFFFFFFFFFFFF,
  0XDFFFFFFFFFFFFFFF, 0XBFFFFFFFFFFFFFFF, 0X7FFFFFFFFFFFFFFF,
  0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF]
downRightMask = [
  0X7FBFDFEFF7FBFDFF, 0XFF7FBFDFEFF7FBFF, 0XFFFF7FBFDFEFF7FF, 0XFFFFFF7FBFDFEFFF, 0XFFFFFFFF7FBFDFFF,
  0XFFFFFFFFFF7FBFFF, 0XFFFFFFFFFFFF7FFF, 0XFFFFFFFFFFFFFFFF,
  0XBFDFEFF7FBFDFFFF, 0X7FBFDFEFF7FBFFFF, 0XFF7FBFDFEFF7FFFF, 0XFFFF7FBFDFEFFFFF, 0XFFFFFF7FBFDFFFFF,
  0XFFFFFFFF7FBFFFFF, 0XFFFFFFFFFF7FFFFF, 0XFFFFFFFFFFFFFFFF,
  0XDFEFF7FBFDFFFFFF, 0XBFDFEFF7FBFFFFFF, 0X7FBFDFEFF7FFFFFF, 0XFF7FBFDFEFFFFFFF, 0XFFFF7FBFDFFFFFFF,
  0XFFFFFF7FBFFFFFFF, 0XFFFFFFFF7FFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XEFF7FBFDFFFFFFFF, 0XDFEFF7FBFFFFFFFF, 0XBFDFEFF7FFFFFFFF, 0X7FBFDFEFFFFFFFFF, 0XFF7FBFDFFFFFFFFF,
  0XFFFF7FBFFFFFFFFF, 0XFFFFFF7FFFFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XF7FBFDFFFFFFFFFF, 0XEFF7FBFFFFFFFFFF, 0XDFEFF7FFFFFFFFFF, 0XBFDFEFFFFFFFFFFF, 0X7FBFDFFFFFFFFFFF,
  0XFF7FBFFFFFFFFFFF, 0XFFFF7FFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XFBFDFFFFFFFFFFFF, 0XF7FBFFFFFFFFFFFF, 0XEFF7FFFFFFFFFFFF, 0XDFEFFFFFFFFFFFFF, 0XBFDFFFFFFFFFFFFF,
  0X7FBFFFFFFFFFFFFF, 0XFF7FFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XFDFFFFFFFFFFFFFF, 0XFBFFFFFFFFFFFFFF, 0XF7FFFFFFFFFFFFFF, 0XEFFFFFFFFFFFFFFF, 0XDFFFFFFFFFFFFFFF,
  0XBFFFFFFFFFFFFFFF, 0X7FFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF,
  0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF, 0XFFFFFFFFFFFFFFFF]
upRightMask = [
  0X0000000000000000, 0X0000000000000000, 0X0000000000000000, 0X0000000000000000, 0X0000000000000000,
  0X0000000000000000, 0X0000000000000000, 0X0000000000000000,
  0X0000000000000002, 0X0000000000000004, 0X0000000000000008, 0X0000000000000010, 0X0000000000000020,
  0X0000000000000040, 0X0000000000000080, 0X0000000000000000,
  0X0000000000000204, 0X0000000000000408, 0X0000000000000810, 0X0000000000001020, 0X0000000000002040,
  0X0000000000004080, 0X0000000000008000, 0X0000000000000000,
  0X0000000000020408, 0X0000000000040810, 0X0000000000081020, 0X0000000000102040, 0X0000000000204080,
  0X0000000000408000, 0X0000000000800000, 0X0000000000000000,
  0X0000000002040810, 0X0000000004081020, 0X0000000008102040, 0X0000000010204080, 0X0000000020408000,
  0X0000000040800000, 0X0000000080000000, 0X0000000000000000,
  0X0000000204081020, 0X0000000408102040, 0X0000000810204080, 0X0000001020408000, 0X0000002040800000,
  0X0000004080000000, 0X0000008000000000, 0X0000000000000000,
  0X0000020408102040, 0X0000040810204080, 0X0000081020408000, 0X0000102040800000, 0X0000204080000000,
  0X0000408000000000, 0X0000800000000000, 0X0000000000000000,
  0X0002040810204080, 0X0004081020408000, 0X0008102040800000, 0X0010204080000000, 0X0020408000000000,
  0X0040800000000000, 0X0080000000000000, 0X0000000000000000]
upMask = [
  0X0000000000000000, 0X0000000000000000, 0X0000000000000000, 0X0000000000000000, 0X0000000000000000,
  0X0000000000000000, 0X0000000000000000, 0X0000000000000000,
  0X0000000000000001, 0X0000000000000002, 0X0000000000000004, 0X0000000000000008, 0X0000000000000010,
  0X0000000000000020, 0X0000000000000040, 0X0000000000000080,
  0X0000000000000101, 0X0000000000000202, 0X0000000000000404, 0X0000000000000808, 0X0000000000001010,
  0X0000000000002020, 0X0000000000004040, 0X0000000000008080,
  0X0000000000010101, 0X0000000000020202, 0X0000000000040404, 0X0000000000080808, 0X0000000000101010,
  0X0000000000202020, 0X0000000000404040, 0X0000000000808080,
  0X0000000001010101, 0X0000000002020202, 0X0000000004040404, 0X0000000008080808, 0X0000000010101010,
  0X0000000020202020, 0X0000000040404040, 0X0000000080808080,
  0X0000000101010101, 0X0000000202020202, 0X0000000404040404, 0X0000000808080808, 0X0000001010101010,
  0X0000002020202020, 0X0000004040404040, 0X0000008080808080,
  0X0000010101010101, 0X0000020202020202, 0X0000040404040404, 0X0000080808080808, 0X0000101010101010,
  0X0000202020202020, 0X0000404040404040, 0X0000808080808080,
  0X0001010101010101, 0X0002020202020202, 0X0004040404040404, 0X0008080808080808, 0X0010101010101010,
  0X0020202020202020, 0X0040404040404040, 0X0080808080808080]
upLeftMask = [
  0X0000000000000000, 0X0000000000000000, 0X0000000000000000, 0X0000000000000000, 0X0000000000000000,
  0X0000000000000000, 0X0000000000000000, 0X0000000000000000,
  0X0000000000000000, 0X0000000000000001, 0X0000000000000002, 0X0000000000000004, 0X0000000000000008,
  0X0000000000000010, 0X0000000000000020, 0X0000000000000040,
  0X0000000000000000, 0X0000000000000100, 0X0000000000000201, 0X0000000000000402, 0X0000000000000804,
  0X0000000000001008, 0X0000000000002010, 0X0000000000004020,
  0X0000000000000000, 0X0000000000010000, 0X0000000000020100, 0X0000000000040201, 0X0000000000080402,
  0X0000000000100804, 0X0000000000201008, 0X0000000000402010,
  0X0000000000000000, 0X0000000001000000, 0X0000000002010000, 0X0000000004020100, 0X0000000008040201,
  0X0000000010080402, 0X0000000020100804, 0X0000000040201008,
  0X0000000000000000, 0X0000000100000000, 0X0000000201000000, 0X0000000402010000, 0X0000000804020100,
  0X0000001008040201, 0X0000002010080402, 0X0000004020100804,
  0X0000000000000000, 0X0000010000000000, 0X0000020100000000, 0X0000040201000000, 0X0000080402010000,
  0X0000100804020100, 0X0000201008040201, 0X0000402010080402,
  0X0000000000000000, 0X0001000000000000, 0X0002010000000000, 0X0004020100000000, 0X0008040201000000,
  0X0010080402010000, 0X0020100804020100, 0X0040201008040201]


def andTogether(x, y):
  return x & y


def biterate(bitBoard):
  while bitBoard:
    bit = bitBoard & -bitBoard
    yield bit
    bitBoard ^= bit


def _expandDirection(delta):
  dic = {1: 0, 7: 1, 8: 2, 9: 3}
  start = [0x8181818181818181, 0xFF818181818181FF, 0xFF000000000000FF, 0xFF818181818181FF][dic[delta]]

  def inner(stables):
    return stables | start | (stables << delta) | (stables >> delta)

  return inner


_expandHorizontal = _expandDirection(1)
_expandVertical = _expandDirection(8)
_expandNE = _expandDirection(7)
_expandNW = _expandDirection(9)


def myKeyGen(a, b):
  return a << 64 | b


def cantorKeyGen(a, b):
  return (a + b) * (a + b + 1) / 2 + a


def szudzikKeyGen(a, b):
  return (a + b * b if b > a else a * a + a + b)


memoUse = 0


class Stables():
  # viggle
  vgl = [0x8080808080808080, 0x4040404040404040, 0x2020202020202020, 0x1010101010101010,
         0x0808080808080808, 0x0404040404040404, 0x0202020202020202, 0x0101010101010101]

  def _expandVertical_GL(stables, empties):
    # don't forget to & with 0xFFFFFFFFFFFFFFFF
    ret = 0xFF000000000000FF | (stables << 8) | (stables >> 8)
    for mask in Stables.vgl:
      if not mask & empties:
        ret |= mask
    return ret

  # naygle
  negl = [0x8000000000000000, 0x4080000000000000, 0x2040800000000000, 0x1020408000000000,
          0x0810204080000000, 0x0408102040800000, 0x0204081020408000, 0x0102040810204080,
          0x0001020408102040, 0x0000010204081020, 0x0000000102040810, 0x0000000001020408,
          0x0000000000010204, 0x0000000000000102, 0x0000000000000001]

  def _expandNE_GL(stables, empties):
    # don't forget to & with 0xFFFFFFFFFFFFFFFF
    ret = 0xFF818181818181FF | (stables << 7) | (stables >> 7)
    for mask in Stables.negl:
      if not mask & empties:
        ret |= mask
    return ret

  # pronounced "noogle"
  nwgl = [0x0100000000000000, 0x0201000000000000, 0x0402010000000000, 0x0804020100000000,
          0x1008040201000000, 0x2010080402010000, 0x4020100804020100, 0x8040201008040201,
          0x0080402010080402, 0x0000804020100804, 0x0000008040201008, 0x0000000080402010,
          0x0000000000804020, 0x0000000000008040, 0x0000000000000080]

  def _expandNW_GL(stables, empties):
    # don't forget to & with 0xFFFFFFFFFFFFFFFF
    ret = 0xFF818181818181FF | (stables << 9) | (stables >> 9)
    for mask in Stables.nwgl:
      if not mask & empties:
        ret |= mask
    return ret

  # higgle
  hgl = [0xFF00000000000000, 0x00FF000000000000, 0x0000FF0000000000, 0x000000FF00000000,
         0x00000000FF000000, 0x0000000000FF0000, 0x000000000000FF00, 0x00000000000000FF]

  def _expandHorizontal_GL(stables, empties):
    # don't forget to & with 0xFFFFFFFFFFFFFFFF
    ret = 0x8181818181818181 | (stables << 1) | (stables >> 1)
    for mask in Stables.hgl:
      if not mask & empties:
        ret |= mask
    return ret

  def _expandStables(stables, myBoard, empties):
    return 0xFFFFFFFFFFFFFFFF & Stables._expandHorizontal_GL(stables, empties) & Stables._expandVertical_GL(stables,
                                                                                                            empties) & Stables._expandNW_GL(
      stables, empties) & Stables._expandNE_GL(stables, empties)

  def fullExpansion(myBoard, otherBoard, myStables, otherStables):
    # Takes current board and old stables and updates stables
    empties = 0xFFFFFFFFFFFFFFFF ^ (myBoard | otherBoard)
    while True:
      n_myStables = myBoard & Stables._expandStables(myStables, myBoard, empties)
      if not (n_myStables ^ myStables):
        break
      myStables = n_myStables
    counter = 0
    while True:
      n_otherStables = otherBoard & Stables._expandStables(otherStables, otherBoard, empties)
      if not (n_otherStables ^ otherStables):
        return myStables, otherStables
      otherStables = n_otherStables

  # Returns bitboard where every on bit is a stable disc of the inputBoard's color
  def getStables(myBoard, otherBoard):
    stables = 0x8100000000000081 & myBoard
    empties = 0xFFFFFFFFFFFFFFFF ^ (myBoard | otherBoard)
    while True:
      w = myBoard & Stables._expandStables(stables, myBoard, empties)
      if not w ^ stables:
        return stables
      stables = w

  # Determining stability
  def _getStableVertical(myBoard):
    stable = 0xFF000000000000FF & myBoard
    # Vary this repetition\/
    for d in range(stableDepth):
      stable |= ((stable << 8) | (stable >> 8)) & myBoard
    stable |= ((stable << 8) | (stable >> 8))
    return stable

  def _getStableNE(myBoard):
    stable = 0xFF818181818181FF & myBoard
    # Vary this repetition\/
    for d in range(stableDepth):
      stable |= ((stable << 7) | (stable >> 7)) & myBoard
    stable |= (((0x00FEFEFEFEFEFEFE & stable) << 7) | ((0x7F7F7F7F7F7F7F00 & stable) >> 7))
    return stable

  def _getStableNW(myBoard):
    stable = 0xFF818181818181FF & myBoard
    # Vary this repetition\/
    for d in range(stableDepth):
      stable |= ((stable << 9) | (stable >> 9)) & myBoard
    stable |= (((0x007F7F7F7F7F7F7F & stable) << 9) | ((0xFEFEFEFEFEFEFE00 & stable) >> 9))
    return stable

  def _getStableHorizontal(myBoard):
    stable = 0x8181818181818181 & myBoard
    # Vary this repetition\/
    for d in range(stableDepth):
      stable |= ((stable << 1) | (stable >> 1)) & myBoard
    stable |= (((0x7F7F7F7F7F7F7F7F & stable) << 1) | ((0xFEFEFEFEFEFEFEFE & stable) >> 1))
    return stable

  # Returns bitboard where every on bit is a stable disc of the inputBoard's color
  def getBrokenStables(myBoard):
    return (Stables._getStableHorizontal(myBoard) & Stables._getStableNW(myBoard) & Stables._getStableNE(
      myBoard) & Stables._getStableVertical(myBoard)) & 0xFFFFFFFFFFFFFFFF

  def getStableMoves(myBoard, otherBoard):
    pm = getPossibleMoves(myBoard, otherBoard)
    maxCount = bin(Stables.getBrokenStables(myBoard)).count('1') + 1
    returnNum = 0
    for move in biterate(pm):
      newCount = bin(Stables.getBrokenStables(*performMove(myBoard, otherBoard, move)[0])).count('1')
      if newCount > maxCount:
        returnNum = move
        maxCount = newCount
      elif newCount == maxCount:
        returnNum |= move
    return returnNum


class Strategy():
  def best_strategy(self, board, player, best_move, still_running):
    brd = list(''.join(board).replace('?', '').replace('@', 'X').replace('o', 'O'))
    token = ['X', 'O'][player != '@']
    myBoard, otherBoard = getBitBoard(brd, token)
    runThroughForStrategy(myBoard, otherBoard, best_move)


def inputXO(humanBoard, botBoard, human):
  if human == 'X':
    return humanBoard, botBoard
  else:
    return botBoard, humanBoard


def getListBoard(XB, OB):
  board = []
  app = board.append
  for looker in coord:
    app([['.', 'O'][OB & looker > 0], 'X'][XB & looker > 0])
  return board


def getBitBoard(board, humanTile):
  humanTile = humanTile.upper()
  board = [x.upper() for x in board]
  humanBoard = 0
  computerBoard = 0
  i = 0
  for t in coord:
    if board[i] == humanTile:
      humanBoard |= t
    elif board[i] != '.':
      computerBoard |= t
    i += 1
  return humanBoard, computerBoard


def getOnList(board):
  onBits = []
  app = onBits.append
  for onBitBin in biterate(board):
    onBit = bitscan[onBitBin]
    app(onBit)
  return onBits


def getRandomOnIndex(board):
  return random.choice(getOnList(board))


def _getPrintString(board):
  return ''.join([''] + [''] * 7 + ['\n']) + ''.join([''] + [''] * 7 + ['']).join(
    ['' + ''.join(board[i * 8:i * 8 + 8]) + '\n' for i in range(8)]) + ''.join([''] + [''] * 7 + ['\n'])
  # return '─'.join(['┌'] + ['┬'] * 7 + ['┐\n']) + '─'.join(['├'] + ['┼'] * 7 + ['┤\n']).join(
  #   ['│' + '│'.join(board[i * 8:i * 8 + 8]) + '│\n' for i in range(8)]) + '─'.join(['└'] + ['┴'] * 7 + ['┘\n'])


getTupFuncs = (Stables._expandHorizontal_GL, Stables._expandVertical_GL, Stables._expandNE_GL, Stables._expandNW_GL)


def getTuple(myBoard, otherBoard):
  # empties
  empties = 0xFFFFFFFFFFFFFFFF ^ (myBoard | otherBoard)
  # myStables and myDirectionStables
  myDirStables = [0] * 4
  myStables = 0
  while 1:
    for i, f in enumerate(getTupFuncs):
      myDirStables[i] = f(myStables, empties) & 0xFFFFFFFFFFFFFFFF
    n_myStables = myBoard & reduce(lambda x, y: x & y, myDirStables)
    if not myStables ^ n_myStables:
      break
    myStables = n_myStables
  # otherStables and otherDirectionStables
  otherDirStables = [0] * 4
  otherStables = 0
  while 1:
    for i, f in enumerate(getTupFuncs):
      otherDirStables[i] = f(otherStables, empties) & 0xFFFFFFFFFFFFFFFF
    n_otherStables = otherBoard & reduce(andTogether, otherDirStables)
    if not otherStables ^ n_otherStables:
      break
    otherStables = n_otherStables
    # if getPossibleMoves becomes expensive get rid of one                         #maybe get rid of stables in exchange for just the lists
    # also consider getting rid of other stables
  return Board(myBoard, otherBoard, empties, getPossibleMoves(myBoard, otherBoard),
               getPossibleMoves(otherBoard, myBoard), myStables, otherStables, myDirStables, otherDirStables)


def flipTuple(tup):
  return Board(tup.otherBoard, tup.myBoard, tup.empties, tup.otherPossibleMoves, tup.myPossibleMoves, tup.otherStables,
               tup.myStables, tup.otherDirectionStables[:], tup.myDirectionStables[:])


maskArray = (Stables.hgl, Stables.vgl, Stables.negl, Stables.nwgl)
getDirectionMasks = {bit: tuple(maskArray[j][k] for j, k in enumerate(reverseLook[bit])) for bit in coord}

nextFuncs = (_expandHorizontal, _expandVertical, _expandNE, _expandNW)

genCount = 0


def getNextBoard(tup, move):
  global genCount
  genCount += 1
  bigFlipper = _getMoveEffects(tup.myBoard, tup.otherBoard, move)
  otherBoard, myBoard = tup.myBoard ^ (bigFlipper | move), tup.otherBoard ^ bigFlipper
  empties = tup.empties ^ move
  myPossibleMoves, otherPossibleMoves = getPossibleMoves(myBoard, otherBoard), getPossibleMoves(otherBoard, myBoard)

  # places where the old direction stables overlapped
  myStables, otherStables = tup.otherStables, tup.myStables  # but not done yet
  myDirectionStables, otherDirectionStables = tup.otherDirectionStables[:], tup.myDirectionStables[:]

  # gridlock
  for i, mask in enumerate(getDirectionMasks[move]):
    if not empties & mask:
      myDirectionStables[i] |= mask
      otherDirectionStables[i] |= mask


      # Since the move took discs in bigFlipper from myBoard the while-loop should only run if the gridlock adder did
  # (Note: Skipping the below computation when gridlock doesn't run may help efficiency)
  n_myStables = (reduce(andTogether, myDirectionStables) & myBoard)
  while myStables ^ n_myStables:
    myStables = n_myStables
    for i, f in enumerate(nextFuncs):
      myDirectionStables[i] |= f(myStables)
    n_myStables = myBoard & reduce(andTogether, myDirectionStables)

  # Since the move gave the discs in (bigFlipper | move)
  n_otherStables = reduce(andTogether, otherDirectionStables) & otherBoard
  while otherStables ^ n_otherStables:
    otherStables = n_otherStables
    for i, f in enumerate(nextFuncs):
      otherDirectionStables[i] |= f(otherStables)
    n_otherStables = otherBoard & reduce(andTogether, otherDirectionStables)
  return Board(myBoard, otherBoard, empties, myPossibleMoves, otherPossibleMoves, myStables, otherStables,
               myDirectionStables, otherDirectionStables)


sortMemo = {}


def sortedBoardMoves(board):
  key = (szudzikKeyGen(board.myBoard, board.otherBoard), evalType)
  boardMoveList = None
  if key in sortMemo:
    boardMoveList = sortMemo[key]
  else:
    nextBoardMv = []
    app = nextBoardMv.append
    for mv in biterate(board.myPossibleMoves):
      nextBoard = getNextBoard(board, mv)
      app((evaluate(nextBoard), nextBoard, mv))
    boardMoveList = sorted(nextBoardMv)
    sortMemo[key] = boardMoveList
  for val, board, move in boardMoveList:
    yield val, board, move


# printing
def printBitBoard(XB, OB):
  print(_getPrintString(getListBoard(XB, OB)))


def printTupleBoard(board, human):
  printBitBoard(*inputXO(board.myBoard, board.otherBoard, human))


def printBoard(board):
  print(_getPrintString(board))  # , file = f)


def outputStarredBitBoard(XB, OB, starSet):
  printer = getListBoard(XB, OB)
  for starBit in biterate(starSet):
    star = bitscan[starBit]
    printer[star] = '*'
    starSet ^= starBit
  printBoard(printer)


def outputStarredBoard(board, starSet):
  printer = board[:]
  for star in starSet:
    printer[star] = '*'
  printBoard(printer)


def evalSetUp():  # refactor to use local variables
  maskScores = (
    (0x4281000000008142,  -8), (0x1800008181000018,  4), (0x2400A50000A50024,  4))  # was 30, 50, 14
  stableMaskScores = ((0x7EFFFFFFFFFFFF7E, 1),)
  cornerSituations = {(0, 0): 0, (1, 0): 6, (2, 0): 12, (3, 0): 24, (4, 0): 30,
                      (0, 1): -6, (1, 1): -1, (2, 1): 8, (3, 1): 15,
                      (0, 2): -12, (1, 2): -8, (2, 2): -1,
                      (0, 3): -24, (1, 3): -15,
                      (0, 4): -30}

  # Easily dynamic
  def _cornerSetUps(board):  # could be replaced by maskScores
    # This is about putting a piece next to an empty corner
    return bin(0x8100000000000081 & board.myPossibleMoves).count('1') - bin(
      0x8100000000000081 & board.otherPossibleMoves).count('1')

  # Also easily dynamic
  #  I'd want to change the algorithm from summing up masks during every call to successive adding of score during tuple creation
  #  It'd go from O(k*v) where k is the number of leaf nodes to O(
  def _evalDiscLocations(board):  # multiply by generalLocationWeight; consider taking unstables as parameter instead of deriving the usntables from board
    # uses weight table, maskScore
    score = 0
    myUnstables, otherUnstables = board.myStables ^ board.myBoard, board.otherStables ^ board.otherBoard
    for mask, value in maskScores:
      score += value * (bin(mask & myUnstables).count('1') - bin(mask & otherUnstables).count('1'))
    myUnstableX, otherUnstableX = myUnstables & 0x0042000000004200, otherUnstables & 0x0042000000004200
    score += -70 * (bin(((myUnstableX << 7) | (myUnstableX >> 7) | (myUnstableX << 9) | (
    myUnstableX >> 9)) & board.empties & 0x8100000000000081).count('1') -
                      bin(((otherUnstableX << 7) | (otherUnstableX >> 7) | (otherUnstableX << 9) | (
                      otherUnstableX >> 9)) & board.empties & 0x8100000000000081).count('1'))
    return score

  # Already dynamic but their value isn't tracked so could be better
  def _evalRealStables(board):
    score = 0
    m = board.myStables
    o = board.otherStables
    for mask, value in stableMaskScores:  # if statements?
      score += value * (bin(mask & m).count('1') - bin(mask & o).count('1'))
    return score

  # Does not lend itself to dynamics
  def _evalMoves(board):
    mine = bin(board.myPossibleMoves & 0xBD3CFFFFFFFF3CBD).count('1')
    his = bin(board.otherPossibleMoves & 0xBD3CFFFFFFFF3CBD).count(
      '1')  # consider taking out masks or weighting those in the mask more highly
    difference = mine - his
    # consider changing to -50, 50, difference
    if difference == 0:
      return 0
    elif mine == 0:
      return -25
    elif his == 0:
      return 25
    else:
      return difference

  # Cheap already but could be made dynamic, might not be worth it though
  def _evalScore(board):
    return bin(board.myBoard).count('1') - bin(board.otherBoard).count('1')

  def _cornersHeld(board):
    return cornerSituations[
      (bin(0x8100000000000081 & board.myBoard).count('1'), bin(0x8100000000000081 & board.otherBoard).count('1'))]

  def _evalFrontiers(board):
    m, o = board.myBoard, board.otherBoard
    mL, oL, mR, oR = 0x7F7F7F7F7F7F7F7F & m, 0x7F7F7F7F7F7F7F7F & o, 0xFEFEFEFEFEFEFEFE & m, 0xFEFEFEFEFEFEFEFE & o
    return bin(((mL << 1) | (mL << 9) | (mL >> 7) | (m << 8) | (m >> 8) | (mR >> 9) | (mR >> 1) | (
    mR << 7)) & board.empties).count('1') - bin(((oL << 1) | (oL << 9) | (oL >> 7) | (o << 8) | (o >> 8) | (oR >> 9) | (
    oR >> 1) | (oR << 7)) & board.empties).count('1')
  def _evalFrontiersModifiedEdges(board):
    m, o = board.myBoard, board.otherBoard
    mMask, oMask = m & 0x7E7E7E7E7E7E7E7E, o&0x7E7E7E7E7E7E7E7E
    return bin(((mMask << 1) | (mMask << 9) | (mMask >> 7) | ((m&0x8181818181818181) << 8) | ((m &0x8181818181818181) >> 8) | (mMask >> 9) | (mMask >> 1) | (
      mMask << 7)) & board.empties).count('1') - bin(((oMask << 1) | (oMask << 9) | (oMask >> 7) | ((o&0x8181818181818181) << 8) | ((o&0x8181818181818181) >> 8) | (oMask >> 9) | (
      oMask >> 1) | (oMask << 7)) & board.empties).count('1')
  def _evalParity(board):
    numEmpties = bin(board.empties).count('1')
    if numEmpties % 2:
      return 1
    else:
      return -1

  return (_evalDiscLocations, _evalRealStables, _cornerSetUps, _evalMoves, _evalScore, _cornersHeld, _evalFrontiers,
          _evalParity)


# evalDiscLocations, evalRealStables, cornerSetUps, evalMoves, evalScore,  cornersHeld, evalFrontiers = evalSetUp()
evalFuncs = evalSetUp()
evalScore = evalFuncs[4]

# @memoize(szudzikKeyGen, False)
# listOfBiggest = [0, 0, 0, 0, 0, 0]
memo = {}
finalMemo = {}
# debug_memo = {}
# listOfBiggest = [None]*len(evalFuncs)
# listOfSmallest = [None]*len(evalFuncs)
# sums = [0]*len(evalFuncs)

def evaluate(board):
  global memo
  global finalMemo
  # global debug_memo
  # global listOfBiggest
  # global listOfSmallest
  global sums
  boardKey = szudzikKeyGen(board.myBoard, board.otherBoard)
  if boardKey in finalMemo:
    return finalMemo[boardKey]
  key = (boardKey, evalType)
  if key in memo:
    return memo[key]
  if evalType == TOKEN:
    val = evalScore(board)
    memo[key] = val
    return val
  if not board.myPossibleMoves | board.otherPossibleMoves or bin(board.myStables).count('1') > 32 or bin(board.otherStables).count('1') > 32:
    s = evalScore(board)
    if s > 0:
      finalMemo[boardKey] = WIN
      return WIN
    elif s == 0:
      finalMemo[boardKey] = TIE
      return TIE
    finalMemo[boardKey] = LOSS
    return LOSS

  # evalDiscLocations, evalRealStables, cornerSetUps, evalMoves, evalScore, cornersHeld, evalFrontiers, evalParity
  # 6/-7/-70 for edge/C/X
  # stable count
  # (1 per corner available)
  # (50 if no available non X/C moves otherwise usually on the range of -12 to 12)
  # 0-64
  # -10 to 10

  # evalWeights = (200, 600000, 300, 600, 100, 200)
  # evalWeights = (200, 60000, 300, -600, 350, 200)
  #                90
  evalWeights = (12, 1000, 200, 50, (-65 if bin(board.empties).count('1') > startFullSearch else 16), 7000, -310, 100)
  # (-80 if bin(board.empties).count('1') > startFullSearch + 4 else 0) .... else 16
  # evalWeights = (0,0,0,1,0)
  total = 0
  # num = 0
  for func, weight in zip(evalFuncs, evalWeights):
    # f = func(board)
    # print(num, "\t"*num, f, f*weight)
    # val = f * weight
    # listOfBiggest[num] = (val if listOfBiggest[num] is None else max(listOfBiggest[num], val))
    # listOfSmallest[num] = (val if listOfSmallest[num] is None else min(listOfSmallest[num], val))
    # sums[num] += abs(val)
    total += func(board)*weight
    # num+=1
  # print()
  # listOfBiggest[maxNum] += 1
  memo[key] = total
  return total

  # (7,80, 3, 200, -30, -60)
  # (700,810000, 300, 1980000, -1080000) <- kicks ass where last one is for getBHeur one
  # lst = [scoreWeight*evalScore(board), evalBrokenStable(board, funkyWeight, actualStables, cornerWeight, cSetUpWeight), moveWeight*evalMoves(board)]
  # return (sum(lst), *lst)/

# Finding moves
def canMove(myBoard, otherBoard):
  empty = 0xFFFFFFFFFFFFFFFF ^ (myBoard | otherBoard)
  return (_directionMoves(myBoard, otherBoard & 0x007E7E7E7E7E7E00, 7) & empty) or \
         (_directionMoves(myBoard, otherBoard & 0x007E7E7E7E7E7E00, 9) & empty) or \
         (_directionMoves(myBoard, otherBoard & 0x7E7E7E7E7E7E7E7E, 1) & empty) or \
         (_directionMoves(myBoard, otherBoard & 0x00FFFFFFFFFFFF00, 8) & empty)

# if a move is a tile and at least one row of opponent tiles that will be flipped
# then let a move be represented by the location of the first tile and the set of tiles that are adjacent to it that will be flipped
def getPossibleMoves(myBoard, otherBoard):
  mask = otherBoard & 0x7E7E7E7E7E7E7E7E
  return (_directionMoves(myBoard, mask, 1) |
          _directionMoves(myBoard, otherBoard, 8) |
          _directionMoves(myBoard, mask, 7) |
          _directionMoves(myBoard, mask, 9)) & (0xFFFFFFFFFFFFFFFF ^ (myBoard | otherBoard))  # empties

def _directionMoves(myBoard, otherMask, delta):
  flip = ((myBoard << delta) | (
  myBoard >> delta)) & otherMask  # all discs that are adjacent to a disc of mine in the delta direction, except those that are in the left and right columns unless it's vertical
  flip |= (((flip << delta) | (
  flip >> delta)) & otherMask)  # now with these discs we've identified, we add on any other neighbors of theirs in the same direction
  flip |= (((flip << delta) | (flip >> delta)) & otherMask)
  flip |= (((flip << delta) | (flip >> delta)) & otherMask)
  flip |= (((flip << delta) | (flip >> delta)) & otherMask)
  flip |= (((flip << delta) | (flip >> delta)) & otherMask)
  return (flip << delta) | (flip >> delta)

def _getMoveEffects(myBoard, otherBoard, x):
  # print("MOVING")
  n = bitscan[x]
  bigFlip = 0

  # E
  c = x | (x - 1)
  # print("c:")
  # outputStarredBitBoard(myBoard, otherBoard, c)
  t = ((otherBoard & 0x7E7E7E7E7E7E7E7E) | c) + 1
  # print("t:")
  # outputStarredBitBoard(myBoard, otherBoard, t)
  if myBoard & (t & -t):  # 0 if going right is illegal
    bigFlip |= ((t & -t) - 1) ^ c
    # print('E')
    # outputStarredBitBoard(myBoard, otherBoard, ((t&-t) - 1) ^ c)

  # SW
  c = downLeftMask[n]
  z = myBoard & ~c
  if ((c | otherBoard) + 1) & z:
    bigFlip |= ((~z & (z - 1)) & (~c & otherBoard))
  # print('SW')

  # S
  c = downMask[n]
  z = myBoard & ~c
  if ((c | otherBoard) + 1) & z:
    bigFlip |= ((~z & (z - 1)) & (~c & otherBoard))
  # print('S')


  # SE
  c = downRightMask[n]
  z = myBoard & ~c
  if ((c | otherBoard) + 1) & z:
    bigFlip |= ((~z & (z - 1)) & (~c & otherBoard))
  # print('SE')

  # W
  # start = bigFlip
  if (myBoard & leftMask[n]) > (leftMask[n] & ~(myBoard | otherBoard)):
    w = x >> 1
    while w & otherBoard:
      bigFlip |= w
      w >>= 1
  # if bigFlip != start:
  #   print("W change:")
  #   outputStarredBitBoard(myBoard, otherBoard, bigFlip ^ start)
  # print('W')

  # NE
  if (myBoard & upRightMask[n]) > upRightMask[n] & ~(myBoard | otherBoard):
    w = x >> 7
    # print('NE')
    while w & otherBoard:
      bigFlip |= w
      w >>= 7

  # N
  if (myBoard & upMask[n]) > upMask[n] & ~(myBoard | otherBoard):
    w = x >> 8
    # print('N')
    while w & otherBoard:
      bigFlip |= w
      w >>= 8

  # NW
  if (myBoard & upLeftMask[n]) > upLeftMask[n] & ~(myBoard | otherBoard):
    w = x >> 9
    # print('NW')
    while w & otherBoard:
      bigFlip |= w
      w >>= 9

  # outputStarredBitBoard(myBoard, otherBoard, bigFlip)
  return bigFlip

def performMove(myBoard, otherBoard, x):
  bigFlip = _getMoveEffects(myBoard, otherBoard, x)
  otherBoard ^= bigFlip
  myBoard ^= (bigFlip | x)
  # print("Done moving.")
  return myBoard, otherBoard

def rootNegamax(board, depth):
  global evalType
  if not evalType & HEUR:
    val, move = negascout(board, minEval, maxEval, depth)
    if val == WIN or evalType & TOKEN:
      return val, move
    else:
      evalType = TOKEN
      val, move = negascout(board, minEval, maxEval, depth)
      return val, move
  myMoves = board.myPossibleMoves
  if not myMoves:
    val = -negascout(flipTuple(board), minEval, maxEval, depth - 1)[0]
    return (val, -1)
  best_v = (minEval, -1)  # in the root case best_v == alpha
  tupleList = []
  app = tupleList.append
  for newVal, newBoard, mv in sortedBoardMoves(board):
    val = -negascout(newBoard, minEval, -best_v[0], depth - 1)[0]
    if val == WIN:
      return val, mv
    app((val, mv))
    best_v = max((val, mv), best_v)
  if len(tupleList)<5:
    return best_v
  bestSet = tuple((val, mv) for val, mv in tupleList if -evalRounder <= best_v[0] - val <= evalRounder)
  print(len(bestSet), "options")
  return random.choice(bestSet)

def negascout(board, alpha, beta, depth, passed=False):
  if not depth:
    # outputStarredBitBoard(board.myBoard, board.otherBoard, board.myPossibleMoves)
    return evaluate(board), -1
  myMoves = board.myPossibleMoves
  if not myMoves:
    if passed:
      return evaluate(board), -1
    else:
      val = -negascout(flipTuple(board), -beta, -alpha, depth, True)[0]
      return val, -1
  best_v = minEval
  best_move = None
  count = True
  val = 0
  for newVal, newBoard, mv in sortedBoardMoves(board):
    if -newVal in (LOSS, WIN) and not evalType & TOKEN:
      # This should trigger the hardbound if it's a WIN or skip the superfluous search if it's already a LOSS
      val = -newVal
    elif count:
      val = -negascout(newBoard, -beta, -alpha, depth - 1)[0]
      count = False
    else:
      val = -negascout(newBoard, -alpha - 1, -alpha, depth - 1)[0]
      if alpha < val < beta:
        val = -negascout(newBoard, -beta, -alpha, depth - 1)[0]
    if val > best_v:
      best_v = val
      best_move = mv
      if val >= alpha:
        alpha = val
        if alpha >= beta:
          break
  return best_v, best_move

def parseCommandInput():
  print(' '.join(sys.argv[1:]))
  board = None
  myChar = None
  for item in sys.argv[1:]:
    if len(item) == 1:
      myChar = item.upper()
    else:
      board = list(item.upper().replace('?', ''))
  if None in (myChar, board):  # sanity check
    print("Error, no args provided")
    raise IOError
  myBoard, otherBoard = getBitBoard(board, myChar)
  return myBoard, otherBoard, myChar

def runOnce(board, depth):
  # global listOfSmallest
  # global listOfBiggest
  # global sums
  listOfSmallest = [None] * len(evalFuncs)
  listOfBiggest = [None] * len(evalFuncs)
  sums = [0] * len(evalFuncs)
  fastStart = perf_counter()
  val, move = rootNegamax(board, depth)
  fastTime = perf_counter() - fastStart
  print("Negamax of depth ", depth, ", took ", fastTime, 's. It assures value of ', val, " and wants to make the move ",
        bitscan[move], sep='')
  # scaler = max(sums)
  # sums = [x/scaler for x in sums]
  # print("loB: ", listOfBiggest, '\nLOS: ', listOfSmallest, '\nSums: ', sums, sep = '')
  if fastTime < .28:
    deltaDepth = 3
  elif fastTime < .7:
    deltaDepth = 2
  else:
    deltaDepth = 1
  return bitscan[move], val, deltaDepth

def runThroughForStrategy(myBoard, otherBoard, best_move):
  # ..X.......X......XXXXX..X.OOOOO.XXXOXOX..XX.O......OOO..........
  global evalType
  print(''.join(getListBoard(myBoard, otherBoard)))
  key = szudzikKeyGen(myBoard, otherBoard)
  if key in openingBook:
    mv = bitscan[openingBook[key]]
    best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
    print('opened')
    return
  board = getTuple(myBoard, otherBoard)
  # mv = runOnce(board, 2)[0]
  # best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
  if bin(board.myStables).count('1') > 32 or bin(board.otherStables).count('1') > 32:
    mv = bitscan[board.myPossibleMoves & -board.myPossibleMoves]
    best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
    return
  numEmpty = bin(board.empties).count('1')
  print("Num empty:", numEmpty)
  offset = 0
  finalOffset = 0
  initialBranch = bin(board.myPossibleMoves).count('1')
  if initialBranch > 9:
    offset = -1
    finalOffset = -2
  elif initialBranch > 7:
    finalOffset = -1
  if numEmpty <= -startFullSearch + finalOffset:
    evalType = FULL
    # best_move.value = -1
    depth = numEmpty
    mv = runOnce(board, depth)[0]
    best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
  else:
    depth = defaultDepth + offset
    evalType = HEUR
    while depth < numEmpty:
      mv, val, deltaDepth = runOnce(board, depth)
      best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
      depth += deltaDepth
      if val == LOSS:
          depth = numEmpty
    evalType = FULL
    mv = runOnce(board, depth)[0]
    best_move.value = 11 + (mv // 8) * 10 + (mv % 8)


if __name__ == '__main__':
  n = multiprocessing.Value('i', 0)
  runThroughForStrategy(*getBitBoard(sys.argv[1], sys.argv[2]), n)
  exit(0)
  # w = ['xxxxxx..',
  #      'xxxxxx.O',
  #      'xxxxxxOO',
  #      'xxxOxOOO',
  #      'xxxxOx.O',
  #      'xxxO..xO',
  #      'xxxxO...',
  #      'xxxxx...']
  # x = ''.join(w)
  # tup = getTuple(*getBitBoard(x, 'x'))
  # outputStarredBitBoard(tup.myBoard, tup.otherBoard, tup.myStables)
  # exit(0)

  # Timing
  start = perf_counter()
  lastEnd = start

  # Set up
  depth = defaultDepth
  myBoard, otherBoard, myChar = parseCommandInput()

  key = szudzikKeyGen(myBoard, otherBoard)
  if key in openingBook:
    mv = bitscan[openingBook[key]]
    print('opened into', mv)
    exit(0)

  board = getTuple(myBoard, otherBoard)
  # outputStarredBitBoard(*inputXO(board.myBoard, board.otherBoard, myChar), board.myPossibleMoves)
  # outputStarredBitBoard(*inputXO(board.myBoard, board.otherBoard, myChar), board.otherPossibleMoves)
  # print(evaluate(board))
  # exit(0)
  if bin(board.myStables).count('1') > 32 or bin(board.otherStables).count('1') > 32:
    mv = bitscan[board.myPossibleMoves & -board.myPossibleMoves]
    print(mv)
    exit(0)

  outputStarredBitBoard(*inputXO(myBoard, otherBoard, myChar), getPossibleMoves(myBoard, otherBoard))
  print("Legal moves:", ', '.join([str(x) for x in getOnList(getPossibleMoves(myBoard, otherBoard))]))
  numEmpty = bin(0xFFFFFFFFFFFFFFFF ^ (myBoard | otherBoard)).count('1')
  print("Empty", numEmpty, '\n')
  if numEmpty <= startFullSearch:
    evalType = FULL
    depth = numEmpty
    s = perf_counter()
    out, val = runOnce(board, depth)
    # print("Full search took ", perf_counter()-start, 's', sep = '')
    print(perf_counter() - s)
    print('A thorough and complete Negamax search of depth,', depth, '\nAssures a score of,', val,
          'tokens and gives move: ',
          out, '\n-----------')
  else:
    evalType = HEUR
    while depth <= maxDepth:
      out, val = runOnce(board, depth)
      myTime = perf_counter()
      print("The heuristic search of depth, ", depth, " took: ", myTime - lastEnd, 's\nTotal time: ', myTime - start,
            's', sep='')
      lastEnd = myTime
      # print("Diffs:", differences)
      print('At depth, ', depth, ' best heuristic is, ', val, ' and gives move: ', out, '\n-----------', sep='')
      depth += 1

# h1 = http.client.HTTPSConnection("tournament.tjhsst.edu")
# h1.request("GET", "/schedule")
# r1 = h1.getresponse()
# print(r1.status, r1.reason)
# data1 = r1.read()
# output = data1.decode('utf-8')
# linesContaining = ["2019azhang" in x for x in output.splitlines() if '2019idavid' in x]
# print(output)
# print(linesContaining)
# h1.close()