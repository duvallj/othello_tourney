#Othello
#Kaitlin Phan

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        import math
        import time
        import random
        depth = 4
        string = ""
        for i in board:
            string+=i
        s = string.replace(OUTER,'')
        #print(s)
        arr = [s[0:8], s[8:16], s[16:24], s[24:32], s[32:40], s[40:48], s[48:56], s[56:64]]
        matrix = []
        for x in arr:
            temp = []
            for y in x:
                temp.append(y)
            matrix.append(temp)
        p = self.getPoints(matrix, player)
        print(matrix)
        node = (p[0], matrix)
        posMoves = self.getPossibleMoves(matrix, player)
        a,b,c,d = posMoves[0]
        best_move.value = ((b+1)*10)+c+1
        #print(posMoves)
        start = time.time()
        while(True):
            print("depth:", depth)
            tempValue = self.alphabeta(node, posMoves, depth, -math.inf, math.inf, player, True)
            #print('temp:',tempValue)
            x, y = tempValue[1]
            print(x, y)
            print('best move:', ((x+1)*10)+y+1)
            print(time.time()-start)
            best_move.value = ((x+1)*10)+y+1
            depth += 1

    def isPossibleMove(self, gameboard, turn, r1, c1):
        moves = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]
            #up, upper right, right, lower right, down, lower left, left, upper left
        if turn == BLACK:
            other = WHITE
        else:
            other = BLACK
        #print(gameboard)
        if gameboard[r1][c1] != EMPTY:
            return False

        posMove = ([], 0) #(list of x and y coordinates, score)

        for x, y in moves:
            flipped = []
            r, c = r1, c1
            r += x
            c += y
            count = 0
            while r>=0 and r<=7 and c>=0 and c<=7 and gameboard[r][c] == other: # if a direction possible can generate score, move to that direction to calculate score
                flipped.append((r,c))
                count+=1
                r += x
                c += y
            if r>=0 and r<=7 and c>=0 and c<=7:
                if gameboard[r][c] == turn and count > 0: # the other end has yours
                    #if posMove[1] < count: # record the move from x1, y1 (directions shown by xdirection, ydirection)
                    flipped.append((r1, c1))
                    if len(posMove[0]):
                        temp1 = flipped
                    else:
                        temp1 = posMove[0].extend(flipped)
                    temp2 = posMove[1] + count
                    posMove = (flipped, temp2)
            count = 0
        return posMove

    def getPossibleMoves(self, gameboard, turn):
        import heapq
        posMoves = []
        for x in range(0,8):
            for y in range(0,8):
                if gameboard[x][y] == EMPTY:
                    aMove = self.isPossibleMove(gameboard, turn, x, y)
                    if aMove != False and aMove[1] > 0:
                        heapq.heappush(posMoves, (aMove[1], x, y, aMove[0]))
        return posMoves

    def alphabeta(self, node, posMoves, depth, a, b, turn, maximizingPlayer):
        #node is a tuple: points, gameboard
        import math
        import heapq
        #print("DEPTH:", depth, maximizingPlayer)
        if turn == BLACK:
            notTurn = WHITE
        else:
            notTurn = BLACK
        if depth == 0 or self.gameOver(node):
            return (self.heuristic(node[1], turn, maximizingPlayer), node[1])
        if maximizingPlayer == True:
            bestValue = -math.inf
            bestMove = 0
            posMoves = self.getPossibleMoves(node[1], turn)
            children = self.generateChildren(node, posMoves, turn, False)
            #print("children", children)
            while len(children) > 0:
            #for child in children:
                child = heapq.heappop(children);
                childMoves = self.getPossibleMoves(child[1], turn)
                #print("next gameboard")
                #formatBoard(child[1])
                #print("next move")
                #print(childMoves)
                temp = self.alphabeta(child, childMoves, depth-1, a, b, notTurn, False)
                if temp[0] > bestValue:
                    bestValue = temp[0]
                    bestMove = (child[2], child[3])
                if temp[0] > a:
                    a = temp[0]
                if b <= a:
                    break
            return bestValue, bestMove
        else:
            bestValue = math.inf
            bestMove = 0
            posMoves = self.getPossibleMoves(node[1], turn)
            children = self.generateChildren(node, posMoves, turn, True)
            while len(children) > 0:
            #for child in children:
                child = heapq.heappop(children);
                childMoves = self.getPossibleMoves(child[1], turn)
                #print("next gameboard")
                #formatBoard(child[1])
                #print("next move")
                #print(childMoves)
                temp = self.alphabeta(child, childMoves, depth-1, a, b, notTurn, False)
                if temp[0] < bestValue:
                    bestValue = temp[0]
                    bestMove = (child[2], child[3])
                if temp[0] < b:
                    b = temp[0]
                if b <= a:
                    break
            return bestValue, bestMove

    def heuristic(self, board, turn, maximizingPlayer):
        if maximizingPlayer:
            if turn == BLACK:
                notTurn = WHITE
            else:
                notTurn = BLACK
        else:
            if turn == BLACK:
                notTurn = BLACK
                turn = WHITE
            else:
                notTurn = WHITE
        """Compares the difference in tiles."""
        d = [[200, -20, 25, 20, 20, 25, -20, 200],
             [-20, -40, 1, 1,  1, 1, -40, -20],
             [25, -5, 5,  2,  2,  5, -5, 25],
             [20, -5, 2, 2, 2, 2, -5, 20],
             [20, -5, 2, 2, 2, 2, -5, 20],
             [25, -5, 5,  2,  2,  5, -5, 15],
             [-20, -40, 1, 1,  1, 1, -40, -20],
             [200, -20, 25, 20, 20, 25, -20, 200]]
        mine = 0
        other = 0
        diskWeight = 0
        for x in range(0, 8):
            for y in range(0, 8):
                if board[x][y] == turn:
                    mine+=1
                    diskWeight+=d[x][y]
                elif board[x][y] == notTurn:
                    other+=1
                    diskWeight-=d[x][y]
        if mine > other:
            p = (100.0 * mine)/(mine + other)
        elif mine < other:
            p = -(100.0 * other)/(mine + other)
        else:
            p = 0
        """Accounts for the mobility."""
        myMoves = len(self.getPossibleMoves(board, turn))
        otherMoves = len(self.getPossibleMoves(board, notTurn))
        m = myMoves-otherMoves
        """Checks for corner occupancy."""
        mine = 0
        other = 0
        corners = [[0,0], [0,7], [7,0], [7,7]]
        for x, y in corners:
            if board[x][y] == turn:
                mine+=1
            elif board[x][y] == notTurn:
                other+=1
        c = (mine-other) * 25
        """Accounts for unstable tiles (ones that can be flipped in the next turn."""
        mine = 0
        other = 0
        if board[0][0] == EMPTY:
            nearCorner = [[0,1], [1,1],[1,0]]
            for x, y in nearCorner:
                if board[x][y] == turn:
                    mine+=1
                elif board[x][y] == notTurn:
                    other+=1
        if board[0][7] == EMPTY:
            nearCorner = [[0,6], [6,1],[6,0]]
            for x, y in nearCorner:
                if board[x][y] == turn:
                    mine+=1
                elif board[x][y] == notTurn:
                    other+=1
        if board[7][0] == EMPTY:
            nearCorner = [[7,1], [6,1],[6,0]]
            for x, y in nearCorner:
                if board[x][y] == turn:
                    mine+=1
                elif board[x][y] == notTurn:
                    other+=1
        if board[7][7] == EMPTY:
            nearCorner = [[6,7], [6,6],[7,6]]
            for x, y in nearCorner:
                if board[x][y] == turn:
                    mine+=1
                elif board[x][y] == notTurn:
                    other+=1
        u = -12.5 * (mine-other)

        h = (p*100) + (m*400) + (c*2000) + (u*300) + (diskWeight*50)
        print(board)
        print(h)
        return h

    def gameOver(self, node):
        gameboard = node[1]
        if len(self.getPossibleMoves(gameboard, BLACK))== 0 and len(self.getPossibleMoves(gameboard, WHITE)) == 0:
            return True
        return False

    def copyBoard(self, orgBoard):
        newBoard = []
        for item in orgBoard:
            temp = []
            for sub in item:
                temp.append(sub)
            newBoard.append(temp)
        return newBoard

    def generateChildren(self, node, posMoves, turn, maximizingPlayer):
        import heapq
        children = []
        for t in posMoves:
            gameboard = self.copyBoard(node[1])
            flipped = t[3]
            gameboard[t[1]][t[2]] = turn
            corners = 0
            for x,y in flipped:
                if (x==0 and y==0) or (x==0 and y==7) or (x==7 and y==0) or (x==7 and y==7):
                    corners += 10
                gameboard[x][y] = turn
            """if maximizingPlayer:
                points = node[0] + t[0]
                points += corners
            else:
                points = node[0] - t[0]
                points -= corners"""
            points = node[0] + t[0]
            points += corners
            #print("move:")
            #formatBoard(gameboard)
            heapq.heappush(children, (-points, gameboard, t[1], t[2]))
        return children

    def getPoints(self, gameboard, turn):
        total1 = 0
        total2 = 0
        if turn == BLACK:
            other = WHITE
        else:
            other = BLACK
        for x in range(0, 8):
            for y in range(0, 8):
                if gameboard[x][y] == turn:
                    total1+=1
                elif gameboard[x][y] == other:
                    total2+=1
        return total1, total2

def main():
    string = '..o....o..oo..o...o@oo..ooooo@....@oo.....@o......@.......@.....'
    obj = Strategy()
    obj.best_strategy(string, WHITE, 0, None)

if  __name__ =='__main__':
    import cProfile
    import re
    cProfile.run('main()')

