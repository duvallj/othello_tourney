import random
import math

#ELENA ZHENG
#### Othello Shell
#### P. White 2016-2018

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
SQUARES = [x for x in range(11, 89) if 1 <= (x % 10) <= 8]
CORNERS = [11, 18, 81, 88]

WEIGHT_MATRIX = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node():

    def __init__(self, board, move):
        self.board = board
        self.last_move = move
        self.score = None
    def __lt__(self,other):
         return (self.score <= other.score)

class Strategy():

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        return '???????????........??........??........??...o@...??...@o...??........??........??........???????????'

    def get_pretty_board(self, board):
        pretty_b = ""
        for b in [board[i:i+10] for i in range(0, 100, 10)]:
            pretty_b += b+"\n"
        return pretty_b

    def opponent(self, player):
        """Get player's opponent."""
        P = {BLACK:WHITE, WHITE:BLACK}
        return P[player]

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        s2 = square+direction
        if board[s2]==player:
            return None
        while(board[s2]==self.opponent(player)):
            s2+=direction
        if board[s2] in [EMPTY, OUTER]:
            return None
        return s2

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move]!=EMPTY:
            return False
        for d in DIRECTIONS:
            if self.find_match(board, player, move, d) != None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        new_board = board[:move]+player+board[move+1:]
        for d in DIRECTIONS:
            s = self.find_match(board, player, move, d)
            if s==None:
                continue
            s2 = move + d
            while s!=s2:
                new_board = new_board[:s2]+player+new_board[s2+1:]
                s2+=d
        return new_board

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        return [s for s in SQUARES if self.is_move_valid(board, player, s)]

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player))!=0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def weighted_score(self, board):
        squares = [x for x in range(0, len(board)) if board[x]==BLACK]
        score = 0
        for i in squares:
            score+=WEIGHT_MATRIX[i]
        squares2 = [x for x in range(0, len(board)) if board[x]==WHITE]
        for i in squares2:
            score-=WEIGHT_MATRIX[i]
        return score+random.random()
    def corner_filled(self, board):
        for c in CORNERS:
            if board[c]!=EMPTY:
                return True
        return False
    def stability(board, corners, weights, player):
        for c in corners:
            if c == 11:
                for i in range(11, 18):
                    weights[i]+=150
                for i in range(11, 81, 10):
                    weights[i]+=150
            if c== 18:
                for i in range(11, 18):
                    weights[i]+=150
                for i in range(18, 88, 10):
                    weights[i]+=150
            if c == 81:
                for i in range(81, 88):
                    weights[i]+=150
                for i in range(11, 81, 10):
                    weights[i]+=150
            if c== 88:
                for i in range(81, 88):
                    weights[i]+=150
                for i in range(18, 88, 10):
                    weights[i]+=150
        squares = [x for x in SQUARES if board[x]==player]
        score = 0
        for i in squares:
            score+=WEIGHT_MATRIX[i]+weights[i]
        return score+random.random()

    def weighted_score_stability(self, board):
        bc = [x for x in CORNERS if board[x]==BLACK]
        score = stability(board, bc, WEIGHT_MATRIX, BLACK)
        wc = [x for x in CORNERS if board[x]==WHITE]
        score-=stability(board, wc, WEIGHT_MATRIX, WHITE)

    def empty_adj_spaces(board, i):
        c = 0
        for d in DIRECTIONS:
            if board[i+d]==EMPTY:
                c+=1
        return c

    def potential_mobility(board, player):
        squares = [x for x in SQUARES if board[x]==self.opponent(PLAYER)]
        pm = 0
        for s in squares:
            pm+=empty_adj_spaces(board, s)
        return pm

    def weighted_score2(self, board):
        b_moves = len(self.get_valid_moves(board, BLACK))
        w_wmoves = len(self.get_valid_moves(board, WHITE))
        s = self.weighted_score(board)
        #s+= 10*(b_moves-w_moves)
        if b_moves+w_moves!=0:
            s += 100*((b_moves-w_moves)/(b_moves+w_moves))
        #pb = potential_mobility(board, BLACK)
        #pw = potential_mobility(board, WHITE)
        #if pb+pw != 0:
        #    s+=100*((pb-pw)/(pb+pw))
        return s + random.random()

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        return board.count(player)-board.count(self.opponent(player))

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return (not self.has_any_valid_moves(board, player)) and (not self.has_any_valid_moves(board, self.opponent(player)))

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    def minmax(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK:max, WHITE:min}
        board = node.board
        if depth==0:
            node.score = self.weighted_score2(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move)
                c.score=1000*self.score(next_board)
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.minmax(c, next_player, depth = depth-1).score
                children.append(c)
        winner = best[player](children)
        node.score = winner.score
        return winner
    def ab(self, node, player, a, b, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK:max, WHITE:min}
        board = node.board
        if depth==0:
            node.score = self.weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move)
                c.score=1000*self.score(next_board)
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.ab(c, next_player, a, b, depth = depth-1).score
                children.append(c)
                if player==BLACK:
                    a = max(a, c.score)
                elif player==WHITE:
                    b = min(b, c.score)
                if a>=b:
                    break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def ab2(self, node, player, a, b, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        best = {BLACK:max, WHITE:min}
        board = node.board
        if depth==0:
            #if corner_filled(board):
            #    node.score = self.weighted_score_stability(board)
            #else:
            node.score = self.weighted_score2(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move)
                c.score=1000*self.score(next_board)
                children.append(c)
            else:
                c = Node(next_board, move)
                c.score = self.ab(c, next_player, a, b, depth = depth-1).score
                children.append(c)
                if player==BLACK:
                    a = max(a, c.score)
                elif player==WHITE:
                    b = min(b, c.score)
                if a>=b:
                    break
        winner = best[player](children)
        node.score = winner.score
        return winner

    def ab2_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        n = self.ab2(Node(board, -1), player, -math.inf, math.inf, depth)
        return n.last_move

    def ab_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        n = self.ab(Node(board, -1), player, -math.inf, math.inf, depth)
        return n.last_move

    def minmax_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        n = self.minmax(Node(board, -1), player, depth)
        return n.last_move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 2
        board = "".join(board)
        while(True):
            ## doing random in a loop is pointless but it's just an example
            #if player==BLACK:
            best_move.value = self.ab2_strategy(board, player, depth)
            #if player==WHITE:
            #    best_move.value = self.ab_strategy(board, player, depth)
            #best_move.value = self.ab_strategy(board, player, depth)
            depth += 1
    standard_strategy = ab2_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()
        black.standard_strategy = black.minmax_strategy
        white.standard_strategy = white.random_strategy

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK
        #self.black.best_strategy = self.black.random_strategy
        #self.white.best_strategy = self.white.random_strategy

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    game =  ParallelPlayer(5)
    #game = StandardPlayer()
    game.play()
