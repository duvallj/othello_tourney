#Lab A
import sys
import random
import time
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        lmCache = {}
        #print("board:", board)
        if best_move == "mod":
            moderator = True
        else:
            moderator = False
        #print("moderator:", moderator)
        if not moderator:
            board = "".join(board)
            #Fix mismatch between size of grid for contestor v. school server
            if len(board) == 116:
                gme = "".join([board[i:i + 8] for i in range(12, 101, 12)])
            else:
                #print("hi")
                gme = "".join([board[i:i+8] for i in range(11,91,10)]) #[*sys.argv[1].lower()]
            gme = [*"".join([*gme.replace("@","x")]).lower()]
            #print("gme:", "".join(gme))
            playerToToken = {"@":"x", "o":"o", "O":"o"}
            turn = playerToToken[player] #sys.argv[2].lower()
        if moderator:
            gme = board
            turn = player
        players = {"x","o"}
        differences = {1,-1,8,-8,9,-9,7,-7}
        corners = {0,7,56,63}
        cornDifs = {0:[1,8],7:[-1,8],56:[1,-8],63:[-1,-18]}
        edges = {*range(8)}.union({*range(0,57,8)}).union({*range(56,64)}).union({*range(7,64,8)}).difference(corners)
        candx = {1,8,9, 6,14,15, 48,49,57, 54,55,62}
        cxToCorner = {1:0,8:0,9:0, 6:7,14:7,15:7, 48:56,49:56,57:56, 54:63,55:63,62:63}

        def printBoard(board):
            for x in range(64):
                print(board[x], end="")
                if x%8 == 7:
                    print()

        #Defines neighbors[]
        neighbors = []
        for x in range(64):
            tempSet = set()
            if not x//8==0:
                tempSet.add(x-8)
                if not x%8==0:
                    tempSet.add(x-9)
                if not x%8==7:
                    tempSet.add(x-7)
            if not x//8 == 7:
                tempSet.add(x+8)
                if not x%8==0:
                    tempSet.add(x+7)
                if not x%8 == 7:
                    tempSet.add(x+9)
            if not x%8==0:
                tempSet.add(x-1)
            if not x%8 == 7:
                tempSet.add(x+1)
            neighbors.append(tempSet)

        #Returns set of legal moves given a board and a turn
        def legalMoves(game,turn):
            tempGame = game[:]
            tempGame.append(turn)
            posStr = "".join(tempGame)
            if posStr in lmCache:
                return lmCache[posStr]
            takenSpots = {c for c,v in enumerate(game)if v==turn}
            notTurn = [*players.difference({turn})][0]
            toReturn = set()
            for spot in takenSpots:
                for dif in differences:
                    nextSpot = spot+dif
                    if nextSpot < 64 and nextSpot >= 0 and nextSpot in neighbors[spot]:
                        curSpot = nextSpot
                    else:
                        continue
                    while game[curSpot] == notTurn and curSpot+dif in neighbors[curSpot]:
                        curSpot = curSpot+dif
                    if game[curSpot] == "." and not curSpot-dif == spot:
                        toReturn.add(curSpot)
            lmCache[posStr] = toReturn
            return toReturn

        #makes a move given a board, turn, and position to play
        def flipTokens(game, trn, pos):
            validMove = False
            notTurn = [*players.difference({trn})][0]
            #print("notTurn:", notTurn)
            gme = game[:]
            gme[pos] = trn
            '''print("flipTokens:")
            printBoard(game)
            print("neighbors:", neighbors[pos])'''
            for neigh in neighbors[pos]:
                dif = neigh-pos
                curSpot = neigh
                lastSpot = pos
                toFlip = set()
                '''print()
                print("Start curSpot:", curSpot)
                print("Token at start curSpot:", gme[curSpot])
                print("Start lastSpot:", lastSpot)
                print("neighbors[lastSpot]:", neighbors[lastSpot])'''
                while curSpot < 64 and gme[curSpot] == notTurn and curSpot in neighbors[lastSpot]:
                    toFlip.add(curSpot)
                    lastSpot = curSpot
                    curSpot = curSpot+dif
                    #print("Next curSpot:", curSpot, "\nNext lastSpot:", lastSpot)
                #print("toFlip:", toFlip)
                if curSpot not in neighbors[lastSpot]:
                    continue
                else:
                    if gme[curSpot] == trn and toFlip:
                        gme = [trn if c in toFlip else v for c,v in enumerate(gme)]
                        validMove = True
                        #print("hi:")
                    else:
                        continue
            '''if validMove:
                return gme
            return ""'''
            '''if not validMove:
                print("\nNot valid move.\nBoard:")
                printBoard(game)
                print("Turn:", trn)
                print("Position:",pos,"\n")
            print()'''
            return gme

        def translate(move):
            #print("Move to translate:", move)
            toReturn = 11 + (move//8)*10 + (move%8)
            #print("Translated:", toReturn)
            return toReturn

        if moderator:
            printBoard(gme)

        legals = legalMoves(gme, turn)
        if not legals:
            raise ValueError('gme:', gme)
        if not legals:
            raise ValueError('legals is empty')
        if moderator:
            print("Legal Moves:", legals)
        if legals.intersection(corners):
            heurChoice = random.choice([*legals.intersection(corners)])
            if moderator:
                print("My heuristic choice is {}".format(heurChoice))
            else:
                best_move.value = translate(heurChoice)
            # exit()
        else:
            safeEdges = set()
            for spot in corners:
                if gme[spot] == turn:
                    for dif in cornDifs[spot]:
                        curSpot = spot + dif
                        lastSpot = spot
                        while curSpot < 64 and curSpot in neighbors[lastSpot] and gme[curSpot] == turn:
                            lastSpot = curSpot
                            curSpot = curSpot + dif
                        if curSpot < 64 and gme[curSpot] == "." and curSpot in neighbors[lastSpot]:
                            safeEdges.add(curSpot)
                        if curSpot < 64 and not gme[curSpot] == "." and not gme[curSpot] == turn and curSpot in neighbors[
                            lastSpot]:
                            notTurn = [*{"x", "o"}.difference({turn})][0]
                            while curSpot < 64 and curSpot in neighbors[lastSpot] and gme[curSpot] == notTurn:
                                lastSpot = curSpot
                                curSpot = curSpot + dif
                            if curSpot < 64 and gme[curSpot] == "." and curSpot in neighbors[lastSpot]:
                                safeEdges.add(curSpot)
            if legals.intersection(safeEdges):
                heurChoice = random.choice([*legals.intersection(safeEdges)])
                if moderator:
                    print("My heuristic choice is {}".format(heurChoice))
                else:
                    best_move.value = translate(heurChoice)
                # exit()
            else:
                tempLeg = legals
                for spot in tempLeg.intersection(candx):
                    if not gme[cxToCorner[spot]] == turn and legals.difference({spot}):
                        legals = legals.difference({spot})

                if legals.difference(edges):
                    legals = legals.difference(edges)
                heurChoice = random.choice([*legals])
                if moderator:
                    print("My heuristic choice is {}".format(heurChoice))
                else:
                    best_move.value = translate(heurChoice)

        #Evaluation function to determine how good a move is. Called in negamax
        def boardEval(board, token):
            notTurn = [*players.difference({*token})][0]
            '''print(board)
            print("turn:", token, "\nnot turn:", notTurn)
            print("token", board.count(token), "\nnot token:", board.count(notTurn))'''
            return board.count(token) - board.count(notTurn)

        #Minimax function for returning best move in an Othello game.
        def negamax(board, token, levels):
            if not legalMoves(board, "x") and not legalMoves(board, "o"):
                return [boardEval(board, token)]
            if not levels:
                '''print("NOT LEVELS")
                printBoard(board)
                print("token:", token)
                print("boardEval:", boardEval(board,token))
                print()'''
                return [boardEval(board, token)]
            lm = legalMoves(board, token)
            enemy = [*{'x','o'}.difference({token})][0]
            '''print("level:", levels)
            print("token:", token)
            print("enemy:", enemy)
            printBoard(board)
            print("legalMoves:", lm)
            print()'''
            if not lm:
                '''print("no legal moves.")
                print("board:", board)
                print("token:", token)
                print()'''
                nm = negamax(board, enemy, levels-1)+[-1]
                return [-nm[0]]+nm[1:]
            nmList = sorted([negamax(flipTokens(board,token,mv), enemy, levels-1)+[mv] for mv in lm])
            best = nmList[0]
            '''print("nmList:",nmList)
            print("level:", levels)
            print("token:")
            print("enemy:", enemy)
            printBoard(board)
            print("legalMoves:", lm)
            print("negamax:", [-best[0]]+best[1:])
            print()'''
            return [-best[0]]+best[1:]

        def negamaxTerminal(brd, token, improvable, hardBound):
            enemy = [*players.difference({token})][0]
            lm = legalMoves(brd, token)
            if not lm:
                lm = legalMoves(brd, enemy)
                if not lm:
                    return [boardEval(brd, token), -3]
                nm = negamaxTerminal(brd, enemy, -hardBound, -improvable) + [-1]
                return [-nm[0]] + nm[1:]
            best = []
            newHB = -improvable
            for mv in lm:
                nm = negamaxTerminal(flipTokens(brd,token,mv),enemy, -hardBound, newHB) + [mv]
                if not best or nm[0] < newHB:
                    best = nm
                    if nm[0] < newHB:
                        newHB = nm[0]
                        if -newHB >= hardBound:
                            return [-best[0]] + best[1:]
            return [-best[0]] + best[1:]


        '''printBoard(gme)
        print("Possible moves:", legalMoves(gme, turn))'''

        '''if gme.count(".") > 8:
            legals = legalMoves(gme, turn)
            if legals.intersection(corners):
                print(random.choice([*legals.intersection(corners)]))
                # exit()
    
            safeEdges = set()
            for spot in corners:
                if gme[spot] == turn:
                    for dif in cornDifs[spot]:
                        curSpot = spot + dif
                        lastSpot = spot
                        while curSpot < 64 and curSpot in neighbors[lastSpot] and gme[curSpot] == turn:
                            lastSpot = curSpot
                            curSpot = curSpot + dif
                        if curSpot < 64 and gme[curSpot] == "." and curSpot in neighbors[lastSpot]:
                            safeEdges.add(curSpot)
                        if curSpot < 64 and not gme[curSpot] == "." and not gme[curSpot] == turn and curSpot in neighbors[
                            lastSpot]:
                            notTurn = [*{"x", "o"}.difference({turn})][0]
                            while curSpot < 64 and curSpot in neighbors[lastSpot] and gme[curSpot] == notTurn:
                                lastSpot = curSpot
                                curSpot = curSpot + dif
                            if curSpot < 64 and gme[curSpot] == "." and curSpot in neighbors[lastSpot]:
                                safeEdges.add(curSpot)
            if legals.intersection(safeEdges):
                print(random.choice([*legals.intersection(safeEdges)]))
                # exit()
    
            tempLeg = legals
            for spot in tempLeg.intersection(candx):
                if not gme[cxToCorner[spot]] == turn and legals.difference({spot}):
                    legals = legals.difference({spot})
    
            if legals.difference(edges):
                legals = legals.difference(edges)
            print(random.sample(set(legals), 1)[0])'''

        if gme.count(".") <= 16:
            print("Running nmTerminal at 16 levels.")
            startTime = time.clock()
            nm = negamaxTerminal(gme, turn, -65, 65)
            print("nmTerminal complete!")
            '''printBoard(gme)
            print(boardEval(gme, turn))
            print("Legal Moves:", legalMoves(gme, turn))
            print("Negamax:", nm)
            print("Score:", nm[0])
            print("Move:", nm[-1])
            print(boardEval(gme, turn))'''
            if not moderator:
                best_move.value = translate(nm[-1])
            else:
                print("Negamax returns {} in {} seconds and I choose move {}".format(nm, time.clock()-startTime, nm[-1]))

if __name__ == '__main__' and len(sys.argv) == 3:
    print("Moderator.")
    Strategy.best_strategy(None, [*sys.argv[1].lower()], sys.argv[2].lower(), "mod", None)
#...........................ox......xo...........................
#????????????@@@@@@@@????@@o@@@@@????@@@@@o@@????@@o@@@@@????@@@o@@@@????@@@@o@@@????@@@@@o@@????@@@@@.o@???????????? len = 116
#???????????........??........??........??...o@...??...@@@..??........??........??........??????????? len = 100
