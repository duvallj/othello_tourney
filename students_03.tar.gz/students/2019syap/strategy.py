#Othello Code
#SAMANTHA YAP P2 ZACHARIAS
import math
import time
import random
import Othello_Core
import itertools


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
#EMPTY, BLACK, WHITE, OUTER = '.', 'x', 'o', '?'
start_time = time.time()

best_val = 0

width = 8
row_g = {}
col_g = {}
rdi_g = {}
ldi_g = {}

for x in range(width * width):
    row_g.setdefault(int(x / width), []).append(x)
    col_g.setdefault(int(x % width), []).append(x)
    rdi_g.setdefault(int(x / width) + int(x % width), []).append(x)
    ldi_g.setdefault(abs(int(x / width) - 7) + int(x % width), []).append(x)

sides = (row_g[0]) + (col_g[0]) + (row_g[width - 1]) + (col_g[width - 1])
corners = [0, 7, 63, 56]
c_sq = [1, 6, 8, 15, 48, 55, 57, 62]
x_sq = [9, 14, 49, 54]

def display_puz(s):
    sr = ''
    start = 0
    end = width
    for x in range(width):
        sr += str(s)[start:end] + "\n"
        start += 8
        end += 8
    return sr


class Strategy(Othello_Core.OthelloCore):
    def best_strategy(self, board, player, best_move, still_running):
        new_board = ''.join(board)
        new_board = new_board.replace("?", "").replace(" ", "")
        new_board = Node(new_board, player, [])
        #if len(new_board.moves) != 0:
        best_move.value = self.move_to_board((random.choice(new_board.moves)))


        """
        b = True
        for c in corners:
            if c in new_board.moves:
                b = False
                best_move.value = self.move_to_board(c)

        if b:
        """
        if len(new_board.moves) == 1:
            best_move.value = self.move_to_board(new_board.moves[0])
        elif len(new_board.moves) == 0:
            best_move.value = 0

        #if set(new_board.moves) & set(corners):
        #    best_move.value = (set(new_board.moves) & set(corners))[0]
        #else:
        else:
            depth = 30
            while (True):
                self.my_search_strategy(new_board, player, depth)
                depth += 1
                if best_val != 0:
                    best_move.value = best_val

       # else:
       #     best_move.value = 0


    def move_to_board(self, move):
        return int(move / width) * 2 + 11 + move
    def my_search_strategy(self, node, maxplayer, depth):
        alpha = +math.inf
        beta = -math.inf
        if node.board.count(EMPTY) <= 5:
            self.alphabeta(node, depth, alpha, beta, True, "MAX")  # wrong!
        else:
            #self.alphabeta(node, depth, alpha, beta, True, "ALT")
            self.alternate_strat(node, depth)


    def alternate_strat(self, node, depth):
        h_dict = {}
        max_val = 0
        #for move in node.moves:
        #evaluate each flipped in move
        for move in node.moves:
            h = 0
            frontier = 0
            #h_dict[move] = 0
            if move in corners:
                h += 1000
            elif move in x_sq:
                h -= 1000

            c_node = node.gen_child(move)
            for n in c_node.moves:
                if n in corners:
                    h -= 100000


            l = list(itertools.chain.from_iterable(c_node.capture.values()))
            for index in node.capture[move]:
                if index in l:
                    frontier += 1
                if index in x_sq and not move in corners:
                    h -= 1000
            h += len(node.capture[move]) - frontier
            if h > max_val:
                max_val = h
                global best_val
                best_val = self.move_to_board(move)
            #h_dict[move] = h
        #return(max(h_dict), key= lambda key: h_dict[key])

            """
            
            """
        """
        max_key = 0
        for key in h_dict:
            if h_dict[key] > max_val:
                max_val = h_dict[key]
                max_key = key

        global  best_val
        best_val = self.move_to_board(max_key)
        """




        #count number of frontier disks
        #best_val = max(h_dict, key = h_dict.get)

    """
    def alternate_strat(self, node):

        

        for index in corners:
            if node.board[index] == node.player:  # extra to corners
                h += 1000
            if node.board[index] == node.not_player:
                h -= 1000




        for index in corners:
            if node.board[index] == node.player:  # extra to corners
                h += 10

                for x in row_g[int(index/width)]:
                    if x == node.player:
                        h += 1
                for x in col_g[int(index%width)]:
                    if x == node.player:
                        h+=1
                for x in rdi_g[int(x / width) + int(x % width)]:
                    if x == node.player:
                        h+= 1
                for x in ldi_g[abs(int(x / width) - 7) + int(x % width)]:
                    if x == node.player:
                        h+= 1


        #count frontier disks (flippable), internal disks
        #more mobility (hopefully)
        #assign each move a value?

        new_n = Node(node.board, node.not_player, node.changed)
        #count = 0
        #for key in new_n.capture.keys():


        #h+= int((len(node.moves) - len(new_n.moves))/2)

        frontier = []
        g_moves = len(node.moves) #2 or greater captured, or corner or side
        b_moves = 0 #2 or less captured
        go_moves = len(new_n.moves)
        bo_moves = 0
        #internal = []
        for key in node.capture.keys():
            #frontier.extend(new_n.capture[key])
            if self.check_good(node, key):
                g_moves += 1
            else:
                g_moves -= 1
        for key in new_n.capture.keys():
            #frontier.extend(new_n.capture[key])
            if self.check_good(new_n, key):
                go_moves += 1
            else:
                go_moves -= 1
        h+= g_moves - go_moves



        #h -= int(len(set(frontier)))

        #good moves, bad moves, compare

        #for index in frontier:

        #for index in set(c_sq) | set(x_sq):
        #    if index in frontier:
        #        h -=2


        
        h_val = 0
        frontier = 0
        if node.changed in corners:
            h_val += 1000
        for move in node.capture.keys:
            if move in corners:
                h_val += 100
            c_node = node.gen_child(move)
            l = list(itertools.chain.from_iterable(c_node.capture.values()))
            for index in node.capture[move]:
                if index in l:
                    frontier += 1
            h_val += len(node.capture[move]) - frontier
        return h_val
    """


    def alphabeta(self, node, depth, alpha, beta, maxplayer, heur):
        if depth == 0 or node.moves == 0:
            if heur == "MAX":
                return node.board.count(node.player) - node.board.count(node.not_player)
            else:
                return self.alternate_strat(node)
        if maxplayer == True:
            v = -math.inf
            #move = node
            for child in node.gen_children():
                #if not (child.changed in c_sq or child.changed in x_sq):
                c = self.alphabeta(child, depth - 1, alpha, beta, False, heur)

                if c > v:
                    v = c
                    #if type(child.changed) is list:
                    global best_val
                    best_val = self.move_to_board(child.changed[0])
                    #else: self.best_move = child.changed

                #v = max(v, c)
                alpha = max(alpha, v)
                if beta <= alpha:
                    break  # beta cut off)
            return v
        else:
            v = +math.inf
            for child in node.gen_children():
                #if not (child.changed in c_sq or child.changed in x_sq):
                v = min(v, self.alphabeta(child, depth - 1, alpha, beta, True, heur))
                beta = min(beta, v)
                if beta <= alpha:
                    break  # alpha cut off)
            return v
            # def heuristic(self, ):
    def heuristic(self, node):
        h_val = 0
        frontier = 0
        if node.changed in corners:
            h_val += 1000
        for move in node.capture.keys:
            if move in corners:
                h_val += 100
            c_node = node.gen_child(move)
            l = list(itertools.chain.from_iterable(c_node.capture.values()))
            for index in node.capture[move]:
                if index in l:
                    frontier += 1
            h_val += len(node.capture[move]) - frontier
        return h_val
    def check_good(self, node, move):
        if move in corners or move in sides:
            return True
        if len(node.capture[move]) >= 2:
            return True
        return False


class Node:  # knows value,
    def __init__(self, board, player, changed):
        self.board = board
        self.player = player
        if changed == None:
            self.changed = []
        else: self.changed = changed
        self.capture = {}
        if self.player == WHITE:
            self.not_player = BLACK
        else:
            self.not_player = WHITE
        self.moves = self.gen_legal_moves()

    def gen_legal_moves(self):
        # moves = []
        for i in range(8):
            self.get_moves(row_g[i])
            self.get_moves(col_g[i])
            self.get_moves(rdi_g[i])
            self.get_moves(ldi_g[i])
        for x in range(8, 15):
            self.get_moves(rdi_g[x])
            self.get_moves(ldi_g[x])
        moves = list(self.capture.keys())

        # return list(set(moves))
        return list(moves)

    def get_moves(self, group): #MAKE SURE TO FIX CAPTURED
        s = ""
        opp_i = []
        #moves = []
        for index in range(len(group)): #index is index in group, not actual index
            s += self.board[group[index]]
            if self.board[group[index]] == self.not_player:
                opp_i.append(index)
        if len(opp_i) == 0: return []
        for index in opp_i:
            if index - 1 >= 0 and s[index - 1] == EMPTY:
                temp = self.search(index, +1, group, s)
                if temp:
                    if group[index - 1] in self.capture.keys():
                        self.capture[group[index-1]].extend(temp)
                    else:
                        self.capture[group[index - 1]] = temp
                    #moves.append(group[index - 1])
            if index + 1 < len(group) and s[index + 1] == EMPTY:
                temp = self.search(index, -1, group, s)
                if temp:
                    if group[index + 1] in self.capture.keys():
                        self.capture[group[index + 1]].extend(temp)
                    else:
                        self.capture[group[index + 1]] = temp

    def search(self, index, dir, group, s):
        current = index
        passed = [group[current]]
        current += dir

        while len(group) > current >= 0:
            curr_val = s[current]
            if curr_val == EMPTY:
                return False
            if curr_val == self.player:
                return passed
            else:
                passed.append(group[current])
            current += dir
        return False

    def gen_children(self):
        child = []
        l = []

        for move in self.capture:
            #if self.changed:
            child.append(self.gen_child(move))
            #else: child.append(Node(self.flip(move), self.not_player, move))
        return child
    def gen_child(self, move):
        return Node(self.flip(move), self.not_player, self.changed + [move])
    def flip(self, move):
        # temp = copy.deepcopy(self.board)
        temp = [self.board[p] for p in range(len(self.board))]
        temp[move] = self.player
        for x in self.capture[move]:
            temp[x] = self.player
        return ''.join(temp)
