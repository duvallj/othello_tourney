import sys, random

n = 18

player_to_token = {'@': 'x', 'o': 'o'}

find_opponent = {'x': 'o', 'o': 'x'}

weights = (1000, 50, 100, 100, 100, 100, 50, 1000,
            50, -20, -10, -10, -10, -10, -20, 50,
            100, -10, 0, 1, 1, 0, -10, 100,
            100, -10, 1, 0, 0, 1, -10, 100,
            100, -10, 1, 0, 0, 1, -10, 100,
            100, -10, 0, 1, 1, 0, -10, 100,
            50, -20, -10, -10, -10, -10, -20, 50,
            1000, 50, 100, 100, 100, 100, 50, 1000)

black = 0
white = 0

shift_values = (1, 9, 8, 7)

shift_masks = (
    0x7f7f7f7f7f7f7f7f,
    0x007f7f7f7f7f7f7f,
    0xffffffffffffffff,
    0x00fefefefefefefe,
    0xfefefefefefefefe,
    0xfefefefefefefe00,
    0xffffffffffffffff,
    0x7f7f7f7f7f7f7f00
)

pre_shift = {index: 1 << index for index in range(64)}

transposition = {}

def to_string():
    return ''.join('x' if black & pre_shift[index] else 'o' if white & pre_shift[index] else '.' for index in range(64))

def display(board):    
    return "\n" + "\n".join(board[i:i+8] for i in range(0, len(board), 8)) + "\n"

def initiate(board):
    global black, white
    for index, value in enumerate(board):
        if value == 'x':
            black |= pre_shift[index]
        elif value == 'o':
            white |= pre_shift[index]

# TODO: optimize with bit vectors
def hamming_weight(bitboard):
    count = 0
    while bitboard:
        bitboard &= bitboard - 1        
        count += 1
    return count

def score(alpha, beta):    
    alpha_count = 0
    beta_count = 0
    for index in range(64):
        if alpha & pre_shift[index]:
            alpha_count += weights[index]            
        elif beta & pre_shift[index]:
            beta_count += weights[index]            
    return alpha_count - beta_count

def board_shift(bitboard, direction):
    if direction < 4:
        return (bitboard >> shift_values[direction]) & shift_masks[direction]
    return (bitboard << shift_values[direction - 4]) & shift_masks[direction]

def find_moves(alpha, beta, dots):    
    moves = 0
    for direction in range(8):
        current_shift = board_shift(alpha, direction) & beta        
        for _ in range(5):
            current_shift |= board_shift(current_shift, direction) & beta
        moves |= board_shift(current_shift, direction) & dots
    return moves

def make_move(alpha, beta, move):
    captured = 0    
    alpha |= pre_shift[move]
    for direction in range(8):
        current_shift = board_shift(pre_shift[move], direction) & beta
        for _ in range(5):
            current_shift |= board_shift(current_shift, direction) & beta
        if board_shift(current_shift, direction) & alpha:
            captured |= current_shift
    alpha ^= captured
    beta ^= captured
    return alpha, beta

def minimax(alpha, beta, level):
    dots = ~(alpha | beta)
    moves = find_moves(alpha, beta, dots)
    if not moves:
        if not find_moves(beta, alpha, dots):
            return [hamming_weight(alpha) - hamming_weight(beta)]
        best = minimax(beta, alpha, level - 1) + [-1]
    else:  
        children = []
        for index in range(64):
            if moves & pre_shift[index]:
                next_alpha, next_beta = make_move(alpha, beta, index)
                children.append(minimax(next_beta, next_alpha, level - 1) + [index])
        best = sorted(children)[0]
    return [-best[0]] + best[1:]

def terminal(alpha, beta, lower, upper):
    dots = ~(alpha | beta)
    moves = find_moves(alpha, beta, dots)
    if not moves:
        moves = find_moves(beta, alpha, dots)        
        if not moves:
            return [hamming_weight(alpha) - hamming_weight(beta), -3]
        result = terminal(beta, alpha, -upper, -lower) + [-1]
        return [-result[0]] + result[1:]
    best = None
    temp = -lower
    for index in range(64):
        if moves & pre_shift[index]:
            next_alpha, next_beta = make_move(alpha, beta, index)
            result = terminal(next_beta, next_alpha, -upper, temp) + [index]
            if not best or result[0] < temp:
                best = result
                if result[0] < temp:
                    temp = result[0]
                    if -temp >= upper:
                        return [-best[0]] + best[1:]    
    return [-best[0]] + best[1:]

def main():
    board = sys.argv[1].lower()
    token = sys.argv[2].lower()

    initiate(board)

    if token == 'x':
        alpha = black
        beta = white
    else:
        alpha = white
        beta = black

    dots = ~(alpha | beta)

    moves = find_moves(alpha, beta, dots)
    debug_board = board
    moves_set = set()
    for index in range(64):
        if moves & pre_shift[index]:
            debug_board = debug_board[:index] + "*" + debug_board[index + 1:]
            moves_set.add(index)
    print(display(debug_board))
    print("Possible moves {}".format(moves_set))

    print("My heuristic choice is {}".format(heuristic(board, token, moves_set)))
    
    empty = sum(dots & pre_shift[index] != 0 for index in range(64))
    if empty <= n:
        # result = minimax(alpha, beta, -1)
        result = terminal(alpha, beta, -65, 65)
        print("Negamax returns {}".format(result))

def big_parser():    
    if random.randint(0, 100) <= 10:
        raise ValueError('''
                     ____  _       _____                         
                    |  _ \(_)     |  __ \                        
                    | |_) |_  __ _| |__) |_ _ _ __ ___  ___ _ __ 
                    |  _ <| |/ _` |  ___/ _` | '__/ __|/ _ \ '__|
                    | |_) | | (_| | |  | (_| | |  \__ \  __/ |   
                    |____/|_|\__, |_|   \__,_|_|  |___/\___|_|   
                              __/ |                              
                             |___/                               

    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIII?=...............................=IIII?IIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIII......................................IIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIII?II...                                   ..~?I?IIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIII?II...                                   ....??IIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                      ...???IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                      ....???IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         .......................         ..IIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..II????????????????+..         ..IIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..I?IIIIIIIIIIIIIIII?.          ...?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..I?IIIIIIIIIIIIIIII?.          ...?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..I?IIIIIIIIIIIIIIII?.          ...IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..I?IIIIIIIIIIIIIIII?..         ...?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..I?IIIIIIIIIIII?????..         ...?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         .......................         ..IIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                       ...,?IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                      ...,IIIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                      ..?III?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                       ..I?IIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                         .I?IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                         ..I?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..?IIIIIIIIIIIIIIIII...         ..??IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..IIIIIIIIIIIIIIIIII?..         ...?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..??IIIIIIIIIIIIIIII?.          ...IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..??IIIIIIIIIIIIIIII?.          ...IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..IIIIIIIIIIIIIIIIII?..         ...?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..IIIIIIIIIIIIIIIIII?..         ..,?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         ..?IIIIIIIIIIIIIII?I...         ..I?IIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...         .......................          ??IIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III..                                       ...+?IIIIIIIIIIIIIIIIII
    IIIIIIIIIIII?III...                                      ..IIII?IIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIII...                                .......II?IIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIII...                                ....,IIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIII,............................ ......~IIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIII??IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII?IIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
                ''')

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):        

        # big_parser()
        
        board = ''.join(board).replace('?', '').replace('@', 'x')
        token = player_to_token[player]

        initiate(board)

        if token == 'x':
            alpha = black
            beta = white
        else:
            alpha = white
            beta = black

        dots = ~(alpha | beta)

        moves = find_moves(alpha, beta, dots)
        moves_set = set(index for index in range(64) if moves & pre_shift[index])
        move = heuristic(board, token, moves_set)        
        best_move.value = 11 + (move // 8) * 10 + (move % 8)

        empty = sum(dots & pre_shift[index] != 0 for index in range(64))
        if empty <= n:            
            result = terminal(alpha, beta, -65, 65)[-1]
            best_move.value = 11 + (move // 8) * 10 + (move % 8)            

def test_move(board, token, move, d):
    opponent = ({'x', 'o'} - {token}).pop()    
    for alpha, beta in d:        
        c = move % 8 + alpha
        r = move // 8 + beta            
        if c in {-1, 8} or r in {-1, 8} or board[r * 8 + c] != opponent:
            continue
        flips = {r * 8 + c}        
        c += alpha
        r += beta
        while c not in {-1, 8} and r not in {-1, 8}:
            if board[r * 8 + c] == opponent:
                flips.add(r * 8 + c)                
                c += alpha
                r += beta                
            elif board[r * 8 + c] == token:                    
                board = board[:move] + token + board[move + 1:]
                for index in flips:
                    board = board[:index] + token + board[index + 1:]
                break
            else:
                break    
    return board

# def heuristic(bitboard, moves):
#     corners = moves & 0x8100000000000081
#     if corners:
#         return corners
    
def heuristic(board, token, moves):
    good = {move for move in moves if move in {0, 7, 56, 63}}
    if good:
        return good.pop()
    for move in moves:
        if (move in {1, 2, 3, 4, 5, 6} or move in {57, 58, 59, 60, 61, 62}) and board != test_move(board, token, move, {(-1, 0), (1, 0)}):
            good.add(move)
        if (move in {8, 16, 24, 32, 40, 48} or move in {15, 23, 31, 39, 47, 55}) and board != test_move(board, token, move, {(0, -1), (0, 1)}):
            good.add(move)            
    if good:
        return good.pop()
    temp = set()
    for move in moves:
        if move in {1, 8, 9} and board[0] != token:
            temp.add(move)
        if move in {6, 14, 15} and board[7] != token:
            temp.add(move)
        if move in {48, 49, 57} and board[56] != token:
            temp.add(move)
        if move in {54, 55, 62} and board[63] != token:
            temp.add(move)
    if len(temp) == len(moves):
        temp.pop()
    moves -= temp
    temp = set()
    for move in moves:
        if move in {1, 2, 3, 4, 5, 6, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 57, 58, 59, 60, 61, 62}:
            temp.add(move)
    if len(temp) == len(moves):
        temp.pop()
    moves -= temp
    return moves.pop()

if __name__  == "__main__":
    main()