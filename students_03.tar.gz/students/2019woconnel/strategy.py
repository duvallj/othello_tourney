import string, random, sys

posToNeighbors = dict()
for pos in range(64):
    posToNeighbors[pos] = [None]*8
    #edges
    up = pos > 7
    down = pos < 56
    left = pos%8 > 0
    right = pos%8 < 7
    if up:
        posToNeighbors[pos][0] = pos-8
    if down:
        posToNeighbors[pos][1] = pos+8
    if left:
        posToNeighbors[pos][2] = pos-1
    if right:
        posToNeighbors[pos][3] = pos+1
    #corners
    if up and left:
        posToNeighbors[pos][4] = pos-8-1
    if up and right:
        posToNeighbors[pos][5] = pos-8+1
    if down and left:
        posToNeighbors[pos][6] = pos+8-1
    if down and right:
        posToNeighbors[pos][7] = pos+8+1

cornerSpots = [0,7,56,63]

legalCache = dict()
def legalMoves(board,toPlay):
    # if (board,toPlay) in legalCache:
    #     return legalCache[(board,toPlay)]
    opponent = "O" if toPlay == "X" else "X"
    moves = set()
    potentialMoves = set() #squares that neighbor an opponent's
    for pos in range(64):
        if board[pos] == ".":
            for neighbor in posToNeighbors[pos]:
                if neighbor is not None and board[neighbor] != "." and board[neighbor] != toPlay:
                    potentialMoves.add(pos)
                    break
    for move in potentialMoves:
        validMove = False
        for direction in range(8):
            if posToNeighbors[move][direction] is not None and board[posToNeighbors[move][direction]] == opponent:
                currentSpot = posToNeighbors[move][direction]
                while not validMove:
                    if board[currentSpot] == toPlay:
                        moves.add(move)
                        validMove = True
                    elif board[currentSpot] == ".":
                        break
                    elif posToNeighbors[currentSpot][direction] is not None:
                        currentSpot = posToNeighbors[currentSpot][direction]
                    else:
                        break
            if validMove:
                break
    legalCache[(board,toPlay)] = moves
    return moves

def replaceChar(board, pos, c):
    return board[:pos]+c+board[pos+1:]

def makeMove(board, location, toPlay):
    opponent = "O" if toPlay == "X" else "X"
    board = replaceChar(board, location, toPlay)
    for direction in range(8):
        currentPos = location
        changeSet = set()
        if posToNeighbors[currentPos][direction] and board[posToNeighbors[currentPos][direction]] == opponent:
            currentPos = posToNeighbors[currentPos][direction]
            #changeSet.add(currentPos)
            while True:
                if currentPos is None:
                    break
                if board[currentPos] == toPlay:
                    for change in changeSet:
                        board = replaceChar(board, change, toPlay)
                    break
                if board[currentPos] == opponent:
                    changeSet.add(currentPos)
                    currentPos = posToNeighbors[currentPos][direction]
                else:
                    break
    return board

def isEdge(pos):
    return pos < 8 or pos > 55 or pos % 8 < 1 or pos % 8 > 6

def boardEval(board, token):
    opponent = "O" if token == "X" else "X"
    us = board.count(token)
    them = board.count(opponent)
    if us > them:
        return 1
    elif us < them:
        return -1
    else:
        return 0

def negamax(board, token, improvable, fixedBound):
    opponent = "O" if token == "X" else "X"
    lm = legalMoves(board,token)
    if not lm: #if this side has no moves
        if not legalMoves(board,opponent): #if the other side doesn't either, the game is over so stop
            return [boardEval(board, token)]
        #otherwise it's a pass
        nm = negamax(board, opponent, -fixedBound, -improvable)+[-1] #fixed and improvable are swaped because negatives
        return [-nm[0]]+nm[1:]
    newFB = -improvable
    best = []
    for mv in lm:
        nm = negamax(makeMove(board,mv,token),opponent,-fixedBound,newFB)+[mv]
        if not best or nm[0] < newFB:
            best = nm
            if nm[0] < newFB:
                newFB = nm[0]
                if -newFB >= fixedBound:
                    return [-best[0]]+best[1:]
    return [-best[0]]+best[1:]

def betterThanRandom(board,toPlay,allOptions):
    opponent = "O" if toPlay == "X" else "X"
    mobilityList = []
    for option in allOptions:
        mobilityList.append((len(legalMoves(makeMove(board, option, toPlay), opponent)), option))
    mobilityList = sorted(mobilityList)
    #0: force a pass
    if mobilityList[0][0] == 0:
        return mobilityList[0][1]
    #1: take corners
    for option in allOptions:
        if option in cornerSpots:
            return option
    #2: take edges that connect to corners
    for option in allOptions:
        if isEdge(option):
            newBoard = makeMove(board, option, toPlay)
            for direction in range(4):
                currentPos = posToNeighbors[option][direction]
                while currentPos is not None and posToNeighbors[currentPos][direction] is not None:
                    if newBoard[currentPos] == toPlay:
                        currentPos = posToNeighbors[currentPos][direction]
                    else:
                        break
                if currentPos in cornerSpots and newBoard[currentPos] == toPlay:
                    return option
    #3: don't play to C or X if you don't have that corner
    restrictedOptions = allOptions.copy()
    if board[0] != toPlay:
        restrictedOptions -= {1, 8, 9}
    if board[7] != toPlay:
        restrictedOptions -= {6, 14, 15}
    if board[56] != toPlay:
        restrictedOptions -= {48, 49, 57}
    if board[63] != toPlay:
        restrictedOptions -= {54, 55, 62}
    if restrictedOptions:
        allOptions = restrictedOptions
    #4
    restrictedOptions = {x for x in allOptions if not isEdge(x)}
    if restrictedOptions:
        allOptions = restrictedOptions
    mobilityList = []
    for option in allOptions:
        mobilityList.append((len(legalMoves(makeMove(board, option, toPlay), opponent)), option))
    mobilityList = sorted(mobilityList)
    return random.choice(mobilityList[:len(mobilityList)//2+1])[1]


def printBoard(board):
    for line in range(8):
        print(board[line*8:line*8+8])

def main():
    board = "...........................OX......XO..........................."
    token = None
    locations = []
    for arg in sys.argv[1:]:
        if len(arg) == 64:
            board = arg.upper()
        elif arg.upper() in ["X", "O"]:
            token = arg.upper()
        else:
            if arg.isdigit():
                locations.append(int(arg))
            else:
                partA = string.ascii_lowercase.index(arg[0].lower())
                partB = int(arg[1])-1
                locations.append(partA+partB * 8)
    if not token:
        token = "X" if board.count(".") % 2 == 0 else "O"

    printBoard(board)

    allOptions = legalMoves(board, token)
    print("Legal Moves:"+str(allOptions))
    #chooseBest(board, token, allOptions)
    print(betterThanRandom(board,token,allOptions))
    print(negamax(board, token, -100, 100)[-1]) #try negamax no matter what

if __name__ == "__main__":
    main()

def convert_move(pos):
    return 11+(pos//8)*10+(pos%8)

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        board = "".join(board).replace("?","").replace("@","X").upper()
        player = "X" if player == "@" else "O"
        allOptions = legalMoves(board, player)
        best_move.value = convert_move(random.choice(list(allOptions)))
        best_move.value = convert_move(betterThanRandom(board, player, allOptions))
        best_move.value = convert_move(negamax(board, player, -100, 100)[-1])