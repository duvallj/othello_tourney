#!/usr/bin/env python3
#Sylesh Suresh
import os, sys, os.path
import urllib.request
from subprocess import call
import random
import requests
import time
import tensorflow as tf
import numpy as np
cache = {}
cacheheur = {}
realtoken=None
csquares = {1 : 0, 6 : 7, 8 : 0, 15 : 7, 48 : 56, 57 : 56, 62 : 63, 55 : 63}
lookup = {
'...........................ox......xo...........................' : 19,
'...........................xo......ox...........................' : 19,
'...........................xo......ox...........................' : 20,
'...........................ox......xo...........................' : 20,
'...........................ox......xo...........................' : 19,
'...........................xo......ox...........................' : 19,
'...........................xo......ox...........................' : 20,
'...........................ox......xo...........................' : 20,
'...........................ox......xo...........................' : 19,
'...........................xo......ox...........................' : 19,
'...................o.......oo......ox...........................' : 34,
'...................x.......xx......xo...........................' : 34,
'....................o......oo......xo...........................' : 37,
'....................x......xx......ox...........................' : 37,
'...................o.......oo......ox...........................' : 34,
'...................x.......xx......xo...........................' : 34,
'....................o......oo......xo...........................' : 37,
'....................x......xx......ox...........................' : 37,
'...................o.......oo......ox...........................' : 34,
'...................x.......xx......xo...........................' : 34,
'...................x.......xx.....ooo...........................' : 45,
'...................o.......oo.....xxx...........................' : 45,
'....................x......xx......ooo..........................' : 42,
'....................o......oo......xxx..........................' : 42,
'...................x.......xx.....ooo...........................' : 45,
'...................o.......oo.....xxx...........................' : 45,
'....................x......xx......ooo..........................' : 42,
'....................o......oo......xxx..........................' : 42,
'...................x.......xx.....ooo...........................' : 45,
'...................o.......oo.....xxx...........................' : 45,
'..................ox.......ox......xo...........................' : 26,
'..................xo.......xo......ox...........................' : 26,
'....................xo.....xo......ox...........................' : 29,
'....................ox.....ox......xo...........................' : 29,
'..................ox.......ox......xo...........................' : 26,
'..................xo.......xo......ox...........................' : 26,
'....................xo.....xo......ox...........................' : 29,
'....................ox.....ox......xo...........................' : 29,
'..................ox.......ox......xo...........................' : 26,
'..................xo.......xo......ox...........................' : 26,
'...................xo......xo......xo...........................' : 29,
'...................ox......ox......ox...........................' : 29,
'...................ox......ox......ox...........................' : 26,
'...................xo......xo......xo...........................' : 26,
'...................xo......xo......xo...........................' : 29,
'...................ox......ox......ox...........................' : 29,
'...................ox......ox......ox...........................' : 26,
'...................xo......xo......xo...........................' : 26,
'...................xo......xo......xo...........................' : 29,
'...................ox......ox......ox...........................' : 29,
'...................o.......oo.....xxo........o..................' : 37,
'...................x.......xx.....oox........x..................' : 37,
'....................o......oo......oxx....o.....................' : 34,
'....................x......xx......xoo....x.....................' : 34,
'...................o.......oo.....xxo........o..................' : 37,
'...................x.......xx.....oox........x..................' : 37,
'....................o......oo......oxx....o.....................' : 34,
'....................x......xx......xoo....x.....................' : 34,
'...................o.......oo.....xxo........o..................' : 37,
'...................x.......xx.....oox........x..................' : 37,
'...................x.......xx.....oooo.......x..................' : 44,
'...................o.......oo.....xxxx.......o..................' : 44,
'....................x......xx.....oooo....x.....................' : 43,
'....................o......oo.....xxxx....o.....................' : 43,
'...................x.......xx.....oooo.......x..................' : 44,
'...................o.......oo.....xxxx.......o..................' : 44,
'....................x......xx.....oooo....x.....................' : 43,
'....................o......oo.....xxxx....o.....................' : 43,
'...................x.......xx.....oooo.......x..................' : 44,
'...................o.......oo.....xxxx.......o..................' : 44,
'...................o.......oo.....xxox......oo..................' : 20,
'...................x.......xx.....ooxo......xx..................' : 20,
'....................o......oo.....xoxx....oo....................' : 19,
'....................x......xx.....oxoo....xx....................' : 19,
'...................o.......oo.....xxox......oo..................' : 20,
'...................x.......xx.....ooxo......xx..................' : 20,
'....................o......oo.....xoxx....oo....................' : 19,
'....................x......xx.....oxoo....xx....................' : 19,
'...................o.......oo.....xxox......oo..................' : 20,
'...................x.......xx.....ooxo......xx..................' : 20,
'...................xo......ox.....ooxo......xx..................' : 43,
'...................ox......xo.....xxox......oo..................' : 43,
'...................ox......xo.....oxoo....xx....................' : 44,
'...................xo......ox.....xoxx....oo....................' : 44,
'...................xo......ox.....ooxo......xx..................' : 43,
'...................ox......xo.....xxox......oo..................' : 43,
'...................ox......xo.....oxoo....xx....................' : 44,
'...................xo......ox.....xoxx....oo....................' : 44,
'...................xo......ox.....ooxo......xx..................' : 43,
'...................ox......xo.....xxox......oo..................' : 43,
'...................ox......oo.....xoox.....ooo..................' : 53,
'...................xo......xx.....oxxo.....xxx..................' : 53,
'...................xo......oo.....xoox....ooo...................' : 50,
'...................ox......xx.....oxxo....xxx...................' : 50,
'...................ox......oo.....xoox.....ooo..................' : 53,
'...................xo......xx.....oxxo.....xxx..................' : 53,
'...................xo......oo.....xoox....ooo...................' : 50,
'...................ox......xx.....oxxo....xxx...................' : 50,
'...................ox......oo.....xoox.....ooo..................' : 53,
'...................xo......xx.....oxxo.....xxx..................' : 53,
'...................xo......xx.....oxxo.....oxo.......o..........' : 46,
'...................ox......oo.....xoox.....xox.......x..........' : 46,
'...................ox......xx.....oxxo....oxo.....o.............' : 41,
'...................xo......oo.....xoox....xox.....x.............' : 41,
'...................xo......xx.....oxxo.....oxo.......o..........' : 46,
'...................ox......oo.....xoox.....xox.......x..........' : 46,
'...................ox......xx.....oxxo....oxo.....o.............' : 41,
'...................xo......oo.....xoox....xox.....x.............' : 41,
'...................xo......xx.....oxxo.....oxo.......o..........' : 46,
'...................ox......oo.....xoox.....xox.......x..........' : 46,
'...................ox......oo.....xooo.....xooo......x..........' : 52,
'...................xo......xx.....oxxx.....oxxx......o..........' : 52,
'...................xo......oo.....ooox...ooox.....x.............' : 51,
'...................ox......xx.....xxxo...xxxo.....o.............' : 51,
'...................ox......oo.....xooo.....xooo......x..........' : 52,
'...................xo......xx.....oxxx.....oxxx......o..........' : 52,
'...................xo......oo.....ooox...ooox.....x.............' : 51,
'...................ox......xx.....xxxo...xxxo.....o.............' : 51,
'...................ox......oo.....xooo.....xooo......x..........' : 52,
'...................xo......xx.....oxxx.....oxxx......o..........' : 52,
'...................xo......xo.....oxox.....ooxx.....oo..........' : 29,
'...................ox......ox.....xoxo.....xxoo.....xx..........' : 29,
'...................ox......ox.....xoxo...xxoo.....oo............' : 26,
'...................xo......xo.....oxox...ooxx.....xx............' : 26,
'...................xo......xo.....oxox.....ooxx.....oo..........' : 29,
'...................ox......ox.....xoxo.....xxoo.....xx..........' : 29,
'...................ox......ox.....xoxo...xxoo.....oo............' : 26,
'...................xo......xo.....oxox...ooxx.....xx............' : 26,
'...................xo......xo.....oxox.....ooxx.....oo..........' : 29,
'...................ox......ox.....xoxo.....xxoo.....xx..........' : 29,
'...................ox......ox.....xoxo.....xxoo.....xx..........' : 29,
'...................xo......xo.....oxox.....ooxx.....oo..........' : 29,
'...................xo......xo.....oxox...ooxx.....xx............' : 26,
'...................ox......ox.....xoxo...xxoo.....oo............' : 26,
'...................ox......ox.....xoxo.....xxoo.....xx..........' : 29,
'...................xo......xo.....oxox.....ooxx.....oo..........' : 29,
'...................xo......xo.....oxox...ooxx.....xx............' : 26,
'...................ox......ox.....xoxo...xxoo.....oo............' : 26,
'...................ox......ox.....xoxo.....xxoo.....xx..........' : 29,
'...................xo......xo.....oxox.....ooxx.....oo..........' : 29,
'..................ooo.....xxo......xo...........................' : 29,
'..................xxx.....oox......ox...........................' : 29,
'...................ooo.....oxx.....ox...........................' : 26,
'...................xxx.....xoo.....xo...........................' : 26,
'..................ooo.....xxo......xo...........................' : 29,
'..................xxx.....oox......ox...........................' : 29,
'...................ooo.....oxx.....ox...........................' : 26,
'...................xxx.....xoo.....xo...........................' : 26,
'..................ooo.....xxo......xo...........................' : 29,
'..................xxx.....oox......ox...........................' : 29,
'..................ooo.....xoxx.....oo......o....................' : 44,
'..................xxx.....oxoo.....xx......x....................' : 44,
'...................ooo....xxox.....oo.......o...................' : 43,
'...................xxx....ooxo.....xx.......x...................' : 43,
'..................ooo.....xoxx.....oo......o....................' : 44,
'..................xxx.....oxoo.....xx......x....................' : 44,
'...................ooo....xxox.....oo.......o...................' : 43,
'...................xxx....ooxo.....xx.......x...................' : 43,
'..................ooo.....xoxx.....oo......o....................' : 44,
'..................xxx.....oxoo.....xx......x....................' : 44,
'..................ooo.....xoox.....xxo.....ox...................' : 21,
'..................xxx.....oxxo.....oox.....xo...................' : 21,
'...................ooo....xoox....oxx......xo...................' : 18,
'...................xxx....oxxo....xoo......ox...................' : 18,
'..................ooo.....xoox.....xxo.....ox...................' : 21,
'..................xxx.....oxxo.....oox.....xo...................' : 21,
'...................ooo....xoox....oxx......xo...................' : 18,
'...................xxx....oxxo....xoo......ox...................' : 18,
'..................ooo.....xoox.....xxo.....ox...................' : 21,
'..................xxx.....oxxo.....oox.....xo...................' : 21
}
finaltoken = None
xsquares = {9 : 0, 14 : 7, 49 : 56, 54 : 63}
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
origout = sys.stdout
origerr = sys.stderr
sys.stderr=open("errors.txt", "w")
positionweights = [10000, -3000, 1000, 800, 800, 1000, -3000, 10000,-3000, -5000, -450, -500, -500, -450, -5000, -3000,1000, -450, 30, 10, 10, 30, -450, 1000,800, -500, 10, 50, 50, 10, -500, 800,800, -500, 10, 50, 50, 10, -500, 800,1000, -450, 30, 10, 10, 30, -450, 1000,-3000, -5000, -450, -500, -500, -450, -5000, -3000,10000, -3000, 1000, 800, 800, 1000, -3000, 10000]

class Strategy():
    def __init__(self):
        os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'
        if not os.path.isfile("/tmp/statico.txt") or not os.path.isfile("/tmp/staticx.txt"):
            response = requests.get('https://raw.github.com/csabadavid/asdoifj/master/statico.txt', stream=True)
            handle = open("/tmp/statico.txt", "wb")
            for chunk in response.iter_content(chunk_size=512):
                if chunk:
                    handle.write(chunk)
            response = requests.get('https://raw.github.com/csabadavid/asdoifj/master/staticx.txt', stream=True)
            handle = open("/tmp/staticx.txt", "wb")
            for chunk in response.iter_content(chunk_size=512):
                if chunk:
                    handle.write(chunk)

        print("init")

    def best_strategy(self, b, token, best_move, running):
        #b="???????????........??..@.....??..@.....??@@@@@o..??.@ooo...??@@@@@...??........??........???????????"
        start = time.time()
        actualboard = ''.join(b).replace("?", "").replace("@", "x")
        global realtoken
        realtoken = actualtoken = token if token == 'o' else 'x'
        if actualtoken == 'x':
            f = open("black.txt", "a")
        else:
            f = open("white.txt", "a")
        global finaltoken
        finaltoken = ({'x','o'}-{actualtoken}).pop()
        print(actualboard)
        if actualboard in lookup:
            mv = lookup[actualboard]
            best_move.value = 11 + (mv//8)*10 + (mv%8)
            quit()
        emptycount = actualboard.count('.')
        legals = getLegalMoves(actualboard, actualtoken)
        corners = [0, 7, 56, 63]
        random.shuffle(corners)
        if legals & {0, 7, 56, 63}:
            for i in corners:
                if i in legals:
                    mv = i
                    best_move.value = 11+ (mv//8)*10 + (mv%8)
                    quit()
        if emptycount <= 10:
            nm = negamaxTerminal(actualboard, actualtoken, 11, tokenheuristic, float("-inf"), float("inf"), start)
            mv = nm[-1]
            best_move.value = 11 + (mv//8)*10 + (mv%8)
            if nm[0] < 0:
                f.write("-1\n")
            elif nm[0] == 0:
                f.write("0\n")
            elif nm[0] > 0:
                f.write("1\n")
            quit()
        depth = 1
        """"
        network = False
        if actualtoken in (actualboard[0], actualboard[7], actualboard[56], actualboard[63]) or actualboard.count('.') <= 55:
            val = predictMain(actualboard, actualtoken)
            network = val > 0.9
            print("I neurally guarantee ", val)
            for possmove in legals:
                predval = predictMain(makeMove(actualboard, actualtoken, possmove), finaltoken)
                if predval < -0.9:
                    bestneurmoves.append(possmove)
            heurval = -100
            if bestneurmoves:
                for bestneurmv in bestneurmoves:
                    eachval = negamaxTerminal(makeMove(actualboard, actualtoken, bestneurmv), actualtoken, 3, combheuristic, -100000, 100000, -1)[0]
                    if eachval > heurval:
                        heurval = eachval
                        mv = bestneurmv
                time.sleep(10)
        """
        prelimval = -1
        if True or actualtoken in (actualboard[0], actualboard[7], actualboard[56], actualboard[63]) or emptycount <= 45:
            """
            mv, prob = predictMainMove(actualboard, actualtoken, legals, -1)
            best_move.value = 11+ (mv // 8)*10 + (mv%8) 
            print("Play ", mv, ". I'm", prob, "sure.")
            if not OHNO(actualboard,actualtoken, mv, legals) and not (mv in xsquares and actualboard[xsquares[mv]] == ".") and (prob > 0.85 or mv % 8 in (0, 7) or mv // 8 in (0, 7)):
                print("Trust me.")
                quit()
            print("Nevermind.")
            """
            h = combheuristic
            if emptycount < 42 or True:
                nm = negamaxTerminal(actualboard, actualtoken, 1, h, -1000000, 1000000, -1, ohyes=True)
                print("Shallow move.")
                best_move.value = 11 + (nm[-1] // 8)*10 + (nm[-1]%8)
                bestprob = -0.95
                bestmoves = []
                for possmove in legals:
                    val = predictMain(makeMove(actualboard, actualtoken, possmove), ({'x','o'}-{actualtoken}).pop())
                    if val < bestprob:
                        bestmoves.append(possmove)
                if len(bestmoves) == 1:
                    mv = bestmoves[0]
                    print("Play", mv, "\b. I can guarantee", bestprob)
                    best_move.value = 11+ (mv // 8)*10 + (mv%8) 
                    quit()
                elif not bestmoves:
                    h = combheuristic
                    while True: 
                        nm = negamaxTerminal(actualboard, actualtoken, depth, h, -1000000, 1000000, -1, ohyes=True)
                        move = nm[-1]
                        print("Actually, with", move, "I guarantee ", nm[0])
                        best_move.value = 11+ (move // 8)*10 + (move%8) 
                        depth += 1
                else:
                    bestval = float("inf")
                    bestmove = bestmoves[0]
                    for move in bestmoves:
                        val = combheuristic(makeMove(actualboard, actualtoken, move), ({'x','o'}-{actualtoken}).pop())
                        if val < bestval:
                            bestval = val
                            bestmove = move
                    mv = bestmove
                    print("special method activated!!!")
                    best_move.value = 11+ (mv // 8)*10 + (mv%8) 
                    quit()
                best_move.value = -1000
        h = combheuristic
        while True: 
            nm = negamaxTerminal(actualboard, actualtoken, depth, h, -1000000, 1000000, -1, ohyes=True)
            move = nm[-1]
            print("Actually, with", move, "I guarantee ", nm[0])
            best_move.value = 11+ (move // 8)*10 + (move%8) 
            depth += 1

        if OHNO(actualboard, actualtoken, mv, legals) or (mv in xsquares and actualboard[xsquares[mv]] == "."):
            for i in legals:
                if not (i in xsquares and actualboard[xsquares[mv]] == ".")  and not OHNO(actualboard, actualtoken, i, legals):
                    mv = i
                    break
        print("START: chose", mv)
        best_move.value  = 11 + (mv // 8)*10 + (mv%8)
        """
        if actualboard.count('.') in (60, 59):
            response = requests.get('https://raw.github.com/csabadavid/asdoifj/master/simplemodel.txt', stream=True)
            handle = open("simplemodel.txt", "wb")
            for chunk in response.iter_content(chunk_size=512):
                if chunk:
                    handle.write(chunk)
        """
        move = getmove(actualboard.lower(),actualtoken.lower(), legals, start)
        depth = 2
        if move == -1:
            move = mv
        if move == 65:
            h = combheuristic 
        if move == 65:
            while True: 
                nm = negamaxTerminal(actualboard, actualtoken, depth, h, -100000, 100000, -1, ohyes=True)
                move = nm[-1]
                print("With", move, "I guarantee ", nm[0])
                if not OHNO(actualboard, actualtoken, move, legals) and not (move in xsquares and actualboard[xsquares[move]] == "."):
                    best_move.value = 11+ (move // 8)*10 + (move%8) 
                depth += 1
        best_move.value = 11+ (move // 8)*10 + (move%8) 
        print("REALFINISH")
        sys.stdout.close()
        sys.stdout=origout
def alphabeta(gameboard, token, levels, heuristic, improvable, hardBound, start, ohyes=False):
    cachereadygameboard = ''.join(gameboard)+token
    if cachereadygameboard not in cache:
        lm = getLegalMoves(gameboard, token)
        cache[cachereadygameboard] = lm
    else:
        lm = cache[cachereadygameboard]
    enemy = ({'x', 'o'} - {token}).pop()
    if not lm:
        cachereadygameboard = ''.join(gameboard)+enemy
        if cachereadygameboard not in cache:
            lm = getLegalMoves(gameboard, enemy)
            cache[cachereadygameboard] = lm
        else:
            lm = cache[cachereadygameboard]
        if not lm:
            return [heuristic(gameboard, token)]
        nm = alphabeta(gameboard, enemy, levels-1, heuristic, -hardBound, -improvable, start, ohyes=ohyes) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in sortedmoves(gameboard, lm, token):
        nm = alphabeta(makeMove(gameboard, token, mv), enemy, levels-1, heuristic, -hardBound, newHB, start, ohyes=ohyes) + [mv]
        if not best or nm[0] < newHB:
            best=nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardBound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]

def sixtyto64():
    j = 0
    six64 = []
    for i in range(60):
        if i == 27: j += 2
        if i == 33: j += 2
        six64.append(j)
        j += 1
    return six64
def predictMainMove(board, token, legal, start):
    X = preprocess(board, token, legal)
    probs = predict(X[0], static=False)
    six64 = sixtyto64()
    n = np.argmax(probs)
    bestmove = six64[n]
    if bestmove in legal:
        print("I am", probs[0][n], "sure about the following move")
        return bestmove, probs[0][n]
    print("I have no idea what I am doing.")
    return bestmove, 0.0
def cornerheuristic(gameboard, token):
    me = 0
    opp = 0
    for i in [0, 7, 56, 63]:
        if gameboard[i] == token:
            me += 1
        elif gameboard[i] != ".":
            opp += 1
    return me - opp
def edgestableheuristic(gameboard, token):
    return edgestable(gameboard, token) - edgestable(gameboard, ({'x','o'}-{token}).pop())
def edgestable(gameboard, token):
    stables = 0
    if gameboard[0] == token:
        stables += 1
        for i in range(1, 8):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(7, 63, 8):
            if gameboard[i] != token:
                break
            stables += 1
    if gameboard[7] == token:
        stables += 1
        for i in range(6, -1, -1):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(15, 64, 8):
            if gameboard[i] != token:
                break
            stables += 1
    if gameboard[56] == token:
        stables += 1
        for i in range(63, 6, -8):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(57, 64):
            if gameboard[i] != token:
                break
            stables += 1
    if gameboard[63] == token:
        stables += 1
        for i in range(62, 55, -1):
            if gameboard[i] != token:
                break
            stables += 1
        for i in range(55, 6, -8):
            if gameboard[i] != token:
                break
            stables += 1
    enemy = ({'x','o'}-{token}).pop()
    if (gameboard[0] == enemy and gameboard[7] == enemy) and all([gameboard[i] != "." for i in range(0, 8)]):
        for i in range(0, 8):
            if gameboard[i] == token:
                stables += 1
    if (gameboard[0] == enemy and gameboard[56] == enemy) and all([gameboard[i] != "." for i in range(0, 57, 8)]):
        for i in range(0, 57, 8):
            if gameboard[i] == token:
                stables += 1
    if (gameboard[63] == enemy and gameboard[7] == enemy) and all([gameboard[i] != "." for i in range(7, 64, 8)]):
        for i in range(7, 64, 8):
            if gameboard[i] == token:
                stables += 1
    if (gameboard[63] == enemy and gameboard[56] == enemy) and all([gameboard[i] != "." for i in range(56, 64)]):
        for i in range(56, 64):
            if gameboard[i] == token:
                stables += 1

    return stables
def xsquareheuristic(gameboard, token):
    meval = 0
    oppval = 0
    for xsq in xsquares:
        if gameboard[xsquares[xsq]] == ".":
            if gameboard[xsq] == token:
                meval += 1
            elif gameboard[xsq] != ".":
                oppval += 1
    return oppval - meval
def edgecontrolheuristic(gameboard, token):
    meval = 0
    oppval = 0
    for edgespace in [*range(8)]+[*range(7,64,8)]+[*range(0,60,8)]+[*range(56,64,8)]:
        if gameboard[edgespace] == token:
            meval+=1
        elif gameboard[edgespace] != '.':
            oppval += 1
    return meval-oppval
def combheuristic(gameboard, token):
    if gameboard.count(token) == 0:
        return -1000000
    if gameboard.count(({'x','o'}-{token}).pop()) == 0:
        return 1000000
    val = 15*edgecontrolheuristic(gameboard,token) + 20*frontierheuristic(gameboard, token) + 6*heuristic(gameboard, token) + 200*edgestableheuristic(gameboard, token) + 100*xsquareheuristic(gameboard, token)+200*heuristicOHNO(gameboard, token)
    return val
def negamax(gameboard, token, levels, heuristic, start):
    lm = getLegalMoves(gameboard, token)
    if (time.time() - start) >= 4.85 or not levels or gameboard.count('.') == 0 or gameboard.count('x') == 0 or gameboard.count('o') == 0: return [heuristic(gameboard, token)]
    if not lm:
        nm = negamax(gameboard, ({'x', 'o'}-{token}).pop(), levels-1, heuristic, start) + [-1]
        return [-1*nm[0]] + nm[1:]
    best = min([negamax(makeMove(gameboard, token, mv), ({'x','o'}-{token}).pop(), levels-1, heuristic, start) + [mv] for mv in lm])
    best[0] = -1*best[0]
    return best
def heuristicOHNO(gameboard, token):
    lm = getLegalMoves(gameboard, ({'x','o'}-{token}).pop())
    oppval = len(({0, 7, 56, 63} & lm))
    lm = getLegalMoves(gameboard, token)
    meval = len({0,7,56,63}&lm)
    return meval - oppval
def OHNO(gameboard, token, move, legals):
    lm = legals
    makemove = makeMove(gameboard, token, move)
    lm = getLegalMoves(makemove, ({'x','o'}-{token}).pop())
    if {0, 7, 56, 63} & lm:
        return True
    return False
def antitoken(board, token):
    oppval = board.count(({'x','o'}-{token}).pop())
    meval = board.count(token)
    if meval == 0:
        return -100
    if oppval == 0:
        return 100
    return 0.5*heuristic(board,token)+0.7*(oppval-meval)
def heuristic(board, token):
    if board.count(token) == 0:
        return -1000
    if board.count( ({'x','o'}-{token}).pop()) == 0:
        return 1000
    return len(getLegalMoves(board, token)) - len(getLegalMoves(board, ({'x', 'o'}-{token}).pop()))

def load(static,token='x'):
    TFGRAPH = tf.GraphDef()
    if static:
        s = "/tmp/static"+realtoken+".txt"
        TFGRAPH.ParseFromString(tf.gfile.GFile(s, "rb").read())
    else:
        TFGRAPH.ParseFromString(tf.gfile.GFile("simplemodel.txt", "rb").read())
    with tf.Graph().as_default() as graph:
        tf.import_graph_def(TFGRAPH, input_map=None, return_elements=None, name="prefix", op_dict=None, producer_op_list=None)
    graphop = graph.get_operations()
    input_name, output_name = graphop[0].name+':0', graphop[-1].name+':0'
    return graph, input_name, output_name
def predict(input_data, static=True, token='x'):
    tgraph,tinput,toutput = load(static,token=token)
    return tf.Session(graph=tgraph).run(tgraph.get_tensor_by_name(toutput) , feed_dict={tgraph.get_tensor_by_name(tinput): np.array([input_data])})
def toMatrix(binstring):
    mat = []
    for i in range(10):
        row = []
        for j in range(10):
            row.append(int(binstring[10*i + j]))
        mat.append(row)
    return mat
def combMat(a, b, c):
    finalmat = []
    for i in range(10):
        row = []
        for j in range(10):
            subrow = [a[i][j], b[i][j], c[i][j]]
            row.append(subrow)
        finalmat.append(row)
    return finalmat
def preprocess(prevboard, token, legal):
    xboard, oboard, legalboard = binify(prevboard, legal)
    if token == 'o':
        xboard, oboard= oboard, xboard
    return np.array([combMat(toMatrix(pad(xboard)), toMatrix(pad(oboard)), toMatrix(pad(legalboard)))])
def pad(binaryboardgame):
    matrix = ['0'*10] + [binaryboardgame[8*i:8*i+8] for i in range(8)] + ['0'*10]
    for i in range(1, 9):
        matrix[i] = '0' + matrix[i] + '0'
    return ''.join(matrix)
def sixtyto64():
    j = 0
    six64 = []
    for i in range(60):
        if i == 27: j += 2
        if i == 33: j += 2
        six64.append(j)
        j += 1
    return six64
def PREVpredictMain(board, token, legal=None, start=0):
    if not legal:
        legal= getLegalMoves(board, token)  
    X = preprocess(board, finaltoken, legal)
    value = predict(X[0], token=token)[0][0]*2 - 1
    if token != finaltoken:
        value *= -1.0
    print("FINISH", board, finaltoken, token, value)
    return value
def predictMain(board, token, legal=None, start=0):
    if not legal:
        legal= getLegalMoves(board, token)  
    X = preprocess(board, finaltoken, legal)
    value = predict(X[0], token=token)[0][0]*2 - 1
    if token != finaltoken:
        value *= -1.0
    print("FINISH", board, finaltoken, token, value)
    return value 
def binify(boardgame, legal):
    return (''.join(['1' if i in ('X', 'x') else '0' for i in boardgame]), ''.join(['1' if i in ('o', 'O') else '0' for i in boardgame]), ''.join(['1' if i in legal else '0' for i in range(len(boardgame))]))

def posheuristic(board, token):
    val = 0
    if board.count(token) == 0:
        return -100000
    enemy = ({'x','o'}-{token}).pop()
    for idx, who in enumerate(board):
        if who == token:
            val += positionweights[idx]
        elif who == enemy:
            val -= positionweights[idx]
    return val
def getmove(board, token, legals, start):
    if board.count('.') <= 8:
        return negamaxTerminal(board, token, 8, tokenheuristic, -65, 65, start)[-1]
    """
    for i in random.sample([0, 7, 56, 63], 4):
        if i in legals:
            return i
    """
    if board.count('.') >= 45:
        return 65
    
        #if move not in xsquares:
        #    return move
    return -1 #negamaxTerminal(board, token, 1, predictMain, -100, 100, start)[-1]
def memcombheuristic(board, token):
    if (board,token) in cacheheur:
        return cacheheur[(board,token)]
    val = combheuristic(board, token)
    cacheheur[(board,token)] = val
    return val
def sortedmoves(gameboard, legals, token):
    orderedlegals = []
    return sorted(list(legals), key=lambda mv : memcombheuristic(makeMove(gameboard, token, mv), ({'x','o'}-{token}).pop()))
    """
    corners = {0, 7, 56, 63}
    for move in legals:
        if move in corners:
            orderedlegals = [move] + orderedlegals
        else:
            orderedlegals.append(move)
    return orderedlegals
    """
def negamaxTerminal(gameboard, token, levels, heuristic, improvable, hardBound, start, ohyes=False):
    if not levels: 
        val = heuristic(gameboard, token)
        return [val]
    enemy = ({'x', 'o'} - {token}).pop()
    lm = getLegalMoves(gameboard, token)
    if not lm:
        lm = getLegalMoves(gameboard, enemy)
        if not lm:
            val = heuristic(gameboard, token)
            return [val]
        nm = negamaxTerminal(gameboard, enemy, levels-1, heuristic, -hardBound, -improvable, start)
        score = -nm[0]
        if score  > improvable:
            improvable = score
        return [improvable, -1]
    bestmv = None
    newHB = -improvable
    best = None
    bareminimum = -100000
    for mv in sortedmoves(gameboard, lm, token):
        if bestmv is None:
            nm = negamaxTerminal(makeMove(gameboard, token, mv), enemy, levels-1, heuristic, -hardBound, newHB, start)
            best = nm
            score = -nm[0]
        else:
            nm = negamaxTerminal(makeMove(gameboard, token, mv), enemy, levels-1, heuristic, newHB-1, newHB, start)
            best = nm
            score = -nm[0]
            if improvable < score < hardBound:
                nm = negamaxTerminal(makeMove(gameboard, token, mv), enemy, levels-1, heuristic, -hardBound, -score, start)
                best = nm
                score = -nm[0]
        if score > improvable:
            improvable = score
            bestmv = mv
        if bestmv is None:
            bestmv = mv
            bareminimum = score
        if improvable >= hardBound:
            break
    return [improvable, bestmv]

def mobilityheuristic(gameboard, token):
    return len(actuallegal(gameboard, token)) - len(actuallegal(gameboard, ({'x', 'o'}-{token}).pop()))
def getAdjacent(index):
    location = 1 << index
    maskedloc = mask(location)
    return shift(maskedloc, -1) | shift(maskedloc, 1) | shift(maskedloc, 7) | shift(maskedloc, -7) | shift(maskedloc, 9) | shift(maskedloc, -9) | shift(location, 8) | shift(location, -8)
    """
    locset = set()
    locstring = bitToString(final_locs)
    for idx, char in enumerate(locstring):
        if char == "1":
            locset.add(idx)
    return locset 
    """

def frontierheuristic(gameboard, token):
    if gameboard.count(token) == 0:
        return -1000
    enemy = ({'x','o'}-{token})
    me, opp = stringToBit(gameboard)
    if token == "o":
        opp, me = me, opp
    oppval = 0
    meval = 0
    for i in range(64):
        if gameboard[i] == ".":
            if me & getAdjacent(i):
                meval += 1
            if opp & getAdjacent(i):
                oppval += 1
    return oppval - meval
def tokenheuristic(gameboard, token):
    me = gameboard.count(token)
    opp = gameboard.count(({'x', 'o'}-{token.lower()}).pop())
    if gameboard.count('.') == 0 or (len(getLegalMoves(gameboard, me)) == 0 and len(getLegalMoves(gameboard, opp))) == 0:
        if (me-opp) < 0:
            return -100000
        elif (me-opp) > 0:
            return 100000
        return 0
    return me-opp
def stringToBit(string):
    bitboardx = 0
    bitboardo = 0
    for i in string.lower():
        bitboardx = bitboardx << 1
        bitboardo = bitboardo << 1
        if i == "x":
            bitboardx += 1
        elif i == "o":
            bitboardo += 1
    return (bitboardx, bitboardo)
def bitToString(bits):
    string = str(bin(bits)[2:])
    if len(string) < 64:
        string = "0"*(64-len(string)) + string
    return string
def shift(singleboard, direction):
    #side TRUE = right: up, upright, right, downright
    #side FALSE = left: upleft, left, downleft, down
    #direction -1: left 1 right
    #direction -7: / downleft 7 upright 
    #direction -8: down 8 up
    #direction -9: \ upleft 9 downright

   #-8 : up, 8 : down, 1 : 
    return 0xFFFFFFFFFFFFFFFF & (((singleboard) >> direction) if direction > 0 else (singleboard) << -1*direction)

def shiftrep(me, opp, direction, empty):
    shifted = (shift(me, direction) & opp)
    shifted |= (shift(shifted, direction) & opp)
    shifted |= (shift(shifted, direction) & opp)
    shifted |= (shift(shifted, direction) & opp )
    shifted |= (shift(shifted, direction) & opp )
    shifted |= (shift(shifted, direction) & opp) 
    shifted |= (shift(shifted, direction) )
    return shifted & empty
def mask(board):
    return board & 0x7E7E7E7E7E7E7E7E
def specmask(board, direc):
    masklookup = {1 : 0xFEFEFEFEFEFEFEFE, -1 : 0x7F7F7F7F7F7F7F7F, 8 : 0xFFFFFFFFFFFFFFFF, -8 : 0xFFFFFFFFFFFFFFFF, 7 : 0x7F7F7F7F7F7F7F00, 9 : 0xFEFEFEFEFEFEFE00, -7 : 0x00FEFEFEFEFEFEFE, -9 : 0x007F7F7F7F7F7F7F}
    return masklookup[direc] & board
def boardToString(bits):
    xstring = bitToString(bits[0])
    ostring = bitToString(bits[1])
    return ''.join(["x" if xstring[i] == "1" else "o" if ostring[i] == "1" else "." for i in range(64)])
def makeMove(board, token, move):   
    boardpair = stringToBit(board)
    move = 1 << (63-move) #move - 0 topleft 63 botright
    captured = 0 
    if token == 'x':
        me, opp = boardpair
    else:
        opp, me = boardpair
    me |= move
    
    for direc in [1, -1, 7, -7, 9, -9]:
        x  = shift(specmask(move, direc), direc) & opp
        x |= shift(specmask(x, direc), direc) & opp
        x |= shift(specmask(x, direc), direc) & opp
        x |= shift(specmask(x, direc), direc) & opp
        x |= shift(specmask(x, direc), direc) & opp
        x |= shift(specmask(x, direc), direc) & opp
        captured |= x if (shift(specmask(x, direc), direc) & me) else 0
    x = shift(move, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    x |= shift(x, 8) & opp
    captured |= (x if (shift(x, 8) & me) else 0)
    x = shift(move, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    x |= shift(x, -8) & opp
    captured |= (x if (shift(x, -8) & me) else 0)
    me ^= captured
    opp ^= captured
    if token == 'o':
        return boardToString((opp,me))
    return boardToString((me, opp))

def binLegalMoves(boardpair, token):
    if token == "x":
        me, opp = boardpair
    else:
        opp, me = boardpair
    mestring = bitToString(me)
    empty = ~(me | opp) 
    upright = shiftrep(me, opp, 7, empty)
    finalstring = bitToString(upright)
    maskedopp = opp & 0x7E7E7E7E7E7E7E7E
    return shiftrep(me, maskedopp, 1, empty) | shiftrep(me, maskedopp, 7, empty) | shiftrep(me, opp, 8, empty) | shiftrep(me, maskedopp, 9, empty) | shiftrep(me, maskedopp, -1, empty) | shiftrep(me, maskedopp, -7, empty) | shiftrep(me, opp, -8, empty) | shiftrep(me, maskedopp, -9, empty)
def getLegalMoves(board, token):
    legals = binLegalMoves(stringToBit(board),token)
    legalset = set()
    legalstring = bitToString(legals)
    for idx, char in enumerate(legalstring):
        if char == "1":
            legalset.add(idx)
    return legalset
#print(negamaxTerminal("..oxoooox.oxxooo.xxxoxoo.xxoxooo.xxooxoo.xooooxo.oooooox.oo..ooo", 'x', 12, tokenheuristic, -10000, 10000, -1))
#boardf = '...........x....oooxxxx.oooooxoooooxxooooooxoooo..xooo.....ooo..'
#print(negamaxTerminal(makeMove('...........x....oooxxxx.oooooxoooooxxooooooxoooo..xooo.....ooo..', 'o', 10),'x', 4, combheuristic, -10000, 10000, -1))
"""
print(makeMove(boardf, 'o', 58))
print(negamaxTerminal(makeMove(boardf, 'o', 58), 'x', 4, combheuristic, -10000000, 1000000, -1))
print(negamaxTerminal(makeMove(makeMove(boardf, 'o', 58), 'x', 10), 'o', 4, combheuristic, -10000000, 1000000, -1))
"""

"""
boardf = "..........x.....ooooo...ooxxxxx.ooxxxx..oo.x...................."
#boardf  = ".xooooo...xoxo..o.xxooxxoxxoxooooxooxoxxooxxxxxxo.xxx....x..x..."
#boardf = "???????????........??........??o.ooo@..??@oo@@...??.@oooo..??..@o@...??........??........???????????".replace("?","").replace("@","x")
#print(negamaxTerminal(boardf, 'x', 4, combheuristic, -10000000, 10000000, -1))
print(alphabeta(boardf, 'x', 2, combheuristic, -10000000, 10000000, -1))
#print(getmove(boardf, "x", getLegalMoves(boardf, "o"), -1))Xprint(makeMove(boardf, 'o', 0))
print(makeMove(boardf, 'x', 11))
made = makeMove(boardf, 'x', 11)
print(makeMove(made, 'o', 2))
#print(negamaxTerminal(makeMove(made, 'o', 2), 'x', 1, combheuristic, -1000000, 1000000, -1))
print(alphabeta(makeMove(made, 'o', 2), 'x', 1, combheuristic, -1000000, 1000000, -1))
"""
