#
#Sebastian Vander Ploeg Fallon Period: 3
import sys
import random
import time
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        brd = ''.join(board).replace('?', "").replace('@',"X").replace('o', 'O')
        brd = brd.upper()
        token = 'X' if player == '@' else 'O'
        spotToNeighbors = [{(i // 8, i % 8 + 1), (i // 8, i % 8 - 1), (i // 8 + 1, i % 8), (i // 8 - 1, i % 8),
                            (i // 8 + 1, i % 8 + 1), (i // 8 + 1, i % 8 - 1), (i // 8 - 1, i % 8 - 1),
                            (i // 8 - 1, i % 8 + 1)} for i in range(64)]  # row,col
        toNeighbors = [
            {m[0] * 8 + m[1] for m in spotToNeighbors[i] if m[0] >= 0 and m[0] < 8 and m[1] >= 0 and m[1] < 8} for i in
            range(64)]
        dotCount = len([i for i in brd if i == '.'])
        if dotCount <= 10:
            best_move.value = bestMove(viableMove(brd, toNeighbors, token), toNeighbors, brd, token)
            move = convertMove(negamaxTerminal(brd, token, -65, 65, toNeighbors)[-1])
            best_move.value = move
        else:
            move = convertMove(bestMove(viableMove(brd, toNeighbors, token), toNeighbors, brd, token))
            best_move.value = move

def printTen(board):
    for i in range(10):
        print("".join([]))
def convertMove(move):
    #map an index on 8x8 to 10x10
    return 11 + (move//8)*10 + (move%8)
def main():
    if len(sys.argv[1:]):
        if sys.argv[1] not in {"X", "O", "x", "o"}:
            board = sys.argv[1].upper()
            if len(sys.argv[1:]) > 1:
                startingToken = sys.argv[2].upper()
            else:
                lst = ["X", "O"]
                startingToken = lst[ len([i for i in board if i != "."])%2 ]#changed from board[i] to i
                startingToken = startingToken.upper()
        else:
            startingToken = sys.argv[1].upper()
            board = startingBoard()
    else:
        board = startingBoard()
        startingToken = "X"
    spotToNeighbors = [{(i // 8, i%8 + 1), (i // 8, i%8 - 1), (i // 8+ 1, i%8), (i // 8 - 1, i%8), (i//8+1, i%8 + 1), (i//8+1, i%8 - 1), (i//8-1, i%8 - 1), (i//8-1, i%8 + 1)} for i in range(64)]#row,col
    toNeighbors = [{m[0]*8+m[1] for m in spotToNeighbors[i] if m[0] >= 0 and m[0] < 8 and m[1] >= 0 and m[1] < 8} for i in range(64)]
    vm = viableMove(board, toNeighbors, startingToken)
    prynt(board)
    print("Legal or possible moves: "+str(vm))
    n = 14
    heuristicChoice = bestMove(vm, toNeighbors, board, startingToken)
    print("my heuristic choice is {}".format(heuristicChoice))
    print(str(11 + (heuristicChoice//8)*10+(heuristicChoice%8)))#What the hell???
    if len([i for i in board if i == '.']) <= n:
        nm = negamaxTerminal(board, startingToken, -65, 65, toNeighbors)
        print("Negamax with Alpha Beta returns {} and I choose move {}".format(nm, nm[-1]))
        #print(nm)
    #else:
    #    heuristicChoice = bestMove(vm, toNeighbors, board, startingToken)
    #    print("My heuristic choice is {}".format(heuristicChoice))
    #go through board, find the opponent's characters. Find the squares around them. Replace all of them, check if viable
def bestMove(setOfMoves, toNeighbors, board, toMove):
    #Greedy Corners
    if len({0, 7, 63, 56} & setOfMoves):
        temp = {0, 7, 63, 56} & setOfMoves
        return random.choice([*temp])
    #No C or X
    tempSet = {i for i in setOfMoves}
    for i in {0, 7, 63, 56}:
        if board[i] != toMove:
            tempSet = tempSet - toNeighbors[i]
    if len(tempSet):
        setOfMoves = tempSet
    #Only on edges with protected corner
    lines = {i for i in range(64) if i // 8 in {0, 7} or i % 8 in {0, 7}} - {0, 7, 63, 56}
    indicesOnLine = lines & setOfMoves
    for i in indicesOnLine:
        boardToConsult = play(board, i, toMove, toNeighbors)
        if i % 8 in {0, 7}:
        # go up and down
            if len({boardToConsult[j] for j in range(0, i + 8, 8)}) == 1:
                return i
            if len({boardToConsult[j] for j in range(i, 64, 8)}) == 1:
                return i
        else:
            # go side to side
            if len({boardToConsult[j] for j in range(i, i + 8) if i // 8 == j // 8}) == 1:
                return i
            if len({boardToConsult[j] for j in range(i - 8, i + 1) if i // 8 == j // 8}) == 1:
                return i
    #No edges if none of above satisfied
    if len(setOfMoves - {i for i in range(64) if i // 8 in {0, 7} or i % 8 in {0, 7}}):
        setOfMoves = setOfMoves - {i for i in range(64) if i // 8 in {0, 7} or i % 8 in {0, 7}}
    return random.choice([*setOfMoves])
def negamax(board, token, levels, toNeighbors, passes):
    if not levels: return[evalBoard(board, token)] #done
    if not len([i for i in board if i == '.']):#board[i] to i
        return[evalBoard(board, token)]
    lm = viableMove(board, toNeighbors, token)
    if passes and not lm:
        return [evalBoard(board, token)]
    enemy = {"X", "O"} - {token}
    enemy = enemy.pop()
    if not lm: #pass
        nm = negamax(board, enemy, levels - 1, toNeighbors, 1) + [-1] #pass == -1
        return [-nm[0]] + nm[1:]
    nmList = sorted([negamax(play(board, mv, token, toNeighbors), enemy, levels - 1, toNeighbors, 0) + [mv] for mv in lm])
    best = nmList[0]
    return [-best[0]] + best[1:]
def negamaxTerminal(board, token, improvable, hardBound, toNeighbors):
    lm = viableMove(board, toNeighbors, token)
    enemy = {"X", "O"} - {token}
    enemy = enemy.pop()
    if not lm:
        lm = viableMove(board, toNeighbors, enemy)
        if not lm:
            return [evalBoard(board, token), -3]
        nm = negamaxTerminal(board, enemy, -hardBound, -improvable, toNeighbors) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(play(board, mv, token, toNeighbors), enemy, -hardBound, newHB, toNeighbors) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB > hardBound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]
def evalBoard(board, token):
    return len([i for i in board if i == token]) - len([i for i in board if i not in {token, '.'}])
def play(board, index, startingToken, toNeighbors):
    convert = {index}
    subConvert = set()
    for i in toNeighbors[index]:
        if board[i] in {startingToken, "."}: continue
        else:
            prevCol, prevRow = i % 8, i//8
            rule = (prevCol - index % 8, prevRow - index // 8)
            subConvert = set()
            while prevCol >= 0 and prevRow >= 0 and prevCol < 8 and prevRow < 8 and board[prevCol + prevRow * 8] in {"X", "O"} - {startingToken}:
                subConvert.add(prevCol + prevRow * 8)
                prevCol = prevCol + rule[0]
                prevRow = prevRow + rule[1]
            if prevCol > 7 or prevRow > 7 or prevCol < 0 or prevRow < 0:
                subConvert = set()
                continue
            if board[prevCol + prevRow * 8] == startingToken:
                convert = convert | subConvert
            subConvert = set()
    for i in convert:
        board = board[:i] + startingToken + board[i + 1:]
    return board
def startingBoard():
    str = "."*64
    str = str[:27] + "OX"+str[29:]
    str = str[:35] + "XO" + str[37:]
    return str
def viableMove(pzl, toNeighbors, toMove):
    viableMoves = set()
    notMoverIndices = {i for i in range(64) if pzl[i] != toMove and pzl[i] != '.'} #not the guy who will move...
    neighbors = {m for i in notMoverIndices for m in toNeighbors[i] if pzl[m] == '.'}#the neighbors of o's
    # Requiem 11/14 also 12/14 is really good!
    for i in neighbors:  # check each possibility.
        # first compute notMoverIndices around it...
        myPathways = {j for j in toNeighbors[i] if pzl[j] != toMove and pzl[j] != "."} #is a member of the other.
        # next check if there exists a piece to finish the encapsulation
        myCol, myRow = i % 8, i // 8
        for path in myPathways:
            prevCol, prevRow = path % 8, path // 8  # I need to call it prev not path because I will use it in my iteration
            rule = (prevCol - myCol, prevRow - myRow)  # How we got from the old spot to the new spot.
            done = False
            while not done:
                prevCol += rule[0]
                prevRow += rule[1]
                if prevCol < 0 or prevRow < 0 or prevCol >= 8 or prevRow >= 8:
                    break
                elif pzl[prevCol + prevRow * 8] == '.':
                    break
                elif pzl[prevCol + prevRow * 8] == toMove:
                    done = True
                else:
                    continue
            if done: viableMoves.add(i)
    return viableMoves
def prynt(pzl):
    for i in range(8):
        print(pzl[i*8:i*8+8])
if __name__ == "__main__":
    main()
