# Jan 12, 0952 version

import random
import math

#### Othello Shell
#### P. White 2016-2018

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
PLAYER_VAL = {BLACK: 1, WHITE: -1}
WEIGHTS = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -20,  20,   5,   5,  20, -20, 120,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 120, -20,  20,   15,   15,  20, -20, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]
########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [OUTER]*100
        for i in range(11, 89):
            if 1 <= (i%10) <= 8: board[i] = EMPTY
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        return "".join(board)

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        str = ""
        for i in range(10):
            for j in range(10):
                str += board[10*i+j]
            str += "\n"
        return str

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK: return WHITE
        return BLACK

    def squares(self):
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        match = square + direction
        if board[match] == player: return None
        while board[match] == self.opponent(player): match += direction
        if board[match] == OUTER or board[match] == EMPTY: return None
        return match

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] != EMPTY: return False
        for d in DIRECTIONS:
            valid = self.find_match(board, player, move, d)
            if valid != None: return True
        return False

    def make_move(self, board, player, move): #calls find_match
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board = list(board)
        temp = move
        for d in DIRECTIONS:
            match = self.find_match(board, player, temp, d)
            if match != None:
                while move != match:
                    board[move] = player
                    move += d
            move = temp
        board = ''.join(board)
        return board

    def get_valid_moves(self, board, player): #calls find match
        """Get a list of all legal moves for player."""
        return [sq for sq in self.squares() if self.is_move_valid(board, player, sq)]

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player)) != 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)): return self.opponent(prev_player)
        if self.has_any_valid_moves(board, prev_player): return prev_player
        return None

    def score(self, board, player):
        """Compute player's score (number of player's pieces minus opponent's)."""
        total = 0
        opp = self.opponent(player)
        for i in self.squares():
            if board[i] == player: total += 1
            if board[i] == opp: total -= 1
        return total

    def weighted_score(self, board, player):
        total = 0
        opp = self.opponent(player)
        for s in self.squares():
            if board[s] == player: total += WEIGHTS[s]
            elif board[s] == opp: total -= WEIGHTS[s]
        return total

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return self.has_any_valid_moves(board, BLACK)==False and self.has_any_valid_moves(board, WHITE)==False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    class Node:
        def __init__(self, board, move, score=0):
            self.board = board
            self.move = move
            self.score = score

    def minmax_search(self, b_node, player, alpha, beta, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        board = b_node.board
        if depth == 0:
            b_node.score = self.weighted_score(board) #score the node
            return b_node
        my_moves = self.get_valid_moves(board, player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = self.Node(next_board, move, score = 1000*self.score(next_board))
                children.append(c)
            else:
                c = self.Node(next_board, move) #node is a class so isn't supposed to need self
                c.score = self.minmax_search(c, next_player, alpha, beta, depth = depth-1).score
                children.append(c)
            if next_player == BLACK: alpha = max(alpha, c.score)
            if next_player == WHITE: beta = min(beta, c.score)
            if alpha >= beta: break
        if player == WHITE: winner = min(children, key=lambda x:x.score)
        if player == BLACK: winner = max(children, key=lambda x:x.score)
        """if len(children) != 0: winner = children[0]
        else: return node
        win_score = children[0].score
        for thing in children:
            if player == BLACK and thing.score>win_score:
                win_score = thing.score
                winner = thing
            if player == WHITE and thing.score<win_score:
                win_score = thing.score
                winner = thing"""
        b_node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        parent = self.Node(board, None)
        best = self.minmax_search(parent, player, -float("inf"), float("inf"), depth)
        return best.move

    class b_Node:
        def __init__(self, board, move, opp_score=0, score=0):
            self.board = board
            self.move = move
            self.opp_score = 0
            self.score = 0

    def minimalist(self, node, player, alpha, beta, depth):
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        unwanted = []
        unwanted2 = []
        winner = None
        for move in my_moves:
            if move == 11 or move == 18 or move == 81 or move == 88: return self.Node(board, move)
            if (move == 22 or move == 27 or move == 72 or move == 77) and self.is_move_valid(board, player, move):
                unwanted.append(self.b_Node(board, move))
                continue
            """if (move == 12 or move == 21 or move == 17 or move == 28 or move == 71 or move == 82 or move == 87 or move == 78) and self.is_move_valid(board, player, move):
                unwanted2.append(self.b_Node(board, move))
                continue"""
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            opp_moves = self.get_valid_moves(next_board, self.opponent(next_player))
            if next_player == None:
                c = self.b_Node(next_board, move, opp_score = len(opp_moves), score = 1000*self.score(next_board))
                children.append(c)
            else:
                c = self.b_Node(next_board, move, opp_score = len(opp_moves))
                c.score = self.minmax_search(c, next_player, alpha, beta, depth = depth-1).score
                children.append(c)
            if next_player == BLACK: alpha = max(alpha, c.score)
            if next_player == WHITE: beta = min(beta, c.score)
            if alpha >= beta: break
        #if len(children) == 0 and len(unwanted2) == 0: return random.choice(unwanted)
        #if len(children) == 0: return random.choice(unwanted2)
        if len(children) == 0: return random.choice(unwanted)
        if player == WHITE: winner = min(children, key=lambda x:x.score)
        if player == BLACK: winner = max(children, key=lambda x:x.score)
        #winner = min(children, key=lambda x:x.opp_score)
        return winner

    def minimalist_strategy(self, board, player, depth=6):
        parent = self.b_Node(board, None)
        best = self.minimalist(parent, player, -float("inf"), float("inf"), depth)
        return best.move

    def negascout(self, node, player, alpha, beta, depth):
        board = node.board
        player_val = PLAYER_VAL[player]
        if depth == 0:
            node.score = self.weighted_score(board, player) * player_val
            return node
        my_moves = self.get_valid_moves(board, player)
        children = []
        unwanted = []
        first_child = True
        for move in my_moves:
            if (move == 22 or move == 27 or move == 72 or move == 77) and self.is_move_valid(board, player, move):
                unwanted.append(self.b_Node(board, move))
                continue
            next_board = self.make_move(board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player == None:
                c = self.Node(next_board, move, score = 1000*self.score(next_board, player))
                children.append(c)
            elif first_child:
                first_child = False
                c = self.Node(next_board, move)
                c.score = -self.negascout(c, next_player, -beta, -alpha, depth=depth - 1).score
                children.append(c)
            else:
                c = self.Node(next_board, move)
                c.score = -self.negascout(c, next_player, -alpha-1, -alpha, depth=depth - 1).score
                if alpha < c.score and c.score < beta:
                    c.score = -self.negascout(c, next_player, -beta, -c.score, depth=depth-1).score
                children.append(c)
            alpha = max(alpha, c.score)
            if alpha >= beta: break
        #if player == WHITE: winner = min(children, key=lambda x: x.score)
        #if player == BLACK: winner = max(children, key=lambda x: x.score)
        if len(children) == 0: return random.choice(unwanted)
        winner = max(children, key=lambda x:x.score)
        return winner

    def negascout_strategy(self, board, player, depth=5):
        parent = self.b_Node(board, None)
        best = self.negascout(parent, player, -float("inf"), float("inf"), depth)
        return best.move

    def get_sorted_moves(self, board, player):
        sorted2 = []
        my_moves = self.get_valid_moves(board, player)
        for move in my_moves:
            c = self.Node(self.make_move(board, player, move), move)
            c.score = self.weighted_score(c.board, player)
            sorted2.append(c)
        thing = sorted(sorted2, key=lambda x:-x.score)
        return thing

    def Negascout(self, node, player, depth, alpha, beta, color):
        board = node.board
        if depth == 0 or self.has_any_valid_moves(board, player)==False:
            node.score = color * self.weighted_score(board, player)
            return node
        firstChild = True
        children = []
        my_moves = self.get_sorted_moves(board, player)
        for thing in my_moves:
            move = thing.move
            #if move == 11 or move == 18 or move == 81 or move == 88: return self.Node(board, move)
            boardTemp = self.make_move(board, player, move)
            nextPlayer = self.next_player(boardTemp, player)
            if not firstChild:
                c = self.Node(boardTemp, move)
                c.score = -self.Negascout(c, self.opponent(player), depth - 1, -alpha - 1, -alpha, -color).score
                if alpha < c.score and c.score < beta:
                    c.score = -self.Negascout(c, self.opponent(player), depth - 1, -beta, -c.score, -color).score
                children.append(c)
            else:
                firstChild = False
                c = self.Node(boardTemp, move)
                c.score = -self.Negascout(c, self.opponent(player), depth - 1, -beta, -alpha, -color).score
                children.append(c)
            alpha = max(alpha, c.score)
            if alpha >= beta:
                break
        return max(children, key=lambda x:x.score)

    def Negascout_strategy(self, board, player, depth=4):
        alpha = -12000
        beta = 12000
        parent = self.Node(board, None)
        temp = self.Negascout(parent, player, depth, alpha, beta, 1)
        return temp.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            board = "".join(board)
            best_move.value = self.Negascout_strategy(board, player)
            depth += 1

    standard_strategy = random_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False

#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.Negascout_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board, player), end=" ")
        print("%s wins" % ("Black" if ref.score(board, player) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.standard_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    #game =  ParallelPlayer(1.5)
    game = StandardPlayer()
    game.play()