EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
#James Kuang Pd. 3 Gabor
import sys, random, time
oppositeToken = {"x":"o", "o":"x"}
edges = {a for a in range(64) if a%8 == 0 or a%8 == 7 or int(a/8)==0 or int(a/8)== 7}
cSquares = {1, 8, 6, 15, 55, 62, 57, 48}
xSquares = {9, 15, 49, 54}
outsideOfInside = {8: 0, 10: 2, 11: 3, 12: 4, 14: 6, 15: 7, 17: 16, 22: 23, 25: 24, 30: 31, 33: 32, 38: 39, 41: 40, 46: 47, 50:58, 51:59, 52:60, 53:61}
def display(board):
    return "\n".join([board[a*8:a*8+8] for a in range(8)])
def toMove(board):
    if board.count(".")%2 == 0:
        return "x"
    return "o"
def legalChange(position, change, newPosition):
    if newPosition>63 or newPosition<0:
        return False
    if change == -1 or change == 1:
        return int(position/8) == int(newPosition/8)
    if change == -9 or change == 7 or change==9 or change == -7:
        return abs(position%8 - newPosition%8) == abs(int(position/8) - int(newPosition/8))
    return True
fullNeighbors = {0: [[1, 2, 3, 4, 5, 6, 7], [8, 16, 24, 32, 40, 48, 56], [9, 18, 27, 36, 45, 54, 63]], 1: [[0], [2, 3, 4, 5, 6, 7], [9, 17, 25, 33, 41, 49, 57], [8], [10, 19, 28, 37, 46, 55]], 2: [[1, 0], [3, 4, 5, 6, 7], [10, 18, 26, 34, 42, 50, 58], [9, 16], [11, 20, 29, 38, 47]], 3: [[2, 1, 0], [4, 5, 6, 7], [11, 19, 27, 35, 43, 51, 59], [10, 17, 24], [12, 21, 30, 39]], 4: [[3, 2, 1, 0], [5, 6, 7], [12, 20, 28, 36, 44, 52, 60], [11, 18, 25, 32], [13, 22, 31]], 5: [[4, 3, 2, 1, 0], [6, 7], [13, 21, 29, 37, 45, 53, 61], [12, 19, 26, 33, 40], [14, 23]], 6: [[5, 4, 3, 2, 1, 0], [7], [14, 22, 30, 38, 46, 54, 62], [13, 20, 27, 34, 41, 48], [15]], 7: [[6, 5, 4, 3, 2, 1, 0], [15, 23, 31, 39, 47, 55, 63], [14, 21, 28, 35, 42, 49, 56]], 8: [[9, 10, 11, 12, 13, 14, 15], [0], [16, 24, 32, 40, 48, 56], [1], [17, 26, 35, 44, 53, 62]], 9: [[8], [10, 11, 12, 13, 14, 15], [1], [17, 25, 33, 41, 49, 57], [0], [2], [16], [18, 27, 36, 45, 54, 63]], 10: [[9, 8], [11, 12, 13, 14, 15], [2], [18, 26, 34, 42, 50, 58], [1], [3], [17, 24], [19, 28, 37, 46, 55]], 11: [[10, 9, 8], [12, 13, 14, 15], [3], [19, 27, 35, 43, 51, 59], [2], [4], [18, 25, 32], [20, 29, 38, 47]], 12: [[11, 10, 9, 8], [13, 14, 15], [4], [20, 28, 36, 44, 52, 60], [3], [5], [19, 26, 33, 40], [21, 30, 39]], 13: [[12, 11, 10, 9, 8], [14, 15], [5], [21, 29, 37, 45, 53, 61], [4], [6], [20, 27, 34, 41, 48], [22, 31]], 14: [[13, 12, 11, 10, 9, 8], [15], [6], [22, 30, 38, 46, 54, 62], [5], [7], [21, 28, 35, 42, 49, 56], [23]], 15: [[14, 13, 12, 11, 10, 9, 8], [7], [23, 31, 39, 47, 55, 63], [6], [22, 29, 36, 43, 50, 57]], 16: [[17, 18, 19, 20, 21, 22, 23], [8, 0], [24, 32, 40, 48, 56], [9, 2], [25, 34, 43, 52, 61]], 17: [[16], [18, 19, 20, 21, 22, 23], [9, 1], [25, 33, 41, 49, 57], [8], [10, 3], [24], [26, 35, 44, 53, 62]], 18: [[17, 16], [19, 20, 21, 22, 23], [10, 2], [26, 34, 42, 50, 58], [9, 0], [11, 4], [25, 32], [27, 36, 45, 54, 63]], 19: [[18, 17, 16], [20, 21, 22, 23], [11, 3], [27, 35, 43, 51, 59], [10, 1], [12, 5], [26, 33, 40], [28, 37, 46, 55]], 20: [[19, 18, 17, 16], [21, 22, 23], [12, 4], [28, 36, 44, 52, 60], [11, 2], [13, 6], [27, 34, 41, 48], [29, 38, 47]], 21: [[20, 19, 18, 17, 16], [22, 23], [13, 5], [29, 37, 45, 53, 61], [12, 3], [14, 7], [28, 35, 42, 49, 56], [30, 39]], 22: [[21, 20, 19, 18, 17, 16], [23], [14, 6], [30, 38, 46, 54, 62], [13, 4], [15], [29, 36, 43, 50, 57], [31]], 23: [[22, 21, 20, 19, 18, 17, 16], [15, 7], [31, 39, 47, 55, 63], [14, 5], [30, 37, 44, 51, 58]], 24: [[25, 26, 27, 28, 29, 30, 31], [16, 8, 0], [32, 40, 48, 56], [17, 10, 3], [33, 42, 51, 60]], 25: [[24], [26, 27, 28, 29, 30, 31], [17, 9, 1], [33, 41, 49, 57], [16], [18, 11, 4], [32], [34, 43, 52, 61]], 26: [[25, 24], [27, 28, 29, 30, 31], [18, 10, 2], [34, 42, 50, 58], [17, 8], [19, 12, 5], [33, 40], [35, 44, 53, 62]], 27: [[26, 25, 24], [28, 29, 30, 31], [19, 11, 3], [35, 43, 51, 59], [18, 9, 0], [20, 13, 6], [34, 41, 48], [36, 45, 54, 63]], 28: [[27, 26, 25, 24], [29, 30, 31], [20, 12, 4], [36, 44, 52, 60], [19, 10, 1], [21, 14, 7], [35, 42, 49, 56], [37, 46, 55]], 29: [[28, 27, 26, 25, 24], [30, 31], [21, 13, 5], [37, 45, 53, 61], [20, 11, 2], [22, 15], [36, 43, 50, 57], [38, 47]], 30: [[29, 28, 27, 26, 25, 24], [31], [22, 14, 6], [38, 46, 54, 62], [21, 12, 3], [23], [37, 44, 51, 58], [39]], 31: [[30, 29, 28, 27, 26, 25, 24], [23, 15, 7], [39, 47, 55, 63], [22, 13, 4], [38, 45, 52, 59]], 32: [[33, 34, 35, 36, 37, 38, 39], [24, 16, 8, 0], [40, 48, 56], [25, 18, 11, 4], [41, 50, 59]], 33: [[32], [34, 35, 36, 37, 38, 39], [25, 17, 9, 1], [41, 49, 57], [24], [26, 19, 12, 5], [40], [42, 51, 60]], 34: [[33, 32], [35, 36, 37, 38, 39], [26, 18, 10, 2], [42, 50, 58], [25, 16], [27, 20, 13, 6], [41, 48], [43, 52, 61]], 35: [[34, 33, 32], [36, 37, 38, 39], [27, 19, 11, 3], [43, 51, 59], [26, 17, 8], [28, 21, 14, 7], [42, 49, 56], [44, 53, 62]], 36: [[35, 34, 33, 32], [37, 38, 39], [28, 20, 12, 4], [44, 52, 60], [27, 18, 9, 0], [29, 22, 15], [43, 50, 57], [45, 54, 63]], 37: [[36, 35, 34, 33, 32], [38, 39], [29, 21, 13, 5], [45, 53, 61], [28, 19, 10, 1], [30, 23], [44, 51, 58], [46, 55]], 38: [[37, 36, 35, 34, 33, 32], [39], [30, 22, 14, 6], [46, 54, 62], [29, 20, 11, 2], [31], [45, 52, 59], [47]], 39: [[38, 37, 36, 35, 34, 33, 32], [31, 23, 15, 7], [47, 55, 63], [30, 21, 12, 3], [46, 53, 60]], 40: [[41, 42, 43, 44, 45, 46, 47], [32, 24, 16, 8, 0], [48, 56], [33, 26, 19, 12, 5], [49, 58]], 41: [[40], [42, 43, 44, 45, 46, 47], [33, 25, 17, 9, 1], [49, 57], [32], [34, 27, 20, 13, 6], [48], [50, 59]], 42: [[41, 40], [43, 44, 45, 46, 47], [34, 26, 18, 10, 2], [50, 58], [33, 24], [35, 28, 21, 14, 7], [49, 56], [51, 60]], 43: [[42, 41, 40], [44, 45, 46, 47], [35, 27, 19, 11, 3], [51, 59], [34, 25, 16], [36, 29, 22, 15], [50, 57], [52, 61]], 44: [[43, 42, 41, 40], [45, 46, 47], [36, 28, 20, 12, 4], [52, 60], [35, 26, 17, 8], [37, 30, 23], [51, 58], [53, 62]], 45: [[44, 43, 42, 41, 40], [46, 47], [37, 29, 21, 13, 5], [53, 61], [36, 27, 18, 9, 0], [38, 31], [52, 59], [54, 63]], 46: [[45, 44, 43, 42, 41, 40], [47], [38, 30, 22, 14, 6], [54, 62], [37, 28, 19, 10, 1], [39], [53, 60], [55]], 47: [[46, 45, 44, 43, 42, 41, 40], [39, 31, 23, 15, 7], [55, 63], [38, 29, 20, 11, 2], [54, 61]], 48: [[49, 50, 51, 52, 53, 54, 55], [40, 32, 24, 16, 8, 0], [56], [41, 34, 27, 20, 13, 6], [57]], 49: [[48], [50, 51, 52, 53, 54, 55], [41, 33, 25, 17, 9, 1], [57], [40], [42, 35, 28, 21, 14, 7], [56], [58]], 50: [[49, 48], [51, 52, 53, 54, 55], [42, 34, 26, 18, 10, 2], [58], [41, 32], [43, 36, 29, 22, 15], [57], [59]], 51: [[50, 49, 48], [52, 53, 54, 55], [43, 35, 27, 19, 11, 3], [59], [42, 33, 24], [44, 37, 30, 23], [58], [60]], 52: [[51, 50, 49, 48], [53, 54, 55], [44, 36, 28, 20, 12, 4], [60], [43, 34, 25, 16], [45, 38, 31], [59], [61]], 53: [[52, 51, 50, 49, 48], [54, 55], [45, 37, 29, 21, 13, 5], [61], [44, 35, 26, 17, 8], [46, 39], [60], [62]], 54: [[53, 52, 51, 50, 49, 48], [55], [46, 38, 30, 22, 14, 6], [62], [45, 36, 27, 18, 9, 0], [47], [61], [63]], 55: [[54, 53, 52, 51, 50, 49, 48], [47, 39, 31, 23, 15, 7], [63], [46, 37, 28, 19, 10, 1], [62]], 56: [[57, 58, 59, 60, 61, 62, 63], [48, 40, 32, 24, 16, 8, 0], [49, 42, 35, 28, 21, 14, 7]], 57: [[56], [58, 59, 60, 61, 62, 63], [49, 41, 33, 25, 17, 9, 1], [48], [50, 43, 36, 29, 22, 15]], 58: [[57, 56], [59, 60, 61, 62, 63], [50, 42, 34, 26, 18, 10, 2], [49, 40], [51, 44, 37, 30, 23]], 59: [[58, 57, 56], [60, 61, 62, 63], [51, 43, 35, 27, 19, 11, 3], [50, 41, 32], [52, 45, 38, 31]], 60: [[59, 58, 57, 56], [61, 62, 63], [52, 44, 36, 28, 20, 12, 4], [51, 42, 33, 24], [53, 46, 39]], 61: [[60, 59, 58, 57, 56], [62, 63], [53, 45, 37, 29, 21, 13, 5], [52, 43, 34, 25, 16], [54, 47]], 62: [[61, 60, 59, 58, 57, 56], [63], [54, 46, 38, 30, 22, 14, 6], [53, 44, 35, 26, 17, 8], [55]], 63: [[62, 61, 60, 59, 58, 57, 56], [55, 47, 39, 31, 23, 15, 7], [54, 45, 36, 27, 18, 9, 0]]}
adjacent = {0: [1, 8, 9], 1: [0, 2, 9, 8, 10], 2: [1, 3, 10, 9, 11], 3: [2, 4, 11, 10, 12], 4: [3, 5, 12, 11, 13], 5: [4, 6, 13, 12, 14], 6: [5, 7, 14, 13, 15], 7: [6, 15, 14], 8: [9, 0, 16, 1, 17], 9: [8, 10, 1, 17, 0, 2, 16, 18], 10: [9, 11, 2, 18, 1, 3, 17, 19], 11: [10, 12, 3, 19, 2, 4, 18, 20], 12: [11, 13, 4, 20, 3, 5, 19, 21], 13: [12, 14, 5, 21, 4, 6, 20, 22], 14: [13, 15, 6, 22, 5, 7, 21, 23], 15: [14, 7, 23, 6, 22], 16: [17, 8, 24, 9, 25], 17: [16, 18, 9, 25, 8, 10, 24, 26], 18: [17, 19, 10, 26, 9, 11, 25, 27], 19: [18, 20, 11, 27, 10, 12, 26, 28], 20: [19, 21, 12, 28, 11, 13, 27, 29], 21: [20, 22, 13, 29, 12, 14, 28, 30], 22: [21, 23, 14, 30, 13, 15, 29, 31], 23: [22, 15, 31, 14, 30], 24: [25, 16, 32, 17, 33], 25: [24, 26, 17, 33, 16, 18, 32, 34], 26: [25, 27, 18, 34, 17, 19, 33, 35], 27: [26, 28, 19, 35, 18, 20, 34, 36], 28: [27, 29, 20, 36, 19, 21, 35, 37], 29: [28, 30, 21, 37, 20, 22, 36, 38], 30: [29, 31, 22, 38, 21, 23, 37, 39], 31: [30, 23, 39, 22, 38], 32: [33, 24, 40, 25, 41], 33: [32, 34, 25, 41, 24, 26, 40, 42], 34: [33, 35, 26, 42, 25, 27, 41, 43], 35: [34, 36, 27, 43, 26, 28, 42, 44], 36: [35, 37, 28, 44, 27, 29, 43, 45], 37: [36, 38, 29, 45, 28, 30, 44, 46], 38: [37, 39, 30, 46, 29, 31, 45, 47], 39: [38, 31, 47, 30, 46], 40: [41, 32, 48, 33, 49], 41: [40, 42, 33, 49, 32, 34, 48, 50], 42: [41, 43, 34, 50, 33, 35, 49, 51], 43: [42, 44, 35, 51, 34, 36, 50, 52], 44: [43, 45, 36, 52, 35, 37, 51, 53], 45: [44, 46, 37, 53, 36, 38, 52, 54], 46: [45, 47, 38, 54, 37, 39, 53, 55], 47: [46, 39, 55, 38, 54], 48: [49, 40, 56, 41, 57], 49: [48, 50, 41, 57, 40, 42, 56, 58], 50: [49, 51, 42, 58, 41, 43, 57, 59], 51: [50, 52, 43, 59, 42, 44, 58, 60], 52: [51, 53, 44, 60, 43, 45, 59, 61], 53: [52, 54, 45, 61, 44, 46, 60, 62], 54: [53, 55, 46, 62, 45, 47, 61, 63], 55: [54, 47, 63, 46, 62], 56: [57, 48, 49], 57: [56, 58, 49, 48, 50], 58: [57, 59, 50, 49, 51], 59: [58, 60, 51, 50, 52], 60: [59, 61, 52, 51, 53], 61: [60, 62, 53, 52, 54], 62: [61, 63, 54, 53, 55], 63: [62, 55, 54]}
def goodPath(board, pieceToMove, position, path):
    flips = [path[0]]
    for a in path[1:]:
        if board[a] == ".":
            return (False, flips)
        elif board[a]== pieceToMove:
            return (True, flips)
        flips.append(a)
    return (False, flips)
def findPossibleMoves(board, pieceToMove):
    possibleMoves = []
    for a in range(64):
        if board[a] == ".":
            for b in fullNeighbors[a]:
                if board[b[0]] == oppositeToken[pieceToMove]:
                    if goodPath(board, pieceToMove, a, b)[0]:
                        possibleMoves.append(a)
                        break
    return possibleMoves
squareWeights = [250, -20,  20,   5,   5,  20, -20, 250,
    -20, -40,  -5,  -2,  -2,  -5, -40, -20,
    20,  -5,  15,   3,   3,  15,  -5,  20,
    5,  -2,   3,   7,   7,   3,  -2,   5,
    5,  -2,   3,   7,   7,   3,  -2,   5,
    20,  -5,  15,   3,   3,  15,  -5,  20,
    -20, -40,  -5,  -2,  -2,  -5, -40, -20,
    250, -20,  20,   5,   5,  20, -20, 250]
stabilityWeights= \
    [20, -3, 11, 8, 8, 11, -3, 20,
    -3, -7, -4, 1, 1, -4, -7, -3,
    11, -4, 2, 2, 2, 2, -4, 11,
    8, 1, 2, -3, -3, 2, 1, 8,
    8, 1, 2, -3, -3, 2, 1, 8,
    11, -4, 2, 2, 2, 2, -4, 11,
    -3, -7, -4,1,1,-4, -7, -3,
    20, -3, 11, 8, 8, 11, -3, 20]
def generateWeights(board, token):
    weights = {"o":[a for a in squareWeights], "x":[a for a in squareWeights]}
    for a in (cSquares | xSquares):
        if board[closestCorner[a]] != ".":
            weights[board[closestCorner[a]]][a] *= -1
    for a in outsideOfInside:
        if board[outsideOfInside[a]] != ".":
            if board[closestCorner[outsideOfInside[a]]] == board[outsideOfInside[a]]:
                weights[board[outsideOfInside[a]]][a] += 7
    return weights
def score(board, token):
    newBoardWeights = generateWeights(board, token)
    return sum([newBoardWeights[token][a] for a in range(64) if board[a] == token]) - sum([newBoardWeights[oppositeToken[token]][a] for a in range(64) if board[a] == oppositeToken[token]])
def parity(board, token):
    return len([a for a in range(64) if board[a] == token])
def mobility(board, token):
    if (board, token) in cacheOfLm:
        lm = cacheOfLm[(board, token)]
    else:
        lm = findPossibleMoves(board, token)
        cacheOfLm[(board, token)] = lm
    return len(lm)
def corners(board, token):
    return len([a for a in {0, 7, 56, 63} if board[a]==token])
def cornerCloseness(board, token):
    return -len([a for a in xSquares & cSquares if (board[a] == token) and (closestCorner[a] == ".")])
def stability(board, token):
    stability = sum([stabilityWeights[a] for a in range(64) if board[a] == token])
    return stability
def frontierScore(board, token):
    frontierTokens = sum(["".join([board[b] for b in adjacent[a]]).count(".") for a in range(64) if board[a]==token ])
    return frontierTokens
def idealEdge(board, token):
    value = 0
    ideal = ".." + 4*str(token) + ".."
    if ideal == "".join([board[a] for a in [0, 8, 16, 24, 32, 40, 48, 56]]):
        value+= 1
    if ideal == "".join([board[a] for a in [0, 1, 2, 3, 4, 5, 6, 7]]):
        value += 1
    if ideal == "".join([board[a] for a in [7, 15, 23, 31, 39, 47, 55, 63]]):
        value += 1
    if ideal == "".join([board[a] for a in [56, 57, 58, 59, 60, 61, 62, 63]]):
        value += 1
    return value
def evaluateBoard(board, token):
    count = board.count(".")
    iehvWeight = 5*(1 - count/64)
    mhvWeight = 15*(count/64)
    value = score(board, token)
    mobilityPlayer, mobilityOpponent = mobility(board,token), mobility(board, oppositeToken[token])# mobility
    mhv = mobilityPlayer - mobilityOpponent
    frontierPlayer, frontierOpponent = frontierScore(board, token), frontierScore(board, oppositeToken[token])
    fhv = frontierOpponent - frontierPlayer
    idealEdgesHV = idealEdge(board,token) - idealEdge(board, oppositeToken[token])
    evaluation = value + mhvWeight*(mhv + fhv) + iehvWeight*idealEdgesHV
    return evaluation
    # if (mobilityPlayer + mobilityOpponent) != 0:
    #     mhv = 100 * (mobilityPlayer - mobilityOpponent) / (mobilityPlayer + mobilityOpponent)
    # else:
    #     mhv = 0
    # cornerPlayer, cornerOpponent = corners(board, token), corners(board, oppositeToken[token]) #corners
    # if (cornerPlayer + cornerOpponent) != 0:
    #     chv = 100 * (cornerPlayer - cornerOpponent) / (cornerPlayer + cornerOpponent)
    # else:
    #     chv = 0
    # cornerClosenessPlayer, cornerClosenessOpponent = cornerCloseness(board, token), cornerCloseness(board, oppositeToken[token])
    # if (cornerClosenessPlayer + cornerClosenessOpponent) != 0:
    #     cchv = 100 * (cornerClosenessPlayer - cornerClosenessOpponent) / (-cornerClosenessPlayer - cornerClosenessOpponent)
    # else:
    #     cchv = 0
    # stabilityPlayer, stabilityOpponent = stability(board, token), stability(board, oppositeToken[token]) #stability
    # if (stabilityPlayer + stabilityOpponent) != 0:
    #     shv = 100 * (stabilityPlayer - stabilityOpponent) / (stabilityPlayer + stabilityOpponent)
    # else:
    #     shv = 0
    # return (801.724 * chv) + (382.026 * cchv) + (78.922 * mhv) + shv
def makeMove(board, pieceToMove, position):
    newBoard = board
    newBoard = newBoard[:position] + pieceToMove + newBoard[position + 1:]
    for a in fullNeighbors[position]:
        if board[a[0]] == oppositeToken[pieceToMove]:
            gp = goodPath(board, pieceToMove, position, a)
            if gp[0]:
                for b in gp[1]:
                        newBoard = newBoard[:b] + pieceToMove + newBoard[b+1:]
    return newBoard
cacheOfLm = {}
cacheOfPos = {}
def negaMax(board, token, alpha, beta, levels):
    if (board, token) in cacheOfLm:
        lm = cacheOfLm[(board, token)]
    else:
        lm = findPossibleMoves(board, token)
        cacheOfLm[(board, token)] = lm
    if not levels:
        return [evaluateBoard(board, token)]
    if not lm:
        lm = findPossibleMoves(board, oppositeToken[token])
        if not lm:
            return [evaluateBoard(board, token), -3]
        if (board, oppositeToken[token]) in cacheOfPos:
            nm = cacheOfPos[(board, oppositeToken[token])]
        else:
            nm = negaMax(board, oppositeToken[token], -beta, -alpha, levels-1) + [-1]
            cacheOfPos[(board, oppositeToken[token])] = nm
        return [-nm[0]] + nm[1:]
    best = []
    newBeta = -alpha
    for mv in lm:
        newBoard = makeMove(board, token, mv)
        if (newBoard, oppositeToken[token]) in cacheOfPos:
            nm = cacheOfPos[(newBoard, oppositeToken[token])]
        else:
            nm = negaMax(newBoard, oppositeToken[token], -beta, newBeta, levels-1) + [mv]
            cacheOfPos[(newBoard, oppositeToken[token])] = nm
        if not best or nm[0] < newBeta:
            best = nm
            if nm[0] < newBeta:
                newBeta = nm[0]
                if -newBeta > beta:
                    return[-best[0]] + best[1:]
    return [-best[0]] + best[1:]
def evaluateBoardEnd(board, token):
    return board.count(token)- board.count(oppositeToken[token])
def negaMaxTerminal(board, token, alpha, beta):
    if (board, token) in cacheOfLm:
        lm = cacheOfLm[(board, token)]
    else:
        lm = findPossibleMoves(board, token)
        cacheOfLm[(board, token)] = lm
    if not lm:
        lm = findPossibleMoves(board, oppositeToken[token])
        if not lm:
            return [evaluateBoardEnd(board, token), -3]
        nm = negaMaxTerminal(board, oppositeToken[token], -beta, -alpha) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    newBeta = -alpha
    for mv in lm:
        newBoard = makeMove(board, token, mv)
        if (newBoard, oppositeToken[token]) in cacheOfPos:
            nm = cacheOfPos[(newBoard, oppositeToken[token])]
        else:
            nm = negaMaxTerminal(makeMove(board, token, mv), oppositeToken[token], -beta, newBeta) + [mv]
            cacheOfPos[(newBoard, oppositeToken[token])] = nm
        if not best or nm[0] < newBeta:
            best = nm
            if nm[0] < newBeta:
                newBeta = nm[0]
                if -newBeta > beta:
                    return[-best[0]] + best[1:]
    return [-best[0]] + best[1:]
closestCorner = {0: 0, 1: 0, 2: 0, 3: 0, 4: 7, 5: 7, 6: 7, 7: 7, 8: 0, 9: 0, 15: 7, 16: 0, 23: 7, 24: 0, 31: 7, 32: 56, 39: 63, 40: 56, 47: 63, 48: 56, 49: 56, 54: 63, 55: 63, 56: 56, 57: 56, 58: 56, 59: 56, 60: 63, 61: 63, 62: 63, 63: 63}
def safeEdge(board, token, position):
    for path in fullNeighbors[position]:
        change = position - path[0]
        if abs(change) == 1 or abs(change) == 8:
            pathPieces = {board[a] for a in path}
            pathPiecesMinus = {board[a] for a in path[:-1]}
            if (len(pathPieces) <= 1 and board[path[0]] == token) or (len(pathPiecesMinus) <= 1 and board[path[0]] == oppositeToken[token]):
                return True
    return False
def fourHeur(board, yourToken, possibleMoves):
    if {*possibleMoves} & {0, 7, 56, 63}:
         return random.choice([*({*possibleMoves} & {0, 7, 56, 63})])
    if {*possibleMoves}& edges:
        safeEdges = [a for a in {*possibleMoves}& edges if safeEdge(board, yourToken, a)]
        if safeEdges:
            return random.choice(safeEdges)
    possibleWithoutEdges = [a for a in possibleMoves if a not in edges]
    possibleWithoutUnsafeCX = [a for a in possibleMoves if a not in (cSquares | xSquares) or board[closestCorner[a]].lower() == yourToken]
    if possibleWithoutUnsafeCX:
        return random.choice(possibleWithoutUnsafeCX)
    elif possibleWithoutEdges:
        return random.choice(possibleWithoutEdges)
    return random.choice(possibleMoves)
class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        board = "".join(board).replace("?", "").replace("@", "x")
        token = "x" if player == "@" else "o"
        possibleMoves = findPossibleMoves(board, token)
        mv = fourHeur(board, token, possibleMoves)
        best_move.value = 11 + (mv // 8) * 10 + (mv % 8)
        depth = 8
        if board.count(".") <= 14:
            mv = negaMaxTerminal(board, token, -65, 65)
        else:
            mv = negaMax(board, token, -65, 65, depth)
        best_move.value =  11 + (mv//8)*10 + (mv%8)
def main():
    try:
        board = sys.argv[1].lower()
    except:
        board = "...........................ox......xo..........................."
    try:
        token = sys.argv[2].lower()
    except:
        token = toMove(board)
    print(board)
    possibleMoves = findPossibleMoves(board, token)
    bestMv = fourHeur(board, token, possibleMoves)
    print(bestMv)
    depth = 7
    if board.count(".") <= 14:
        bestMv = negaMaxTerminal(board, token, -65, 65)
        print(bestMv)
    else:
        bestMv = negaMax(board, token,-65, 65, depth)
        print(bestMv)
if __name__ == "__main__":
    main()

