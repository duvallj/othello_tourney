#
#Vasil Iakimovitch
import sys
emptyBoard=['.']*27+['o','x']+['.']*6+['x','o']+['.']*27 #...........................ox......xo...........................
edgePositions={1,2,3,4,5,6, 8,16,24,32,40,48, 15,23,31,39,47,55, 57,58,59,60,61,62} #Does not include corners
neighbors=[(-1, -1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)]

class Strategy():
  def best_strategy(self, board, player, best_move, still_running):
    brd=[]
    for letter in board:
      if(letter!='?'):
        if(letter=='@'):
          brd.append('x')
        else:
          brd.append(letter)
    if player == '@':
      token, otherToken='x', 'o'
    else:
      token, otherToken='o', 'x'
    mv=selectMove(legalMoves(brd, token, otherToken), brd[:], token, otherToken)
    best_move.value=11+(mv//8)*10+(mv%8)
    for x in range(7, 100):
      nmMv= negamaxTerminal(brd[:], token, otherToken, -65, 65, x)[-1]
      best_move.value= 11+(nmMv//8)*10+(nmMv%8)

def printBoard(board):
  toPrint=""
  for x in range(0,8):
    toPrint+="".join(board[x*8:(x*8)+8])+'\n'
  print(toPrint)

def outOfBounds(board, position, neighbor):
  col=position%8
  row=position//8
  if((neighbor[0]==-1 and col==0) or (neighbor[0]==1 and col==7)): #X shift
    return True
  elif((neighbor[1]==-1 and row==0) or (neighbor[1]==1 and row==7)): #Y shift
    return True
  return False

def legalMoves(board, piece, otherPiece):
  possibleMoves=set()
  for position in range(0,64):
    if(board[position] != '.'):
      continue #x, y
    for neighbor in neighbors:
      neighborPos=position
      count=1
      while(not outOfBounds(board, neighborPos, neighbor)):
        neighborPos=neighborPos+neighbor[0]+(neighbor[1]*8)
        if(board[neighborPos] == '.'):
          break
        elif(board[neighborPos]==piece):
          if(count>1):
            count+=1
          break
#         elif(board[neighborPos]==piece and count>1):
#           count+=1
#           break
        count+=1
      if(count>=3 and board[neighborPos]==piece):
        possibleMoves.add(position)
      
  return possibleMoves

def playMove(board, piece, position, otherPiece):
  movesPlayed, spacesFilled, validNeighbor = set(), set(), None
  
  if(board[position] != '.'):
    print("Invalid Move: Space is not empty")
    return [], {-1}
  for neighbor in neighbors:
    tempSpacesFilled=set()
    neighborPos=position
    count=1
    while(not outOfBounds(board, neighborPos, neighbor)):
      neighborPos=neighborPos+neighbor[0]+(neighbor[1]*8)
      if(board[neighborPos] == '.'):
        break
      elif(board[neighborPos]==piece and count==1):
        break
      elif(board[neighborPos]==piece and count>1):
        count+=1
        #tempSpacesFilled.add(neighborPos)
        break
      count+=1
      tempSpacesFilled.add(neighborPos)
    if(count>=3 and board[neighborPos]==piece):
      movesPlayed.add(position)
      spacesFilled=spacesFilled.union(tempSpacesFilled)
      validNeighbor=neighbor
    
  if(movesPlayed):
    for space in spacesFilled:
      board[space]=piece
    board[position]=piece
    return board, {str(movesPlayed.pop())}, spacesFilled, validNeighbor #Make moves played a single var?
  else:
    print("Invalid Move: No possible moves")
    return [], {-1}, set(), None

def safeEdgeMoves(possibleMoves, board, piece, otherPiece):
  possibleEdgeMoves=possibleMoves.intersection(edgePositions)
  list1, list2, spacesFilled, neighbor=[],[], None, None
  for position in possibleEdgeMoves:
    board, position, spacesFilled, neighbor = playMove(board, piece, position, otherPiece)
    if(position in {1,2,3,4,5,6}):
      edge=board[0:8]
      list1, list2 = edge[0:position], edge[position:]  
    elif(position in {8,16,24,32,40,48}):
      edge=board[0]+board[8]+board[16]+board[24]+board[32]+board[40]+board[48]+board[56]
      list1, list2 = edge[0:position//8], edge[position//8:]
    elif(position in {15,23,31,39,47,55}):
      edge=board[7]+board[15]+board[23]+board[31]+board[39]+board[47]+board[55]+board[63]
      list1, list2 = edge[0:position//8], edge[position//8:]
    elif(position in {57,58,59,60,61,62}):
      edge=board[56:64]
      list1, list2 = edge[0:position%8], edge[position%8:]
    
    if(set(list1)=={piece} or set(list2)=={piece}):
      return {position} #Can modify to add position to safeEdgeMoves set and return that
    else:
      for space in spacesFilled:
        board[space]=otherPiece
  
  return {}

def evalBoard(board, token, otherToken):
  return board.count(token)-board.count(otherToken)

def negamaxTerminal(brd, token, otherToken, improvable, hardBound, level):
  if not level:
    return [evalBoard(brd, token, otherToken), -3]
  lm=legalMoves(brd, token, otherToken)
  if not lm:
    lm=legalMoves(brd, otherToken, token)
    if not lm: return [evalBoard(brd, token, otherToken), -3]
    nm=negamaxTerminal(brd[:], otherToken, token, -hardBound, -improvable, level-1)+[-1]
    return [-nm[0]]+nm[1:]
  best=[] #What gets returned
  newHB=-improvable
  for mv in lm:
    nm=negamaxTerminal(playMove(brd[:], token, mv, otherToken)[0], otherToken, token, -hardBound, newHB, level-1)+[mv]
    if not best or nm[0]<newHB:
      best=nm
      if nm[0]<newHB:
        newHB=nm[0]
        if -newHB>=hardBound: return [-best[0]]+best[1:] #Prune, comment out to do standard negamax
  return [-best[0]]+best[1:]

def selectMove(possibleMoves, board, piece, otherPiece):  
  if(0 in possibleMoves): return 0 #Play into a corner if possible
  elif(7 in possibleMoves): return 7
  elif(56 in possibleMoves): return 56
  elif(63 in possibleMoves): return 63
  safeEdges=safeEdgeMoves(possibleMoves, board, piece, otherPiece)
  if(safeEdges): return safeEdges.pop() #Play into a safe edge move if possible
  
  #Can I drop the corner checking here?
  if(board[0]!=piece and possibleMoves-{1,8,9}): #Remove x and c squares from possible moves if your piece is not in that corner
    possibleMoves=possibleMoves-{1,8,9}
  if(board[7]!=piece and possibleMoves-{6,14,15}):
    possibleMoves=possibleMoves-{6,14,15}
  if(board[56]!=piece and possibleMoves-{48,49,57}):
    possibleMoves=possibleMoves-{48,49,57}
  if(board[63]!=piece and possibleMoves-{54,55,62}):
    possibleMoves=possibleMoves-{54,55,62}
    
  if(possibleMoves-edgePositions):
    possibleMoves=possibleMoves-edgePositions
    
  return possibleMoves.pop()

def fromCommandLine():
  board=list(sys.argv[1].lower())
  if(sys.argv[2].lower()=='x'):
    nextToken, otherToken='x','o'
  else:
    nextToken, otherToken='o','x'
  possibleMoves=legalMoves(board, nextToken, otherToken)
  print("Possible Moves: {}".format(possibleMoves))
  print("My heuristic choice is {}".format(selectMove(possibleMoves, board[:], nextToken, otherToken)))
  for x in range(7, 100):
      print(negamaxTerminal(board[:], nextToken, otherToken, -65, 65, x)[-1])
  
def debugOnline():
  best_move, still_running=-1, True
  Strategy.best_strategy('???????????@@@oooo.??o@ooo@..??.ooooooo??o@@o@@o.??o@oo@o@@??@@o@o@oo??..ooooo.??...oo.o@???????????'.lower(), '@'.lower(), best_move, still_running)
  print(best_move)
  
  
if __name__=="__main__":
  fromCommandLine()
  #debugOnline()

#5 Runs: 0.9327 Script ran in 662.7121334075928 seconds
#40 Runs: percent: 0.9154 Script ran in 5765.569218873978 seconds