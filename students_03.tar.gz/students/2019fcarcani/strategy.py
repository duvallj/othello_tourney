import sys
class Strategy(): 
  def best_strategy(self, board, player, best_move, still_running): 
    brd = ''.join(board).replace('?','').replace('@','x')
    token = 'x' if player =='@' else 'o'
    other = 'o' if player =='@' else 'x'
    #mv = pickMove(brd, token, posMoves(createMatrix(brd), token, other))
    for i in range(4, 1000): 
      mv = findBestMove(brd, token, other, i)
      mv1 = 11+(mv//8)*10+(mv%8)
      best_move.value = mv1

def createMatrix(game): 
  matrix = []
  for y in range(8): 
    row = [game[y*8+x] for x in range(8)]
    matrix.append(row)
  return matrix
def onBoard(x, y): 
  if x>7 or x <0 or y>7 or y<0: 
    return False
  return True
def isPossible(game, mine, other, xcoord, ycoord): 
  if not onBoard(xcoord, ycoord):
    return False
  if game[xcoord][ycoord]!='.':
    return False
  possible = False
  for (xmove, ymove) in [(1, 1), (1, 0), (0, 1), (1, -1), (-1, 1), (0, -1), (-1, 0), (-1, -1)]:
    thisCase = True
    x, y = xcoord, ycoord
    x = x+xmove 
    y = y+ymove
    if not onBoard(x, y) or game[x][y]!=other:	
      thisCase = False	
      continue
    x = x+xmove
    y = y+ymove
    while onBoard(x, y) and game[x][y] == other:
      x = x+xmove
      y = y+ymove
    if not onBoard(x, y):
      thisCase = False	
      continue
    if game[x][y]==mine and thisCase: 
      possible = True
  return possible
def posMoves(game, mine, other): 
  posMoves = []
  for x in range(8): 
    for y in range(8): 
      if isPossible(game, mine, other, x, y):
        posMoves.append(x*8+y)
  return posMoves
def tokensFlipped(board, mine, other, xcoord, ycoord): 
  game = createMatrix(board)
  change = True
  newGame = game
  if change:
    if not onBoard(xcoord, ycoord):
      return 'Not a valid move'
    newGame[xcoord][ycoord] = mine
    for (xmove, ymove) in [(1, 1), (1, 0), (0, 1), (1, -1), (-1, 1), (0, -1), (-1, 0), (-1, -1)]:
      others = []
      x, y = xcoord, ycoord
      x = x+xmove 
      y = y+ymove
      others.append((x, y))
      if not onBoard(x, y) or game[x][y]!=other:	
        continue
      x = x+xmove
      y = y+ymove
      while onBoard(x, y) and game[x][y] == other:
        others.append((x, y))
        x = x+xmove
        y = y+ymove
      if not onBoard(x, y):	
        continue
      if game[x][y]==mine: 
        for a, b in others: 
          newGame[a][b] = mine
  newGameString = ''
  for row in newGame: 
    newGameString = newGameString+"".join(row)
  newcount = 0
  oldcount = 0
  for char in newGameString:
    if char==other: 
      newcount += 1
  for char in board: 
    if char == other: 
      oldcount +=1
  return newcount - oldcount
def findBestMove(board, mine, other, depth): 
  return alphabeta(board, mine, other, -100000000, 100000000, depth)[1]
def alphabeta(board, mine, other, alpha, beta, depth):
  if depth == 0:
    return evalBoard(board, mine, other), None
  def value(board, alpha, beta):
    return -alphabeta(board, other, mine, -beta, -alpha, depth-1)[0]
  moves = posMoves(createMatrix(board), mine, other)
  if not moves:
    if not posMoves(createMatrix(board), other, mine):
      return evalBoard(board, mine, other), None
    return value(board, alpha, beta), None
  bestMove = moves[0]
  for move in moves:
    if alpha >= beta:
      break
    val = value(makeMove(board, mine, move), alpha, beta)
    if val > alpha:
      alpha = val
      bestMove = move
  return alpha, bestMove
def evalBoard(board, mine, other):
  myScore = 0
  otherScore = 0
  for i in range(len(board)): 
    if board[i]==mine: 
      #myScore += score(createMatrix(board), mine, i)
      myScore+=score2(i)
    elif board[i]==other: 
      #otherScore += score(createMatrix(board), other, i)
      otherScore+=score2(i)
  flippable = 0
  for move in posMoves(createMatrix(board), other, mine): 
    f = tokensFlipped(board, other, mine, int(move/8), move%8)
    if f > flippable: 
      flippable = f
  return myScore - otherScore - 10*flippable
  #return len(posMoves(createMatrix(board), mine, other)) - len(posMoves(createMatrix(board), other, mine))
def score(game, mine, pos): 
  corners = {0, 7, 56, 63}
  edges = {1, 2, 3, 4, 5, 6, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 57, 58, 59, 60, 61, 62}
  nextToC1 = {1, 8, 9} 
  nextToC2 = {6, 14, 15}
  nextToC3 = {48, 49, 57}
  nextToC4 = {54, 55, 62}
  if pos in corners: 
    return 500
  if pos in edges:
    x, y = int(pos/8), pos%8
    if x == 0 or x == 7: 
      for ycoord in range(0, y-1):
        if game[x][ycoord]!=mine: 
          continue
        if game[x][ycoord] in corners: 
          return 10
      for ycoord in range(y+1, 8): 
        if game[x][ycoord]!=mine: 
          continue
        if game[x][ycoord] in corners: 
          return 10
    if y == 0 or y == 7:
      for xcoord in range(0, x-1):
        if game[xcoord][y] !=mine: 
          continue
        if game[xcoord][y] in corners: 
          return 10
      for xcoord in range(x+1, 8): 
        if game[xcoord][y] != mine: 
          continue
        if game[xcoord][y] in corners: 
          return 10
    return 0
  '''badMoves = set()
  if pos in nextToC1 and game[0][0]!=mine:
    return -40
  elif pos in nextToC2 and game[0][7]!=mine: 
    return -40
  elif pos in nextToC3 and game[7][0]!=mine: 
    return -40
  elif pos in nextToC4 and game[7][7]!=mine: 
    return -40'''
  return 0
def score2(pos): 
  scores = [
    120, -20,  20,   5,   5,  20, -20, 120,
    -20, -40,  -5,  -5,  -5,  -5, -40, -20,
    20,  -5,  15,   3,   3,  15,  -5,  20,
    5,  -5,   3,   3,   3,   3,  -5,   5,
    5,  -5,   3,   3,   3,   3,  -5,   5,
    20,  -5,  15,   3,   3,  15,  -5,  20,
    -20, -40,  -5,  -5,  -5,  -5, -40, -20,
    120, -20,  20,   5,   5,  20, -20, 120,
  ]
  return scores[pos]
def makeMove(board, mine, mv): 
  return (board[0:mv]+str(mine)+board[mv+1:])
def printGame(game): 
  for i in range(0, 64, 8): 
    print(game[i:8+i])
def main(): 
  game = '...........................ox......xo...........................'
  mine = 'x'
  if len(sys.argv)>1:
    game = sys.argv[1].lower()
    if len(sys.argv)>2:
      mine = sys.argv[2].lower()
    elif game.count('.')%2==0:
      mine = 'x'
    else: 
      mine = 'o'
  if mine == 'x':
    other = 'o'
  else: other = 'x'
  gameMatrix = createMatrix(game)
  printGame(game)
  print(game)
  possibleMoves = posMoves(gameMatrix, mine, other)
  if(len(possibleMoves)==0):
    print("No moves are possible")
  else: 
    for i in range(50): 
      print("Possible Move: "+str(findBestMove(game, mine, other, i)))
if __name__ == "__main__": 
  main()