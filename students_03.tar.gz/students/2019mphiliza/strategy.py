lookup = []
for sq in range(64):
    adjs = [sq-9,sq-8,sq-7,sq-1,sq+1,sq+7,sq+8,sq+9]
    if sq%8==0:
        adjs[0]=-1
        adjs[3]=-1
        adjs[5]=-1
    if sq%8==7:
        adjs[2]=-1
        adjs[4]=-1
        adjs[7]=-1
    if sq//8==0:
        adjs[0]=-1
        adjs[1]=-1
        adjs[2]=-1
    if sq//8==7:
        adjs[5]=-1
        adjs[6]=-1
        adjs[7]=-1

    lookup.append(adjs)

def opposite(token):
    if token=="x":
        return "o"
    else:
        return "x"

def moves(board,token):
    optoken=opposite(token)
    possmoves = set()
    spots = [sq for sq in range(64) if board[sq]==token]
    for sq in spots:
        for idx,adj in enumerate(lookup[sq]):
            if adj!=-1:
                if board[adj]==optoken:
                    while adj!=-1 and board[adj]==optoken:
                        adj = lookup[adj][idx]
                    if adj!=-1 and board[adj]==".":
                        possmoves.add(adj)
    return possmoves

def heuristicChoice(board,token,possible):
    t = possible.intersection({0,7,56,63})
    if t:
        possible=t
    else:
        best=set()
        #2
        for move in possible:
            if move%8==0 or move%8==7:
                for idx,adj in enumerate([lookup[move][1],lookup[move][6]]):
                    while adj!=-1 and adj not in {0,7,56,63}:
                        if idx==0:
                            adj=lookup[adj][1]
                        if idx==1:
                            adj=lookup[adj][6]
                    if adj!=1 and adj in {0,7,56,63} and board[adj]==token:
                        best.add(move)
            if move//8==0 or move//8==7:
                for idx,adj in enumerate([lookup[move][3],lookup[move][4]]):
                    while adj!=-1 and adj not in {0,7,56,63}:
                        if idx==0:
                            adj=lookup[adj][3]
                        if idx==1:
                            adj=lookup[adj][4]
                    if adj!=1 and adj in {0,7,56,63} and board[adj]==token:
                        best.add(move)
        t = possible.intersection(best)
        if t:
            possible=t
        else:
            remove=set()
            #3
            test = [1,8,9,6,14,15,48,49,57,54,55,62]
            corner = [0,7,56,63]
            for idx,move in enumerate(test):
                if move in possible:
                    if board[corner[idx//3]]!=token:
                        remove.add(move)
            if len(remove)<len(possible):
                for move in remove:
                    possible.remove(move)
            remove=set()
            #4
            for move in possible:
                if move%8==0 or move%8==7 or move//8==0 or move//8==7:
                    remove.add(move)
            if len(remove)<len(possible):
                for move in remove:
                    possible.remove(move)

    import random
    return(random.choice([*possible]))

def evalboard(board,token):
    return board.count(token)-board.count(opposite(token))

def update(board,token,position):
    flip = []
    optoken = opposite(token)
    for idx,adj in enumerate(lookup[position]):
        temp = [position]
        if adj!=-1 and board[adj]==optoken:
            while adj!=-1 and board[adj]==optoken:
                temp.append(adj)
                adj = lookup[adj][idx]
            if adj!=-1 and board[adj]==token:
                for x in temp:
                    flip.append(x)
    return "".join([board[x] if x not in flip else token for x in range(64)])

def negamax(board,token):
    lm = moves(board,token)
    if board.count(".")==0 or (not lm and not moves(board,opposite(token))):
        return [evalboard(board,token)]
    if not lm:
        nm = negamax(board,opposite(token))+[-1]
        return [-nm[0]]+nm[1:]
    nmlist=sorted([negamax(update(board,token,move),opposite(token))+[move] for move in lm])
    best = nmlist[0]
    return [-best[0]]+best[1:]

def newmove(move):
    return 11+(move//8)*10+(move%8)

class Strategy():
    def best_strategy(self,board,player,best_move,still_running):
        board = "".join(board).replace("?","").replace("@","x")
        player = "x" if player=="@" else "o"
        possible = moves(board,player)
        best_move.value = newmove(heuristicChoice(board,player,possible))
        if board.count(".")<=8:
            nm = negamax(board,player)
            best_move.value = newmove(nm[-1])
