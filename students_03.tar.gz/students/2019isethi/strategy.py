import random

legalMovesDict = {}
class Strategy():
    def best_strategy(self, board, player, best_move, running):
        game = "".join(board)
        game = game.replace("?", "")
        game = game.replace("@", "X")
        game = game.replace("o", "O")
        playerToToken = {"@": "X", "o": "O"}
        player = playerToToken[player]
        opposite = "O" if player == "X" else "X"
        possSets = legalMoves(game, player, opposite)
        flag = True
        cornerFlag = True
        corners = {0, 7, 56, 63}
        edges = set().union({*range(8)}, {*range(56, 64)}, {8 * i for i in range(8)}, {7 + 8 * i for i in range(8)})
        cornerSet = corners & possSets
        if len(cornerSet) > 0:
            flag = False
            cornerFlag = False
            oldMove = random.choice([*cornerSet])
            best_move.value = 11 + (oldMove // 8) * 10 + (oldMove % 8)

        if flag:
            playingSet = set()
            for i in possSets:
                if i in edges:
                    nextGame = placeToken(game, player, opposite, i)
                    for xdir, ydir in ((1, 0), (0, 1), (-1, 0), (0, -1)):
                        currentX, currentY = i % 8  , i // 8
                        currentX += xdir
                        currentY += ydir
                        currentIndex = 8 * currentY + currentX
                        if currentX in range(8) and currentY in range(8) and currentIndex in edges and nextGame[currentIndex] == player:
                            while currentX in range(8) and currentY in range(8) and currentIndex in edges and currentIndex not in corners and nextGame[currentIndex] == player:
                                currentX += xdir
                                currentY += ydir
                                currentIndex = 8 * currentY + currentX
                            if currentX in range(8) and currentY in range(8) and currentIndex in corners and nextGame[currentIndex] == player:
                                playingSet.add(i)
            if len(playingSet) > 0:
                flag = False
                oldMove = random.choice([*playingSet])
                best_move.value = 11 + (oldMove // 8) * 10 + (oldMove % 8)

        boardEval = [10000, -3000, 1000, 800, 800, 1000, -3000, 10000,
                     -3000, -5000, -450, -500, -500, -450, -5000, -3000,
                     1000, -450, 30, 10, 10, 30, -450, 1000,
                     800, -500, 10, 50, 50, 10, -500, 800,
                     800, -500, 10, 50, 50, 10, -500, 800,
                     1000, -450, 30, 10, 10, 30, -450, 1000,
                     -3000, -5000, -450, -500, -500, -450, -5000, -3000,
                     10000, -3000, 1000, 800, 800, 1000, -3000, 10000]
        if flag and cornerFlag:
            bestScore, oldMove, checked = -100000000000000000, 0, False
            for i in possSets:
                newGame = placeToken(game, player, opposite, i)
                enemyGoodLM = corners & legalMoves(newGame, opposite, player)
                if len(enemyGoodLM) > 0:
                    continue
                boardScore = sum([boardEval[i] for i in range(64) if newGame[i] == player]) - sum([boardEval[i] for i in range(64) if newGame[i] == opposite])
                if boardScore > bestScore:
                    bestScore = boardScore
                    oldMove = i
                    checked = True
            if checked:
                best_move.value = 11 + (oldMove // 8) * 10 + (oldMove % 8)
            else:
                best_move.value = 11 + ([*possSets][0] // 8) * 10 + ([*possSets][0]  % 8)

        oldMove = negamaxTerminal(game, player, opposite, -65, 65)[-1]
        best_move.value = 11 + (oldMove // 8) * 10 + (oldMove % 8)

def negamaxTerminal(board, player, enemy, improvable, hardBound):
    if (board, player) in legalMovesDict:
        lm = legalMovesDict[(board, player)]
    else:
        lm = legalMovesForDot(board, player, enemy)
        legalMovesDict[(board, player)] = lm
    if not lm:
        if (board, enemy) in legalMovesDict:
            lm = legalMovesDict[(board, enemy)]
        else:
            lm = legalMovesForDot(board, enemy, player)
            legalMovesDict[(board, enemy)] = lm
        if not lm: return[board.count(player) - board.count(enemy), -3] #-3 means game is over
        nm = negamaxTerminal(board, enemy, player, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1::]
    newHB, best = -improvable, []
    for move in lm:
        nm = negamaxTerminal(placeToken(board, player, enemy, move), enemy, player, -hardBound, newHB) + [move]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardBound: return [-best[0]] + best[1::]
    return [-best[0]] + best[1::]

def legalMoves(game, player, opposite):
    possSets = set()
    dotSet = {i for i, sym in enumerate(game) if sym == player}
    for index in dotSet:
        for xdirection, ydirection in ((1, 0), (-1, -1), (0, 1), (1, -1), (0, -1), (1, 1), (-1, 1), (-1, 0)):
            currentX, currentY = index % 8, index // 8
            currentX += xdirection
            currentY += ydirection
            currentIndex = 8 * currentY + currentX
            if currentX in range(8) and currentY in range(8) and game[currentIndex] == opposite:
                while currentX in range(8) and currentY in range(8) and game[currentIndex] == opposite:
                    currentX += xdirection
                    currentY += ydirection
                    currentIndex = 8 * currentY + currentX
                if currentX in range(8) and currentY in range(8) and game[currentIndex] == ".":
                    possSets.add(currentIndex)
    return possSets

def legalMovesForDot(game, player, opposite):
    possSets = set()
    dotSet = {i for i, sym in enumerate(game) if sym == "."}
    for index in dotSet:
        for xdirection, ydirection in ((1, 0), (-1, -1), (0, 1), (1, -1), (0, -1), (1, 1), (-1, 1), (-1, 0)):
            currentX, currentY = index % 8, index // 8
            currentX += xdirection
            currentY += ydirection
            currentIndex = 8 * currentY + currentX
            if currentX in range(8) and currentY in range(8) and game[currentIndex] == opposite:
                while currentX in range(8) and currentY in range(8) and game[currentIndex] == opposite:
                    currentX += xdirection
                    currentY += ydirection
                    currentIndex = 8 * currentY + currentX
                if currentX in range(8) and currentY in range(8) and game[currentIndex] == player:
                    possSets.add(index)
    return possSets

def placeToken(myGame, player, opposite, position):
    newGame = myGame[0:position] + player + myGame[position + 1::]
    for xdirection, ydirection in ((1, 0), (-1, -1), (0, 1), (1, -1), (0, -1), (1, 1), (-1, 1), (-1, 0)):
        currentX, currentY = position % 8, position // 8
        currentX += xdirection
        currentY += ydirection
        currentIndex = 8 * currentY + currentX
        if currentX in range(8) and currentY in range(8) and newGame[currentIndex] == opposite:
            while currentX in range(8) and currentY in range(8) and myGame[currentIndex] == opposite:
                currentX += xdirection
                currentY += ydirection
                currentIndex = 8 * currentY + currentX
            if currentX in range(8) and currentY in range(8) and newGame[currentIndex] == player:
                newXDirection, newYDirection = xdirection * -1, ydirection * -1
                currentX += newXDirection
                currentY += newYDirection
                currentIndex = 8 * currentY + currentX
                while currentX in range(8) and currentY in range(8) and newGame[currentIndex] == opposite:
                    newGame = newGame[0:currentIndex] + player + newGame[currentIndex + 1::]
                    currentX += newXDirection
                    currentY += newYDirection
                    currentIndex = 8 * currentY + currentX
    return newGame
