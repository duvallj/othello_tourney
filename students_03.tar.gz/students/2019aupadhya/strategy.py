# legalMoves and makeMove are Cassidy Trinh's Dr. gabor gave me permission to use it to speed up my code for the othello Labs
import sys
import curses, time
import termios
from sys import stdin
import random

w = ['X', 'O'] #x -> black, o -> white
moveList = {}
global pToken
global game
global n
pToken = 'X'
game = '...........................OX......XO...........................'
n = 0

def main():
    n = 0
    if len(sys.argv) == 3:
        game = str(sys.argv[1]).upper()
        pToken = str(sys.argv[2]).upper()
        if pToken == 'O': n = 1
        return findBestMove(game, n)

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        bfs = "".join(board).replace('?', '').replace('@','X').replace('o','O')
        token = 0 if player == '@' else 1
        mv = findBestMove(bfs, token)
        mv1 = 11 + (mv//8)*10 + (mv%8)
        best_move.value = mv1

#The method legalMoves(board, t) is Cassidy Trinh's. Dr. Gabor gave me permission to use it to speed up my code for the othello Labs
#I have made a few edits to her code
def legalMoves(board, t):
 if board+t in moveList:
    return moveList[board+t]
 legal = {}
 enemies = []
 for i in range(64):
  if board[i] != t and board[i] != ".":
   enemies.append(i)
 for pos in enemies:
  # place piece to the left of an enemy
  if 0 < pos % 8 < 7:
   if board[pos - 1] == ".":
    temp = pos + 1
    while temp % 8 <= 7 and temp < 64:
     if board[temp] == ".":
      break
     elif board[temp] == t:
      if pos - 1 not in legal:
       legal[pos - 1] = []
      legal[pos - 1].append(("L", temp))
      break
     if temp % 8 == 7:
      break
     temp += 1
  # place piece to the right of an enemy
  if 0 < pos % 8 < 7:
   if board[pos + 1] == ".":
    temp = pos - 1
    while temp % 8 >= 0 and temp >= 0:
     if board[temp] == ".":
      break
     elif board[temp] == t:
      if pos + 1 not in legal:
       legal[pos + 1] = []
      legal[pos + 1].append(("R", temp))
      break
     if temp % 8 == 0:
      break
     temp -= 1
  # place piece above an enemy
  if pos > 7:
   if board[pos - 8] == ".":
    temp = pos + 8
    while temp < 64:
     if board[temp] == ".":
      break
     elif board[temp] == t:
      if pos - 8 not in legal:
       legal[pos - 8] = []
      legal[pos - 8].append(("A", temp))
      break
     temp += 8
   # diag above, moves LR
   if 8 < pos < 56 and 0 < pos % 8 < 7:
    if board[pos - 9] == ".":
     temp = pos + 9
     while temp < 64:
      if board[temp] == ".":
       break
      elif board[temp] == t:
       if pos - 9 not in legal:
        legal[pos - 9] = []
       legal[pos - 9].append(("ALR", temp))
       break
      if temp % 8 == 7:
       break
      temp += 9
   # diag above, moves RL
   if 8 < pos < 56 and 7 > pos % 8 > 0:
    if board[pos - 7] == ".":
     temp = pos + 7
     while temp < 64:
      if board[temp] == ".":
       break
      elif board[temp] == t:
       if pos - 7 not in legal:
        legal[pos - 7] = []
       legal[pos - 7].append(("ARL", temp))
       break
      if temp % 8 == 0:
       break
      temp += 7
  # place piece below enemy
  if pos < 56:
   if board[pos + 8] == ".":
    temp = pos - 8
    while temp >= 0:
     if board[temp] == ".":
      break
     elif board[temp] == t:
      if pos + 8 not in legal:
       legal[pos + 8] = []
      legal[pos + 8].append(("B", temp))
      break
     temp -= 8
   # diag below, moves RL
   if 56 > pos > 8 and 7 > pos % 8 > 0:
    if board[pos + 9] == ".":
     temp = pos - 9
     while temp >= 0:
      if board[temp] == ".":
       break
      elif board[temp] == t:
       if pos + 9 not in legal:
        legal[pos + 9] = []
       legal[pos + 9].append(("BRL", temp))
       break
      if temp % 8 == 0:
       break
      temp -= 9
   # diag below, moves LR
   if 56 > pos > 8 and 0 < pos % 8 < 7:
    if board[pos + 7] == ".":
     temp = pos - 7
     while temp >= 0:
      if board[temp] == ".":
       break
      elif board[temp] == t:
       if pos + 7 not in legal:
        legal[pos + 7] = []
       legal[pos + 7].append(("BLR", temp))
       break
      if temp % 8 == 7:
       break
      temp -= 7
 if board+t not in moveList: moveList[board+t] = legal
 return legal

#The method makeMove(board, t, pos) is Cassidy Trinh's. Dr. Gabor gave me permission to use it to speed up my code for the othello Labs
def makeMove(board, t, pos):
 moves = legalMoves(board, t)
 if len(moves) == 0 or pos not in moves:
  return board
 pb = board[:pos] + t + board[pos + 1:]
 flips = []
 for rel, end in moves[pos]:
  if rel == "L":
   flips.extend([*range(pos, end)])
  elif rel == "R":
   flips.extend([*range(end, pos)])
  elif rel == "A":
   flips.extend([*range(pos, end, 8)])
  elif rel == "B":
   flips.extend([*range(end, pos, 8)])
  elif rel == "ALR":
   flips.extend([*range(pos, end, 9)])
  elif rel == "ARL":
   flips.extend([*range(pos, end, 7)])
  elif rel == "BLR":
   flips.extend([*range(end, pos, 7)])
  else:  # BRL
   flips.extend([*range(end, pos, 9)])
 final = ''.join(t if i in flips else char for i, char, in enumerate(pb))
 return final

def evalBoard(board, token):
    return len([i for i in board if i == w[token]]) - len([i for i in board if i == w[not token]])


def negamaxTerminal(board, token, improvable, hardBound): # put best guess move first
    #if not levels: return [evalBoard(board, token)]
    lm = legalMoves(board, w[token])
    if not lm: 
        lm = legalMoves(board, w[not token])
        if not lm: return [evalBoard(board, token), -3]

        nm = negamaxTerminal(board, not token, -hardBound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]   

    best = []
    newHB = -improvable
    for mv in lm:
        nm = negamaxTerminal(makeMove(board, w[token], mv), not token, -hardBound, newHB) + [mv]
        if not best or nm[0] < newHB:
            best = nm
            if nm[0] < newHB:
                newHB = nm[0]
                if -newHB >= hardBound:
                    return [-best[0]] + best[1:]
    return [-best[0]] + best[1:]


def findBestMove(game, n):
#negamax alpha beta
    q = game.count('.')
    if q <= 10: return negamaxTerminal(game, n, -65, 65)[-1]

#hueristic
    lom = [x for x in legalMoves(game, w[n])]
    print(lom, legalMoves(game, w[n]))
        #gabors rules
    improve = False
    x = -1
    x = []

        #A
    x = [q for q in lom if q in [0,7,56,63]]
    if len(x) > 0:
        improve = True
        return random.choice(x)

        #B  FIX
    elif not improve: #not places next to corners!!!!
        x = [q for q in lom if q in [2,3,4,5, 58,59,60,61, 23, 31, 39, 47, 16, 24, 32, 40, 26]]
        if len(x) > 0:
            improve = True
            return random.choice(x)
                    
        #C
    elif not improve:
        temp = []
        if game[0] == w[n]:
            temp.extend([1,8,9])
        if game[7] == w[n]:
            temp.extend([6, 14, 15])
        if game[56] == w[n]:
            temp.extend([48, 49, 57])
        if game[63] == w[n]:
            temp.extend([54, 55, 62])
        x = [q for q in lom if q in temp]
        if len(x) > 0:
            improve = True
            return random.choice(x)


        #D
    x = [i for i in lom if i not in (1, 8, 9, 6, 14, 15, 48, 49, 57, 54, 55, 62)]
    print('X', x)
    x = [r for r in x if r > -1]
    
    if len(x) == 0:
        x = [r for r in lom if r > -1 ]
    #print(min([(len(legalMoves(makeMove(game, w[n], i), w[not n])), i) for i in x]))
    #return min([(len(legalMoves(makeMove(game, w[n], i), w[not n])), i) for i in x])[1]
    return random.choice(x)

if __name__ == "__main__":
    print(main())