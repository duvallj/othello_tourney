import random
import math
from collections import deque
# from bitarray import bitarray

import time
from multiprocessing import Value, Process
import os
import signal

# #### othello Shell
# #### P. White 2016-2018

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

double, single = [
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 240, -20, 20, 5, 5, 20, -20, 240, 0,
                             0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                             0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
                             0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
                             0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
                             0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
                             0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                             0, 240, -20, 20, 5, 5, 20, -20, 240, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                         ], [
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
                             0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                             0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
                             0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
                             0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
                             0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
                             0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                             0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                         ]
best = {BLACK: max, WHITE: min}
unordered = [r + c for r in range(10, 90, 10) for c in range(1, 9)]


def main():
    s = Strategy()
    # print(s.get_pretty_board(s.get_starting_board()))
    game = ParallelPlayer(5)
    # game = StandardPlayer()
    game.play()
    # board = Board("???????????ooo.....?" + 7 * "?........?" + "??????????")
    # print(Strategy.get_pretty_board(board))
    # s.territory(board, WHITE)


class Bitboard:
    def __init__(self, board_list=None, board=None):
        if board_list is not None:
            self.empty = 0
            self.black = 0
            self.white = 0
            mask = 1
            for i in range(100):
                val = board_list[i]
                if val != OUTER:
                    if val == BLACK:
                        self.black |= mask
                    elif val == WHITE:
                        self.white |= mask
                    else:
                        self.empty |= mask
                mask <<= 1
        else:
            self.empty, self.black, self.white = board

    def __hash__(self):
        return hash((self.empty, self.black, self.white))

    def __str__(self):
        return str(bin(self.empty)) + "\n" + str(bin(self.black)) + "\n" + str(bin(self.white))

    def get(self, i):
        if i < 11 or i > 88 or i % 10 == 0 or i % 10 == 9:
            return OUTER
        mask = 1 << i
        if self.empty & mask:
            return EMPTY
        elif self.black & mask:
            return BLACK
        elif self.white & mask:
            return WHITE

    def get_empty(self):
        count = 0
        temp = self.empty >> 10
        for i in range(11, 89):
            temp >>= 1
            if temp & 1:
                count += 1
        return count

    def score(self):
        count = 0
        mask = 1 << 10
        for i in range(11, 89):
            mask <<= 1
            if self.black & mask:
                count += 1
            elif self.white & mask:
                count -= 1
        return count

    @staticmethod
    def make_move(board, player, move):
        e, b, w = board.empty, board.black, board.white
        flipped = 0
        for d in DIRECTIONS:  # check all possible rows to flip
            match = Strategy.find_match(board, player, move, d)
            if match is not None:  # if match, flip from next until match
                i = move + d
                while i != match:
                    flipped += 1 << i
                    i += d
        new = 1 << move  # flip starting square
        e &= ~new
        if player == BLACK:
            b ^= flipped + new  # player
            w ^= flipped  # opponent
        elif player == WHITE:
            w ^= flipped + new  # player
            b ^= flipped  # opponent
        return Bitboard(board=(e, b, w))

    def get_valid_moves(self, strategy, player):
        candidates = strategy.get_frontier(self)
        valid_moves = []
        opponent = Strategy.opponent(player)
        for move in strategy.ordered:
            if move in candidates:
                for d in DIRECTIONS:
                    if self.get(move + d) == opponent:
                        i = move + d + d
                        while self.get(i) == opponent:
                            i += d
                        if self.get(i) == player:
                            valid_moves.append(move)
                            break
        # if self.score_vector is not None:
        #    valid_moves.sort(key=lambda x: -self.score_vector[x])
        return valid_moves


'''
class Bitarrayboard:
    def __init__(self, board_list=None, board=None):
        if board_list is not None:
            self.empty = bitarray(100)
            self.black = bitarray(100)
            self.white = bitarray(100)
            for r in range(10, 90, 10):
                for c in range(1, 9):
                    val = board_list[r + c]
                    if val == BLACK:
                        self.black[r + c] = True
                    elif val == WHITE:
                        self.white[r + c] = True
                    else:
                        self.empty[r + c] = True
        else:
            self.empty, self.black, self.white = board

    def __hash__(self):
        return hash((str(self.empty), str(self.black), str(self.white)))

    def __str__(self):
        return str(self.empty) + "\n" + str(self.black) + "\n" + str(self.white)

    def get(self, i):
        if i < 11 or i > 88 or i % 10 == 0 or i % 10 == 9:
            return OUTER
        if self.empty[i]:
            return EMPTY
        elif self.black[i]:
            return BLACK
        elif self.white[i]:
            return WHITE

    def get_empty(self):
        return self.empty.count(True)

    def score(self):
        return self.black.count(True) - self.white.count(True)

    @staticmethod
    def make_move(board, player, move):
        e, b, w = board.empty[:], board.black[:], board.white[:]
        for d in DIRECTIONS:  # check all possible rows to flip
            match = Strategy.find_match(board, player, move, d)
            if match is not None:  # if match, flip from next until match
                i = move + d
                while i != match:
                    b[i], w[i] = w[i], b[i]
                    i += d
        e[move] = False
        if player == BLACK:
            b[move] = True
        elif player == WHITE:
            w[move] = True
        return Bitarrayboard(board=(e, b, w))
'''


class Listboard:
    def __init__(self, board_list):
        self.board = board_list

    def __hash__(self):
        return hash("".join(self.board))

    def __str__(self):
        return "".join(self.board)

    def get(self, i):
        return self.board[i]

    def get_empty(self):
        return self.board.count(EMPTY)

    def score(self):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count = 0
        for i in unordered:  # check play squares, increment or decrement score if piece
            player = self.board[i]
            if player == BLACK:
                count += 1
            elif player == WHITE:
                count -= 1
        return count

    @staticmethod
    def make_move(board, player, move):
        new_board = board.board[:]
        for d in DIRECTIONS:  # check all possible rows to flip
            match = Strategy.find_match(board, player, move, d)
            if match is not None:  # if match, flip from next until match
                i = move + d
                while i != match:
                    new_board[i] = player
                    i += d
        new_board[move] = player
        return Listboard(new_board)

    def get_valid_moves(self, strategy, player):
        candidates = strategy.get_frontier(self)
        valid_moves = []
        opponent = Strategy.opponent(player)
        for move in strategy.ordered:
            if move in candidates:
                for d in DIRECTIONS:
                    if self.board[move + d] == opponent:
                        i = move + d + d
                        while self.board[i] == opponent:
                            i += d
                        if self.board[i] == player:
                            valid_moves.append(move)
                            break
        # if self.score_vector is not None:
        #    valid_moves.sort(key=lambda x: -self.score_vector[x])
        return valid_moves


class Stringboard:
    def __init__(self, board_list=None, board=None):
        if board_list is not None:
            self.board = "".join(board_list)
        else:
            self.board = board

    def __str__(self):
        return self.board

    def __hash__(self):
        return hash(self.board)

    def get(self, i):
        return self.board[i]

    def get_empty(self):
        return self.board.count(EMPTY)

    def score(self):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count = 0
        for i in unordered:  # check play squares, increment or decrement score if piece
            player = self.board[i]
            if player == BLACK:
                count += 1
            elif player == WHITE:
                count -= 1
        return count

    @staticmethod
    def make_move(board, player, move):
        new_board = list(board.board)
        for d in DIRECTIONS:  # check all possible rows to flip
            match = Strategy.find_match(board, player, move, d)
            if match is not None:  # if match, flip from next until match
                i = move + d
                while i != match:
                    new_board[i] = player
                    i += d
        new_board[move] = player
        return Stringboard(board_list=new_board)

    def get_valid_moves(self, strategy, player):
        candidates = strategy.get_frontier(self)
        valid_moves = []
        opponent = Strategy.opponent(player)
        for move in strategy.ordered:
            if move in candidates:
                for d in DIRECTIONS:
                    if self.board[move + d] == opponent:
                        i = move + d + d
                        while self.board[i] == opponent:
                            i += d
                        if self.board[i] == player:
                            valid_moves.append(move)
                            break
        # if self.score_vector is not None:
        #    valid_moves.sort(key=lambda x: -self.score_vector[x])
        return valid_moves


class Tokenboard:
    def __init__(self, board_list=None, board=None):
        if board is not None:
            self.board = board
            self.str = "".join([s for part in self.board[0] for s in part])
        else:
            self.board = Tokenboard.tokenize(board_list)
            self.str = "".join(board_list)

    def __hash__(self):
        return hash(self.str)

    def __str__(self):
        return self.str

    def get(self, i):
        return self.str[i]

    def get_empty(self):
        return self.str.count(EMPTY)

    def score(self):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count = 0
        for part in self.board[0]:  # check play squares, increment or decrement score if piece
            for s in part:
                player = s[0]
                if player == BLACK:
                    count += len(s)
                elif player == WHITE:
                    count -= len(s)
        return count

    @staticmethod
    def make_move(board, player, move):
        new_tokens = board.copy_tokens()
        opponent = Strategy.opponent(player)
        for coord in [(0, int(move / 10)), (1, move % 10),
                      (2, move % 10 + 9 - int(move / 10)), (3, int(move / 10) + move % 10)]:
            way = new_tokens[coord[0]][coord[1]]
            j = move / 10 if coord[0] == 1 else move % 10
            k = 0
            while j >= len(way[k]):
                j -= len(way[k])
                k += 1
            back = (0 <= k - 2 and way[k - 2][0] == player and way[k - 1][0] == opponent)
            fore = (k + 2 < len(way) and way[k + 2][0] == player and way[k + 1][0] == opponent)
            if back:
                for sq in [Tokenboard.get_index(new_tokens, coord[0], coord[1], k-2, n) for n in range(len(way[k-2]))]:
                    Tokenboard.set_token(new_tokens, sq, player, skip=[coord[0]])
            if fore:
                for sq in [Tokenboard.get_index(new_tokens, coord[0], coord[1], k+2, n) for n in range(len(way[k+2]))]:
                    Tokenboard.set_token(new_tokens, sq, player, skip=[coord[0]])
            if back and fore:
                way[k - 1] = (len(way[k - 1]) + 1 + len(way[k + 1])) * player
                del way[k:k+1]
            elif back:
                way[k - 1] = (len(way[k - 1]) + 2) * player
                way[k] = way[k][1:]
                if way[k] == "":
                    del way[k]
                del way[k - 2]
            elif fore:
                way[k + 1] = (len(way[k + 1]) + 2) * player
                way[k] = way[k][1:]
                del way[k + 2]
                if way[k] == "":
                    del way[k]

        return Tokenboard(board=new_tokens)

    def get_valid_moves(self, strategy, player):
        valid_moves = set()
        opponent = Strategy.opponent(player)
        for t in range(len(self.board)):
            tok = self.board[t]
            for l in range(len(tok)):
                line = tok[l]
                for i in range(2, len(line) - 2):
                    if line[i] == "":
                        print()
                    if line[i][0] == opponent:
                        if line[i - 1][0] == player and line[i + 1][0] == ".":
                            valid_moves.add(Tokenboard.get_index(self.board, t, l, i + 1, 0))
                        elif line[i - 1][0] == "." and line[i + 1][0] == player:
                            valid_moves.add(Tokenboard.get_index(self.board, t, l, i - 1, len(line[i - 1]) - 1))
        valid_moves = list(valid_moves)
        return sorted(valid_moves, key=lambda x: (-double[x], x))

    @staticmethod
    def tokenize(board_list):
        rows, cols, downs, ups = [], [], [], []
        for row in range(0, 10):
            rows.append([])
            curr = board_list[10 * row]
            for col in range(1, 10):
                sq = board_list[10 * row + col]
                if sq == curr[0]:
                    curr += sq
                else:
                    rows[row].append(curr)
                    curr = sq
            rows[row].append(curr)
        for col in range(0, 10):
            cols.append([])
            curr = board_list[col]
            for row in range(1, 10):
                sq = board_list[10 * row + col]
                if sq == curr[0]:
                    curr += sq
                else:
                    cols[col].append(curr)
                    curr = sq
            cols[col].append(curr)
        for i in [90, 80, 70, 60, 50, 40, 30, 20, 10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
            downs.append([])
            curr = board_list[i]
            i += 11
            while i < 100 and i % 10 != 0:
                sq = board_list[i]
                if sq == curr[0]:
                    curr += sq
                else:
                    downs[-1].append(curr)
                    curr = sq
                i += 11
            downs[-1].append(curr)
        for i in [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]:
            ups.append([])
            curr = board_list[i]
            i -= 9
            while i >= 1 and i % 10 != 0:
                sq = board_list[i]
                if sq == curr[0]:
                    curr += sq
                else:
                    ups[-1].append(curr)
                    curr = sq
                i -= 9
            ups[-1].append(curr)
        return rows, cols, downs, ups

    def copy_tokens(self):
        return tuple([[part.copy() for part in way] for way in self.board])

    @staticmethod
    def get_index(board, t, l, s, i):
        if t == 0:
            return 10 * l + len("".join(board[0][l][:s])) + i
        elif t == 1:
            return 10 * (len("".join(board[1][l][:s])) + i) + l
        elif t == 2:
            start = [90, 80, 70, 60, 50, 40, 30, 20, 10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9][l]
            return start + 11 * (len("".join(board[2][l][:s])) + i)
        elif t == 3:
            start = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99][l]
            return start - 9 * (len("".join(board[3][l][:s])) + i)

    @staticmethod
    def set_token(tokens, i, kind, skip=None):
        ways = (tokens[0][int(i / 10)], tokens[1][i % 10],
                tokens[2][i % 10 + 9 - int(i / 10)], tokens[3][int(i / 10) + i % 10])
        m = 0
        for way in ways:
            if skip is None or m not in skip:
                j = int(i / 10) if way == ways[1] else i % 10
                k = 0
                while j >= len(way[k]):
                    j -= len(way[k])
                    k += 1
                old = way[k][0]
                if old != kind:
                    way[k] = way[k][j + 1:]
                    way.insert(k, kind)
                    way.insert(k, j * old)
                    back = (way[k] == "" and k - 1 >= 0 and way[k - 1][0] == kind)
                    fore = (way[k + 2] == "" and k + 3 < len(way) and way[j + 3][0] == kind)
                    if back and fore:
                        way[k - 1] += kind + way[k + 3]
                        del way[k:k+3]
                    elif back:
                        way[k - 1] += kind
                        del way[k:k+1]
                    elif fore:
                        way[k + 3] += kind
                        del way[k+1:k+2]
                    if "" in way:
                        way.remove("")
            m += 1

Board = Stringboard


class Node:
    def __init__(self, board, move, score=None):
        self.board = board
        self.move = move
        self.score = score

    def __lt__(self, other):
        assert self.score is not None and other.score is not None
        return self.score < other.score

#############################################################
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################


class Strategy:
    def __init__(self):
        self.my_player = None
        self.MOVES = {}
        self.NO_MOVES = set()
        self.FRONTIER = {}
        self.score_vector = None
        self.smart_score = None

        self.score_vector_choice = {WHITE: single, BLACK: single}
        self.smart_score_choice = {WHITE: self.terra_weighted2, BLACK: self.terra_weighted2}
        self.ordered = unordered

    def update_my_player(self, my_player):
        self.my_player = my_player
        self.score_vector = self.score_vector_choice[my_player]
        self.ordered.sort(key=lambda x: -self.score_vector[x])
        # print(self.ordered)
        self.smart_score = self.smart_score_choice[my_player]

    # scoring functions

    def terra_weighted(self, board):
        return self.move_diff_score(board) + self.terra(board) + self.weighted_score(board) / 40
        # single: -24 W 27 B

    def terra_weighted2(self, board):
        return self.move_diff_score(board) + self.terra(board)/3.5 + self.weighted_score(board) / 40

    def terra_weighted3(self, board):
        return self.move_diff_score(board) + self.terra(board)/8 + self.weighted_score(board) / 40

    def terra_hybird(self, board):
        return self.move_diff_score(board) + self.terra(board)

    def add_hybrid(self, board):
        return self.move_diff_score(board) + self.weighted_score(board) / 40

    def mult_hybrid(self, board):
        move_diff = self.move_diff_score(board)
        weighted = self.weighted_score(board)
        if move_diff > 0 and weighted > 0:
            return move_diff * weighted
        elif move_diff * weighted < 0:
            return -math.sqrt(-move_diff * weighted)
        else:
            return -move_diff * weighted

    def terra(self, board):
        return self.territory(board, BLACK) - self.territory(board, WHITE)

    def territory(self, board, player):
        potential = deque([11, 18, 81, 88])
        safe = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
                10, 19, 20, 29, 30, 39, 40, 49, 50, 59, 60, 69, 70, 79, 80, 89,
                90, 91, 92, 93, 94, 95, 96, 97, 98, 99}
        while len(potential) != 0:
            sq = potential.popleft()
            if sq not in safe and board.get(sq) == player:
                neighbors = [sq + d in safe for d in DIRECTIONS]
                for start in range(5):
                    if neighbors[start:start+4] == 4 * [True]:
                        safe.add(sq)
                        for d in DIRECTIONS:
                            potential.append(sq + d)
                        break
                for start in range(5, 8):
                    if neighbors[start:] + neighbors[:start-4] == 4 * [True]:
                        safe.add(sq)
                        for d in DIRECTIONS:
                            potential.append(sq + d)
                        break
        return len(safe) - 36

    def weighted_score(self, board):
        count = 0
        for i in unordered:  # check play squares, increment or decrement score if piece
            player = board.get(i)
            if player == BLACK:
                count += self.score_vector[i]
            elif player == WHITE:
                count -= self.score_vector[i]
        return count

    def move_diff_score(self, board):
        return len(self.get_moves(board, BLACK)) - len(self.get_moves(board, WHITE))

    # utility

    @staticmethod
    def get_pretty_board(board):
        """Get a string representation of the board."""
        return "\n".join(["".join([board.get(10 * r + c).replace(OUTER, "✗ ").replace(EMPTY, "◦ ")
                                  .replace(BLACK, "◯ ").replace(WHITE, "◉ ") for c in range(10)])
                          for r in range(10)]) + "\n"

    @staticmethod
    def get_starting_board(board_type=Board):
        return board_type(board_list=list(
            "??????????"
            "?........?"
            "?........?"
            "?........?"
            "?...o@...?"
            "?...@o...?"
            "?........?"
            "?........?"
            "?........?"
            "??????????"))

    def get_random_board(self, min_moves, max_moves):
        s = Strategy()
        board = Strategy.get_starting_board()
        player = BLACK
        for i in range(random.randint(min_moves, max_moves)):
            board = Strategy.make_move(board, player, s.random_strategy(board, player))
            player = self.next_player(board, player)
        return board, player

    @staticmethod
    def opponent(player):
        """Get player's opponent."""
        return WHITE if player == BLACK else BLACK

    @staticmethod
    def find_match(board, player, i, d):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        # assert board[square] == EMPTY  # should not call otherwise
        opponent = Strategy.opponent(player)
        if board.get(i + d) != opponent:  # need at least one opponent square
            return None

        match = i + 2 * d
        while board.get(match) == opponent:  # go to first square past line of opponents
            match += d
        if board.get(match) == player:  # if square is player, match found
            return match
        else:
            return None  # no match

    @staticmethod
    def make_move(board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        return Board.make_move(board, player, move)

    def get_frontier(self, board):
        if board not in self.FRONTIER:
            self.FRONTIER[board] = Strategy.frontier(board, 44, set(unordered))
        return self.FRONTIER[board]

    @staticmethod
    def frontier(board, i, part):
        f = set()
        part.remove(i)
        for d in DIRECTIONS:
            if board.get(i + d) == EMPTY:
                f.add(i + d)
            elif (i + d) in part:
                f = f | Strategy.frontier(board, i + d, part)
        return f

    def get_valid_moves(self, board, player):
        return board.get_valid_moves(self, player)

    def get_moves(self, board, player):
        if (board.__hash__(), player) not in self.MOVES:
            self.MOVES[(board.__hash__(), player)] = self.get_valid_moves(board, player)
        return self.MOVES[(board.__hash__(), player)]

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if (board, player) in self.NO_MOVES:
            # print("here")
            return False
        result = (len(self.get_moves(board, player)) != 0)
        if not result:
            self.NO_MOVES.add((board, player))
        return result

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opp_player = Strategy.opponent(prev_player)
        if self.has_any_valid_moves(board, opp_player):  # go to other player if they have moves
            return opp_player
        elif self.has_any_valid_moves(board, prev_player):  # if not, same player moves again if they have moves
            return prev_player
        else:
            return None  # neither player has moves; end game

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return not self.has_any_valid_moves(board, player) and \
            not self.has_any_valid_moves(board, Strategy.opponent(player))

    # ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    # ################ strategies #################

    @staticmethod
    def score(board):
        return board.score()

    def minmax_search(self, node, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        # prioritize ties to punish bad moves
        if depth == 0:
            if self.game_over(node.board, player):
                node.score = 10000 * Strategy.score(node.board)
            else:
                node.score = self.smart_score(node.board)
            return node

        moves = self.get_moves(node.board, player)
        # print(Strategy.get_pretty_board(node.board), moves)
        winner = None
        for move in moves:
            next_board = Strategy.make_move(node.board, player, move)
            next_player = self.next_player(next_board, player)
            if next_player is None:
                c = Node(next_board, move, score=10000 * Strategy.score(next_board))
                # print("over", c.score)
                winner = best[player](winner, c) if winner is not None else c
            else:
                c = Node(next_board, move)
                c.score = self.minmax_search(c, next_player, depth - 1, alpha, beta).score
                winner = best[player](winner, c) if winner is not None else c
                if player == BLACK:
                    alpha = max(alpha, winner.score)
                elif player == WHITE:
                    beta = min(beta, winner.score)
                if beta <= alpha:
                    break
        node.score = winner.score
        return winner

    default_depth = 7

    def minmax_strategy(self, board, player, depth=default_depth):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node(board, None), player, depth, -float("inf"), float("inf")).move

    def random_strategy(self, board, player, best_move=None, still_running=None):
        if still_running is not None:
            best_move.value = random.choice(self.get_moves(board, player))
            return
        else:
            return random.choice(self.get_moves(board, player))

    def best_strategy(self, board, player, best_move=None, still_running=None, md=default_depth):
        # ## THIS IS the public function you must implement
        # ## Run your best search in a loop and update best_move.value
        self.update_my_player(player)
        if still_running is not None:
            if type(board) is list:
                board = Board(board_list=board)
            elif type(board) is str:
                board = Board(board_list=list(board))
            best_move.value = self.random_strategy(board, player)
            max_depth = 1
            limit = Board.get_empty(board)
            while max_depth <= limit:
                best_move.value = self.minmax_strategy(board, player, max_depth)
                print("best = %i, depth = %i" % (best_move.value, max_depth))
                max_depth += 1
        else:
            result = self.minmax_strategy(board, player, md)
            print(len(self.MOVES))
            return result

    standard_strategy = best_strategy

################################################
# The main game-playing code
# You can probably run this without modification
################################################

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer:
    def __init__(self):
        pass

    @staticmethod
    def play(test=False):
        # ### create 2 opponent objects and one referee to play the game
        # ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            s = time.time()
            move = strategy[player](board, player)
            e = time.time()
            print("Player %s chooses %i in t = %f" % (player, move, e - s))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)
            if test:
                break

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


##################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer:
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        ParallelPlayer.strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=ParallelPlayer.strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive():
                os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent:
                print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:
                print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent:
                print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"
        print(winner, black_score)

        return board, ref.score(board)


#################################################
# The main routine
#################################################

if __name__ == "__main__":
    main()
