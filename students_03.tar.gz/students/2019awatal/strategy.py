import time, random
from functools import lru_cache as cache

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
OPPONENT = { BLACK: WHITE, WHITE: BLACK }
FORMAT = { x: (11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 31, 32, 33, 34, 35, 36, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 51, 52, 53, 54, 55, 56, 57, 58, 61, 62, 63, 64, 65, 66, 67, 68, 71, 72, 73, 74, 75, 76, 77, 78, 81, 82, 83, 84, 85, 86, 87, 88)[i] for i, x in enumerate((9223372036854775808, 4611686018427387904, 2305843009213693952, 1152921504606846976, 576460752303423488, 288230376151711744, 144115188075855872, 72057594037927936, 36028797018963968, 18014398509481984, 9007199254740992, 4503599627370496, 2251799813685248, 1125899906842624, 562949953421312, 281474976710656, 140737488355328, 70368744177664, 35184372088832, 17592186044416, 8796093022208, 4398046511104, 2199023255552, 1099511627776, 549755813888, 274877906944, 137438953472, 68719476736, 34359738368, 17179869184, 8589934592, 4294967296, 2147483648, 1073741824, 536870912, 268435456, 134217728, 67108864, 33554432, 16777216, 8388608, 4194304, 2097152, 1048576, 524288, 262144, 131072, 65536, 32768, 16384, 8192, 4096, 2048, 1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1)) }
A = (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304, 8388608, 16777216, 33554432, 67108864, 134217728, 268435456, 536870912, 1073741824, 2147483648, 4294967296, 8589934592, 17179869184, 34359738368, 68719476736, 137438953472, 274877906944, 549755813888, 1099511627776, 2199023255552, 4398046511104, 8796093022208, 17592186044416, 35184372088832, 70368744177664, 140737488355328, 281474976710656, 562949953421312, 1125899906842624, 2251799813685248, 4503599627370496, 9007199254740992, 18014398509481984, 36028797018963968, 72057594037927936, 144115188075855872, 288230376151711744, 576460752303423488, 1152921504606846976, 2305843009213693952, 4611686018427387904, 9223372036854775808)
def pb(b):
	s = format(b, '064b')
	print('\n'.join([s[i:i+8] for i in range(0, len(s), 8)]))
	print()

class Strategy():

	def __init__(self):
		self.weights = [
			0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			0, 16.16, -3.03,  4,   1,   1,  4, -3.03, 16.16,   0,
			0, -4.12, -51.81,  -5,  -5,  -5,  -5, -51.81, -4.12,   0,
			0,  1.33,  1,  2,   0.07,  0.07,  2,  1,  1.33,   0,
			0,   0.63,  -0.18,   1,   3,   3,   1,  -0.18,   0.63,   0,
			0,   0.63,  -0.18,   1,   3,   3,   1,  -0.18,   0.63,   0,
			0,  1.33,  1,  2,   0.07,   0.07,  2,  1,  1.33,   0,
			0, -4.12, -51.81,  -5,  -5,  -5,  -5, -51.81, -4.12,   0,
			0, 16.16, -3.03,  4,   1,   1,  4, -3.03, 16.16,   0,
			0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
		]

	def format_move(self, move):
		return FORMAT[move]

	def convert(self, board, player):
		return (int('0b' + ''.join(('1' if thing == player else '0' for thing in board if thing == BLACK or thing == WHITE or thing == EMPTY)), 2), int('0b' + ''.join(('1' if thing == OPPONENT[player] else '0' for thing in board if thing == BLACK or thing == WHITE or thing == EMPTY)), 2))

	def get_starting_board(self):
		return list('???????????........??........??........??...o@...??...@o...??........??........??........???????????')

	def get_middle_board(self):
		return list('???????????........??..oo....??..ooo.@.??.o@o@o.o??o.@@@@o@??.o@@@oo@??...oo@@@??....o.@@???????????')

	def get_end_board(self):
		return list('???????????@@@@@@@@??oooooo@@??oo@@o@@@??oo@@@@@@??oo@@@@@@??.o@oo@@@??.oo@@o@@??.oo@@@@@???????????')

	@cache(maxsize=None)
	def count(self, n):
		n = (n & 0x5555555555555555) + ((n & 0xAAAAAAAAAAAAAAAA) >> 1)
		n = (n & 0x3333333333333333) + ((n & 0xCCCCCCCCCCCCCCCC) >> 2)
		n = (n & 0x0F0F0F0F0F0F0F0F) + ((n & 0xF0F0F0F0F0F0F0F0) >> 4)
		n = (n & 0x00FF00FF00FF00FF) + ((n & 0xFF00FF00FF00FF00) >> 8)
		n = (n & 0x0000FFFF0000FFFF) + ((n & 0xFFFF0000FFFF0000) >> 16)
		n = (n & 0x00000000FFFFFFFF) + ((n & 0xFFFFFFFF00000000) >> 32)
		return n

	@cache(maxsize=None)
	def get_valid_moves(self, board):
		empty = ~(board[1]|board[0])
		w = board[1] & 0x00FEFEFEFEFEFEFE
		t = w & ((board[0] & 0x00FEFEFEFEFEFEFE) << 7)
		t |= w & (t << 7)
		t |= w & (t << 7)
		t |= w & (t << 7)
		t |= w & (t << 7)
		t |= w & (t << 7)
		moves = (empty) & (t << 7)
		w = board[1] & 0x00FFFFFFFFFFFFFF
		t = w & ((board[0] & 0x00FFFFFFFFFFFFFF) << 8)
		t |= w & (t << 8)
		t |= w & (t << 8)
		t |= w & (t << 8)
		t |= w & (t << 8)
		t |= w & (t << 8)
		moves |= (empty) & (t << 8)
		w = board[1] & 0x007F7F7F7F7F7F7F
		t = w & ((board[0] & 0x007F7F7F7F7F7F7F) << 9)
		t |= w & (t << 9)
		t |= w & (t << 9)
		t |= w & (t << 9)
		t |= w & (t << 9)
		t |= w & (t << 9)
		moves |= (empty) & (t << 9)
		w = board[1] & 0x7F7F7F7F7F7F7F7F
		t = w & ((board[0] & 0x7F7F7F7F7F7F7F7F) << 1)
		t |= w & (t << 1)
		t |= w & (t << 1)
		t |= w & (t << 1)
		t |= w & (t << 1)
		t |= w & (t << 1)
		moves |= (empty) & (t << 1)
		w = board[1] & 0xFEFEFEFEFEFEFEFE
		t = w & ((board[0] & 0xFEFEFEFEFEFEFEFE) >> 1)
		t |= w & (t >> 1)
		t |= w & (t >> 1)
		t |= w & (t >> 1)
		t |= w & (t >> 1)
		t |= w & (t >> 1)
		moves |= (empty) & (t >> 1)
		w = board[1] & 0xFEFEFEFEFEFEFE00
		t = w & ((board[0] & 0xFEFEFEFEFEFEFE00) >> 9)
		t |= w & (t >> 9)
		t |= w & (t >> 9)
		t |= w & (t >> 9)
		t |= w & (t >> 9)
		t |= w & (t >> 9)
		moves |= (empty) & (t >> 9)
		w = board[1] & 0x7F7F7F7F7F7F7F00
		t = w & ((board[0] & 0x7F7F7F7F7F7F7F00) >> 7)
		t |= w & (t >> 7)
		t |= w & (t >> 7)
		t |= w & (t >> 7)
		t |= w & (t >> 7)
		t |= w & (t >> 7)
		moves |= (empty) & (t >> 7)
		w = board[1] & 0xFFFFFFFFFFFFFF00
		t = w & ((board[0] & 0xFFFFFFFFFFFFFF00) >> 8)
		t |= w & (t >> 8)
		t |= w & (t >> 8)
		t |= w & (t >> 8)
		t |= w & (t >> 8)
		t |= w & (t >> 8)
		moves |= (empty) & (t >> 8)
		if moves == 0b0:
			return None
		return [ moves & x for x in A if moves & x != 0]

	@cache(maxsize=None)
	def make_move(self, board, move):
		w = board[1] & 0x00FEFEFEFEFEFEFE
		t1 = w & ((move & 0x00FEFEFEFEFEFEFE) << 7)
		t1 |= w & (t1 << 7)
		t1 |= w & (t1 << 7)
		t1 |= w & (t1 << 7)
		t1 |= w & (t1 << 7)
		t1 |= w & (t1 << 7)
		if not (board[0]) & (t1 << 7):
			t1 = 0
		w = board[1] & 0x00FFFFFFFFFFFFFF
		t2 = w & ((move & 0x00FFFFFFFFFFFFFF) << 8)
		t2 |= w & (t2 << 8)
		t2 |= w & (t2 << 8)
		t2 |= w & (t2 << 8)
		t2 |= w & (t2 << 8)
		t2 |= w & (t2 << 8)
		if not (board[0]) & (t2 << 8):
			t2 = 0
		w = board[1] & 0x007F7F7F7F7F7F7F
		t3 = w & ((move & 0x007F7F7F7F7F7F7F) << 9)
		t3 |= w & (t3 << 9)
		t3 |= w & (t3 << 9)
		t3 |= w & (t3 << 9)
		t3 |= w & (t3 << 9)
		t3 |= w & (t3 << 9)
		if not (board[0]) & (t3 << 9):
			t3 = 0
		w = board[1] & 0x7F7F7F7F7F7F7F7F
		t4 = w & ((move & 0x7F7F7F7F7F7F7F7F) << 1)
		t4 |= w & (t4 << 1)
		t4 |= w & (t4 << 1)
		t4 |= w & (t4 << 1)
		t4 |= w & (t4 << 1)
		t4 |= w & (t4 << 1)
		if not (board[0]) & (t4 << 1):
			t4 = 0
		w = board[1] & 0xFEFEFEFEFEFEFEFE
		t5 = w & ((move & 0xFEFEFEFEFEFEFEFE) >> 1)
		t5 |= w & (t5 >> 1)
		t5 |= w & (t5 >> 1)
		t5 |= w & (t5 >> 1)
		t5 |= w & (t5 >> 1)
		t5 |= w & (t5 >> 1)
		if not (board[0]) & (t5 >> 1):
			t5 = 0
		w = board[1] & 0xFEFEFEFEFEFEFE00
		t6 = w & ((move & 0xFEFEFEFEFEFEFE00) >> 9)
		t6 |= w & (t6 >> 9)
		t6 |= w & (t6 >> 9)
		t6 |= w & (t6 >> 9)
		t6 |= w & (t6 >> 9)
		t6 |= w & (t6 >> 9)
		if not (board[0]) & (t6 >> 9):
			t6 = 0
		w = board[1] & 0x7F7F7F7F7F7F7F00
		t7 = w & ((move & 0x7F7F7F7F7F7F7F00) >> 7)
		t7 |= w & (t7 >> 7)
		t7 |= w & (t7 >> 7)
		t7 |= w & (t7 >> 7)
		t7 |= w & (t7 >> 7)
		t7 |= w & (t7 >> 7)
		if not (board[0]) & (t7 >> 7):
			t7 = 0
		w = board[1] & 0xFFFFFFFFFFFFFF00
		t8 = w & ((move & 0xFFFFFFFFFFFFFF00) >> 8)
		t8 |= w & (t8 >> 8)
		t8 |= w & (t8 >> 8)
		t8 |= w & (t8 >> 8)
		t8 |= w & (t8 >> 8)
		t8 |= w & (t8 >> 8)
		if not (board[0]) & (t8 >> 8):
			t8 = 0
		t = t1 | t2 | t3 | t4 | t5 | t6 | t7 | t8
		own = (board[0] | move) ^ (board[1] & t)
		return (board[1] ^ (board[1] & own), own)

	@cache(maxsize=None)
	def game_over(self, board):
		return board[0] | board[1] == 0xFFFFFFFFFFFFFFFF or not ( self.get_valid_moves(board) or self.get_valid_moves((board[1], board[0])) )

	def score(self, board, go, num):
		if go:
			return 100000000 * (self.count(board[0]) - self.count(board[1]))
		edge_stablity = 0
		internal_stability = 0
		current_mobility = 0
		potential_mobility = 0
		my_moves = self.get_valid_moves(board)
		opp_moves = self.get_valid_moves((board[1], board[0]))
		if my_moves and opp_moves:
			my_moves, opp_moves = len(my_moves), len(opp_moves)
			current_mobility = ((1000*(my_moves-opp_moves)) / (my_moves+opp_moves+2))//1
		esac = 312 + (6.24 * num)
		if num <= 25:
			cmac = 50 + (2*num)
		else:
			cmac = 75 + num
		return (esac * edge_stablity) + (36 * internal_stability) + (cmac*current_mobility) + (99*potential_mobility)

	def pvs(self, board, depth, alpha, beta, color, num):
		go = self.game_over(board)
		if depth == 0 or go:
			return color * self.score(board, go, num)
		first = False
		moves = self.get_valid_moves(board)
		if moves:
			for move in moves:
				child = self.make_move(board, move)
				if first:
					v = -self.pvs(child, depth-1, -beta, -alpha, -color, num + 1)
				else:
					v = -self.pvs(child, depth-1, -alpha-1, -alpha, -color, num + 1)
					if alpha < v < beta:
						v = -self.pvs(child, depth-1, -beta, -v, -color, num + 1)
				if v > alpha:
					alpha = v
				if alpha >= beta:
					break
		return alpha

	def pvs_strategy(self, board, depth):
		max_score, best_move = -100000000, -99
		for move in self.get_valid_moves(board):
			child = self.make_move(board, move)
			score = self.pvs(child, depth, -100000000, 100000000, 1, self.count(~(board[0]|board[1]))-59)
			if score > max_score:
				max_score = score
				best_move = move
		return self.format_move(best_move)

	def best_strategy(self, board, player, best_move, still_running):
		board = self.convert(board, player)
		moves = self.get_valid_moves(board)
		if moves and len(moves) == 1:
			best_move.value = moves[0]
		depth = 1
		while True:
			best_move.value = self.pvs_strategy(board, depth)
			depth += 1

	def testing_suite(self):
		print('---Setting Up Board---')
		s = time.time()
		board = self.convert(self.get_middle_board(), BLACK)
		print('Time: ' + str(time.time() - s))
		print('---Timing Get Valid Moves x10000---')
		s = time.time()
		for x in range(10000):
			moves = self.get_valid_moves(board)
		print('Time: ' + str(time.time() - s))
		print('---Timing Make Moves x10000---')
		s = time.time()
		for x in range(10000):
			self.make_move(board, moves[0])
		print('Time: ' + str(time.time() - s))
		print('---Searching With MinMax (Mid-game) Depth 6---')
		s = time.time()
		depth = 1
		while depth != 6:
			best_move = self.pvs_strategy(board, depth)
			depth += 1
		print('Time: ' + str(time.time() - s))
		print('Best Move: ' + str(best_move))

if __name__ == "__main__":
	strat = Strategy()
	strat.testing_suite()