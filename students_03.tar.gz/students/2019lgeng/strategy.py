import random
import math
import sys
from collections import defaultdict

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}
best = {BLACK: max, WHITE: min}
ROWS = [[x + i for i in range(8)] for x in range(11, 82, 10)]
COLS = [[y + i for i in range(0, 71, 10)] for y in range(11, 19)]
UD_DIAG = []
for y in range(81, 89):
    UD_DIAG.append([y - 11*x for x in range(0, y % 80)])
for x in range(18, 79, 10):
    UD_DIAG.append([x - 11*y for y in range(0, x//10)])
DU_DIAG = []
for x in range(11, 82, 10):
    DU_DIAG.append([x - 9*y for y in range(0, x//10)])
for y in range(82, 89):
    DU_DIAG.append([y - 9*x for x in range(0, 89 - y)])
UNITS = ROWS+COLS+UD_DIAG+DU_DIAG

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        middle = [EMPTY]*8 + [OUTER]*2
        board = [OUTER]*11 + middle*8 + [OUTER]*9
        board[45] = board[54] = BLACK
        board[44] = board[55] = WHITE
        return ''.join(board)

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        p = ""
        for i in range(1, 9):
            p = "%s%s\n" % (p, board[i*10+1:i*10+9])
        return p

    def opponent(self, player):
        """Get player's opponent."""
        return WHITE if player == BLACK else BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        num = 0
        square += direction
        while board[square] == self.opponent(player):
            square += direction
            num += 1
        if board[square] == player:  # no longer need to check num > 0
            return square, num
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] != EMPTY:
            return False
        for direction in DIRECTIONS:
            if board[move + direction] != self.opponent(player):  # not sure if useful
                continue
            match = self.find_match(board, player, move, direction)
            if match is not None:
                return match[1]
        return False

    def make_move(self, board, player, move):  # make into list and then back into string
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board_list = list(board)
        board_list[move] = player
        for direction in DIRECTIONS:
            target = self.find_match(board, player, move, direction)
            if target is not None:
                for i in range(1, target[1]+1):
                    board_list[move+direction*i] = player
                # a = move+direction
                # while a is not target[0]:
                #     board_list[a] = player
                #     a += direction
        return ''.join(board_list)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valid = []
        for i in range(11, 89):
            if self.is_move_valid(board, player, i):
                valid.append(i)
        return valid

    def get_ordered_moves(self, board, player):
        '''
        weight = [
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 6, 2, 3, 5, 5, 3, 2, 6, 0,
         0, 2, 1, 4, 4, 4, 4, 1, 2, 0,
         0, 3, 4, 5, 3, 3, 5, 4, 3, 0,
         0, 5, 4, 3, 5, 5, 3, 4, 5, 0,
         0, 5, 4, 3, 5, 5, 3, 4, 5, 0,
         0, 3, 4, 5, 3, 3, 5, 4, 3, 0,
         0, 2, 1, 4, 4, 4, 4, 1, 2, 0,
         0, 6, 2, 3, 5, 5, 3, 2, 6, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        '''
        weight = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
            0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
            0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
            0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        return sorted(self.get_valid_moves(board, player), key=lambda x: weight[x], reverse=True)
    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player)) > 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        player = self.opponent(prev_player)
        if self.has_any_valid_moves(board, player):
            return player
        elif self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        score = 0
        for i in range(11, 89):
            if board[i] == player:
                score += 1
            elif board[i] == self.opponent(player):
                score += -1
        return score

    def weighted_score(self, board, player=BLACK):
        weight = [
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
         0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
         0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
         0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
         0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
         0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
         0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
         0, 120, -20, 20, 5, 5, 20, -20, 120, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        score = 0
        for i in range(11, 89):
            if board[i] == player:
                score += 1*weight[i]
            elif board[i] == self.opponent(player):
                score += -1*weight[i]
        return score

    def weighted_score2(self, board, player=BLACK):
        weight = [
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
         0, 60, -10, 10, 5, 5, 10, -10, 60, 0,
         0, -10, -20, -2, -2, -2, -2, -20, -10, 0,
         0, 10, -2, 10, 3, 3, 10, -2, 10, 0,
         0, 5, -2, 3, 2, 2, 3, -2, 5, 0,
         0, 5, -2, 3, 2, 2, 3, -2, 5, 0,
         0, 10, -2, 10, 3, 3, 10, -2, 10, 0,
         0, -10, -20, -2, -2, -2, -2, -20, -10, 0,
         0, 60, -10, 10, 5, 5, 10, -10, 60, 0,
         0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ]
        score = 0
        for i in range(11, 89):
            if board[i] == player:
                score += 1*weight[i]
            elif board[i] == self.opponent(player):
                score += -1*weight[i]
        return score

    def num_adj_empty(self, board, index):
        num = 0
        for direction in DIRECTIONS:
            if board[index + direction] == EMPTY:
                num += 1
        return num

    def potential_mobility(self, board):
        max_num = 0
        min_num = 0
        for i in range(11, 89):
            if board[i] == BLACK:
                min_num += self.num_adj_empty(board, i)
            elif board[i] == WHITE:
                max_num += self.num_adj_empty(board, i)
        return max_num, min_num

    def total_mobility(self, board):
        potential = self.potential_mobility(board)
        max_num = len(self.get_valid_moves(board, BLACK)) + potential[0]
        min_num = len(self.get_valid_moves(board, WHITE)) + potential[1]
        return max_num - min_num

    def corner_or_adj_filled(self, board):
        corner_and_adj = [11, 12, 21, 17, 18, 28, 71, 81, 82, 78, 88, 87]
        for c in corner_and_adj:
            if board[c] != EMPTY:
                return True
        return False

    def line_filled(self, board, line):
        for i in line:
            if board[i] == EMPTY:
                return False
        return True

    def stability(self, board):  # initial implementation
        # if not self.corner_or_adj_filled(board):
        #     return 0
        fills = {x: 0 for x in range(11, 89)}
        max_stable = 0
        min_stable = 0
        # print(self.get_pretty_board(board))
        for line in UNITS:
            if self.line_filled(board, line):
                for i in line:
                    fills[i] += 1
        for k in fills.items():
            if board[k[0]] == EMPTY:
                continue
            elif board[k[0]] == BLACK:
                max_stable += k[1]
            elif board[k[0]] == WHITE:
                min_stable += k[1]
        return max_stable - min_stable

    def get_mix(self, board, player):
        move_num = 0
        capture = 0
        for i in range(11, 89):
            nums = self.is_move_valid(board, player, i)
            if nums:
                move_num += 1
                capture += nums
        return move_num, capture

    def mixed_eval(self, board):
        potential = self.potential_mobility(board)
        max_nums = self.get_mix(board, BLACK)
        min_nums = self.get_mix(board, WHITE)
        return potential[0]//2 + max_nums[0] + max_nums[1] - potential[1]//2 - min_nums[0] - min_nums[1]

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return self.next_player(board, player) is None

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, depth):
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        children = []
        for move in self.get_valid_moves(board, node.player):
            next_board = self.make_move(board, node.player, move)
            next_player = self.next_player(next_board, node.player)
            if next_player is None:  # game is over
                possible_score = self.score(next_board)
                # print("Possible end score for %s: %s, final move on %i" % (node.player, possible_score, move))
                c = Node(next_board, next_player, move, 10000*possible_score)
            else:
                c = Node(next_board, next_player, move)
                c.score = self.minmax_search(c, depth-1).score
                # c.score = self.alphabeta_search(c, depth-1, 1000000, -1000000).score
            children.append(c)
        winner = best[node.player](children)  # handled by __lt__
        node.score = winner.score
        return winner

    def alphabeta_search(self, node, depth, a, b):
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board)
            return node
        v = Node(None, None, None, best[self.opponent(node.player)](sys.maxsize, -sys.maxsize))  # initialize other way
        for move in self.get_valid_moves(board, node.player):
            next_board = self.make_move(board, node.player, move)
            next_player = self.next_player(next_board, node.player)
            if next_player is None:
                c = Node(next_board, next_player, move, 10000*self.score(next_board))
            else:
                c = Node(next_board, next_player, move)
                c.score = self.alphabeta_search(c, depth-1, a, b).score
            if node.player is BLACK:
                a = max(a, c.score)
                if c.score > v.score:
                    v = c
            elif node.player is WHITE:
                b = min(b, c.score)
                if c.score < v.score:
                    v = c
            if b <= a:
                break
        node.score = v.score
        return v

    def alphabeta_search_mobility(self, node, depth, a, b):
        board = node.board
        if depth == 0:
            node.stability = self.stability(board)
            node.score = self.weighted_score(board) + 2*node.stability
            return node
        v = Node(None, None, None, best[self.opponent(node.player)](sys.maxsize, -sys.maxsize))
        for move in self.get_ordered_moves(board, node.player):
            next_board = self.make_move(board, node.player, move)
            next_player = self.next_player(next_board, node.player)
            if next_player is None:
                c = Node(next_board, next_player, move, 10000*self.score(next_board))
            else:
                c = Node(next_board, next_player, move)
                c.score = self.alphabeta_search_stability(c, depth-1, a, b).score
                c.mobility = self.total_mobility(next_board)
            if node.player is BLACK:
                a = max(a, c.score)
                if (c.score + c.mobility//2) > (v.score + v.mobility//2):
                    # print("score: %s mobility: %s" % (abs(c.score), abs(c.mobility)))  # 2-15-40-15 as game progresses
                    v = c
            else:
                b = min(b, c.score)
                if (c.score + c.mobility//2) < (v.score + v.mobility//2):
                    v = c
            if b <= a:
                break
        node.score = v.score
        return v

    def alphabeta_search_stability(self, node, depth, a, b):
        board = node.board
        if depth == 0:
            node.stability = self.stability(board)
            # s = self.weighted_score(board)
            node.score = self.weighted_score(board) + 2*node.stability
            # print("score: %s stability: %s" % (abs(s), abs(node.stability)))  # 0-30 as game progresses, usually 12-15
            return node
        v = Node(None, None, None, best[self.opponent(node.player)](sys.maxsize, -sys.maxsize))
        for move in self.get_ordered_moves(board, node.player):
            next_board = self.make_move(board, node.player, move)
            next_player = self.next_player(next_board, node.player)
            if next_player is None:
                c = Node(next_board, next_player, move, 10000*self.score(next_board))
            else:
                c = Node(next_board, next_player, move)
                c.score = self.alphabeta_search_stability(c, depth-1, a, b).score
            if node.player is BLACK:
                a = max(a, c.score)
                if c.score > v.score:
                    v = c
            else:
                b = min(b, c.score)
                if c.score < v.score:
                    v = c
            if b <= a:
                break
        node.score = v.score
        return v

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node = self.minmax_search(Node(board, player, None), depth)
        return node.move

    def alphabeta_strategy(self, board, player, depth=6):
        node = self.alphabeta_search_mobility(Node(board, player, None), depth, -sys.maxsize, sys.maxsize)
        return node.move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        board = ''.join(board)
        while True:
            best_move.value = self.alphabeta_search_mobility(Node(board, player, None), depth, -sys.maxsize, sys.maxsize).move
            print("Best Strategy Depth: %s" % depth)
            if depth > 64:
                return best_move.value
            depth += 1

    def second_best_strategy(self, board, player, best_move, still_running):
        depth = 1
        while True:
            # best_move.value = self.random_strategy(board, player)
            # best_move.value = self.minmax_search(Node(board, player, None), depth).move
            best_move.value = self.alphabeta_search(Node(board, player, None), depth, -sys.maxsize, sys.maxsize).move
            print("2nd Best Strategy Depth: %s" % depth)
            if depth > 64:
                return best_move.value
            depth += 1

    standard_strategy = alphabeta_strategy


class Node:

    def __init__(self, board, player, move, score=None, mobility=0, stability=0):
        self.board = board
        self.player = player
        self.score = score
        self.move = move
        self.mobility = mobility
        self.stability = 0

    def __lt__(self, other):
        return self.score < other.score


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.alphabeta_strategy, WHITE: white.minmax_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.second_best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


if __name__ == "__main__":
    game = ParallelPlayer(5)
    # game = StandardPlayer()
    game.play()
