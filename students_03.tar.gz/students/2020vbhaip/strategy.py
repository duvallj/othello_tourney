#Vinay Bhaip
#Dr. Zacharias
#Period 1

import Othello_Core as core
import math
import copy as copymod

MAX_VAL = math.inf
MIN_VAL = -math.inf

SQUARE_WEIGHTS = [
            0,      0,      0,       0,    0,    0,    0,    0,     0,      0,

            0,      130,    -20,    20,    5,    5,    20,   -20,   130,    0,

            0,      -20,    -40,    -5,    -5,   -5,   -5,   -40,   -20,    0,

            0,      20,     -5,      15,    3,    3,   15,   -5,    20,     0,

            0,      5,      -5,      3,    3,    3,    3,    -5,    5,      0,

            0,      5,      -5,      3,    3,    3,    3,    -5,    5,      0,

            0,      20,     -5,     15,    3,    3,    15,   -5,    20,     0,

            0,      -20,    -40,    -5,    -5,   -5,   -5,   -40,   -20,    0,

            0,      130,    -20,    20,    5,    5,    20,   -20,   130,    0,

            0,      0,      0,       0,    0,    0,    0,    0,     0,      0
            ]


class Strategy(core.OthelloCore):

    def inBounds(self, move):
        return move in self.squares()

    def getOpp(self, player):
        return core.BLACK if player is core.WHITE else core.WHITE


    def getAllIndices(self, board, player):
        return [x for x, char in enumerate(board) if char == player]


    def getPos(self, board, player, move, change):
        move += change

        if not self.inBounds(move) or board[move] == player or board[move] == core.EMPTY:
            return None

        move += change

        while(self.inBounds(move) and board[move] != player):
            if board[move] == core.EMPTY:
                return move
            move += change
        return None

    def getAllPos(self, board, player, move):
        moves = set()


        for change in core.DIRECTIONS:
            pos = self.getPos(board, player, move, change)

            if pos is not None:
                moves.add(pos)

        return moves



    def getPossibleMoves(self, board, player):
        totalmoves = set()
        for position in self.getAllIndices(board, player):
            totalmoves = totalmoves.union(self.getAllPos(board, player, position))
        return totalmoves

    def countPlayer(self, board, player):
        return board.count(player)


    def find_bracket(self, square, player, board, direction):

        square += direction

        opp = self.getOpp(player)
        while board[square] == opp:
            square += direction

        if(board[square] != player):
            return False

        return square;
    def is_legal(self, move, player, board):
        return move in self.getPossibleMoves(board, player)

    # def readBoards(self, filename):
    #
    #     emptyboard = ['?' for x in range(100)]
    #     with open(filename) as f:
    #         for line in f:
    #             if line != '':
    #
    #                 board = emptyboard
    #                 for x in range(11,89):
    #                     print(8*((x/10)-1) + (x-1)%10)
    #                     board[x] = line[8*((x/10)-1) + (x-1)%10]
    #                 player = line[65]
    #                 print(self.display(board))
    #                 print(list(self.getPossibleMoves(board, player)))
    #                 print("\n\n")

    def pieces_on_board(self, board):
        return 64 - board.count('.')

    def count_heur(self, board, player):
        return self.countPlayer(board, player) - self.countPlayer(board, self.getOpp(player))

    def weights_multiply_heur(self, board, player):
        # heur = 0
        # for x in range(11,89):
        #     if board[x] == player:
        #         heur += board[x]*
        # print(self.print_board(board))
        count = 0
        # if board[11] == player:
        #     count = 10000
        # if board[11] == self.getOpp(player):
        #     count = -10000
        opp = self.getOpp(player)
        for x in range(11, 89):
            if board[x] == player:
                count += SQUARE_WEIGHTS[x]
            elif board[x] == opp:
                count -= SQUARE_WEIGHTS[x]

        return count
        #return sum([(1 if a == player else (-1 if a == self.getOpp(player) else 0))*b for a,b in zip(board, SQUARE_WEIGHTS)])


    def update_weights(self, board, player):

        if(SQUARE_WEIGHTS[21]!=45 and board[11] == player):
            SQUARE_WEIGHTS[12]=SQUARE_WEIGHTS[21]=45
            SQUARE_WEIGHTS[18]=SQUARE_WEIGHTS[81]=160

        if(SQUARE_WEIGHTS[28]!=45 and board[18] == player):
            SQUARE_WEIGHTS[17]=SQUARE_WEIGHTS[28]=45
            SQUARE_WEIGHTS[88]=SQUARE_WEIGHTS[11]=160

        if(SQUARE_WEIGHTS[71]!=45 and board[81] == player):
            SQUARE_WEIGHTS[82]=SQUARE_WEIGHTS[71]=45
            SQUARE_WEIGHTS[11]=SQUARE_WEIGHTS[88]=160

        if(SQUARE_WEIGHTS[78]!=45 and board[88] == player):
            SQUARE_WEIGHTS[87]=SQUARE_WEIGHTS[78]=45
            SQUARE_WEIGHTS[18]=SQUARE_WEIGHTS[81]=160

    def stable_pieces(self, board, player):

        stable = 0

        start_look = 11
        end_look = 18


        while(self.inBounds(end_look) and self.inBounds(start_look) and end_look > start_look and board[start_look] == player):
            for x in range(start_look, end_look+1):
                if(board[x] == player):
                    stable += 1
                else:
                    start_look += 10
                    end_look = (start_look + x%10 - 1)
                    break

        start_look = 81
        end_look = 88
        while(self.inBounds(end_look) and self.inBounds(start_look) and end_look > start_look and board[start_look] == player):
            for x in range(start_look, end_look+1,-1):
                if(board[x] == player):
                    stable += 1
                else:
                    start_look -= 10
                    end_look = (start_look + x%10 - 1)
                    break
        print(stable)
        return stable


    def make_move(self, move, player, board):
        # if not self.is_legal(move, player, board):
        #     return "rip"
        board[move] = player
        for d in core.DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board

    def make_flips(self, move, player, board, direction):
        """Flip pieces in the given direction as a result of the move by player."""
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction


    def heuristic(self, board, player):
        #self.update_weights(board, player)
        # print(self.weights_multiply_heur(board, player))
        # print(self.print_board(board))
        # print("\n\n\n")
        return self.weights_multiply_heur(board, player) #+ (int(math.log(self.pieces_on_board(board),16)))*self.count_heur(board, player)


    #maximizingPlayer is me
    def alphabeta(self, board, player, depth, alpha, beta, maximizingPlayer):
        #print(board)

        if self.pieces_on_board(board) == 64:
            temp = self.countPlayer(board, player);
            temp_2 = self.countPlayer(board, self.getOpp(player))
            if temp > temp_2:
                return (9999,None)
            else:
                return (-9999, None)


        if depth == 0:
            return (self.heuristic(board, player), None) #return heuristics

        # if depth == 0:
        #     # print("MIN HEUR")
        #     # print(self.heuristic(board, player))
        #     return (self.heuristic(board, maximizingPlayer), None)

        moves = self.getPossibleMoves(board, player)
        # if len(moves) == 0:
        #     return (500, None) if player != maximizingPlayer else (-500, None)
        #     #return self.alphabeta(board, self.getOpp(player), depth-1, alpha, beta, maximizingPlayer)[0], None #return heuristics
        #
        # if len(moves) == 1:
        #     return (400, None) if player != maximizingPlayer else (-400, None)

        if len(moves) == 0:
            return self.alphabeta(board, player, depth-1, alpha, beta, -1*maximizingPlayer)

        if maximizingPlayer:

            val = MIN_VAL
            bestmove = None

            for move in moves:

                # print(self.print_board(self.make_move(move, player, myboard)))
                # print(move)

                moverecur = self.alphabeta(self.make_move(move, player, copymod.deepcopy(board)), player, depth-1, -beta, -alpha, False)[0]

                if moverecur >= val:
                    bestmove = move
                    val = moverecur

                alpha = max(val, alpha)
                #
                if beta <= alpha:
                    break
            # print("BEST MOVE: " + str(bestmove))
            # print("MOVE VAL: " + str(val))
            # print("DEPTH: " + str(depth-1))
            # print("\n\n")
            # print(self.print_board(board))
            # print(val)
            # print(bestmove)
            # print(depth)
            # print("\n\n")

            return (val, bestmove)

        else:

            val = MAX_VAL
            bestmove = None

            for move in moves:

                moverecur = self.alphabeta(self.make_move(move, self.getOpp(player), copymod.deepcopy(board)), player, depth-1, -beta, -alpha, True)[0]


                if moverecur <= val:
                    bestmove = move
                    val = moverecur

                beta = min(val, beta)

                if beta <= alpha:
                    break
            # print("BEST MOVE: " + str(bestmove))
            # print("MOVE VAL: " + str(val))
            # print("DEPTH: " + str(depth-1))
            # print("\n\n")
            # print(self.print_board(board))
            # print(val)
            # print(bestmove)
            # print(depth)
            # print("\n\n")
            return (val, bestmove)




    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        best_move.value = self.getPossibleMoves(board, player).pop()

        while(True):
            best_move.value = self.alphabeta(board, player, depth, MIN_VAL, MAX_VAL, True)[1]
            depth += 1

            # return best_move.value
            print(depth-1)
            print('BEST MOVE:')
            print(best_move.value)
            print()
            print()
            print("\n\n\n\n")
            # return best_move.value
