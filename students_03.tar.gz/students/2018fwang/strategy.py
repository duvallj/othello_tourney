#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 19 16:26:34 2018

@author: franklyn
"""

"""
Base class for Othello Core
Must be subclassed by student Othello solutions
"""

#TODO: REMOVE CLASS ACCSESES
#

from multiprocessing import Value
import random
from random import choice

#

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PIECES = (EMPTY, BLACK, WHITE, OUTER)
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

# To refer to neighbor squares we can add a direction to a square.
UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)


Value_of_square = [[20, -3, 11, 8, 8, 11, -3, 20], [-3, -7, -4, 1, 1, -4, -7, -3], [11, 
     -4, 2, 2, 2, 2, -4, 11], [8, 1, 2, -3, -3, 2, 1, 8], [8, 1, 2, -3, -3, 2, 1, 8]
, [11, -4, 2, 2, 2, 2, -4, 11], [-3, -7, -4, 1, 1, -4, -7, -3], [20, -3, 11, 8, 8, 11, -3, 20] ]

class Strategy:
    def squares(self):
        """List all the valid squares on the board."""
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]


    def initial_board(self):
        """Create a new board with the initial black and white positions filled."""
        board = [OUTER] * 100
        for i in self.squares():
            board[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        board[44], board[45] = WHITE, BLACK
        board[54], board[55] = BLACK, WHITE
        return board


    def print_board(self,board):
        """Get a string representation of the board."""
        rep = ''
        rep += '  %s\n' % ' '.join(map(str, list(range(1, 9))))
        for row in range(1, 9):
            begin, end = 10 * row + 1, 10 * row + 9
            rep += '%d %s\n' % (row, ' '.join(board[begin:end]))
        return rep


    def is_valid(self, move):
        """Is move a square on the board?"""
        pass

    def opponent(self, player):
        """Get player's opponent piece."""
        pass

    def find_bracket(self, square, player, board, direction):
        """
        Find a square that forms a bracket with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        Returns the index of the bracketing square if found
        """
        pass

    def is_legal(self, move, player, board):
        """Is this a legal move for the player?"""
        pass

    ### Making moves

    # When the player makes a move, we need to update the board and flip all the
    # bracketed pieces.

    def make_move(self, move, player, board):
        """Update the board to reflect the move by the specified player."""
        if not self.is_legal(move, player, board):
            raise self.IllegalMoveError(player, move, board)
        board[move] = player
        for d in DIRECTIONS:
            self.make_flips(move, player, board, d)
        return board

    def make_flips(self, move, player, board, direction):
        """Flip pieces in the given direction as a result of the move by player."""
        bracket = self.find_bracket(move, player, board, direction)
        if not bracket:
            return
        square = move + direction
        while square != bracket:
            board[square] = player
            square += direction

    def legal_moves(self, player, board):
        """Get a list of all legal moves for player, as a list of integers"""
        pass

    def any_legal_move(self, player, board):
        """Can player make any moves? Returns a boolean"""
        pass

    def next_player(self,board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        pass

    def score(self, player, board):
        """Compute player's score (number of player's pieces minus opponent's)."""
        pass
    
    def tryMove(self, board, loc, player):
      k = board[:]
      notplayer = '.'
      if player == BLACK:
        notplayer = WHITE;
      if player == WHITE:
        notplayer = BLACK;
      i = loc[0]
      j = loc[1]
      valid = False
      if k[10*i + j] != '.':
        return None
      x = i-1
      while k[10*x + j] == notplayer:
        x -= 1
        if k[10*x + j] == player:
          valid = True
          for u in range(x + 1, i + 1):
            k[10*u + j] = player
          break
      x = i + 1
      while k[10*x + j] == notplayer:
        x += 1
        if k[10*x + j] == player:
          valid = True
          for u in range(i, x):
            k[10*u + j] = player
          break
      y = j - 1
      while k[10*i + y] == notplayer:
        y -= 1
        if k[10*i + y] == player:
          valid = True
          for u in range(y + 1, j + 1):
            k[10*i + u] = player
          break
      y = j + 1
      while k[10*i + y] == notplayer:
        y += 1 
        if k[10*i + y] == player:
          valid = True
          for u in range(j, y):
            k[10*i + u] = player
          break
      x = i + 1
      y = j + 1
      while k[10*x + y] == notplayer:
        x += 1
        y += 1
        if k[10*x + y] == player:
          valid = True
          for u in range(i, x):
            k[10*u + (j - i + u)] = player
          break
      x = i - 1
      y = j - 1
      while k[10*x + y] == notplayer:
        x -= 1
        y -= 1
        if k[10*x + y] == player:
          valid = True
          for u in range(x + 1, i + 1):
            k[10*u + (j - i + u)] = player
          break
      x = i - 1
      y = j + 1
      while k[10*x + y] == notplayer:
        x -= 1
        y += 1
        if (k[10*x + y] == player):
          valid = True
          for u in range(x + 1, i + 1):
            k[10*u + (i + j - u)] = player
          break
      x = i + 1
      y = j - 1
      while k[10*x + y] == notplayer:
        x += 1
        y -= 1
        if k[10*x + y] == player:
          valid = True
          for u in range(i, x):
            k[10*u + (i + j - u)] = player
          break
      if valid:
        return k
      else:
        return None

    def findMoves(self, board, player): 
      moves = []
      notplayer = '.'
      if player == BLACK:
        notplayer = WHITE;
      if player == WHITE:
        notplayer = BLACK;

      for i in range(1, 9):
        for j in range(1, 9):
          if (board[10*i + j] != '.'):
            continue
          x = i-1
          while board[10*x + j] == notplayer:
            x -= 1
          if x != i - 1 and board[10*x + j] == player:
            moves.append(10*i + j)
            continue
          x = i + 1
          while board[10*x + j] == notplayer:
            x += 1
          if x != i + 1 and board[10*x + j] == player:
            moves.append(10*i + j)
            continue
          y = j - 1
          while board[10*i + y] == notplayer:
            y -= 1
          if y != j - 1 and board[10*i + y] == player:
            moves.append(10*i + j)
            continue
          y = j + 1
          while board[10*i + y] == notplayer:
            y += 1 
          if y != j + 1 and board[10*i + y] == player:
            moves.append(10*i + j)
            continue
          x = i + 1
          y = j + 1
          while board[10*x + y] == notplayer:
            x += 1
            y += 1
          if x != i + 1 and board[10*x + y] == player:
            moves.append(10*i + j)
            continue
          x = i - 1
          y = j - 1
          while board[10*x + y] == notplayer:
            x -= 1
            y -= 1
          if x != i - 1 and board[10*x + y] == player:
            moves.append(10*i + j)
            continue
          x = i - 1
          y = j + 1
          while board[10*x + y] == notplayer:
            x -= 1
            y += 1
          if x != i - 1 and board[10*x + y] == player:
            moves.append(10*i + j)
            continue
          x = i + 1
          y = j - 1
          while board[10*x + y] == notplayer:
            x += 1
            y -= 1
          if x != i + 1 and board[10*x + y] == player:
            moves.append(10*i + j)
            continue
      return moves
      
    def findKids(self, board, player):
      '''takes in board, an array with the current position, and player
      returns a list of the positions. '''
      l = []
      mvs = self.findMoves(board, player)
      for i in mvs: 
        l.append(self.tryMove(board, ((i//10), (i%10)), player))
      return l

    def countMoves(self, board, player):
      res = 0;
      notplayer = '.'
      if player == BLACK:
        notplayer = WHITE;
      if player == WHITE:
        notplayer = BLACK;

      for i in range(1, 9):
        for j in range(1, 9):
          valid = False
          if (board[10*i + j] != '.'):
            continue
          x = i-1
          while (board[10*x + j] == notplayer):
            x -= 1
            if board[10*x + j] == player:
              res += 1
              break
          x = i + 1
          while (board[10*x + j] == notplayer):
            x += 1
            if board[10*x + j] == player:
              res += 1
              break
          y = j - 1
          while (board[10*i + y] == notplayer):
            y -= 1
            if board[10*i + y] == player:
              res += 1
              break
          y = j + 1
          while (board[10*i + y] == notplayer):
            y += 1 
            if board[10*i + y] == player:
              res += 1
              break
          x = i + 1
          y = j + 1
          while board[10*x + y] == notplayer:
            x += 1
            y += 1
            if board[10*x + y] == player:
              res += 1
              break
          x = i - 1
          y = j - 1
          while board[10*x + y] == notplayer:
            x -= 1
            y -= 1
            if board[10*x + y] == player:
              res += 1
              break
          x = i - 1
          y = j + 1
          while board[10*x + y] == notplayer:
            x -= 1
            y += 1
            if (board[10*x + y] == player):
              res += 1
              break
          x = i + 1
          y = j - 1
          while board[10*x + y] == notplayer:
            x += 1
            y -= 1
            if board[10*x + y] == player:
              res += 1
              break 
      return res

    def done(self, board):
      if self.countMoves(board, BLACK) == 0:
        if self.countMoves(board, WHITE) == 0:
          return True
      return False

    def heuristic2(self, board, player):
      notplayer = '.'
      if player == BLACK:
        notplayer = WHITE
      else:
        notplayer = BLACK
      cnt1 = 0
      cnt2 = 0
      for i in range(1, 9):
        for j in range(1, 9):
          if (board[10*i + j] == player):
            cnt1 += 1
          if (board[10*i + j] == notplayer):
            cnt2 += 1
      if cnt1 > cnt2:
        return 100000*(64 - 2*cnt2)
      else:
        return 100000*(2*cnt1 - 64)

    def heuristic1(self, board, player):
      notplayer = '.'
      if player == BLACK:
        notplayer = WHITE
      else:
        notplayer = BLACK
      square_weight = 0
      my_tiles = 0
      not_my_tiles = 0
      my_frontier_tiles = 0
      not_my_frontier_tiles = 0
      for i in range(1, 9):
        for j in range(1, 9):
          if (board[10*i + j] == player):
            square_weight += Value_of_square[i - 1][j - 1]
            my_tiles += 1
          if (board[10*i + j] == notplayer):
            square_weight -= Value_of_square[i - 1][j - 1]
            not_my_tiles += 1
          if (board[10*i + j] == player):
            if board[10*(i+1) + j] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*(i+1) + (j+1)] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*i + (j+1)] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*(i - 1) + j] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*i + (j - 1)] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*(i-1) + (j-1)] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*(i - 1) + (j + 1)] == '.':
              my_frontier_tiles += 1
              continue
            if board[10*(i + 1) + (j - 1)] == '.':
              my_frontier_tiles += 1
              continue
          if (board[10*i + j] == notplayer):
            if board[10*(i+1) + j] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*(i+1) + (j+1)] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*i + (j + 1)] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*(i-1) + j] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*i + (j - 1)] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*(i - 1) + (j - 1)] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*(i - 1) + (j + 1)] == '.':
              not_my_frontier_tiles += 1
              continue
            if board[10*(i + 1) + (j - 1)] == '.':
              not_my_frontier_tiles += 1
              continue
      corner_count = 0           
      if (board[18] == player):
        corner_count += 25
      if (board[88] == player):
        corner_count += 25
      if (board[81] == player):
        corner_count += 25
      if (board[11] == player):
        corner_count += 25
      if (board[18] == notplayer):
        corner_count -= 25
      if (board[88] == notplayer):
        corner_count -= 25
      if (board[81] == notplayer):
        corner_count -= 25
      if (board[11] == notplayer):
        corner_count -= 25
      corner_closeness = 0
      if (board[11] == '.'):
        if (board[12] == notplayer):
          corner_closeness -= 1
        if (board[21] == notplayer):
          corner_closeness -= 1
        if (board[22] == notplayer):
          corner_closeness -= 1
        if (board[12] == player):
          corner_closeness += 1
        if (board[21] == player):
          corner_closeness += 1
        if (board[22] == player):
          corner_closeness += 1
      if (board[18] == '.'):
        if (board[17] == notplayer):
          corner_closeness -= 1
        if (board[28] == notplayer):
          corner_closeness -= 1
        if (board[27] == notplayer):
          corner_closeness -= 1
        if (board[17] == player):
          corner_closeness += 1 
        if (board[28] == player):
          corner_closeness += 1
        if (board[27] == player):
          corner_closeness += 1
      if (board[88] == '.'):
        if (board[78] == notplayer):
          corner_closeness -= 1
        if (board[87] == notplayer):
          corner_closeness -= 1
        if (board[77] == notplayer):
          corner_closeness -= 1
        if (board[78] == player):
          corner_closeness += 1
        if (board[77] == player):
          corner_closeness += 1
        if (board[87] == player):
          corner_closeness += 1
      if (board[81] == '.'):
        if (board[71] == notplayer):
          corner_closeness -= 1
        if (board[72] == notplayer):
          corner_closeness -= 1
        if (board[82] == notplayer):
          corner_closeness -= 1 
        if (board[71] == player):
          corner_closeness += 1
        if (board[72] == player):
          corner_closeness += 1
        if (board[82] == player):
          corner_closeness += 1
      corner_closeness *= -12.5
      my_moves = self.countMoves(board, player)
      his_moves = self.countMoves(board, notplayer)
      moves_scores = 0
      if my_moves > his_moves:
        moves_scores = (100*(my_moves - his_moves))/(my_moves + his_moves)
      #  if his_moves == 0 and my_moves > 0:
      #    if my_tiles + not_my_tiles > 30:
      #      moves_scores = 900
      if his_moves > my_moves:
        moves_scores = -(100*(his_moves - my_moves))/(my_moves + his_moves)
        if my_moves == 0 and his_moves > 0:
          if my_tiles + not_my_tiles > 30:
            moves_scores = -900

      tiles_scores = 0
      if my_tiles > not_my_tiles:
        tiles_scores = (100.0*(my_tiles - not_my_tiles))/(my_tiles + not_my_tiles)
      if not_my_tiles > my_tiles:
        tiles_scores = -(100.0*(not_my_tiles - my_tiles))/(my_tiles + not_my_tiles)
      frontier_scores = 0
      if my_frontier_tiles > not_my_frontier_tiles:
        frontier_scores = (100.0*(my_frontier_tiles - not_my_frontier_tiles))/(my_frontier_tiles + not_my_frontier_tiles)
      if not_my_frontier_tiles > my_frontier_tiles:
        frontier_scores = (-100.0*(not_my_frontier_tiles - my_frontier_tiles))/(my_frontier_tiles + not_my_frontier_tiles)
      space = 64 - my_tiles - not_my_tiles
      total_score = (space)/64.0 * corner_closeness * 301 + (64 - space)*tiles_scores + (801.724*corner_count*(space + 16))/32 - frontier_scores * 74.396 + 78.922 *  moves_scores * (space)/64.0 + 10*square_weight
      return total_score

    def alphabeta(self, board, player, depth, _alpha, _beta, maximizingPlayer):
      #returns a guess for the maximum value of heuristic 
      #pretty(pos)
      notplayer = '.'
      if (player == BLACK):
        notplayer = WHITE
      else:
        notplayer = BLACK
      if depth == 0:
        if maximizingPlayer:
          square_weight = 0
          my_tiles = 0
          not_my_tiles = 0
          my_frontier_tiles = 0
          not_my_frontier_tiles = 0
          for i in range(1, 9):
            for j in range(1, 9):
              if (board[10*i + j] == player):
                square_weight += Value_of_square[i - 1][j - 1]
                my_tiles += 1
              if (board[10*i + j] == notplayer):
                square_weight -= Value_of_square[i - 1][j - 1]
                not_my_tiles += 1
              if (board[10*i + j] == player):
                if board[10*(i+1) + j] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i+1) + (j+1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*i + (j+1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + j] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*i + (j - 1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i-1) + (j-1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + (j + 1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i + 1) + (j - 1)] == '.':
                  my_frontier_tiles += 1
                  continue
              if (board[10*i + j] == notplayer):
                if board[10*(i+1) + j] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i+1) + (j+1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*i + (j + 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i-1) + j] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*i + (j - 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + (j - 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + (j + 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i + 1) + (j - 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
          corner_count = 0           
          if (board[18] == player):
            corner_count += 25
          if (board[88] == player):
            corner_count += 25
          if (board[81] == player):
            corner_count += 25
          if (board[11] == player):
            corner_count += 25
          if (board[18] == notplayer):
            corner_count -= 25
          if (board[88] == notplayer):
            corner_count -= 25
          if (board[81] == notplayer):
            corner_count -= 25
          if (board[11] == notplayer):
            corner_count -= 25
          corner_closeness = 0
          if (board[11] == '.'):
            if (board[12] == notplayer):
              corner_closeness -= 1
            if (board[21] == notplayer):
              corner_closeness -= 1
            if (board[22] == notplayer):
              corner_closeness -= 1
            if (board[12] == player):
              corner_closeness += 1
            if (board[21] == player):
              corner_closeness += 1
            if (board[22] == player):
              corner_closeness += 1
          if (board[18] == '.'):
            if (board[17] == notplayer):
              corner_closeness -= 1
            if (board[28] == notplayer):
              corner_closeness -= 1
            if (board[27] == notplayer):
              corner_closeness -= 1
            if (board[17] == player):
              corner_closeness += 1 
            if (board[28] == player):
              corner_closeness += 1
            if (board[27] == player):
              corner_closeness += 1
          if (board[88] == '.'):
            if (board[78] == notplayer):
              corner_closeness -= 1
            if (board[87] == notplayer):
              corner_closeness -= 1
            if (board[77] == notplayer):
              corner_closeness -= 1
            if (board[78] == player):
              corner_closeness += 1
            if (board[77] == player):
              corner_closeness += 1
            if (board[87] == player):
              corner_closeness += 1
          if (board[81] == '.'):
            if (board[71] == notplayer):
              corner_closeness -= 1
            if (board[72] == notplayer):
              corner_closeness -= 1
            if (board[82] == notplayer):
              corner_closeness -= 1 
            if (board[71] == player):
              corner_closeness += 1
            if (board[72] == player):
              corner_closeness += 1
            if (board[82] == player):
              corner_closeness += 1
          corner_closeness *= -12.5
          my_moves = self.countMoves(board, player)
          his_moves = self.countMoves(board, notplayer)
          moves_scores = 0
          if my_moves > his_moves:
            moves_scores = (100*(my_moves - his_moves))/(my_moves + his_moves)
          #  if his_moves == 0 and my_moves > 0:
          #    if my_tiles + not_my_tiles > 30:
          #      moves_scores = 900
          if his_moves > my_moves:
            moves_scores = -(100*(his_moves - my_moves))/(my_moves + his_moves)
            if my_moves == 0 and his_moves > 0:
              if my_tiles + not_my_tiles > 30:
                moves_scores = -900
          tiles_scores = 0
          if my_tiles > not_my_tiles:
            tiles_scores = (100.0*(my_tiles - not_my_tiles))/(my_tiles + not_my_tiles)
          if not_my_tiles > my_tiles:
            tiles_scores = -(100.0*(not_my_tiles - my_tiles))/(my_tiles + not_my_tiles)
          frontier_scores = 0
          if my_frontier_tiles > not_my_frontier_tiles:
            frontier_scores = (100.0*(my_frontier_tiles - not_my_frontier_tiles))/(my_frontier_tiles + not_my_frontier_tiles)
          if not_my_frontier_tiles > my_frontier_tiles:
            frontier_scores = (-100.0*(not_my_frontier_tiles - my_frontier_tiles))/(my_frontier_tiles + not_my_frontier_tiles)
          space = 64 - my_tiles - not_my_tiles
          total_score = (space)/64.0 * corner_closeness * 301 + (64 - space)*tiles_scores + (801.724*corner_count*(space + 16))/32 - frontier_scores * 74.396 + 78.922 *  moves_scores * (space)/64.0 + 10*square_weight
          return total_score
        else:
          square_weight = 0
          my_tiles = 0
          not_my_tiles = 0
          my_frontier_tiles = 0
          not_my_frontier_tiles = 0
          for i in range(1, 9):
            for j in range(1, 9):
              if (board[10*i + j] == player):
                square_weight += Value_of_square[i - 1][j - 1]
                my_tiles += 1
              if (board[10*i + j] == notplayer):
                square_weight -= Value_of_square[i - 1][j - 1]
                not_my_tiles += 1
              if (board[10*i + j] == player):
                if board[10*(i+1) + j] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i+1) + (j+1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*i + (j+1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + j] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*i + (j - 1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i-1) + (j-1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + (j + 1)] == '.':
                  my_frontier_tiles += 1
                  continue
                if board[10*(i + 1) + (j - 1)] == '.':
                  my_frontier_tiles += 1
                  continue
              if (board[10*i + j] == notplayer):
                if board[10*(i+1) + j] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i+1) + (j+1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*i + (j + 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i-1) + j] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*i + (j - 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + (j - 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i - 1) + (j + 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
                if board[10*(i + 1) + (j - 1)] == '.':
                  not_my_frontier_tiles += 1
                  continue
          corner_count = 0           
          if (board[18] == player):
            corner_count += 25
          if (board[88] == player):
            corner_count += 25
          if (board[81] == player):
            corner_count += 25
          if (board[11] == player):
            corner_count += 25
          if (board[18] == notplayer):
            corner_count -= 25
          if (board[88] == notplayer):
            corner_count -= 25
          if (board[81] == notplayer):
            corner_count -= 25
          if (board[11] == notplayer):
            corner_count -= 25
          corner_closeness = 0
          if (board[11] == '.'):
            if (board[12] == notplayer):
              corner_closeness -= 1
            if (board[21] == notplayer):
              corner_closeness -= 1
            if (board[22] == notplayer):
              corner_closeness -= 1
            if (board[12] == player):
              corner_closeness += 1
            if (board[21] == player):
              corner_closeness += 1
            if (board[22] == player):
              corner_closeness += 1
          if (board[18] == '.'):
            if (board[17] == notplayer):
              corner_closeness -= 1
            if (board[28] == notplayer):
              corner_closeness -= 1
            if (board[27] == notplayer):
              corner_closeness -= 1
            if (board[17] == player):
              corner_closeness += 1 
            if (board[28] == player):
              corner_closeness += 1
            if (board[27] == player):
              corner_closeness += 1
          if (board[88] == '.'):
            if (board[78] == notplayer):
              corner_closeness -= 1
            if (board[87] == notplayer):
              corner_closeness -= 1
            if (board[77] == notplayer):
              corner_closeness -= 1
            if (board[78] == player):
              corner_closeness += 1
            if (board[77] == player):
              corner_closeness += 1
            if (board[87] == player):
              corner_closeness += 1
          if (board[81] == '.'):
            if (board[71] == notplayer):
              corner_closeness -= 1
            if (board[72] == notplayer):
              corner_closeness -= 1
            if (board[82] == notplayer):
              corner_closeness -= 1 
            if (board[71] == player):
              corner_closeness += 1
            if (board[72] == player):
              corner_closeness += 1
            if (board[82] == player):
              corner_closeness += 1
          corner_closeness *= -12.5
          my_moves = self.countMoves(board, player)
          his_moves = self.countMoves(board, notplayer)
          moves_scores = 0
          if my_moves > his_moves:
            moves_scores = (25*(my_moves - his_moves))/(my_moves + his_moves)
          #  if his_moves == 0 and my_moves > 0:
          #    if my_tiles + not_my_tiles > 30:
          #      moves_scores = 900
          if his_moves > my_moves:
            moves_scores = -(100*(his_moves - my_moves))/(my_moves + his_moves)
            if my_moves == 0 and his_moves > 0:
              if my_tiles + not_my_tiles > 30:
                moves_scores = -900
          tiles_scores = 0
          if my_tiles > not_my_tiles:
            tiles_scores = (100.0*(my_tiles - not_my_tiles))/(my_tiles + not_my_tiles)
          if not_my_tiles > my_tiles:
            tiles_scores = -(100.0*(not_my_tiles - my_tiles))/(my_tiles + not_my_tiles)
          frontier_scores = 0
          if my_frontier_tiles > not_my_frontier_tiles:
            frontier_scores = (100.0*(my_frontier_tiles - not_my_frontier_tiles))/(my_frontier_tiles + not_my_frontier_tiles)
          if not_my_frontier_tiles > my_frontier_tiles:
            frontier_scores = (-100.0*(not_my_frontier_tiles - my_frontier_tiles))/(my_frontier_tiles + not_my_frontier_tiles)
          space = 64 - my_tiles - not_my_tiles
          total_score = (space)/64.0 * corner_closeness * 301 + (64 - space)*tiles_scores + (801.724*corner_count*(space + 16))/32 - frontier_scores * 74.396 + 78.922 *  moves_scores * (space)/64.0 + 10*square_weight
          return -total_score
      if self.done(board) == True:
        if maximizingPlayer:
          return self.heuristic2(board, player)
        else:
          return -self.heuristic2(board, player)
      alpha = _alpha
      beta = _beta
      if maximizingPlayer:
        v = -10000000
        for pos3 in self.findKids(board, player):
          v = max(v, self.alphabeta(pos3, notplayer, depth - 1, alpha, beta, False))
          alpha = max(alpha, v)
          if beta <= alpha:
            break
        if v == -10000000:
          v = max(v, self.alphabeta(board, notplayer, depth - 1, alpha, beta, False))
          alpha = max(alpha, v)
        return v
      else:
        v = 10000000
        for pos3 in self.findKids(board, player):
          v = min(v, self.alphabeta(pos3, notplayer, depth - 1, alpha, beta, True))
          beta = min(beta, v)
          if (beta <= alpha):
            break
        if v == 10000000:
          v = min(v, self.alphabeta(board, notplayer, depth - 1, alpha, beta, True))
          beta = min(beta, v)
        return v

    def alphabetaVariant(self, board, player, depth, _alpha, _beta, maximizingPlayer):
      #returns a guess for the highest value of heuristic if 
      #pretty(pos)
      notplayer = '.'
      if (player == BLACK):
        notplayer = WHITE
      else:
        notplayer = BLACK
      if (depth == 0):
        if maximizingPlayer:
          return self.heuristic2(board, player)
        else:
          return -self.heuristic2(board, player)
      if self.done(board):
        if maximizingPlayer:
          return self.heuristic2(board, player)
        else:
          return -self.heuristic2(board, player)
      alpha = _alpha
      beta = _beta
      if maximizingPlayer:
        v = -10000000
        for pos3 in self.findKids(board, player):
          v = max(v, self.alphabetaVariant(pos3, notplayer, depth - 1, alpha, beta, False))
          alpha = max(alpha, v)
          if beta <= alpha:
            break
        if v == -10000000:
          v = max(v, self.alphabetaVariant(board, notplayer, depth - 1, alpha, beta, False))
          alpha = max(alpha, v)
        return v
      else:
        v = 10000000
        for pos3 in self.findKids(board, player):
          v = min(v, self.alphabetaVariant(pos3, notplayer, depth - 1, alpha, beta, True))
          beta = min(beta, v)
          if (beta <= alpha):
            break
        if v == 10000000:
          v = min(v, self.alphabetaVariant(board, notplayer, depth - 1, alpha, beta, True))
          beta = min(beta, v)
        return v    

    def best_strategy(self, board, player, best_move, still_running):
      """
        :param board: a length 100 list representing the board state
        :param player: WHITE or BLACK
        :param best_move: shared multiptocessing.Value containing an int of
                the current best move
        :param still_running: shared multiprocessing.Value containing an int
                that is 0 iff the parent process intends to kill this process
        :return: best move as an int in [11,88] or possibly 0 for 'unknown'
      """
      notplayer = '.'
      if (player == WHITE):
        notplayer = BLACK
      else:
        notplayer = WHITE
      moves = []
      kids = []
      for i in range(1, 9):
        for j in range(1, 9):
          r = self.tryMove(board, (i, j), player)
          if (r != None):
            moves.append((i, j))
            kids.append(r)
      #best_move.value = 10*moves[0][0] + moves[0][1]
      dep = 2
      squares = 0
      for i in range(1, 9):
        for j in range(1, 9):
          if (board[10*i + j] != '.'):
            squares += 1
      if squares <= 59:
        while dep + squares <= 65:
          bes = 0
          val = -10000000
          for i in range(len(moves)):
            k = self.alphabeta(kids[i], notplayer, dep, -10000000, 10000000, False)
            if k > val:
              val = k
              bes = i
          best_move.value = 10*moves[bes][0] + moves[bes][1]
          if val > 100000: 
            break
          dep += 1
      else:
        while dep + squares <= 65:
          bes = 0
          val = -10000000
          for i in range(len(moves)):
            k = self.alphabetaVariant(kids[i], notplayer, dep, -10000000, 10000000, False)
            if k > val:
              val = k
              bes = i
          best_move.value = 10*moves[bes][0] + moves[bes][1]
          if val > 100000: 
            break
          dep += 1

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)
