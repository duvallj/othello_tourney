empty, black, white, outer = '.','@','o','?'
class Strategy:
    def best_strategy(self, board, player, best_move, still_running):
        board = [i.lower() for i in board]
        board = (''.join(board))
        board = board.replace('?','')
        board = board.replace('@','x')
        pos = []
        reee = [0, -3, 5, 6, 2, 9]

        turn = 'a'
        alpha = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
        def findTurn(board):
                tokes = 0
                for x in range(len(board)):
                        if board[x] != '.':
                                tokes+=1
                if tokes%2 == 0:
                        return 'x'
                else:
                        return 'o'
        if(turn == 'a'):
                turn = findTurn(board)
        def totTokes(board):
                tote = 0
                for x in range(len(board)):
                        if(board[x] != '.'):
                                tote += 1
                return tote
        levels = 2*(64-totTokes(board))
        if levels%2 ==0:
                levels+=1
        def output(board):
                r = []
                k = 0
                for i in range(8):
                        print(board[k:(8+k)])
                        k+=8
                        r = []
                
        def playMove(board, turn, pos):
                enempos = []
                r = []
                for x in range(len(board)):
                        if board[x] == turn:
                                continue
                        elif board[x] != '.':
                                enempos.append(x)
                if(pos in enempos):
                        return [-1]
                for i in [1,7,8,9]:
                        if i == 1:
                                q = int(pos)+i
                                z = int(pos)-i
                                if(q < 64 and q >-1 and q in enempos):
                                        a =move(board, turn, q, i,int(pos))
                                        if(a != -1):
                                                r.append(a)
                                if(z < 64 and z >-1 and z in enempos):
                                        b =move(board,turn,z,-i,int(pos))
                                        if(b!=-1):
                                                r.append(b)
                        if i == 7:
                                q, z = int(pos)+i, int(pos)-i
                                if(q < 64 and q >-1 and q in enempos):
                                        a =move(board, turn, q, i,int(pos))
                                        if(a != -1):
                                                r.append(a)
                                if(z < 64 and z >-1 and z in enempos):
                                        b =move(board,turn,z,-i,int(pos))
                                        if(b!=-1):
                                                r.append(b) 
                        if i == 8:
                                q, z = int(pos)+i, int(pos)-i
                                if(q < 64 and q >-1 and q in enempos):
                                        a =move(board, turn, q, i,int(pos))
                                        if(a != -1):
                                                r.append(a)
                                if(z < 64 and z >-1 and z in enempos):
                                        b =move(board,turn,z,-i,int(pos))
                                        if(b!=-1):
                                                r.append(b)
                        if i == 9:
                                q, z = int(pos)+i, int(pos)-i
                                if(q < 64 and q >-1 and q in enempos):
                                        a =move(board, turn, q, i,int(pos))
                                        if(a != -1):
                                                r.append(a)
                                if(z < 64 and z >-1 and z in enempos):
                                        b =move(board,turn,z,-i,int(pos))
                                        if(b!=-1):
                                                r.append(b)
                if(len(r) == 0):
                        return [-1]
                return r
        def move(board, turn, pos, c,x):
                flippers = [pos-c]
                while(board[pos]!= '.'):
                        if(board[pos] == turn):
                                return flippers
                        if(c == 1 or c == -1):
                                if(pos//8 == x//8):
                                        flippers.append(pos)
                                        pos = pos+c
                                else:
                                        return -1
                        elif(c == 8 or c == -8):
                                if(pos%8 == x%8):
                                        flippers.append(pos)
                                        pos = pos+c
                                else:
                                        return -1
                        elif(c == 7 or c == -9):
                                if(pos%8 < x%8):
                                        flippers.append(pos)
                                        pos = pos+c
                                else:
                                        return -1
                        elif(c == -7 or c == 9):
                                if(pos%8 > x%8):
                                        flippers.append(pos)
                                        pos = pos+c
                                else:
                                        return -1
                        if(pos <64 and pos >-1):
                                continue
                        else:
                                return -1
                return -1
        def check(board, turn, pos, c):
                while(board[pos]!= '.'):
                        if(board[pos] == turn):
                                return -1
                        pos = pos+c
                        if(pos <64 and pos >-1):
                                continue
                        else:
                                return -1
                return pos
        def legalMoves(board, turn):
                enempos = []
                pos = []
                posmoves = []
                moves = [1,7,8,9]
                for x in range(len(board)):
                        if board[x] == turn:
                                pos.append(x)
                        elif board[x] != '.':
                                enempos.append(x)
                for x in pos:
                        for i in moves:
                                if i == 1:
                                        q, z = x+i, x-i
                                        if(q < 64 and q >-1 and q in enempos):
                                                a =check(board, turn, q, i)
                                                if(a != -1 and a not in posmoves):
                                                        if(x//8 == a//8):
                                                                posmoves.append(a)
                                        if(z < 64 and z >-1 and z in enempos):
                                                b =check(board,turn,z,-i)
                                                if(b!=-1 and b not in posmoves):
                                                        if(x//8 == b//8):
                                                                posmoves.append(b)  
                                if i == 7:
                                        q, z = x+i, x-i
                                        if(q < 64 and q >-1 and q in enempos):
                                                a =check(board, turn, q, i)
                                                if(a != -1 and a not in posmoves):
                                                        if(x%8 > a%8):
                                                                posmoves.append(a)
                                        if(z < 64 and z >-1 and z in enempos):
                                                b =check(board,turn,z,-i)
                                                if(b!=-1 and b not in posmoves):
                                                        if(x%8 < b%8):
                                                                posmoves.append(b)  
                                if i == 8:
                                        q, z = x+i, x-i
                                        if(q < 64 and q >-1 and q in enempos):
                                                a =check(board, turn, q, i)
                                                if(a != -1 and a not in posmoves):
                                                        if(x%8 == a%8):
                                                                posmoves.append(a)
                                        if(z < 64 and z >-1 and z in enempos):
                                                b =check(board,turn,z,-i)
                                                if(b!=-1 and b not in posmoves):
                                                        if(x%8 == b%8):
                                                                posmoves.append(b)  
                                if i == 9:
                                        q, z = x+i, x-i
                                        if(q < 64 and q >-1 and q in enempos):
                                                a =check(board, turn, q, i)
                                                if(a != -1 and a not in posmoves):
                                                        if(x%8 < a%8):
                                                                posmoves.append(a)
                                        if(z < 64 and z >-1 and z in enempos):
                                                b =check(board,turn,z,-i)
                                                if(b!=-1 and b not in posmoves):
                                                        if(x%8 > b%8):
                                                                posmoves.append(b)  
                return posmoves
        def opt(board, turn):
                pos = []
                for a in board:
                        if a.lower() == turn:
                                pos.append(a)
                j, r = [], []
                atile, btile, ctile, xtile = [2, 5, 16, 23, 40, 47, 58, 61], [3, 4, 24, 31, 32, 39, 59, 60], [1, 6, 8, 15, 48, 55, 57, 62], [9, 14, 49, 54]
                q = legalMoves(board, turn)
                if(q == []):
                        if(turn.lower() == 'x'):
                                turn, q= 'o', legalMoves(board, turn)
                        elif(turn.lower() == 'o'):
                                turn,q = 'x', legalMoves(board, turn)
                for i in range(len(xtile)):
                        if i in q:
                                q.remove(i)
                                if q == []: q.append(i)
                if(0 in q): return 0
                if(7 in q): return 7
                if(56 in q): return 56
                if(63 in q): return 63
                for a in range(len(atile)):
                        if(atile[a] in q):
                                return(atile[a])
                        elif(btile[a] in q):
                                return(btile[a])
                for i in q:
                        flip = playMove(board, turn, i)
                        if(flip[0] == -1):
                                continue
                        else:
                                j.append(flip)
                                r.append(i)
                if(0 in pos and 1 in q): return 1
                if(0 in pos and 8 in q): return 8
                if(7 in pos and 6 in q): return 6
                if(7 in pos and 15 in q): return 15
                if(56 in pos and 48 in q): return 48
                if(56 in pos and 57 in q): return 57
                if(63 in pos and 62 in q): return 62
                if(63 in pos and 55 in q): return 55
                a = totTokes(board)
                mini = 100
                maxi= 0
                for q in j:
                        if(a > 42):
                                if len(q) > maxi:
                                        maxi = len(q)
                        else:
                                if(len(q) < mini):
                                        mini = len(q)
                for i in range(len(j)):
                        if(a > 42):
                                if(len(j[i]) == maxi):
                                        return(r[i])
                                else:
                                        return r[0]
                        else:
                                if(len(j[i]) == mini):
                                        return(r[i])
                                else:
                                        return r[0]
        def numfree(board, turn):
                c = 0
                for i in range(len(board)):
                        if(board[i] == '.'):
                                c+=1
                return c
        def printBo(pos, turn, board):
                dica = {}
                q = legalMoves(board, turn)
                if(q == []):
                        if(turn.lower() == 'x'):
                                turn = 'o'
                                q = legalMoves(board, turn)
                        elif(turn.lower() == 'o'):
                                turn = 'x'
                                q = legalMoves(board, turn)
                if int(pos) in q:
                        flip = playMove(board, turn, pos)
                        if(flip[0] == -1):
                                print("Invalid")
                                quit()
                        board = list(board)
                        for j in flip:
                                for y in j:
                                        board[y] = turn
                return(''.join(board))
        def evalBoard(board, token, enemy):
                return board.count(token) - board.count(enemy)
        def negamax(board, token, levels):
                if token.lower() == 'x': enemy = 'o'
                else: enemy = 'x'
                if not levels: return [evalBoard(board, token, enemy)]
                lm = legalMoves(board, token)
                lem = legalMoves(board, enemy)
                if not lm and not lem or board.count('.') == 0: return [evalBoard(board,token,enemy)]
                if not lm: best = negamax(board, enemy, levels-1) + [-1]
                else:
                        best = sorted([negamax(printBo(mv, token, board), enemy, levels-1) + [mv]for mv in lm])[0]
                return [-best[0]] + best[1:]
        lm = set(legalMoves(board, turn))
        if(board.count('.') > 10):
            best_move = (opt(board, turn))
            best_move = 11+ 10*(best_move//8) + best_move%8
            best_move = str(best_move)
            return best_move
        else:
             best_move = negamax(board,turn,levels)[0]
             best_move = 11+10*(best_move//8) + best_move%8
             best_move = str(best_move)
             return best_move
