import random
# import math
# import time
# import OthelloRand as opponent

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Strategy():

    def __init__(self):
        self.board_weights = [0,   0,   0,  0,  0,  0,  0,   0,   0, 0,
                              0, 120, -20, 20,  5,  5, 20, -20, 120, 0,
                              0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
                              0,  20,  -5, 15,  3,  3, 15,  -5,  20, 0,
                              0,  5,  -5,  3,  3,  3,  3,  -5,   5, 0]
        reversed_board_weights = list(reversed(self.board_weights))
        self.board_weights = self.board_weights + reversed_board_weights

        self.inner_squares = list()
        for i in range(1, 9):
            for j in range(1, 9):
                self.inner_squares.append(10 * i + j)


    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        starting_board = ''
        starting_board += OUTER * 10
        for i in range(3):
            starting_board += OUTER + EMPTY * 8 + OUTER
        starting_board += OUTER + EMPTY * 3 + WHITE + BLACK + EMPTY * 3 + OUTER
        starting_board += OUTER + EMPTY * 3 + BLACK + WHITE + EMPTY * 3 + OUTER
        for i in range(3):
            starting_board += OUTER + EMPTY * 8 + OUTER
        starting_board += OUTER * 10
        return starting_board

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        pretty_board = '0123456780\n'
        for i in range(1, 9):
            pretty_board += str(i) + board[i*10+1:i*10+9] + str(i) + '\n'
        pretty_board += '0123456780'
        return pretty_board

    def opponent(self, player):
        """Get player's opponent."""
        opponent = {WHITE: BLACK, BLACK: WHITE}
        return opponent[player]

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        square += direction
        if board[square] != self.opponent(player):
            return None
        while board[square] == self.opponent(player):
            square += direction
        if board[square] == player:
            return square
        return None

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        if board[move] != EMPTY:
            return False
        for direction in DIRECTIONS:
            match = self.find_match(board, player, move, direction)
            if match is not None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        board = list(board)
        board[move] = player
        for direction in DIRECTIONS:
            match = self.find_match(board, player, move, direction)
            if match is not None:
                for i in range(move, match + direction, direction):
                    board[i] = player
        return ''.join(board)

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        valid_moves = list()
        for move in range(100):
            if board[move] == EMPTY and self.is_move_valid(board, player, move):
                valid_moves.append(move)
        return valid_moves

    def mobility(self, board):
        return len(self.get_valid_moves(board, BLACK)) - len(self.get_valid_moves(board, WHITE))

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        return len(self.get_valid_moves(board, player)) != 0

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)):
            return self.opponent(prev_player)
        if self.has_any_valid_moves(board, prev_player):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        black_score, white_score = 0, 0
        for square in board:
            if square == BLACK:
                black_score += 1
            elif square == WHITE:
                white_score += 1
        # if player == BLACK:
            # return black_score - white_score
        # else:
            # return white_score - black_score
        return black_score - white_score

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        return (not self.has_any_valid_moves(board, player) and
                not self.has_any_valid_moves(board, self.opponent(player)))

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################
    def corner_stability(self, board, corner, dir1, dir2):
        stable_list = set()
        queue = list()
        if board[corner] != EMPTY:
            stable_list.add(corner)
            queue.append(corner + dir1)
            queue.append(corner + dir2)
        while len(queue) != 0:
            square = queue.pop()
            if board[square] != board[corner]:
                continue
            else:
                stable_list.add(square)
                queue.append(square + dir1)
                queue.append(square + dir2)
        return stable_list


    def stable_squares(self, board):
        stable_squares = {BLACK: set(), WHITE: set()}
        # all of the following are 1-indexed
        row_is_filled = [True] * 9
        col_is_filled = [True] * 9
        right_diag_is_filled = [True] * 16
        #number 1 right diagonal is square 18, 15 is square 81
        left_diag_is_filled  = [True] * 16
        #number 1 left diagonal is square 11, 15 is square 88
        for i in self.inner_squares:
            if board[i] == EMPTY:
                row_is_filled[i//10] = False
                col_is_filled[i%10] = False
                right_diag_is_filled[i//10 - i%10 + 8] = False
                left_diag_is_filled[i//10 + i%10 - 1] = False
        for i in self.inner_squares:
            row, col, right_diag, left_diag = i//10, i%10, i//10-i%10+8, i//10+i%10-1
            if (row_is_filled[row] and
                    col_is_filled[col] and
                    right_diag_is_filled[right_diag] and
                    left_diag_is_filled[left_diag]):
                stable_squares[board[i]].add(i)
        corners = [(11, S, E), (18, S, W), (81, N, E), (88, N, W)]
        for corner in corners:
            if board[corner[0]] != EMPTY:
                stable_squares[board[corner[0]]] |= self.corner_stability(board, *corner)
        return stable_squares

    def count_frontier(self, board):
        player_frontier = {BLACK: set(), WHITE: set()}
        for i in range(len(board)):
            if board[i] == EMPTY:
                adj_squares = []
                for dir in DIRECTIONS:
                    adj_squares.append(i + dir)
                for adj in adj_squares:
                    if board[adj] != EMPTY and board[adj] != OUTER:
                        player_frontier[board[adj]].add(adj)
        return player_frontier

    def evaluate_board(self, board):
        # move = 0
        # for i in range(len(board)):
            # if board[i] == BLACK or board[i] == WHITE:
                # move += 1
        player_score = {BLACK: 0, WHITE: 0}
        # stable_squares = self.stable_squares(board)
        # frontier = self.count_frontier(board)
        for i in range(len(board)):
            ch = board[i]
            if ch in player_score:
                player_score[ch] += self.board_weights[i]
        # frontier_heuristic = len(frontier[WHITE]) - len(frontier[BLACK])
        # stability_heurisitc = len(stable_squares[BLACK]) - len(stable_squares[WHITE])
        score_heuristic = player_score[BLACK] - player_score[WHITE]
        # random_heuristic = -10 + (20 * random.random())
        sohom_heuristic = 0
        sohom_heuristic += score_heuristic
        # sohom_heuristic += 7 * frontier_heuristic * (1.5 - (move ** 2)/(64*64))
        # if move <= 20:
        	# sohom_heuristic += 7 * frontier_heuristic
        # if move >= 40:
        	# sohom_heuristic -= 3 * frontier_heuristic
        # sohom_heuristic += 10 * stability_heurisitc
        # sohom_heuristic += random_heuristic
        return sohom_heuristic


    def minmax_search(self, board, player, depth, alpha, beta):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters
        if self.game_over(board, player):
            return self.score(board) * 100000, None
        if depth == 0:
            return self.evaluate_board(board), None
        valid_moves = self.get_valid_moves(board, player)
        child_to_move = dict()
        children = list()
        for move in valid_moves:
            child = self.make_move(board, player, move)
            children.append(child)
            child_to_move[child] = move
        if player == BLACK:
            v = float('-inf')
            best_move = None
            #for child in sorted(children, key=self.mobility, reverse=True):
            for child in children:
                min_max = self.minmax_search(child, self.next_player(board, player), depth - 1, alpha, beta)
                if min_max[0] > v:
                    v, best_move = min_max[0], child_to_move[child]
                alpha = max(alpha, v)
                if beta <= alpha:
                    break
            return (v, best_move)
        elif player == WHITE:
            v = float('inf')
            best_move = None
            # for child in sorted(children, key=self.mobility):
            for child in children:
                min_max = self.minmax_search(child, self.next_player(board, player), depth - 1, alpha, beta)
                if min_max[0] < v:
                    v, best_move = min_max[0], child_to_move[child]
                beta = min(beta, v)
                if beta <= alpha:
                    break
            return (v, best_move)


    def minmax_strategy(self, board, player, depth=5):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        heuristic, best_move = self.minmax_search(board, player, depth, float('-Inf'), float('Inf'))
        if best_move is not None:
            return best_move
        else:
            return random.choice(self.get_valid_moves(board, player))

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        # if type(board) is list:
            # board = ''.join(board)
        # empty_squares = 0
        # for i in range(len(board)):
            # if board[i] == EMPTY:
                # empty_squares += 1
        '''
        if empty_squares > 54 or empty_squares < 15:
            depth = 5
        else:
            depth = 3
        '''
        depth = 1
        # if empty_squares <= 6:
            # depth = empty_squares + 1
        valid_moves = set(self.get_valid_moves(board, player))
        '''
        for corner in [11, 18, 81, 88]:
        	if corner in valid_moves:
        		best_move.value = corner
        		return corner
        '''
        while depth <= 64:
            # print(depth)
            update_move = self.minmax_strategy(board, player, depth=depth)
            if update_move in valid_moves:
                best_move.value = self.minmax_strategy(board, player, depth=depth)
            else:
                best_move.value = random.choice(list(valid_moves))
            depth += 2

    standard_strategy = best_strategy
    # standard_strategy = minmax_strategy

###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            move = strategy[player](board, player)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(board, player, move)
            print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))
        return ref.score(board)


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -1)
            best_shared.value = 11
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            # if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        black_score = ref.score(board, BLACK)
        if black_score > 0:
            winner = BLACK
        elif black_score < 0:
            winner = WHITE
        else:
            winner = "TIE"
        print(black_score)
        print(winner)
        return board, ref.score(board, BLACK)


#################################################
# The main routine
################################################

if __name__ == "__main__":
    # game = StandardPlayer()
    game = ParallelPlayer()
    game.play()
