import random,time,sys,math

class Strategy():
    def best_strategy(self,board,player,best_move,still_running):

        brd = "".join(board).replace('?',"").replace('@','x')
        if player=='@': token = 'x'
        else: token = 'o'
        if len([i for i, letter in enumerate(board) if letter == "."])>11:
            currentLevel=4
            while still_running:
                mv=alphabeta(token,brd,-9999,9999,currentLevel)[1]
                mv1 = 11 + (mv // 8) * 10 + (mv % 8)
                best_move.value=mv1
                currentLevel+=1
        else:
            mv = negamaxTerminal(brd,token, -65,65)[-1]
            mv1 = 11 + (mv // 8) * 10 + (mv % 8)
            best_move.value = mv1




edges = [0,1,2,3,4,5,6,7,8,16,24,32,40,48,56,57,58,59,60,61,62,63,15,23,31,39,47,55]
corners = [0,7,56,63]
def move(index, token, board):
    if index in possibleMoves(token, board):
        if token == 'x':
            opptoken = 'o'
        else:
            opptoken = 'x'
        copyBoard = list(board)
        # left,right,up,down,diagupleft,diagupright,diagdownleft,diagdownright = index-1,index+1,index-8,index+8,index-9,index-7,index+7,index+9
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]
        switchedPositions = [index]
        for x in directions:
            tempObj = index + x
            positionsPassed = []
            while 63 >= (tempObj + x) >= 0 and board[tempObj] == opptoken:
                if x == 1 or x == -1:
                    if int((tempObj + x) / 8) != int(index / 8):
                        break
                if x == 7 or x == -9:
                    if tempObj % 8 == 0 or index % 8 == 0:
                        break
                if x == 9 or x == -7:
                    if tempObj % 8 == 7 or index % 8 == 7:
                        break
                positionsPassed.append(tempObj)
                tempObj += x
            if len(positionsPassed) > 0 and board[tempObj] == token:

                for z in positionsPassed:
                    switchedPositions.append(z)
        # print(switchedPositions)
        for pos in switchedPositions:
            copyBoard[pos] = token
        finalBoard = "".join(copyBoard)
        # printBoardShort(finalBoard)
        return finalBoard
    return board
def evalBoard(board, token):
    if token=='x': opptoken = 'o'
    else: opptoken='x'
    num = len([i for i, letter in enumerate(board) if letter == token])-len([a for a, letter in enumerate(board) if letter == opptoken])
    return num
def oppToken(token):
    if token=='x':return 'o'
    return 'x'
def negamax(board, token, levels):

        if not levels: return [evalBoard(board, token)]
        lm = possibleMoves(token,board)
        if not lm:
            mm = negamax(board, oppToken(token), levels - 1) + [1]
            return [-mm[0]] + mm[1:]
        else:
            nmList = sorted([negamax(move(mv,token,board), oppToken(token), levels - 1) + [mv] for mv in lm])
            best = nmList[0]
            return [-best[0]] + best[1:]

def forceMove(token,board):
    tempmvs = possibleMoves(token,board)
    badMoves = []
    for index in tempmvs[:]:
        newBrd = move(index,token,board)
        opp = oppToken(token)
        newPoss = possibleMoves(opp,newBrd)
        for corn in [0,7,56,63]:
            if corn in newPoss:
                badMoves.append(index)
    return badMoves

def possibleMoves(token,board):
    if token == 'x':
        opptoken = 'o'
    else:
        opptoken = 'x'
    poss = set()
    for index in [i for i, letter in enumerate(board) if letter == "."]:


        # left,right,up,down,diagupleft,diagupright,diagdownleft,diagdownright = index-1,index+1,index-8,index+8,index-9,index-7,index+7,index+9
        directions = [-1, 1, -8, 8, -9, -7, 7, 9]

        for x in directions:
            tempObj = index + x

            while 63 >= (tempObj + x) >= 0:
                if board[tempObj] == opptoken:
                    if x == 1 or x == -1:
                        if int((tempObj + x) / 8) != int(index / 8):
                            break
                    if x == 7 or x == -9:
                        if tempObj % 8 == 0 or index % 8 == 0:
                            break
                    if x == 9 or x == -7:
                        if tempObj % 8 == 7 or index % 8 == 7:
                            break
                    tempObj += x
                else: break
            if 63 >= (tempObj) >= 0 and board[tempObj] == token and tempObj!=index+x:
                poss.add(index)
                #print(index)
        # print(switchedPositions)


    return list(poss)
def finalMove(brd,player):

    mv = findBestMove(brd, player)
    print("beforeswitch" + str(mv))
    mv1 = 11 + (mv // 8) * 10 + (mv % 8)
    print("final" + str(mv1))
    return mv1
def main():
    #print("main")

    if len(sys.argv) == 1:
        board = "...........................ox......xo..........................."
        if len([i for i, letter in enumerate(board) if letter == "."]) % 2 == 0:
            token = 'x'
        else:
            token = 'o'

    elif len(sys.argv) == 2:
        board = sys.argv[1].lower()
        if len([i for i, letter in enumerate(board) if letter == "."]) % 2 == 0:
            token = 'x'
        else:
            token = 'o'
    else:
        board,token = sys.argv[1].lower(), sys.argv[2].lower()
    if token == '@':
        player = 'x'
    else:
        player = 'o'
    #print("fixing board")
    #start = time.time()

    if len([i for i, letter in enumerate(board) if letter == "."]) > 8:
       
        #while time.time()-start<4900:
        if len([i for i, letter in enumerate(board) if letter == "."])>54:
            mv = alphabeta(token, board, -9999, 9999, 5)[1]
        elif len([i for i, letter in enumerate(board) if letter == "."])>50:
            mv = alphabeta(token, board, -9999, 9999, 4)[1]
        elif len([i for i, letter in enumerate(board) if letter == "."])>26:
            mv = alphabeta(token, board, -9999, 9999, 3)[1]
        elif len([i for i, letter in enumerate(board) if letter == "."])>16:
            mv = alphabeta(token, board, -9999, 9999, 4)[1]
        elif len([i for i, letter in enumerate(board) if letter == "."])>8:
            mv = alphabeta(token, board, -9999, 9999, 5)[1]

        # elif len([i for i, letter in enumerate(board) if letter == "."])>32:
        #     mv = alphabeta(token, board, -9999, 9999, 3)[1]
        # elif len([i for i, letter in enumerate(board) if letter == "."]) > 20:
        #     mv = alphabeta(token, board, -9999, 9999, 3)[1]
        # elif len([i for i, letter in enumerate(board) if letter == "."])>12:
        #     mv = alphabeta(token, board, -9999, 9999, 5)[1]
        #
        # else:
        #     mv = alphabeta(token, board, -9999, 9999, 6)[1]




    else:
        mv = negamax(board, token, 8)[-1]
    print(mv)



        #print(alphabeta(player,board,-9999,9999,5))
    #print("\n".join([board[i:i + 8] for i in range(0, 64, 8)]))
    #print("possible moves: " + str(possibleMoves(player, board)))
    #if len([i for i, letter in enumerate(board) if letter == "."]) > 8:
        #print("heuristic: " + str(findBestMove(board, player)))
    #else:
        #print("heuristic: " + str(findBestMove(board, player)))
        #nm = negamax(board, player, 9)
        #print("negamax: " + str(nm))
def findBestMove(table,token):
    xplaces = [1,8,9,6,14,15,48,49,57,55,54,62]

    return alphabeta(token,table, 3000, -9999, 9999)





def negamaxTerminal (brd, token, improvable, hardbound):
    lm = possibleMoves(token,brd)
    if not lm:
        olm = possibleMoves(brd, oppToken(token))
        if not olm:
            return [evalBoard(brd,token),-3]  ##The -3 means game is over
        nm = negamaxTerminal(brd, oppToken(token), -hardbound, -improvable) + [-1]
        return [-nm[0]] + nm[1:]
    else:
        best = []  #what gets returned
        newHB = -improvable
        for mv in lm:
            nm = negamaxTerminal(move(mv, token,brd), oppToken(token), -hardbound, newHB) + [mv]
            if not best or nm[0] < newHB:    #######Both nm[0] && newHB are negative
                best = nm
                if nm[0] < newHB:
                    newHB = nm[0]
                    if -newHB > hardbound: return [-best[0]] + best[1:]
        return [-best[0]] + best[1:]
def stability(board,token):
    sum = 0
    directions = [[-1,1],[-8,8]]
    for pos in range(len(board)):
        if board[pos]==token:
            if pos in corners:
                sum+=10
            else:
                if pos in edges:
                    sum+=1
                tempPos = pos
                if tempPos%8==0 or tempPos%8==7:
                    for dir in directions[1]:
                        tempPos+=dir
                        while 0<=tempPos<=63 and tempPos==token:
                            tempPos+=dir
                        if tempPos in corners:
                            sum+=2
                if tempPos%8==0 or tempPos%8==7:
                    for dir in directions[0]:
                        tempPos+=dir
                        while 0<=tempPos<=63 and tempPos==token:
                            tempPos+=dir
                        if tempPos in corners:
                            sum+=2

        elif board[pos]==oppToken(token):
            if pos in corners:
                sum-=100
            if pos in edges:
                sum-=3
    return sum

def negamaxTerminalLevels(brd, token, improvable, hardbound,levels):
    lm = possibleMoves(token,brd)
    if levels==0:
        return stability(brd,token)
    if not lm:
        olm = possibleMoves(brd, oppToken(token))
        if not olm:
            return [evalBoard(brd,token),-3]  ##The -3 means game is over
        nm = negamaxTerminalLevels(brd, oppToken(token), -hardbound, -improvable,levels-1) + [-1]
        return [-nm[0]] + nm[1:]
    else:
        best = []  #what gets returned
        newHB = -improvable
        for mv in lm:
            nm = negamaxTerminalLevels(move(mv, token,brd), oppToken(token), -hardbound, newHB,levels-1) + [mv]
            if not best or nm[0] < newHB:    #######Both nm[0] && newHB are negative
                best = nm
                if nm[0] < newHB:
                    newHB = nm[0]
                    if -newHB > hardbound: return [-best[0]] + best[1:]
        return [-best[0]] + best[1:]


def alphabeta(player, board, alpha, beta, depth):
    def value(board, alpha, beta):
        return -alphabeta(oppToken(player), board, -beta, -alpha, depth - 1)[0]
    if depth == 0:
        return stability(board, player), None
    moves = possibleMoves(player, board)
    if not moves:
        if len(possibleMoves(oppToken(player), board))==0:
            return stability(board,player), None
        return value(board, alpha, beta), None

    best_move = moves[0]
    for ind in moves:
        if alpha >= beta:
            break
        val = value(move(ind, player, list(board)), alpha, beta)
        if val > alpha:
            alpha = val
            best_move = ind

    return alpha, best_move


if __name__=='__main__':
    main()
