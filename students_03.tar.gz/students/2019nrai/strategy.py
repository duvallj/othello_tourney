#Jan 12, 0952 version

import random
import math


#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N,S,E,W = -10, 10, 1, -1
NE, SE, NW, SW = N+E, S+E, N+W, S+W
DIRECTIONS = (N,NE,E,SE,S,SW,W,NW)
PLAYERS = {BLACK: WHITE, WHITE: BLACK}
SCORING_MATRIX = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 120, -30,  20,   5,   5,  20, -30, 120,   0,
    0, -30, -50,  -5,  -5,  -5,  -5, -50, -30,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -30, -50,  -5,  -5,  -5,  -5, -50, -30,   0,
    0, 120, -30,  20,   5,   5,  20, -30, 120,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################
class Node:
    def __init__(self, board, move):
        self.board = board
        self.move = move
        self.score = 0

class Strategy():
    board = ""
    def __init__(self):
        pass
    def squares(self):
        return [i for i in range(11, 89) if 1 <= (i % 10) <= 8]
    def get_starting_board(self):
        #self.board = "???????????.........??........??........??...o@...??...@o...??........??........??.......???????.?@?"
        self.board = "???????????........??........??........??...o@...??...@o...??........??........??........???????????"
        return self.board
        """Create a new board with the initial black and white positions filled."""
        


    def get_pretty_board(self, board):
        toRet = ""
        for i in range(0, 100, 10):
            toRet += board[i:i+10] + "\n"
        return toRet
        #return board
        """Get a string representation of the board."""

    def opponent(self, player):
        if player == WHITE:
            return BLACK
        else:
            return WHITE
        """Get player's opponent."""


    def find_match(self, board, player, square, direction):
        # bool = False
        # if 0 > square+direction or square+direction > 64:
        #     return False
        # if board[square + direction] != self.opponent(player):
        #     return True
        # start = 0
        # while bool:
        #     start += direction
        #     if board[square + start] == OUTER or board[square + start] == player:
        #         print("failed")
        #         return False
        #     elif board[square + start] == EMPTY:
        #         print("found index")
        #         return True
        #     elif board[square + start] == self.opponent(player):
        #         print("still moving")
        s = square+direction
        if (board[s] == PLAYERS[player]):
            while(board[s] == PLAYERS[player]):
                s+=direction
                if(board[s] == EMPTY):
                    return s
        return None
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """


    def is_move_valid(self, board, player, move):
        list = self.get_valid_moves(board,player)
        for i in list:
            if(move == i):
                return True
        return False
        """Is this a legal move for the player?"""

    def find_match_2(self, board,player,square,direction):
        bool = False
        dire = direction
        opp = self.opponent(player)
        if(board[square+dire] == player or board[square+dire] == EMPTY or board[square+dire] == OUTER):
            return False
        while(bool==False):
            dire+=direction
            if(board[square+dire] == EMPTY):
                return False
            elif(board[square+dire] == OUTER):
                return False
            elif(board[square + dire] == player):
                return True
    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        # returns a new board/string
        # opp = self.opponent(player)
        # for i in range(8):
        #     dire = DIRECTIONS[i]
        #     d = 0
        #     if self.is_move_valid(board,player,move):
        #         d+=dire
        #         while board[move + d] == opp:
        #             board = board[0:move+d] + player + board[move+d+1:]
        # return board
        board = board[0:move] + player + board[move+1:]
        opp = self.opponent(player)
        for direc in DIRECTIONS:
            dire = 0
            s = self.find_match_2(board,player,move,direc)
            dire+=direc
            if (s== False):
                continue
            else:
                while board[move + dire] == opp:
                    board = board[0:move+dire] + player + board[move+dire+1:]
                    dire += direc
        return board



    def get_valid_moves(self,board,player):
        l = []
        for i in range(len(board)):
            #print(i)
            if board[i] == player:
                for dir in DIRECTIONS:
                    s = self.find_match(board,player,i,dir)
                    if s!= None:
                        l.append(s)
        return l
        """Get a list of all legal moves for player."""

    def has_any_valid_moves(self, board, player):
        list = self.get_valid_moves(board,player)
        if(len(list) == 0):
            return False
        return True
        """Can player make any moves?"""

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        opp = self.opponent(prev_player)
        if(self.has_any_valid_moves(board,opp) == True):
            return opp
        elif(self.has_any_valid_moves(board,prev_player) == True):
            return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        count = 0
        for i in range(100):
            if(board[i] == player):
                count+=1
        return count
    def weighted_score(self, player, board):
        opp = self.opponent(player)
        total = 0
        for i in range(len(board)):
            if board[i] == player:
                total += SCORING_MATRIX[i]
            elif board[i] == opp:
                total -= SCORING_MATRIX[i]
        return total


    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if (self.next_player(board,player) == None):
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        board = node.board
        if depth < 1:
            node.score = self.score(board,player)
            return node
        my_moves = self.get_valid_moves(board,player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board,player,move)
            next_player = self.next_player(next_board,player)
            c = Node(next_board,move)
            if next_player is None:
                c.score = self.score(next_board,player)*1000
                children.append(c)
            else:
                c.score = self.minmax_search(c,next_player,depth = depth - 1).score
                children.append(c)
            # if(player == BLACK):
            #     alpha = max(alpha,c.score)
            # if(player == WHITE):
            #     beta = min(beta,c.score)
            # if alpha >= beta:
            #     break
        if player == BLACK:
            winnerB = max(children, key = lambda x: x.score)
            node.score = winnerB.score
            #print(winnerB)
            return winnerB
        if player == WHITE:
            winnerW= min(children, key = lambda x: x.score)
            node.score = winnerW.score
           # print(winnerW)
            return winnerW
    def alphabeta_searcher(self,node,player,depth,alpha,beta):
        board = node.board
        if depth < 1:
            node.score = self.score(board,player)
            return node
        my_moves = self.get_valid_moves(board,player)
        children = []
        for move in my_moves:
            next_board = self.make_move(board,player,move)
            next_player = self.next_player(next_board,player)
            c = Node(next_board,move)
            if next_player is None:
                c.score = self.weighted_score(next_board,player)*1000
                children.append(c)
            else:
                c.score = self.alphabeta_searcher(c,next_player,depth - 1,alpha,beta).score
                children.append(c)
                if(player == BLACK):
                    alpha = max(alpha,c.score)
                if(player == WHITE):
                    beta = min(beta,c.score)
                if alpha >= beta:
                    break
        if player == BLACK:
            winnerB = max(children, key = lambda x: x.score)
            node.score = winnerB.score
            #print(winnerB)
            return winnerB
        if player == WHITE:
            winnerW= min(children, key = lambda x: x.score)
            node.score = winnerW.score
           # print(winnerW)
            return winnerW

    def minmax_strategy(self, board, player, depth=4):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(Node(board, -1), player,depth).move

    def alphabeta_strategy(self,board,player,alpha=-math.inf,beta=math.inf,depth=4):
        return self.alphabeta_searcher(Node(board, -1), player,depth,alpha,beta).move

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        board = ''.join(board)
        depth = 1
        while(True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alphabeta_strategy(board, player,depth)
            depth += 1

    standard_strategy = alphabeta_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal
silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()

        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.alphabeta_strategy, WHITE: white.minmax_strategy}
        print(ref.get_pretty_board(board))

        while player is not None:
            if ref.has_any_valid_moves(board, player):
                move = strategy[player](board, player)
                print("Player %s chooses %i" % (player, move))
                board = ref.make_move(board, player, move)
                print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board)>0 else "White"))



#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():

    def __init__(self, time_limit = 5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)

            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent:print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(board, player, move)
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

if __name__ == "__main__":
    #game =  ParallelPlayer(0.1)
    game = StandardPlayer()
    game.play()
