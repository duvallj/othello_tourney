import random
import math

#### Othello Shell
#### P. White 2016-2018
##https://activities.tjhsst.edu/othello/play

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, S, SE, E, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}


########## ########## ########## ########## ########## ##########
# The strategy class for your AI
# You must implement this class
# and the method best_strategy
# Do not tamper with the init method's parameters, or best_strategy's parameters
# But you can change anything inside this you want otherwise
#############################################################

class Node:
    score = -99.0
    board = ""
    children = []
    move = 0
    taken = 0
    mavg = 0

    def __init__(self, b, m, s):
        self.score = s
        self.board = b
        self.move = m
        self.taken = 0
        self.mavg = 0.0
        self.children = []

    def __lt__(self, other):
        return self.score < other.score


class Strategy():
    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        b = []
        for z in range(0, 10):
            b.append(OUTER)
        for p in range(0, 8):
            b.append(OUTER)
            if p == 3:
                b = self.add(b, EMPTY, 3)
                b.append(WHITE)
                b.append(BLACK)
                b = self.add(b, EMPTY, 3)
            elif p == 4:
                b = self.add(b, EMPTY, 3)
                b.append(BLACK)
                b.append(WHITE)
                b = self.add(b, EMPTY, 3)
            else:
                b = self.add(b, EMPTY, 8)  # [EMPTY for j in range(0, 8)]
            b.append(OUTER)
        for o in range(0, 10):
            b.append(OUTER)
        return ''.join(b)

    def add(self, b, a, n):
        for i in range(0, n):
            b.append(a)
        return b

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        b = list(board)
        c = 0
        for i in range(0, 10):
            s = ""
            for j in range(c, c + 10):
                s = s + b[j]
            c += 10
            print(s)
        return board  # when i finish program for upload, delete part above

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        else:
            return BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        overtakes = []
        b = list(board)
        tr = square + direction
        while b[tr] == self.opponent(player):
            overtakes.append(tr)
            tr = tr + direction
        if b[tr] != player:  # end should be friendly piece
            return None
        return overtakes

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        b = list(board)
        for i in DIRECTIONS:
            p = move + i
            if b[p] == self.opponent(player):
                if self.find_match(board, player, move, i) != None:
                    return True

    def make_move(self, node, player):
        k = list(node.board)
        k[node.move] = player
        for i in DIRECTIONS:
            overtakes = self.find_match(node.board, player, node.move, i)
            if overtakes != None:
                for i in overtakes:
                    k[i] = player
                    node.taken += 1
        node.board = ''.join(k)
        return node

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""
        t = []
        b = list(board)
        for i in range(0, len(b)):
            if b[i] == '.':
                if self.is_move_valid(board, player, i) == True:  # starts at top of board down
                    t.append(i)
        return t

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        if self.get_valid_moves(board, player) == []:
            return False
        return True

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        if self.has_any_valid_moves(board, self.opponent(prev_player)) == True:
            return self.opponent(prev_player)
        if self.has_any_valid_moves(board, prev_player) == True:
            return prev_player
        return None

    def weighted_score(self, board, player):
        weight = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 1000.02, -57, 0.55, -0.10, 0.08, 0.47, -58, 1000.00, 0,
                  0, -63, -552, -18, -7, -18, -29, -568, -74, 0,
                  0, 55, -0.24, 0.02, -0.01, -0.01, 0.10, -0.13, 77, 0,
                  0, 31, -0.10, 0.01, -0.01, 0.00, -0.01, -0.09, 55, 0,
                  0, 51, -0.17, 0.02, -0.04, -0.03, 0.03, -0.09, 32, 0,
                  0, 56, -0.25, 0.05, 0.02, -0.02, 0.17, -0.35, 42, 0,
                  0, -75, -571, -24, -23, -18, -29, -563, -74, 0,
                  0, 930, -44, 55, 22, -0.15, 74, -57, 970, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        bscore = 0.0
        wscore = 0.0
        for j in range(0, len(weight)):
            if board[j] == BLACK:
                bscore += weight[j]
            elif board[j] == WHITE:
                wscore += weight[j]
        return bscore - wscore

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        return board.count(player) - board.count(self.opponent(player))

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        if self.has_any_valid_moves(board, player) == False and self.has_any_valid_moves(board, self.opponent(
                player)) == False:
            return True
        return False

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, node, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board, player)
            return node
        moves = self.get_valid_moves(board, player)
        children = []
        for m in moves:
            newnode = Node(board, m, -99)
            newnode = self.make_move(newnode, player)
            nextb = newnode.board
            nextp = self.next_player(nextb, player)
            if nextp == None:
                sc = 1000 * self.score(nextb, player)
                n = Node(nextb, m, sc)
                children.append(n)
            else:
                n = Node(nextb, m, -99)
                n.score = self.minmax_search(n, nextp, depth=depth - 1).score
                children.append(n)
        winner = None
        if player == WHITE:
            winner = min(children, key=lambda x: x.score)
        if player == BLACK:
            winner = max(children, key=lambda x: x.score)
        node.score = winner.score
        return winner

    def minmax_strategy(self, board, player, depth):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        node = Node(board, -99, -99)
        # depth = 2
        m = self.minmax_search(node, player, depth).move
        return m

    def playrandom(self, b, player):
        board = b
        while player is not None:
            move = self.random_strategy(board, player)
            print("Player %s chooses %i" % (player, move))
            board = self.make_move(Node(board, move, -99), player).board
            player = self.next_player(board, player)
        # account if win return +1/-1 for white
        return self.score(board)

    def main_strategy(self, board, player, depth):
        node = Node(board, -99, -99.0)
        depth = 3
        m = self.main_search(node, player, depth)
        return m

    def main_search(self, node, player, depth):
        bnum = node.board.count(BLACK)
        wnum = node.board.count(WHITE)
        # percent = ((bnum + wnum) / 64) * 100
        return self.greedy_strategy(node.board, player, depth)

    def alpha_beta_strategy(self, board, player, depth):
        node = Node(board, -99, -99)
        # depth=1
        m = self.alpha_beta_search(node, -math.inf, math.inf, player, depth).move
        return m

    def isEdge(self, m):
        if m == 11 or m == 18 or m == 81 or m == 88:
            return True
        return False

    def clearInsides(self, board, choices):
        b = list(board)
        #random.shuffle(choices)
        for m in choices:
          if len(choices) > 1:
            if m == 22 or m == 27 or m == 72 or m == 77:
                choices.remove(m)
            '''if m == 12 or m == 82:
                if b[m - 1] == EMPTY:
                    choices.remove(m)
            if m == 21 or m == 28:
                if b[m - 10] == EMPTY:
                    choices.remove(m)
            if m == 17 or m == 87:
                if b[m + 1] == EMPTY:
                    choices.remove(m)
            if m == 78 or m == 71:
                if b[m + 10] == EMPTY:
                    choices.remove(m)'''
        return choices

    def alpha_beta_search(self, node, alpha, beta, player, depth):  # go to edge if possible ignore others
        board = node.board
        if depth == 0:
            node.score = self.weighted_score(board, player)
            return node
        moves = self.get_valid_moves(board, player)
        children = []
        moves = self.clearInsides(board, moves)
        for m in moves:  # look at overtakes for patterns
            newnode = Node(board, m, -99.0)
            newnode = self.make_move(newnode, player)
            if self.isEdge(m):
                return newnode
            if alpha >= beta:
                break
            nextb = newnode.board
            nextp = self.next_player(nextb, player)
            if nextp == None:
                num = 1000
                if player == WHITE:
                    num = -1000
                sc = num * self.score(nextb, player)
                n = Node(nextb, m, sc)
                children.append(n)
            else:
                g = Node(nextb, m, -99.0)
                g.score = self.alpha_beta_search(g, -beta, -alpha, nextp, depth=depth - 1).score
                if player == BLACK:
                    if g.score > alpha:
                        alpha = g.score
                children.append(g)
        if player == WHITE:
            node = min(children, key=lambda x: x.score)
        if player == BLACK:
            node = max(children, key=lambda x: x.score)
        return node

    def greedy_strategy(self, board, player, depth):
        node = Node(board, -99, -99.0)
        # depth=1
        m = self.greedy_search(node, -math.inf, math.inf, player, depth).move
        return m

    def greedy_search(self, node, alpha, beta, player, depth):
        board = node.board
        moves = self.get_valid_moves(board, player)
        children = []
        for m in moves:
            newnode = Node(board, m, -99.0)
            newnode = self.make_move(newnode, player)
            if self.isEdge(m):
                if player==BLACK:
                    newnode.score = 1000000
                else:
                    newnode.score = -1000000
                return newnode
        if depth == 0:
            node.score = self.weighted_score(board, player)
            return node
        #moves = self.clearInsides(board, moves)
        '''if len(moves)==1:
            newnode = Node(board, moves[0], -99.0)
            newnode = self.make_move(newnode, player)
            return newnode'''
        for m in moves:
            #if m != 22 and m != 27 and m != 72 and m != 77:
                newnode = Node(board, m, -99.0)
                newnode = self.make_move(newnode, player)
                if alpha >= beta:
                    break
                nextb = newnode.board
                nextp = self.next_player(nextb, player)
                if nextp == None:
                    sc = 100000 * self.score(nextb, player)
                    n = Node(nextb, m, sc)
                    children.append(n)
                else:  # multiplier based on how many taken
                    g = Node(nextb, m, -99.0)
                    g.score = self.greedy_search(g, -beta, -alpha, nextp, depth=depth - 1).score
                    if player == BLACK:
                        if g.score > alpha:
                            alpha = g.score
                    children.append(g)
        #if len(children)==0:
            #for m in moves:
        if player == WHITE:
            node = min(children, key=lambda x: x.score)
        if player == BLACK:
            node = max(children, key=lambda x: x.score)
        return node

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move,
                      still_running):  # more position based at game start-> more how many took based at game end
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            # best_move.value = self.minmax_strategy(board, player, depth)
            best_move.value = self.main_strategy(board, player, depth)
            '''if player==WHITE:
                best_move.value = self.minmax_strategy(board, player, depth)  # change strategy here
            if player==BLACK:
                best_move.value = self.alpha_beta_strategy(board, player, depth)#  change strategy here'''
            depth += 1

    standard_strategy = main_strategy


###############################################
# The main game-playing code
# You can probably run this without modification
################################################
import time
from multiprocessing import Value, Process
import os, signal

silent = False


#################################################
# StandardPlayer runs a single game
# it calls Strategy.standard_strategy(board, player)
#################################################
class StandardPlayer():
    def __init__(self):
        pass

    def play(self):
        ### create 2 opponent objects and one referee to play the game
        ### these could all be from separate files
        ref = Strategy()
        black = Strategy()
        white = Strategy()
        print("Playing Standard Game")
        board = ref.get_starting_board()
        player = BLACK
        strategy = {BLACK: black.standard_strategy, WHITE: white.standard_strategy}
        # print(ref.get_pretty_board(board))
        ref.get_pretty_board(board)
        co = 1
        while player is not None:
            move = strategy[player](board, player, co)
            print("Player %s chooses %i" % (player, move))
            board = ref.make_move(Node(board, move, -99.0), player).board
            co += 1
            # print(ref.get_pretty_board(board))
            ref.get_pretty_board(board)
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))


#################################################
# ParallelPlayer simulated tournament play
# With parallel processes and time limits
# this may not work on Windows, because, Windows is lame
# This calls Strategy.best_strategy(board, player, best_shared, running)
##################################################
class ParallelPlayer():
    def __init__(self, time_limit=5):
        self.black = Strategy()
        self.white = Strategy()
        self.time_limit = time_limit

    def play(self):
        ref = Strategy()
        print("play")
        board = ref.get_starting_board()
        player = BLACK

        print("Playing Parallel Game")
        strategy = lambda who: self.black.best_strategy if who == BLACK else self.white.best_strategy
        while player is not None:
            best_shared = Value("i", -99)
            best_shared.value = -99
            running = Value("i", 1)
            p = Process(target=strategy(player), args=(board, player, best_shared, running))
            # start the subprocess
            t1 = time.time()
            p.start()
            # run the subprocess for time_limit
            p.join(self.time_limit)
            # warn that we're about to stop and wait
            running.value = 0
            time.sleep(0.01)
            # kill the process
            p.terminate()
            time.sleep(0.01)
            # really REALLY kill the process
            if p.is_alive(): os.kill(p.pid, signal.SIGKILL)
            # see the best move it found
            move = best_shared.value
            if not silent: print("move = %i , time = %4.2f" % (move, time.time() - t1))
            if not silent: print(board, ref.get_valid_moves(board, player))
            # make the move
            board = ref.make_move(Node(board, move, -99.0), player).board
            if not silent: print(ref.get_pretty_board(board))
            player = ref.next_player(board, player)

        print("Final Score %i." % ref.score(board), end=" ")
        print("%s wins" % ("Black" if ref.score(board) > 0 else "White"))

# if __name__ == "__main__":
#game = StandardPlayer()
#game = ParallelPlayer(2)
#game.play()

