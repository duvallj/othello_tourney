import sys, time

trans_table = {}
move_cache = {}
new_cache = {}

class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        in_board = ''.join(board).replace('?', '').replace('@', 'x').lower()
        turn = player == '@'
        start_x, start_y = int(in_board.replace('o', '0').replace('.', '0').replace('x', '1'), 2), int(in_board.replace('x', '0').replace('.', '0').replace('o', '1'), 2)
        if turn:
            for i in range(1, 100):
                value, move = transpo(start_x, start_y, i)
                move = convert_index(move[-1])
                best_move.value = 11+(move//8)*10+(move%8)
        else:
            for i in range(1, 100):
                value, move = transpo(start_y, start_x, i)
                move = convert_index(move[-1])
                best_move.value = 11+(move//8)*10+(move%8)

def main():
    start_x, start_y, turn = parse_board()
    if turn:
        for i in range(1, 100):
            value, move = transpo(start_x, start_y, i)
            print(convert_index(move[-1]))
    else:
        for i in range(1, 100):
            value, move = transpo(start_y, start_x, i)
            print(convert_index(move[-1]))

def parse_board():
    if len(sys.argv) == 2:
        try: in_board = ''.join(sys.argv[1]).lower().replace('?', '').replace('@', 'x')
        except: in_board = sys.argv[1].lower()
        return int(in_board.replace('o', '0').replace('.', '0').replace('x', '1'), 2), int(in_board.replace('x', '0').replace('.', '0').replace('o', '1'), 2), 1^(in_board.count('.')&1)
    elif len(sys.argv) == 3:
        in_board = sys.argv[1].lower()
        turn = sys.argv[2].lower()
        return int(in_board.replace('o', '0').replace('.', '0').replace('x', '1'), 2), int(in_board.replace('x', '0').replace('.', '0').replace('o', '1'), 2), turn == 'x'
    else: return 0b10000001 << 28, 0b1000000001 << 27, True #converts input to x board, y board, turn

def set_bits(binInt):
    while binInt:
        yield binInt&-binInt
        binInt &= binInt-1 #generator that returns deconstructed binInt

def order_bits(current, other, moves):
    moves = []
    for move in set_bits(moves):
        new_c, new_o = make_move(current, other, move)
        moves.append((board_score(new_c, new_o), move))
    return [i[1] for i in sorted(moves)]

def display(X=0, O=0, move=0, moves=0):
    display_board = ''
    for x, o, m in zip('{0:064b}'.format(X), '{0:064b}'.format(O), '{0:064b}'.format(moves)):
        if x == '1':
            display_board += 'X'
        elif o == '1':
            display_board += 'O'
        elif m == '1':
            display_board += '*'
        else:
            display_board += '.'
    for i in range(9):
        print(display_board[(i-1)*8 : i*8])
    print(convert_index(move))#converts and prints move from bit representation to index representation

def convert_index(move):
    return 63-(move.bit_length()-1)

def transpo(current, other, depth, a=float('-inf'), b=float('inf'), passes=0):
    global trans_table
    a_o = a; b_o = b
    if (current, other) in trans_table and trans_table[(current, other)]['d'] >= depth:
        entry = trans_table[(current, other)]
        if entry['f'] == 0:
            return entry['v'], entry['m']
        elif entry['f'] == -1:
            a = max(a, entry['v'])
        elif entry['f'] == 1:
            b = min(b, entry['v'])
        if a >= b:
            return entry['v'], entry['m']
    if passes == 2:
        return 1000000 * dumb_score(current, other), []
    if not depth:
        return board_score(current, other), []
    current_moves = find_moves(current, other)
    if not current_moves:
        best, move_list = transpo(other, current, depth-1, -b, -a, passes+1)
        return -best, move_list
    best_value = float('-inf')
    best_move_list = []
    for move in set_bits(current_moves):
        new_current, new_other = make_move(current, other, move)
        value, move_list = transpo(new_other, new_current, depth-1, -b, -a,)
        value = -value
        if value > best_value:
            best_value = value
            best_move_list = move_list + [move]
        if a >= b:
            break
    entry = {}
    entry['v'] = best_value
    if best_value <= a_o:
        entry['f'] = 1
    elif best_value >= b_o:
        entry['f'] = -1
    else:
        entry['f'] = 0
    entry['d'] = depth
    entry['m'] = best_move_list
    trans_table[(current, other)] = entry
    return best_value, best_move_list

def negascout(current, other, depth, a=float('-inf'), b=float('inf'), passes=0):
    if passes == 2:
        return 1000000 * dumb_score(current, other), []
    if not depth:
        return board_score(current, other), []
    moves = find_moves(current, other)
    if not moves:
        score, moveset = transpo(other, current, depth-1, -b, -a, passes+1)
        return -score, moveset
    moveset = []
    for index, move in enumerate(order_bits(current, other,  moves)):
        if index == 0:
            score, moveset = -negascout(other, current, depth-1, -b, -a)
            moveset += [move]
        else:
            score, moveset = -negascout(other, current, depth-1, -a-1, -a)
            moveset += [move]
            if a < score < b:
                score, moveset = -negascout(other, current, depth-1, -b, -score)
                moveset += [move]
        a = max(a, score)
        if a >= b:
            break
    return a, moveset

def max_move(current, other):
    scores = [(board_score(current, other, move), move) for move in set_bits(find_moves(current, other))]
    return max(scores)[1]#returns move with highest board_score

def board_score(current, other, move=0):
    evals = [heuristic_tokens, heuristic_moves, heuristic_stable, heuristic_x, heuristic_corners]
    weight = [1, 200, 98, 200, 1000000000000]
    if move:
        current, other = make_move(current, other, move)
    count = 0
    for w, f in zip(weight, evals):
        count += w * f(current, other)
    if other == 0:
        return float('inf')
    return count #evaluates board based on weighted heuristics #

def dumb_score(current, other, move=-1):
    return heuristic_tokens(current, other)

def make_move(current, other, move):
    global new_cache
    if (current, other, move) in new_cache:
        return new_cache[(current, other, move)]
    else:
        flips = all_flips(current, other, move)
        return current|flips|move, other^flips #makes move and implements flip on current and other, returns new current and new other

def heuristic_corners(current, other):
    return bin(current&0x8100000000000081).count('1')-bin(other&0x8100000000000081).count('1') #returns current's corners - other's corners

def heuristic_stable(current, other):
    return bin(stable_pieces(current)).count('1') - bin(stable_pieces(other)).count('1') #returns current stable pieces - other stable pieces

def heuristic_x(current, other):#returns other unsafe x - current unsafe x
    return unsafe_x(current)-unsafe_x(other)

def heuristic_c(current, other):
    return unsafe_c(current)-unsafe_c(other)

def heuristic_tokens(current, other):
    return bin(current).count('1')-bin(other).count('1')

def heuristic_moves(current, other):
    return bin(find_moves(current, other)).count('1')-bin(find_moves(other, current)).count('1') #returns current moves - other moves

def stable_pieces(current):
    top = 0x00000000000000FF; left = 0x0101010101010101; right = 0x8080808080808080; bottom = 0xFF00000000000000
    topr = top | right; topl = top | left; botr = bottom | right; botl = bottom | left
    stable = 0
    while True:
        topbot_c = some_stable(current, stable, top, bottom, 8)
        leftright_c = some_stable(current, stable, left, right, 1)
        diag1_c = some_stable(current, stable, topr, botl, 7)
        diag2_c = some_stable(current, stable, topl, botr, 9)
        newstable = (topbot_c) & (leftright_c) & (diag1_c) & (diag2_c)
        if not (newstable ^ stable): break
        stable |= newstable
    return stable #returns # of stable pieces on board (based on adjacency on parsing axis)

def some_stable(current, stable, pos, neg, shift):
    return (((stable >> shift) | pos) | ((stable << shift) | neg)) & current #does local adjacency check on axis and position

def unsafe_x(current):
    count = 0
    if (1 << 9) & current and not (1 << 0) and current: count += 1
    if (1 << 14) & current and not (1 << 7) and current: count += 1
    if (1 << 49) & current and not (1 << 56) and current: count += 1
    if (1 << 54) & current and not (1 << 63) and current: count += 1
    return count #returns number of unsaf #returns # of unsafe x squares occupied

def unsafe_c(current):
    count = 0
    if (1 << 1) & current and not (1 << 0) and current: count += 1
    if (1 << 6) & current and not (1 << 7) and current: count += 1
    if (1 << 8) & current and not (1 << 0) and current: count += 1
    if (1 << 15) & current and not (1 << 7) and current: count += 1
    if (1 << 48) & current and not (1 << 56) and current: count += 1
    if (1 << 57) & current and not (1 << 56) and current: count += 1
    if (1 << 55) & current and not (1 << 63) and current: count += 1
    if (1 << 62) & current and not (1 << 63) and current: count += 1
    return count

def local_moves (current, other_e, shift):
    level = ((current << shift) | (current >> shift)) & other_e
    level |= ((level << shift) | (level >> shift)) & other_e
    level |= ((level << shift) | (level >> shift)) & other_e
    level |= ((level << shift) | (level >> shift)) & other_e
    level |= ((level << shift) | (level >> shift)) & other_e
    level |= ((level << shift) | (level >> shift)) & other_e
    return (level << shift) | (level >> shift) #helper function to find local moves along axis

def find_moves(current, other):
    global move_cache
    if (current, other) in move_cache:
        return move_cache[(current, other)]
    other_e = other & 0x7E7E7E7E7E7E7E7E
    full = 0xFFFFFFFFFFFFFFFF
    moves = local_moves(current, other_e, 1) | local_moves(current, other, 8) | local_moves(current, other_e, 7) | local_moves(current, other_e, 9)
    final_moves = moves & (full ^ (current|other)) #finds all moves for board for current
    move_cache[(current, other)] = final_moves
    return final_moves

def some_flips(current, other_e, shift, move):
    level_c = ((current << shift) | (current >> shift)) & other_e
    level_m = ((move << shift) | (move >> shift)) & other_e
    level_c |= ((level_c << shift) | (level_c >> shift)) & other_e
    level_m |= ((level_m << shift) | (level_m >> shift)) & other_e
    level_c |= ((level_c << shift) | (level_c >> shift)) & other_e
    level_m |= ((level_m << shift) | (level_m >> shift)) & other_e
    level_c |= ((level_c << shift) | (level_c >> shift)) & other_e
    level_m |= ((level_m << shift) | (level_m >> shift)) & other_e
    level_c |= ((level_c << shift) | (level_c >> shift)) & other_e
    level_m |= ((level_m << shift) | (level_m >> shift)) & other_e
    level_c |= ((level_c << shift) | (level_c >> shift)) & other_e
    level_m |= ((level_m << shift) | (level_m >> shift)) & other_e
    return level_c & level_m #helper function to create flip int on single axis

def all_flips(current, other, move):
    other_e = other & 0x7E7E7E7E7E7E7E7E
    full = 0xFFFFFFFFFFFFFFFF
    moves = some_flips(current, other_e, 1, move) | some_flips(current, other, 8, move) | some_flips(current, other_e, 7, move) | some_flips(current, other_e, 9, move)
    return moves #returns flip int for all 4 axes

if __name__ == '__main__':
    main()
