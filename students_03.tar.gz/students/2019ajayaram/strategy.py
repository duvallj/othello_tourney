
#Name: Anupama Jayaraman        Period: 1
import Othello_Core
import sys
from copy import deepcopy

EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
PLAYERS = {BLACK: 'Black', WHITE: 'White'}

posVals = [
        12, -2, 2, .5, .5, 2, -2, 12,
        -2, -4, -.5, -.5, -.5, -.5, -4, -2,
        2, -.5, 1.5, .3, .3, 1.5, -.5, 2,
        .5, -.5, .3, .3, .3, .3, -.5, .5,
        .5, -.5, .3, .3, .3, .3, -5., .5,
        2, -.5, 1.5, .3, .3, 1.5, -.5, 2,
        -2, -4, -.5, -.5, -.5, -.5, -4, -2,
        12, -2, 2, .5, .5, 2, -2, 12
    ]

class Strategy (Othello_Core.OthelloCore):

    def best_strategy(self, board, player, best_move, still_running):
        depth = 1
        best_move.value = 0
        self.tempAddBoard = None
        while(True):
            best_move.value = self.my_search_strategy(board, player, depth)
            depth += 1

    def my_search_strategy(self, board, player, depth):
        b = []
        count = 0
        for elem in board:
            if elem!='?':
                b.append(elem)
            count+=1
        brd = self.setup(b)

        pl = player
        #pl = self.getOpP(self.get_player(player))
        #if (pl=='@'):
        #    pl = self.getOpP(pl)
        bTemp = self.moves(brd, pl)

        if len(bTemp) == 0:
            return 0

        vals = []
        for bT in bTemp:
            vals.append(self.alphabeta(bT[2], depth, -sys.maxsize - 1, sys.maxsize, self.getOpP(pl), pl))
        mVal = max(vals)
        ind = vals.index(mVal)

        row = bTemp[ind][0]
        col = bTemp[ind][1]

        move = 8*row + col
        num = (move//8)*2+11+move

        return num

    def display(self, board):
        for r in range(0, 8):
            for c in range(0, 8):
                print(board[r][c], end=' ')
            print()

    def get_player(self, pl):
        if pl == "Black":
            return '@'
        else:
            return 'o'


    def setup (self, rep):
        board = []
        count = 0
        for r in range(0, 8):
            temp = []
            for c in range(0, 8):
                temp.append(rep[count])
                count += 1
            board.append(temp)
        return board

    def alphabeta(self, board, depth, alpha, beta, player, ogP):
        if depth == 0 or not self.blankInBoard(board):
            return self.heuristic(board, player)
        if player == ogP:
            v = -sys.maxsize - 1
            for child in self.moves(board, player):
                v = max(v, self.alphabeta(child[2], depth - 1, alpha, beta, self.getOpP(player), ogP))
                alpha = max(alpha, v)
                if beta <= alpha:
                    break
            return v
        else:
            v = sys.maxsize
            cList = self.moves(board, player)
            for child in cList:
                v = min(v, self.alphabeta(child[2], depth - 1, alpha, beta, self.getOpP(player), ogP))
                beta = min(beta, v)
                if beta <= alpha:
                    break
            return v

    def heuristic(self, board, player):
        num = 0
        for r in range(0, 8):
            for c in range(0, 8):
                if board[r][c] == player:
                    num += posVals[(r*8)+c]
        return num

    def getOpP(self, player):
        if player == '@':
            return 'o'
        else:
            return '@'

    def blankInBoard(self, board):
        for r in range (0, 8):
            for c in range (0, 8):
                if board[r][c] == '.':
                    return True
        return False

    def isAdjGood(self, board, player, r, c):
        opp = 'o'
        if player == opp:
            opp = '@'

        for x in range(r - 1, r + 2):
            for y in range(c - 1, c + 2):
                if x >= 0 and x < 8 and y >= 0 and y < 8:
                    if board[x][y] == opp:
                        return True
        return False

    def horizWorks(self, board, bCopy, player, r, c):
        temp = deepcopy(bCopy)
        xL = c - 1
        num = 0
        while xL >= 0:
            if board[r][c - 1] == player:
                break
            if board[r][xL] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[r][xL] == ".":
                bCopy = temp
                break
            bCopy[r][xL] = player
            xL -= 1
            num += 1

        xR = c + 1
        num = 0
        while xR < 8:
            if board[r][c + 1] == player:
                break
            if board[r][xR] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[r][xR] == ".":
                bCopy = temp
                break
            bCopy[r][xR] = player
            xR += 1
            num += 1

        return False

    def vertWorks(self, board, bCopy, player, r, c):
        yD = r - 1
        num = 0
        temp = deepcopy(bCopy)
        while yD >= 0:
            if board[r - 1][c] == player:
                break
            if board[yD][c] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[yD][c] == ".":
                bCopy = temp
                break
            bCopy[yD][c] = player
            yD -= 1
            num += 1

        yU = r + 1
        num = 0
        while yU < 8:
            if board[r + 1][c] == player:
                break
            if board[yU][c] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[yU][c] == ".":
                bCopy = temp
                break
            bCopy[yU][c] = player
            yU += 1
            num += 1

        return False

    def diagWorks(self, board, bCopy, player, r, c):
        xDLU = c - 1
        yDLU = r - 1
        num = 0
        temp = deepcopy(bCopy)

        while xDLU >= 0 and yDLU >= 0:
            if board[r - 1][c - 1] == player:
                break
            if board[yDLU][xDLU] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[yDLU][xDLU] == ".":
                bCopy = temp
                break
            bCopy[yDLU][xDLU] = player
            xDLU -= 1
            yDLU -= 1
            num += 1

        xDRD = c + 1
        yDRD = r + 1
        num = 0

        while xDRD < 8 and yDRD < 8:
            if board[r + 1][c + 1] == player:
                break
            if board[yDRD][xDRD] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[yDRD][xDRD] == ".":
                bCopy = temp
                break
            bCopy[yDRD][xDRD] = player
            xDRD += 1
            yDRD += 1
            num += 1

        xDLD = c - 1
        yDLD = r + 1
        num = 0

        while xDLD >= 0 and yDLD < 8:
            if board[r + 1][c - 1] == player:
                break
            if board[yDLD][xDLD] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[yDLD][xDLD] == ".":
                bCopy = temp
                break
            bCopy[yDLD][xDLD] = player
            xDLD -= 1
            yDLD += 1
            num += 1

        xDRU = c + 1
        yDRU = r - 1
        num = 0

        while xDRU < 8 and yDRU >= 0:
            if board[r - 1][c + 1] == player:
                break
            if board[yDRU][xDRU] == player:
                if num != 0:
                    self.tempAddBoard = bCopy
                    return True
                else:
                    bCopy = temp
                    break
            elif board[yDRU][xDRU] == ".":
                bCopy = temp
                break
            bCopy[yDRU][xDRU] = player
            xDRU += 1
            yDRU -= 1
            num += 1

        return False

    def moves(self, board, player):
        pos = []
        for r in range(0, 8):
            for c in range(0, 8):
                if board[r][c] == '.':

                    if self.isAdjGood(board, player, r, c):

                        self.tempAddBoard = deepcopy(board)

                        bCopy = deepcopy(board)
                        boolH = self.horizWorks(board, bCopy, player, r, c)
                        bCopy = self.tempAddBoard
                        boolV = self.vertWorks(board, bCopy, player, r, c)
                        bCopy =  self.tempAddBoard
                        boolD = self.diagWorks(board, bCopy, player, r, c)
                        bCopy = self.tempAddBoard
                        if boolH or boolV or boolD:
                            temp = []
                            bCopy[r][c]= player
                            temp.append(r)
                            temp.append(c)
                            temp.append(deepcopy(bCopy))
                            pos.append(temp)

        return pos

