import sys 


def main():
	defaultBoard = "...........................ox......xo..........................."
	arguments = len(sys.argv) - 1 
	n = 0
	board = ""
	yourToken = ""
	if arguments == 0: 
	  board = defaultBoard
	  yourToken = nextToken(board)
	elif arguments == 1:
	  board = sys.argv[1].lower()
	  yourToken = nextToken(board)
	elif arguments == 2:
	  board = sys.argv[1].lower()
	  yourToken = sys.argv[2].lower()
	  
	elif arguments == 3:
	  board = sys.argv[1].lower()
	  yourToken = sys.argv[2].lower()
	  n = int(sys.argv[3])
	
	positions = isLegal(board, yourToken)
	newGame = posBoard(board, positions)
	printBoard(newGame)
	print("Possible moves: " + ', '.join(str(x) for x in positions))
	print("my heurestic move is: " + str(positions.pop()))


	if board.count(".") <= 8:
		nm = negamax(board, yourToken, board.count(".")*2)
		
		score = nm[0]
		lm = nm[1:]
		print("Negamax  Score: " + str(score) + "  Move sequence: " + ', '.join(str(x) for x in lm[::-1]) + " and my move is " + str(nm[-1]))




#strategy.py
EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
class Strategy():
	#player is token
	

	def best_strategy(self, board, player, best_move, still_running):
		brd = "".join(board).replace("?", "").replace("@", "X")
		player = "X" if player == "@" else "o"
		
		if brd.count(".") <= 7:
			mv = getNegamaxMove(brd.lower(), player.lower(), brd.count("."))
		else:
			mv = findBestMove(brd.lower(), player.lower())      
		
		mv1 = 11+(mv//8) * 10 + (mv%8)


		best_move.value = mv1 




def printBoard(x):
	
	l = list(x)
	s1 = ''.join(l[0:8])
	s2 = ''.join(l[8:16])
	s3 = ''.join(l[16:24])
	s4 = ''.join(l[24:32])
	s5 = ''.join(l[32:40])
	s6 = ''.join(l[40:48])
	s7 = ''.join(l[48:56])
	s8 = ''.join(l[56:])
	print(s1 + "\n" + s2 + "\n" + s3 + "\n" + s4 + "\n" + s5 + "\n" + s6 + "\n" + s7 + "\n" + s8 + "\n")
	print("\n")

def posBoard(board, possiblePos):
	for x in possiblePos:
		board = board[:x] + "*" + board[x+1:]
	return board

def otherTokenChange(yourToken):
	if yourToken == "x":
		return "o"
	else:	return "x"

def down(pos):
	return pos+8
def up(pos):
	return pos-8
def right(pos):
	return pos+1
def left(pos):
	return pos-1
def diagDownRight(pos):
	return (pos+8) + 1
def diagDownLeft(pos):
	return (pos+8) - 1
def diagUpRight(pos):
	return (pos-8) + 1
def diagUpLeft(pos):
	return (pos-8) - 1


UPSTOP = [0, 1, 2, 3, 4, 5, 6, 7]
DOWNSTOP = [56, 57, 58, 59, 60, 61, 62, 63]
LEFTSTOP = [0, 8, 16, 24, 32, 40, 48, 56]
RIGHTSTOP = [7, 15, 23, 31, 39, 47, 55, 63]
DIAGDR = [56, 57, 58, 59, 60, 61, 62, 63, 7, 15, 23, 31, 39, 47, 55]
DIAGDL = [56, 57, 58, 59, 60, 61, 62, 63, 0, 8, 16, 24, 32, 40, 48]
DIAGUL = [0, 1, 2, 3, 4, 5, 6, 7, 8, 16, 24, 32, 40, 48, 56]
DIAGUR = [0, 1, 2, 3, 4, 5, 6, 7, 15, 23, 31, 39, 47, 55, 63]
#POSSIBLEPOS = []
keyer = {"down": DOWNSTOP, "up": UPSTOP, "left": LEFTSTOP, "right": RIGHTSTOP, "diagDownRight": DIAGDR, "diagDownLeft": DIAGDL, "diagUpLeft": DIAGUL, "diagUpRight": DIAGUR}
def chooseMethod(method, temp):
	if method == "down":	return down(temp)
	elif method == "up":	return up(temp)
	elif method == "right":	return right(temp)	
	elif method == "left":	return left(temp)
	elif method == "diagDownRight":	return diagDownRight(temp)
	elif method == "diagDownLeft":	return diagDownLeft(temp)
	elif method == "diagUpRight":	return diagUpRight(temp)
	elif method == "diagUpLeft":	return diagUpLeft(temp)			


def moveThrough(stopPosList, x, yourToken, board, method):
	temp = x
	toRet = []
	stopper = stopPosList
	
	marker = True 
	while temp not in stopper:
		temp = chooseMethod(method, temp)
		if(board[temp] == yourToken or board[temp] == "."):
			break 
		while temp  not in stopper:
			temp = chooseMethod(method, temp)
			if(board[temp] == "."):
				toRet.append((temp))
				marker = False
				break
			elif(board[temp] == yourToken):
				marker = False
				break 
		if marker == False:
			break 		 
	return toRet


def freeSpace(board):
	return int(board.count("."))
def flip(stopPosList, x, yourToken, board, method, otherToken, pos):
	copy = board
	temp = x#pos#position of yourtoken on board
	toRet = []
	stopper = stopPosList
	marker = True
	toRet.append(temp)
	while temp not in stopper:
		temp = chooseMethod(method, temp)
		if(copy[temp] == yourToken or copy[temp] == "."):
			break
		copy = copy[:temp] + yourToken + copy[temp+1:] 	 
		toRet.append(temp)
		while temp not in stopper:
			temp = chooseMethod(method, temp)
			#if(copy[temp] == otherToken):
			#copy = copy[:temp] + yourToken + copy[temp+1:]
			if(copy[temp] == "."):
				copy = copy[:temp] + yourToken + copy[temp+1:]
				toRet.append(temp)
				marker = False
				break
			if(copy[temp] == yourToken):
				marker = False 
				break 	
			copy = copy[:temp] + yourToken + copy[temp+1:]
			toRet.append(temp)		
		if marker == False:
			break

	if temp == pos:
		return toRet
	else:
		return []

def isLegal(board, yourToken):
	POSSIBLEPOS = []
	for x in range(len(board)):
		if board[x] == yourToken:
			for method, stopList in keyer.items():
				POSSIBLEPOS.extend(moveThrough(stopList, x, yourToken, board, method))
	POSSIBLEPOS = set(POSSIBLEPOS)
	return list(POSSIBLEPOS)

def flipPieces(board, GAMES, yourToken):
	newGame = list(board)
	
	for x in GAMES:
		if x != []:
			for y in x:
				newGame[y] = yourToken

	final = "".join(newGame)
	return final 

def makeMove(board, yourToken, pos):
	GAMES = []
	otherToken = otherTokenChange(yourToken)
	for x in range(len(board)):
		if board[x] == yourToken:
			for method, stopList in keyer.items():
					GAMES.append(flip(stopList, x, yourToken, board, method, otherToken, pos))
	newBoard = flipPieces(board, GAMES, yourToken)
	return newBoard
def evalBoard(board, yourToken):
	return board.count(yourToken) - board.count(otherTokenChange(yourToken)) 
def negamax(board, token, levels):
	if not levels:  
		return [evalBoard(board, token)]#evalBoard: yourtokens - enemy tokens
	lm = isLegal(board, token)
	if not lm:
		nm = negamax(board, otherTokenChange(token), levels - 1) + [-1]
		return [-nm[0]] + nm[1:]

	nmList = sorted([negamax(makeMove(board, token, mv), otherTokenChange(token), levels-1) + [mv] for mv in lm])       
	best = nmList[0]
	return [-best[0]] + best[1:]

def getNegamaxMove(board, yourToken, x):
	toRetList = negamax(board.lower(), yourToken.lower(), x)
	return toRetList[-1]
def findBestMove(board, yourToken):
	
	return isLegal(board.lower(), yourToken.lower()).pop()

if __name__ == "__main__":
	main()


