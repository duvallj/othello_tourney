EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
#Sanjay Ramakrishnan
PLAYERS = {BLACK: 'Black', WHITE: 'White'}
from Othello_Core import OthelloCore
import random
import math
class Strategy(OthelloCore):
    depthg = None
    bestpos = None
    def best_strategy(self, board, player, best_move, still_running):
        numempty = 0
        board1 = ''
        self.origplayer = player
        for x in board:
            board1 += x
            if x == EMPTY:
                numempty += 1
        if player == BLACK:
            opp = WHITE
        else:
            opp = BLACK
        lm = self.legalMoves(board1, player)
        # if numempty >= 5:
        forbidden = set()
        for c in lm:
            if c in {11, 18, 81, 88}:   #if corner, pick it instantly
                best_move.value = c
                return
            if board[11] == EMPTY:
                if c == 22:
                    forbidden.add(c)
            if board[18] == EMPTY:
                if c == 27:
                    forbidden.add(c)
            if board[81] == EMPTY:
                if c == 72:
                    forbidden.add(c)
            if board[88] == EMPTY:
                if c == 77:
                    forbidden.add(c)
            boardasdf = board[:]
            nextboard = self.make_move(c, player, boardasdf)
            nextboard1 = ''
            for x in nextboard:
                nextboard1 += x
            opplm = self.legalMoves(nextboard1, opp)
            for d in opplm:
                if len(opplm) == 0:
                    best_move.value = c
                    return
                if d in {11, 18, 81, 88}:   #if opponent has corner, avoid
                    forbidden.add(c)
        if len(lm - forbidden) == 0:
            best_move.value = random.choice(list(lm))
            return
        if self.bestpos == None:
            self.depthg = 4
            self.bestpos = 0
            while True:
                self.ab(board, player, self.depthg, -pow(2, 150), pow(2, 150), True, forbidden)
                best_move.value = self.bestpos
                self.bestpos = None
                self.depthg += 1
    def ab(self, board, player, depth, alpha, beta, maxing, forbidden):
        boardasdf = board[:]
        board1 = ''
        for x in board:
            board1 += x
        lm = self.legalMoves(board1, player)
        if player == BLACK:
            np = WHITE
        else:
            np = BLACK
        if depth == 0 or len(lm) == 0:
            return self.heuristic(board, self.origplayer)
        lm = lm - forbidden
        if maxing:
            v = -pow(2, 50)
            for c in lm:
                asdf = max(v, self.ab(self.make_move(c, player, boardasdf), np, depth - 1, alpha, beta, False, set()))
                if depth == self.depthg and asdf > v:
                    self.bestpos = c    #this keeps track of the best position
                v = asdf
                alpha = max(alpha, v)
                if beta <= alpha:
                    break
        else:
            v = pow(2, 50)
            for c in lm:
                v = min(v, self.ab(self.make_move(c, player, boardasdf), np, depth - 1, alpha, beta, True, set()))
                beta = min(beta, v)
                if beta <= alpha:
                    break
        return v

    def legalMoves(self, board, player):    #find legal moves -- returns list of ints (indices in string)
        puz = board.split(OUTER)
        puzzle = ''
        for p in puz:
            if p != '':
                puzzle += p
        myturn = player
        bpuzzle = [[],[],[],[],[],[],[],[]]
        legalmoves = set()
        for r in range(8):
            for c in range(8):
                bpuzzle[r].append(puzzle[8*r+c])
        for r in range(8):
            for c in range(8):
                if bpuzzle[r][c] == '.':
                    if myturn == '@':
                        b = []
                        for i in range(3):
                            for j in range(3):
                                if r-1+i >= 0 and c-1+j >= 0 and r-1+i < 8 and c-1+j < 8:
                                    if bpuzzle[r-1+i][c-1+j] == 'o':
                                        b.append((r-1+i, c-1+j))
                        if not len(b) == 0:
                            for p in b:
                                if p == (r-1, c-1):
                                    for x in range(25):
                                        if r-x > 0 and c-x > 0:
                                            if bpuzzle[r-1-x][c-1-x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c-1-x] == '.':
                                                break
                                elif p == (r-1, c):
                                    for x in range(25):
                                        if r-x > 0:
                                            if bpuzzle[r-1-x][c] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c] == '.':
                                                break
                                elif p == (r-1, c+1):
                                    for x in range(25):
                                        if r-x > 0 and c+x < 7:
                                            if bpuzzle[r-1-x][c+1+x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c+1+x] == '.':
                                                break
                                elif p == (r, c-1):
                                    for x in range(25):
                                        if c-x > 0:
                                            if bpuzzle[r][c-1-x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c-1-x] == '.':
                                                break
                                elif p == (r, c+1):
                                    for x in range(25):
                                        if c+x < 7:
                                            if bpuzzle[r][c+1+x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c+1+x] == '.':
                                                break
                                elif p == (r+1, c-1):
                                    for x in range(25):
                                        if r+x < 7 and c-x > 0:
                                            if bpuzzle[r+1+x][c-1-x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c-1-x] == '.':
                                                break
                                elif p == (r+1, c):
                                    for x in range(25):
                                        if r+x < 7:
                                            if bpuzzle[r+1+x][c] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c] == '.':
                                                break
                                elif p == (r+1, c+1):
                                    for x in range(25):
                                        if r+x < 7 and c+x < 7:
                                            if bpuzzle[r+1+x][c+1+x] == '@':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c+1+x] == '.':
                                                break

                    else:
                        b = []
                        for i in range(3):
                            for j in range(3):
                                if r-1+i >= 0 and c-1+j >= 0 and r-1+i < 8 and c-1+j < 8:
                                    if bpuzzle[r-1+i][c-1+j] == '@':
                                        b.append((r-1+i, c-1+j))
                        if not len(b) == 0:
                            for p in b:
                                if p == (r-1, c-1):
                                    for x in range(0, 25, 1):
                                        if r-x > 0 and c-x > 0:
                                            if bpuzzle[r-1-x][c-1-x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c-1-x] == '.':
                                                break
                                elif p == (r-1, c):
                                    for x in range(25):
                                        if r-x > 0:
                                            if bpuzzle[r-1-x][c] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c] == '.':
                                                break
                                elif p == (r-1, c+1):
                                    for x in range(25):
                                        if r-x > 0 and c+x < 7:
                                            if bpuzzle[r-1-x][c+1+x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r-1-x][c+1+x] == '.':
                                                break
                                elif p == (r, c-1):
                                    for x in range(25):
                                        if c-x > 0:
                                            if bpuzzle[r][c-1-x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c-1-x] == '.':
                                                break
                                elif p == (r, c+1):
                                    for x in range(25):
                                        if c+x < 7:
                                            if bpuzzle[r][c+1+x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r][c+1+x] == '.':
                                                break
                                elif p == (r+1, c-1):
                                    for x in range(25):
                                        if r+x < 7 and c-x > 0:
                                            if bpuzzle[r+1+x][c-1-x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c-1-x] == '.':
                                                break
                                elif p == (r+1, c):
                                    for x in range(25):
                                        if r+x < 7:
                                            if bpuzzle[r+1+x][c] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c] == '.':
                                                break
                                elif p == (r+1, c+1):
                                    for x in range(25):
                                        if r+x < 7 and c+x < 7:
                                            if bpuzzle[r+1+x][c+1+x] == 'o':
                                                legalmoves.add((r+1) * 10 + (c+1))
                                                break
                                            if bpuzzle[r+1+x][c+1+x] == '.':
                                                break
        return legalmoves

    def heuristic(self, board, player): #"if you walk in on your friends playing Othello" -- work in progress
        #from the strategy website on blackboard, heuristic is a function of:
        #corners, mobility (center/frontier/useful moves) c-squares & x-squares, tempo, parity, stability
        if player == WHITE:
            opp = BLACK
        else:
            opp = WHITE
        board1 = ''
        for x in board:
            board1 += x
        a = self.legalMoves(board1, player)
        b = self.legalMoves(board1, opp)
        e = p = o = out = 0 #empty = player = opponent = out = 0
        for x in board:
            if x == EMPTY:
                e += 1
            elif x == player:
                p += 1
            elif x == opp:
                o += 1
        if len(a) == 0 and len(b) == 0:
            return pow(2, 25) * (p - o)
        if e < 36: #midgame
            s = 0   #stability -- maximize this
            # IMPORTANT -- READ BELOW:
            # Stability is defined as the number of pieces that are guaranteed to never flip sides
            # A piece is stable if it has two paths, one vertical and one horizontal, to an edge,
            # Consisting only of stable pieces of that piece's side.
            # Corners and edges with a horizontal or vertical path to a corner are ALWAYS stable
            # In order to code stability, there are two parts:
            # 1. Find which pieces have a pathway to two perpendicular edges consisting of only that color's piece
            # 2. Recursively determine if all pieces on that path are stable
            out += p
            out -= o
            stabilitymatrix = []
            for i in range(100):
                if board[i] == OUTER:
                    stabilitymatrix.append(1)
                else:
                    stabilitymatrix.append('i')
            for x in range(100):
                self.calcstability(board, player, x, stabilitymatrix)
            p = o = 0
            for x in stabilitymatrix:
                if x == 1:
                    p += 1
                elif x == -1:
                    o += 1
            return p - o
        elif e >= 36:   #early game
            out = 10*(len(a) - len(b))
            if len(a) == 0 and a - {22, 27, 72, 77} == set():
                out -= 99999999
            elif len(b) == 0 and b - {22, 27, 72, 77} == set():
                out += 99999999
            for x in {11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 31, 41, 51, 61, 71, 81, 28, 38, 48, 58, 68, 78, 88, 82, 83, 84, 85, 86, 87}: #edges
                if board[x] == player:
                    out += 5
                elif board[x] == opp:
                    out -= 5
            return out
        return p - o

    def calcstability(self, board, player, pos, stabilitymatrix):    #edit stabilitymatrix to reflect board's stability
        # curr keeps track of the player we are testing the stability of, if it is None then find a player to test
        # player never changes, kind of like self.origplayer
        # Psuedocode:
        # for every square in board:
        #     if that value is neither white nor black
        #         that square is unstable
        #     if value is the opposite color of testing:
        #         that square is unstable
        #     else if stability matrix has determinate value (note that all empty spaces have NO stability)
        #         return that value
        #     else
        #         if all values on a horizontal or vertical path to an edge are stable (including that piece on the edge)
        #             this piece is stable
        #         else
        #             this is not stable
        # stabilitymatrix values: i = indeterminate, t = testing, 0 = unstable, 1 = stable for self, -1 = stable for opponent
        if board[pos] == OUTER:   #if it is outer, you reached the edge!
            return True
        if board[pos] == EMPTY:
            stabilitymatrix[pos] = 0
            return False
        elif stabilitymatrix[pos] != 'i':
            return stabilitymatrix[pos] != 0
        else:
            stabilitymatrix[pos] = 't'
            if player == BLACK:
                opp = WHITE
            else:
                opp = BLACK
            if board[pos] == player:
                #test for +1, if stability is determined put in +1
                dirver = {-10, 10}
                dirhor = {-1, 1}
                boolver = False
                boolhor = False
                for x in dirver:
                    if self.calcstability(board, player, pos + x, stabilitymatrix):
                        boolver = True
                for x in dirhor:
                    if self.calcstability(board, player, pos + x, stabilitymatrix):
                        boolhor = True
                if boolver and boolhor:
                    stabilitymatrix[pos] = 1
                    return True
                return False
            else:
                #test for -1, if stability is determined put in -1
                dirver = {-10, 10}
                dirhor = {-1, 1}
                boolver = False
                boolhor = False
                for x in dirver:
                    if self.calcstability(board, opp, pos + x, stabilitymatrix):
                        boolver = True
                for x in dirhor:
                    if self.calcstability(board, opp, pos + x, stabilitymatrix):
                        boolhor = True
                if boolver and boolhor:
                    stabilitymatrix[pos] = -1
                    return True
                return False


    def is_legal(self, move, player, board):
        return True
    def find_bracket(self, square, player, board, direction):#used for OthelloCore.make_move() -- overrides superclass
        curr = square + direction
        while(True):
            if board[curr] == player:
                return curr
            elif board[curr] == OUTER or board[curr] == EMPTY:
                return None
            else:
                curr = curr + direction

if __name__ == '__main__':  #for testing and debugging purposes
    from multiprocessing import Value
    bm = Value('i', 0)
    boardstr = '???????????........??........??........??........??........??........??........??........???????????'
    boardlistasdf = []
    for i in boardstr:
        boardlistasdf.append(i)
    print(Strategy().legalMoves(boardstr, BLACK))
    Strategy().best_strategy(boardlistasdf, BLACK, bm, True)
    print(bm)
