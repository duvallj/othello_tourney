class Strategy():
    def best_strategy(self, board, player, best_move, still_running):
        #format
        game=''.join(board).replace("?","").replace("@","X").replace("o","O")


        global cornerTiles, cornerDictionary, computer, neighboringIndexes, n, BLACK, WHITE, EMPTY, SIZE, LENGTH
        computer = "X" if player=="@" else"O"
        legalMovesTable, changeTilesTable = {}, {}
        BLACK, WHITE, EMPTY, SIZE, LENGTH = "X", "O", ".", 64, 8
        cornerTiles = {0, 7, 63, 56}
        cornerDictionary = {0: [1, 1], 7: [-1, 1], 63: [-1, -1], 56: [1, -1]}
        edgeTiles = {1, 8, 6, 15, 48, 57, 62, 55, 16, 2, 5, 23, 40, 58, 61, 47, 3, 4, 24, 32, 59, 60, 31, 39}
        neighboringIndexes = {
        index: [(index + r + c, r, c) for c in range(-1, 2) for r in range(-LENGTH, LENGTH + 1, LENGTH) if
                SIZE > index + r > -1 and (index + c) // LENGTH == index // LENGTH and
                index + r + c != index] for index in range(SIZE)}
        n=20
        tile = computer
        opp = returnOther(computer)
        displayGame(game)
        print(" ")


        lm = legalMoves(game, tile, opp)
        lmStrategy=lm.keys()
        move=-1
        if lmStrategy:
            continuedEdges = checkCorners(game, tile, lmStrategy)
            notProtect = XCpieces(game, tile, lmStrategy)
            if cornerTiles & lmStrategy:
                move = random.choice([*cornerTiles & lmStrategy])  # pick corner
            elif continuedEdges:
                move = random.choice([*continuedEdges])  # pick safe edges
            if lmStrategy - notProtect: lmStrategy = lmStrategy - notProtect  # don't pick X,C if possible
            if lmStrategy - edgeTiles: lmStrategy = lmStrategy - edgeTiles  # don't pick edges if possible
            if move == -1:  # if the move is not already chosen
                availabilityDict = {mv: legalMoves(changeTiles(game, tile, lm[mv]), opp, tile) for mv in lmStrategy}
                move = min(availabilityDict, key=lambda c: len(availabilityDict[c]))
            best_move.value = 11 + (move // 8) * 10 + move % 8
        if game.count(EMPTY) <= n:
            nm = negamaxTerminal(game, computer, opp, -65, 65, legalMovesTable)
            best_move.value = 11 + (nm[-1] // 8) * 10 + nm[-1] % 8
        elif game.count(EMPTY):
            for d in range(2, 10):
                nm = negamax(game, d, computer, opp, legalMovesTable)
                print("Negamax returns {} and I choose move {}".format(nm, nm[-1]))


import sys
import random
def main():
    global cornerTiles, cornerDictionary, computer, neighboringIndexes, n, BLACK, WHITE, EMPTY, SIZE, LENGTH
    legalMovesTable = {}
    BLACK, WHITE, EMPTY, SIZE, LENGTH = "X", "O", ".", 64, 8
    cornerTiles = {0, 7, 63, 56}
    cornerDictionary = {0: [1, 1], 7: [-1, 1], 63: [-1, -1], 56: [1, -1]}
    edgeTiles = {1,8,6,15,48,57,62,55,16,2,5,23,40,58,61,47,3,4,24,32,59,60,31,39}
    neighboringIndexes = {index:[(index + r + c, r, c) for c in range(-1, 2) for r in range(-LENGTH, LENGTH+1,LENGTH) if
                    SIZE > index + r > -1 and (index + c) // LENGTH == index // LENGTH and
                 index + r + c != index] for index in range(SIZE)}
    if len(sys.argv)==3:game, computer, n, f=sys.argv[1].upper(), sys.argv[2].upper(), 15, 30
    else:game, computer, n=sys.argv[1].upper(), sys.argv[2].upper(), int(sys.argv[3])
    tile=computer
    opp = returnOther(computer)
    displayGame(game)
    print(" ")
    lm=legalMoves(game, tile, opp)
    lmStrategy = lm.keys()
    print("Legal Moves: {}".format(lmStrategy))

    move = -1
    if lmStrategy:
        continuedEdges = checkCorners(game, tile, lmStrategy)
        notProtect = XCpieces(game, tile, lmStrategy)
        if cornerTiles&lmStrategy: move = random.choice([*cornerTiles&lmStrategy])  # pick corner
        elif continuedEdges:  move = random.choice([*continuedEdges])  # pick safe edges
        if lmStrategy - notProtect: lmStrategy = lmStrategy - notProtect  # don't pick X,C if possible
        if lmStrategy-edgeTiles: lmStrategy=lmStrategy-edgeTiles  # don't pick edges if possible
        if move ==-1:  # if the move is not already chosen
            availabilityDict={mv:legalMoves(changeTiles(game, tile, lm[mv]), opp,tile) for mv in lmStrategy}
            move = min(availabilityDict, key=lambda c: len(availabilityDict[c]))
        print("My Heuristic move is {}".format(move))
    if game.count(EMPTY) <= n:
        nm = negamaxTerminal(game,computer, opp, -65,65, legalMovesTable)
        print("Negamax returns {} and I choose move {}".format(nm,nm[-1]))
    elif game.count(EMPTY):
        for d in range(2,10):
            nm = negamax(game, d, computer, opp, legalMovesTable)
            print("Negamax returns {} and I choose move {}".format(nm, nm[-1]))



def XCpieces(game, tile, lmStrategy):
    XCtiles = set()
    for corner in cornerTiles:
        x,y = cornerDictionary[corner]
        if game[corner]!=tile: XCtiles= XCtiles | {corner+x, corner+y*LENGTH, corner+x+y*LENGTH}
    return XCtiles&lmStrategy


def checkCorners(game, tile, legalMoves):
    edges=set()
    for corner in cornerTiles:
        pos = corner
        if game[corner]==tile:
            while(pos//LENGTH==corner//LENGTH):
                if game[pos]==EMPTY:
                    edges.add(pos)
                    break
                pos+=cornerDictionary[corner][0]
            pos = corner
            while(-1<pos<SIZE):
                if game[pos]==EMPTY:
                    edges.add(pos)
                    break
                pos+=cornerDictionary[corner][1]*LENGTH
    return edges&legalMoves

def changeTilesOld(game, index, tile, opp):
    for i in neighboringIndexes[index]:
        if game[i[0]]==opp:
            pos, rtrans, ctrans = i
            newGame = changeTileHelper(pos, game, rtrans, ctrans, tile)
            if newGame!="": game=newGame
    game = game[:index] + tile + game[index + 1:]
    return game


def changeTileHelper(pos, game, rtrans, ctrans, tile):
    if 7 < pos // LENGTH or pos // LENGTH < 0 or 0 > pos or pos > 63 or game[pos] == EMPTY: return ""
    if game[pos] == tile: return game
    if (pos + ctrans) // LENGTH != pos // LENGTH: return ""
    else:
        newGame = changeTileHelper(pos + rtrans + ctrans, game, rtrans, ctrans, tile)
        if newGame!="": return newGame[:pos]+tile+newGame[pos+1:]
        else: return ""

# legalMoves
def legalMovesOld(game, tile, opp):
    opponentSet = {i for i, c in enumerate(game) if c == opp}
    possibleMoves = set()
    for index in opponentSet:
        for i in neighboringIndexes[index]:
            if game[i[0]]==EMPTY:
                pos, rtrans, ctrans = i[0], -i[1], -i[2]
                posTemp = index
                while (LENGTH > posTemp // LENGTH and posTemp // LENGTH >= 0 and 0 <= posTemp and posTemp <= 63):
                    if game[posTemp] == tile:
                        possibleMoves.add(pos)
                        break
                    if game[posTemp] == EMPTY: break
                    if (posTemp + ctrans) // LENGTH != posTemp // LENGTH: break
                    posTemp = posTemp + rtrans + ctrans
    return possibleMoves


def legalMoves(game, tile, opp):
    possibleMoves={}
    for pos in range(len(game)):
        if game[pos]==EMPTY:
            allFlips = []
            for neighbor in neighboringIndexes[pos]:
                if game[neighbor[0]]==opp:
                    posTemp, rtrans, ctrans = neighbor
                    flips=[]
                    while(LENGTH > posTemp // LENGTH and posTemp // LENGTH >= 0 and 0 <= posTemp and posTemp <= 63):
                        if game[posTemp]==tile:
                            allFlips+=flips
                            break
                        if game[posTemp]!=opp:break
                        if (posTemp + ctrans) // LENGTH != posTemp // LENGTH: break
                        flips.append(posTemp)
                        posTemp+=rtrans+ctrans
            if allFlips:
                allFlips.append(pos)
                possibleMoves[pos]=allFlips
    return possibleMoves

def changeTiles(game, tile, flips):
    for i in flips:
        game=game[:i]+tile+game[i+1:]
    return game

def heuristic(game, tile, opp):
    toReturn = len(legalMoves(game, tile, opp))-len(legalMoves(game, opp, tile))
    for pos in cornerTiles:
        if game[pos]== tile: toReturn+=2
        elif game[pos]==opp: toReturn-=2
    return toReturn

def negamaxTerminal(game, tile, opp, a, b, legalMovesTable):
    key = game + " " + tile
    if key in legalMovesTable:
        lm = legalMovesTable[key]
    else:
        lm = legalMoves(game, tile, opp)
        legalMovesTable[key] = lm
    if not lm:
        if not legalMoves(game, opp, tile):
            return [game.count(tile) - game.count(opp), -3]
        nm = negamaxTerminal(game, opp, tile, -b, -a, legalMovesTable) + [-1]
        return [-nm[0]] + nm[1:]
    best = []
    for move in lm:
        nm = negamaxTerminal(changeTiles(game, tile, lm[move]), opp, tile, -b,-a, legalMovesTable)+[move]
        nm = [-nm[0]]+nm[1:]
        a, best = max(a, nm[0]), max(best,nm)
        if a>=b: break
    return best

# helpers
def whoesMove(game):
    return WHITE if game.count(EMPTY) % 2 else BLACK

def negamax(game, depth, tile, opp, legalMovesTable):
    if depth==0: return [heuristic(game, tile, opp)]
    key = game + " " + tile
    if key in legalMovesTable:
        lm = legalMovesTable[key]
    else:
        lm = legalMoves(game, tile, opp)
        legalMovesTable[key] = lm
    if not lm:
        if not legalMoves(game,opp,tile):
            return [heuristic(game, tile, opp)]
        nm = negamax(game, depth-1,opp,tile, legalMovesTable) + [-1]
        return[-nm[0]]+nm[1:]
    nmList=sorted([negamax(changeTiles(game, tile, lm[move]),depth-1,opp,tile, legalMovesTable) + [move] for move in lm])
    best=nmList[0]
    return [-best[0]]+best[1:]


def returnOther(tile):
    return WHITE if tile == BLACK else BLACK


def displayGame(game):
    print("\n".join(" ".join(game[r * LENGTH:r * LENGTH + LENGTH]) for r in range(LENGTH)))

if __name__=="__main__":
    main()
