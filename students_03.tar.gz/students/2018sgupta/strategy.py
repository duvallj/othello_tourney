#Sachit Gupta

import random
import math

#### Othello Shell
#### P. White 2016-2018


EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'

# To refer to neighbor squares we can add a direction to a square.
N, S, E, W = -10, 10, 1, -1
NE, SE, NW, SW = N + E, S + E, N + W, S + W
DIRECTIONS = (N, NE, E, SE, S, SW, W, NW)
PLAYERS = {BLACK: "Black", WHITE: "White"}

class Strategy():

    wmatrix = [
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0, 300, -20,  20,   5,   5,  20, -20, 300,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,   5,  -5,   3,   3,   3,   3,  -5,   5,   0,
    0,  20,  -5,  15,   3,   3,  15,  -5,  20,   0,
    0, -20, -40,  -5,  -5,  -5,  -5, -40, -20,   0,
    0, 300, -20,  20,   5,   5,  20, -20, 300,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
]

    def __init__(self):
        pass

    def get_starting_board(self):
        """Create a new board with the initial black and white positions filled."""
        b = [OUTER] * 100
        for i in [i for i in range(11, 89) if 1 <= (i % 10) <= 8]:
            b[i] = EMPTY
        # The middle four squares should hold the initial piece positions.
        b[44], b[45] = WHITE, BLACK
        b[54], b[55] = BLACK, WHITE
        boardstr = ''.join(b)
        return boardstr

    def get_pretty_board(self, board):
        """Get a string representation of the board."""
        s = ""
        for x in range(0, 100):
            if x > 0 and x % 10 == 0:
                s += '\n'
            s += board[x]
        return s

    def opponent(self, player):
        """Get player's opponent."""
        if player == BLACK:
            return WHITE
        else:
            return BLACK

    def find_match(self, board, player, square, direction):
        """
        Find a square that forms a match with `square` for `player` in the given
        `direction`.  Returns None if no such square exists.
        """
        if board[square + direction] == player:
            return None
        sq = square
        while not board[sq] == player:
            sq += direction
            if board[sq] == EMPTY or board[sq] == OUTER:
                return None

        return sq

    def is_move_valid(self, board, player, move):
        """Is this a legal move for the player?"""
        for dir in DIRECTIONS:
            m = self.find_match(board, player, move, dir)
            if m is not None:
                return True
        return False

    def make_move(self, board, player, move):
        """Update the board to reflect the move by the specified player."""
        boardlayout = list(board)
        directions = []
        for x in DIRECTIONS:
            possiblem = self.find_match(board, player, move, x)
            if possiblem is not None:
                directions.append(x)
        for y in directions:
            temp = move
            while boardlayout[temp] is not player:
                boardlayout[temp] = player
                temp += y
        board2 = ''.join(boardlayout)
        return board2

    def get_valid_moves(self, board, player):
        """Get a list of all legal moves for player."""

        m = list()
        for x in range(0, len(board)):
            if board[x] is EMPTY:
                possiblemove = self.is_move_valid(board, player, x)
                if possiblemove is True:
                    m.append(x)
        return m

    def has_any_valid_moves(self, board, player):
        """Can player make any moves?"""
        for x in range(0, len(board)):
            if board[x] is EMPTY:
                possiblemove = self.is_move_valid(board, player, x)
                if possiblemove is True:
                    return True
        return False

    def next_player(self, board, prev_player):
        """Which player should move next?  Returns None if no legal moves exist."""
        nextplayer = self.opponent(prev_player)
        hasmoves1 = self.has_any_valid_moves(board, nextplayer)
        if hasmoves1 is True:
            return nextplayer
        else:
            hasmoves2 = self.has_any_valid_moves(board, prev_player)
            if hasmoves2 is True:
                return prev_player
        return None

    def score(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        wh = 0
        bl = 0
        for x in range(0, len(board)):
            if board[x] == WHITE:
                wh = wh + 1
            elif board[x] == BLACK:
                bl = bl + 1
        game_score = bl - wh
        return game_score

    def wscore(self, board, player=BLACK):
        """Compute player's score (number of player's pieces minus opponent's)."""
        wh = 0
        bl = 0
        for x in range(0, len(board)):
            if board[x] == WHITE:
                wh = wh + self.wmatrix[x]
            elif board[x] == BLACK:
                bl = bl + self.wmatrix[x]
        game_score = bl - wh
        return game_score

    def game_over(self, board, player):
        """Return true if player and opponent have no valid moves"""
        possiblemove = self.next_player(board, player)
        if possiblemove is not None:
            return False
        return True

    ### Monitoring players

    class IllegalMoveError(Exception):
        def __init__(self, player, move, board):
            self.player = player
            self.move = move
            self.board = board

        def __str__(self):
            return '%s cannot move to square %d' % (PLAYERS[self.player], self.move)

    ################ strategies #################

    def minmax_search(self, board, player, depth):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters

        if depth == 0:
            gamescore = self.score(board, player=BLACK)
            return gamescore
        validmoves = self.get_valid_moves(board, player)
        ch = set()
        for m in validmoves:
            tempboard = self.make_move(board, player, m)
            otherplayer = self.next_player(tempboard, player)
            if otherplayer is not None:
                tempscore = self.minmax_search(tempboard, otherplayer, depth = depth - 1)
                ch.add((tempscore, m))
            else:
                tempscore = self.score(tempboard, player=BLACK)
                ch.add((tempscore, m))
        if player == WHITE:
            return min(ch)[1]
        if player == BLACK:
            return max(ch)[1]


    def alpha_beta(self, board, player, depth, a, b):
        # determine best move for player recursively
        # it may return a move, or a search node, depending on your design
        # feel free to adjust the parameters

        if depth == 0:
            gamescore = self.wscore(board, player=BLACK) * 1000
            return gamescore
        validmoves = self.get_valid_moves(board, player)
        ch = set()
        for m in validmoves:
            tempboard = self.make_move(board, player, m)
            otherplayer = self.next_player(tempboard, player)
            if otherplayer is not None:
                if player == WHITE:
                    tempscore = self.alpha_beta(tempboard, otherplayer, depth - 1, a, b)
                    if tempscore < b:
                        b = tempscore
                        ch.add((tempscore, m))
                if player == BLACK:
                    tempscore = self.alpha_beta(tempboard, otherplayer, depth - 1, a, b)
                    if tempscore > a:
                        a = tempscore
                        ch.add((tempscore, m))
            else:
                tempscore = self.score(tempboard, player=BLACK)
                ch.add((tempscore, m))
        if player == WHITE:
            return min(ch)[1]
        if player == BLACK:
            return max(ch)[1]


    def minmax_strategy(self, board, player, depth=3):
        # calls minmax_search
        # feel free to adjust the parameters
        # returns an integer move
        return self.minmax_search(board, player, depth)

    def random_strategy(self, board, player):
        return random.choice(self.get_valid_moves(board, player))

    def best_strategy(self, board, player, best_move, still_running):
        ## THIS IS the public function you must implement
        ## Run your best search in a loop and update best_move.value
        depth = 1
        while (True):
            ## doing random in a loop is pointless but it's just an example
            best_move.value = self.alpha_beta(board, player, depth, math.inf*-1, math.inf)
        depth += 2

    standard_strategy = best_strategy
