## OTHELLO STRATEGY (or AI or whatever.  The naming system they gave us is weird.)
## COPYRIGHT © 2018 ALEXANDER HAYDEN

#import Othello_Core
from multiprocessing import Value
from functools import lru_cache

'''TODO: BITBOARDS, HEURISTIC, RECURSIVE DEEPENING, DYNAMIC WEIGHT, *CACHE'''
i=0

matrix = [128,  -96,    32, 8, 8, 32,     -96, 128,
          -96,  -128,    0, 0,   0, 0,       -128, -96,
          32,   0,      16, 4, 4, 16,    0, 32,
          8,   0,      4,  4, 4, 4,     0, 8,
          8,   0,      4,  4, 4, 4,     0, 8,
          32,   0,      16, 4, 4, 16,    0, 32,
          -96,  -128,    0, 0,  0, 0,     -128, -96,
          128,  -96,    32, 8, 8, 32,     -96, 128]

##matrix = [
##        120, -20, 20, 5, 5, 20, -20, 120,
##        -20, -40, -5, -5, -5, -5, -40, -20,
##        20, -5, 15, 3, 3, 15, -5, 20,
##        5, -5, 3, 3, 3, 3, -5, 5,
##        5, -5, 3, 3, 3, 3, -5, 5,
##        20, -5, 15, 3, 3, 15, -5, 20,
##        -20, -40, -5, -5, -5, -5, -40, -20,
##        120, -20, 20, 5, 5, 20, -20, 120]

##def invMatrix(mat):
##    out = []
##    for x in mat:
##        out.append((128-x)/100)
##    return out

##def scaleMatrix(matrix, mod, mult = 1):
##    mat = matrix[:]
##    for x in range(64):
##        mat[x] = mat[x] + mod[x]*mult
##    return mat

##def currentMatrix(board):
##    global matrix
##    out = []
##    l = 2 ** (-1*board.count('.')) * 10 + 1
##    for x in range(64):
##        out.append(matrix[x] // l)
##    return out


##modMatrix = invMatrix(matrix)

class Strategy():

    ## method
    def best_strategy(self, board, player, move, still_running):
        
        if isinstance(board, list):
            board = ''.join(board)
        board = board.replace('?', '')
        opponent = '@o'.replace(player, '')
        for x in range(1, 60):
            move.value =  ab_init(board, player, opponent, x)
            if not move.value < 0:
                move.value = makePositionBad(move.value)
        
        

def ab_init(board, player, opponent, deepness):
    global matrix#, modMatrix
    hMatrix = matrix[:]#scaleMatrix(matrix, modMatrix, 60-board.count('.'))
    moves = return_legal_moves(board, player, opponent)
    best = (-502, -500000)
    for mov in moves:
        thisBoard = exec_move(board[:], mov, player, opponent)
        v = alphabeta(thisBoard, deepness, -100000000, 100000000, False, player, opponent, hMatrix)
        if v > best[1]:
            best = (mov, v)

    return best[0]

def alphabeta(board, depth, low, high, isMax, player, opponent, matrix):
    #global modMatrix
    
    matrix = updateMatrix(matrix, board, player)
    b = toBitboard(board, player, opponent)

    movesMax = return_valid_moves(b[0], b[1])
    
    movesMin = return_valid_moves(b[1], b[0])
    
    if depth == 0 or ((isMax and len(movesMax) == 0) or (~isMax and len(movesMin) == 0)):
        if len(movesMin) > 0:
            return matrixHeuristic(board, player, opponent, matrix) * (len(movesMax) / len(movesMin))
        else:
            return matrixHeuristic(board, player, opponent, matrix)

    if isMax:
        v = -1 * (100 ** 1000)
        for mov in movesMax:
            thisBoard = exec_move(board[:], mov, player, opponent)
            v = max(v, alphabeta(thisBoard, depth - 1, low, high, False, player, opponent, matrix))
            low = max(low, v)
            if high <= low:
                break
        return v
    
    else:
        v = (100 ** 1000)
        for mov in movesMin:
            thisBoard = exec_move(board[:], mov, opponent, player)
            v = min(v, alphabeta(thisBoard, depth - 1, low, high, True, player, opponent, matrix))
            high = min(high, v)
            if high <= low:
                break
        return v

    #return matrixHeuristic(board, player, opponent, matrix)


def heuristic(board, player):
    return matrixHeuristic(board, player)
    #return uncaptureHeuristic(board, player)


def matrixHeuristic(board, player, opponent, scoreMatrix):
    #scoreMatrix = currentMatrix(board)##########################
    score = 0
    for x in range(64):
        if board[x] == player:
            score += scoreMatrix[x]
        elif board[x] == opponent:
            score -= scoreMatrix[x]
    
    return score


def updateMatrix(matrix, board, player):
    out = matrix[:]
    n = board.count('.')
    
    for x in [0, 7, 56, 63]:
        if board[x] != '.':
            cornerThing(board, x, out)

    if n <= 0:
        out = [64] * 64

        
    return out

def cornerThing(board, x, out):
    for d in [1, -1, 8, -8]:
        n = x
        for i in range(8):#while board[n] != '.':
            n += d
            if bad_move(n, d):
                break
            else:
                out[n] = 96
    for d in [-9, -7, 7, 9]:
        if not bad_move(x + d, d):
            out[n] = 96
            


################################################### API

def makePositionBad(position):
    return int(str(position // 8 + 1) + str(position % 8 + 1))

@lru_cache(maxsize=4096)
def toBitboard(board, player, opponent):
    this = 0
    that = 0
    for x in range(64):
        this <<= 1
        that <<= 1
        if board[x] == player:
            this += 1
        if board[x] == opponent:
            that += 1
    return (this, that)

@lru_cache(maxsize=4096)
def return_valid_moves(this, that):
    musk = that & 0x7E7E7E7E7E7E7E7E
    out = (bit_valid_moves(this, musk, 1) | bit_valid_moves(this, that, 8)\
           | bit_valid_moves(this, musk, 7) | bit_valid_moves(this, musk, 9)) & ~(this|that)
    ex = set()
    for x in range(64):
        if out & 1 == 1:
            ex.add(63 - x)
        out >>= 1
    return ex
        

def bit_valid_moves(this, musk, delta):
    out = 0
    out = (((this << delta) | (this >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    return (out << delta) | (out >> delta)

def bitExec(this, musk, delta):
    out = 0
    out = (((this << delta) | (this >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    out |= (((out << delta) | (out >> delta)) & musk)
    return (out << delta) | (out >> delta)

def bit_exec_moves(this, that, x):
    musk = that & 0x7E7E7E7E7E7E7E7E
    make = 1 << x
    
    out = (bit_valid_moves(make, musk, 1) | bit_valid_moves(make, that, 8)\
           | bit_valid_moves(make, musk, 7) | bit_valid_moves(make, musk, 9))

    this = this | out
    that = that & ~out
    return (this, that)

def exec_move(board, x, player, opponent):
    deltas = [-9, -8, -7, -1, 1, 7, 8, 9]
    for d in deltas:
            pos = x + d
            if bad_move(pos, d):
                continue
            if board[pos] == opponent:
                indexes = deep_move_exec(board, player, opponent, pos, d)    ## check along the line
                if indexes is not None:
                    for loc in indexes:
                        board = board[:loc] + player + board[loc+1:]#board[loc] = player
    board = board[:x] + player + board[x+1:]
    return board

def deep_move_exec(board, player, opponent, pos, delta):
    moves = set()
    while board[pos] == opponent:
        moves.add(pos)
        pos += delta
        if bad_move(pos, delta):
            return None
    if board[pos] == player:
        return moves
    return None

#### FIND VALID MOVES ####
## return a list of the spaces the player can play

## check if move out of bound
def bad_move(pos, delta):
    if pos < 0 or pos > 63:     ## top or bottom
        return True
    if pos % 8 == 0 and (delta == -7 or delta == 9 or delta == 1):        ## left
        return True
    if pos % 8 == 7 and (delta == 7 or delta == -9 or delta == -1):        ## right
        return True
    return False

# NOT DEPRECATED
def return_legal_moves(board, player, opponent):
    moves = set()
    
    for y in range(8):
        ir = 8 * y
        ic = y
        lastr = ir
        lastc = ic
        for x in range(1, 8):
            ir += 1
            if ir > lastr + 1:
                if board[lastr] == player and board[ir] == '.':
                    moves.add(ir)
                if board[ir] == player and board[lastr] == '.':
                    moves.add(lastr)
            if board[ir] != opponent:#r
                lastr = ir

            ic += 8
            if ic > lastc + 8:
                if board[lastc] == player and board[ic] == '.':
                    moves.add(ic)
                if board[ic] == player and board[lastc] == '.':
                    moves.add(lastc)
            if board[ic] != opponent:#c
                lastc = ic
                
##    ranges_dr = [(40, 2), (32, 3), (24, 4), (16, 5), (8, 6), (0, 7),
##                 (1, 6), (2, 5), (3, 4), (4, 3), (5, 2)]
##    ranges_dl = [(2, 2), (3, 3), (4, 4), (5, 5), (6, 6), (7, 7),
##                 (15, 6), (23, 5), (31, 4), (39, 3), (47, 2)]
    starts_dr = [40, 32, 24, 16, 8, 0, 1, 2, 3, 4, 5]
    starts_dl = [2, 3, 4, 5, 6, 7, 15, 23, 31, 39, 47]
    lens = [2, 3, 4, 5, 6, 7, 6, 5, 4, 3, 2]


    for x in range(11):
        ir = starts_dr[x]
        il = starts_dl[x]
        lastr = ir
        lastl = il
        for a in range(lens[x]):

            ir += 9
            if ir > lastr + 9:
                if board[lastr] == player and board[ir] == '.':
                    moves.add(ir)
                if board[ir] == player and board[lastr] == '.':
                    moves.add(lastr)
            if board[ir] != opponent:#dr
                lastr = ir

            il += 7
            if il > lastl + 7:
                if board[lastl] == player and board[il] == '.':
                    moves.add(il)
                if board[il] == player and board[lastl] == '.':
                    moves.add(lastl)
            if board[il] != opponent:#dl
                lastl = il

            
    return moves


#DEPRECATED
def check_moves(board, player, opponent):
    p = board.count(player)
    e = board.count('.')
    if abs(p - e) < 30:
        return return_legal_moves(board, player, opponent)
    if p > e:
        return move_search(board, '.', opponent, player)
    else:
        return move_search(board, player, opponent, '.')
#DEPRECATED
def move_search(board, start, middle, end):
    deltas = [-9, -8, -7, -1, 1, 7, 8, 9]   ## indexes for 8 surrounding spaces
    playable_spaces = set()
    for x in range(0o100):          ## 64, but with improvements by Dylan.  Probably shouldn't let him touch my computer
        if board[x] != start:
            continue
        for d in deltas:            ## check all 8 surrounding pieces
            pos = x + d
            if bad_move(pos, d):    ## kill it if it is out of bounds
                continue
            if board[pos] == middle:
                index = deep_move_check(board, end, middle, pos, d)    ## check along the line
                if index is not None:
                    playable_spaces.add(index)
    return playable_spaces
#DEPRECATED
##  Iterate along a path to check if the other end can be completed to flank the path
def deep_move_check(board, end, middle, pos, delta):
    while board[pos] == middle:
        pos += delta
        if bad_move(pos, delta):
            return None
    if board[pos] == end:
        return pos
    return None



##def ab_init(board, player, opponent, deepness):
##    moves = return_legal_moves(board, player, opponent)
##    best = (-500, -5000)
##    for mov in moves:
##        thisBoard = exec_move(board[:], mov, player, opponent)
##        v = alphabeta(thisBoard, deepness, -1 * 10 ** 999, 10 ** 999, False, player, opponent)
##        if v > best[1]:
##            best = (mov, v)
##    return best[0]
##
##def alphabeta(board, depth, low, high, isMax, player, opponent):
##    global potato
##    if isMax:
##        moves = return_legal_moves(board, player, opponent)
##    else:
##        moves = return_legal_moves(board, opponent, player)
##    if depth == 0 or len(moves) == 0:
##        potato += 1
##        return heuristic(board, player)
##
##    if isMax:
##        v = -1 * (100 ** 1000)
##        for mov in moves:
##            thisBoard = exec_move(board[:], mov, player, opponent)
##            v = max(v, alphabeta(thisBoard, depth - 1, low, high, False, player, opponent))
##            low = max(low, v)
##            if high <= low:
##                break
##        return v
##    
##    else:
##        v = (100 ** 1000)
##        for mov in moves:
##            thisBoard = exec_move(board[:], mov, opponent, player)
##            v = min(v, alphabeta(thisBoard, depth - 1, low, high, True, player, opponent))
##            high = min(high, v)
##            if high <= low:
##                break
##        return v


##def uncaptureHeuristic(board, player):
##    start = '@o'.replace(player, '')
##    end = '.'
##    middle = player
##    deltas = [-9, -8, -7, -1, 1, 7, 8, 9]   ## indexes for 8 surrounding spaces
##    playable_spaces = set()
##    for x in range(0o100):          ## 64, but with improvements by Dylan.  Probably shouldn't let him touch my computer
##        if board[x] != start:
##            continue
##        for d in deltas:            ## check all 8 surrounding pieces
##            pos = x + d
##            if bad_move(pos, d):    ## kill it if it is out of bounds
##                continue
##            if board[pos] == middle:
##                index = deep_heuristic_check(board, end, middle, pos, d)    ## check along the line
##                if index is not None:
##                    playable_spaces.union(index)
##    return board.count(player) - len(playable_spaces)
##
####  Iterate along a path to check if the other end can be completed to flank the path
##def deep_heuristic_check(board, end, middle, pos, delta):
##    capt = set()
##    while board[pos] == middle:
##        capt.add(pos)
##        pos += delta
##        if bad_move(pos, delta):
##            return None
##    if board[pos] == end:
##        return capt
##    return None
