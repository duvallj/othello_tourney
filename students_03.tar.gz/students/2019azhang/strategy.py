import Othello_Core as core
import random
import math
import copy


class Strategy(core.OthelloCore):

    UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
    UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
    DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)

    def best_strategy(self, board, player, best_move, still_running):
       for x in range(1,30):
           best_move.value = self.alphabetahelper(player, board, x, )

    # def best_strategy(self, board, player):
    #     for x in range(1,30):
    #          print(self.alphabetahelper(player, board, x, ))


    def alphabetahelper(self, player, board, depth):
        alpha = -10000000000
        beta = 10000000000
        whichmove = {}
        debuglist = self.convertfinalback(self.positioncheck( self.convertfinal(board, player)))
        for x in self.convertfinalback(self.positioncheck( self.convertfinal(board, player))):
            whichmove[self.alphabeta( player, self.opponent(player), self.makemovehelper(board, x, player), alpha, beta, depth, self.movesleft(board))]=x
        v=-10000000000000000
        for y in whichmove.keys():
            v=max(v, y)
        return whichmove[v]

    def alphabeta(self, player, playing, board, alpha, beta, depth, movesleft):
        if depth == 0 or movesleft==0:
            return self.evaluate(player, board, movesleft)
        if playing == player:
            v=-100000000000
            for x in self.convertfinalback(self.positioncheck(self.convertfinal(board, playing))):
                v=max(v,self.alphabeta( player, self.opponent(playing), self.makemovehelper(board, x, playing), alpha, beta, depth-1, movesleft-1))
                alpha = max(alpha, v)
                if beta <= alpha:
                    break
            return v
        if not playing == player:
            v=100000000000
            for x in self.convertfinalback(self.positioncheck(self.convertfinal(board, playing))):
                v=min(v,self.alphabeta( player, self.opponent(playing), self.makemovehelper(board, x, playing), alpha, beta, depth-1, movesleft-1))
                alpha = min(alpha, v)
                if beta <= alpha:
                    break
            return v

    def makemovehelper(self, board, num, player):
        UP, DOWN, LEFT, RIGHT = -10, 10, -1, 1
        UP_RIGHT, DOWN_RIGHT, DOWN_LEFT, UP_LEFT = -9, 11, 9, -11
        DIRECTIONS = (UP, UP_RIGHT, RIGHT, DOWN_RIGHT, DOWN, DOWN_LEFT, LEFT, UP_LEFT)
        totalflip = []
        tempboard = copy.deepcopy(board)

        for x in DIRECTIONS:
            list1 = self.makemove(board, num+x, x, player)
            if not -1 in list1:
                totalflip.extend(list1)
        for y in totalflip:
            tempboard[y]=player
        tempboard[num]=player
        return tempboard


    def makemove(self, board, num, direction, player):
        totalturned = []
        totalturned.append(num)
        if board[num] == ".":
            totalturned.append(-1)
            return totalturned
        if board[num] == "?":
            totalturned.append(-1)
            return totalturned
        if board[num] == player:
            return totalturned
        if board[num] == self.opponent(player):
            totalturned.extend(self.makemove(board, num + direction, direction, player))
            return totalturned


    def movesleft(self, board):
        totalmovesleft = 0
        for x in range(0,100):
            if board[x]==".":
                totalmovesleft+=1
        return totalmovesleft

    def evaluate(self, player, board, movesleft):
        opponent = self.opponent(player)
        total = 0
        # if(40 <movesleft <25 ):
        for sq in range(0,100):
            if board[sq] == player:
                total += self.SQUARE_WEIGHTS[sq]
            elif board[sq] == opponent:
                total -= self.SQUARE_WEIGHTS[sq]

        for sq in range(1,100):
            if board[sq] == player:
                total += 1*(64/movesleft/3)
            elif board[sq] == opponent:
                total -= 1*(64/movesleft/3)
        # else:
        #     for sq in range(0,100):
        #         if board[sq] == player:
        #             total += self.SQUARE_WEIGHTS2[sq]
        #         elif board[sq] == opponent:
        #             total -= self.SQUARE_WEIGHTS2[sq]
        return total

    def opponent(self, player):
        if player == "o":
            return "@"
        if player == "@":
            return "o"

    SQUARE_WEIGHTS = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 280, -100, 20, 5, 5, 20, -100, 280, 0,
        0, -100, -140, -5, -5, -5, -5, -140, -100, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -100, -140, -5, -5, -5, -5, -140, -100, 0,
        0, 280, -100, 20, 5, 5, 20, -100, 280, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    SQUARE_WEIGHTS1 = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 280, -100, 20, 5, 5, 20, -100, 280, 0,
        0, -100, -140, -5, -5, -5, -5, -140, -100, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 35, 35, 3, -5, 5, 0,
        0, 5, -5, 3, 35, 35, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -100, -140, -5, -5, -5, -5, -140, -100, 0,
        0, 280, -100, 20, 5, 5, 20, -100, 280, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    SQUARE_WEIGHTS2 = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 200, -20, 20, 5, 5, 20, -20, 200, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 100, 100, 3, -5, 5, 0,
        0, 5, -5, 3, 100, 100, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -20, -40, -5, -5, -5, -5, -40, -20, 0,
        0, 200, -20, 20, 5, 5, 20, -20, 200, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    SQUARE_WEIGHTS3 = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 200, -400, 80, 5, 5, 20, -100, 120, 0,
        0, -400, -80, -5, -5, -5, -5, -140, -100, 0,
        0, 80, -5, 15, 3, 3, 15, -5, 20, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 5, -5, 3, 3, 3, 3, -5, 5, 0,
        0, 20, -5, 15, 3, 3, 15, -5, 20, 0,
        0, -100, -140, -5, -5, -5, -5, -140, -100, 0,
        0, 120, -100, 20, 5, 5, 20, -100, 120, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]

    def random(self, board, player):
        return self.convertfinalback(self.positioncheck( self.convertfinal(board, player)))[0]


    def convertfinal(self, boardlist, player):
        stringrep = ""
        for x in range(1,9):
            for y in range(1,9):
                stringrep= stringrep + boardlist[x*10+y]
        stringrep = stringrep + " " + player
        return stringrep


    def convertfinalback(self, list):
        finallist = []
        for x in list:
            finallist.append(int((int(x/8) + 1)*10 + x%8 +1))
        return finallist

    def convert(self, stringrep):
        a = [[0] * 8 for i in range(8)]
        for x in range(0, 64):
            a[int(x / 8)][int(x % 8)] = str(stringrep[x])
        return a

    # a = convert('.ooooooo..oxxxxx.ooxxoxooooxoxoooxxoxooooxxxox.oo.oooooo..ooxxxo x')
    # print(a)

    def convertback(self, blockrep, turn):
        string = ''
        for x in range(0, 8):
            for y in range(0, 8):
                string += str(blockrep[x][y])
        if (turn):
            string += ' @'
        else:
            string += ' o'
        return string

    # b = convertback(a, True)
    # print(b)

    def checkturn(self, currentboard):
        if '@' == currentboard[65]:
            return True
        else:
            return False

    # print(checkturn(b))

    def findallpiece(self, stringrep, color):
        positions = []
        if color:
            for x in range(0, 64):
                if str(stringrep[x]) == '@':
                    positions.append(x)
        else:
            for x in range(0, 64):
                if str(stringrep[x]) == 'o':
                    positions.append(x)
        return positions

    def findsurroundings(self, place):  # could possibly fix where it checks if the thing is inside the box or not.
        positions = []
        row = int(place / 8)
        col = int(place % 8)
        if (row + 1 < 8):
            positions.append((row + 1) * 8 + col)
            if (col + 1 < 8):
                positions.append((row + 1) * 8 + col + 1)
            if (col - 1 >= 0):
                positions.append((row + 1) * 8 + col - 1)
        if (row - 1 >= 0):
            positions.append((row - 1) * 8 + col)
            if (col + 1 < 8):
                positions.append((row - 1) * 8 + col + 1)
            if (col - 1 >= 0):
                positions.append((row - 1) * 8 + col - 1)
        if (col + 1 < 8):
            positions.append((row) * 8 + col + 1)
        if (col - 1 >= 0):
            positions.append((row) * 8 + col - 1)
        return positions

    def checksurroundings(self, stringrep, places, player):
        rightonce = []
        if player:
            for x in range(0, len(places)):
                if stringrep[places[x]] == 'o':
                    rightonce.append(places[x])
        else:
            for x in range(0, len(places)):
                if stringrep[places[x]] == '@':
                    rightonce.append(places[x])
        return rightonce

    def movedirection(self, origin, place):
        return place - origin

    def pathcheck(self, origin1, rowchange, colchange, player, currentboard):
        row = int(origin1 / 8) + rowchange
        col = origin1 % 8 + colchange

        if (0 <= row < 8) and (0 <= col < 8):
            if player:

                if currentboard[row][col] == ".":
                    return (row * 8 + col)
                if currentboard[row][col] == "@":
                    return -1
                if currentboard[row][col] == "o":
                    return self.pathcheck(row * 8 + col, rowchange, colchange, player, currentboard)
            if not player:
                if currentboard[row][col] == ".":
                    return (row * 8 + col)
                if currentboard[row][col] == "@":
                    return self.pathcheck(row * 8 + col, rowchange, colchange, player, currentboard)
                if currentboard[row][col] == "o":
                    return -1
        else:
            return -1

    def positioncheck(self, board):
        # print(board)
        allmoves = []
        rowmovement = {-9: -1, -8: -1, -7: -1, -1: 0, 1: 0, 7: 1, 8: 1, 9: 1}
        colmovement = {-9: -1, -8: 0, -7: 1, -1: -1, 1: 1, 7: -1, 8: 0, 9: 1}
        b = board
        player = self.checkturn(board)
        a = self.convert(b)
        allpiece = self.findallpiece(b, player)
        for p1 in allpiece:
            p2 = self.findsurroundings(p1)
            p3 = self.checksurroundings(b, p2, player)
            for p4 in p3:
                ind = self.movedirection(p1, p4)
                ##            if pathcheck(p4, rowmovement[ind], colmovement[ind], player, a) == -1:
                ##                return
                ##           else:
                allmoves.append(self.pathcheck(p4, rowmovement[ind], colmovement[ind], player, a))
        temp = set(allmoves)
        allmoves = list(temp)
        if -1 in allmoves:
            allmoves.remove(-1)
        # if len(allmoves) == 0:
        #     print("no moves for this player")
        #     print("----------------------------------------------------------")
        #     print()
        # else:
        #     print(allmoves)
        #     print("----------------------------------------------------------")
        #     print()
        return allmoves




# EMPTY, BLACK, WHITE, OUTER = '.', '@', 'o', '?'
# PIECES = (EMPTY, BLACK, WHITE, OUTER)
# PLAYERS = {BLACK: 'Black', WHITE: 'White'}
# squares = []
# for i in range(1,9):
#     for z in range(1,9):
#         squares.append(z*10+i)
#
#
# board = [OUTER] * 100
# for i in squares:
#     board[i] = EMPTY
# # The middle four squares should hold the initial piece positions.
# board[44], board[45] = WHITE, BLACK
# board[54], board[55] = BLACK, WHITE
#
# #
# la = Strategy()
# la.best_strategy(board,'@')
#
# # la = Strategy()
# # la.makemovehelper(board, 34, BLACK)